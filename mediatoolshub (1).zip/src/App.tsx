import { AdminDashboard } from './components/AdminDashboard.tsx';
import { BlogDetailPage, BlogIndexPage } from './components/BlogPages.tsx';
import { HomePage } from './components/HomePage.tsx';
import {
  AccountPage,
  ApiDocsPage,
  ContactPage,
  DmcaReportPage,
  PricingPage,
  StaticLegalPage,
  ToolDirectoryPage,
} from './components/InfoAndLegalPages.tsx';
import { Layout } from './components/Layout.tsx';
import { ToolPage } from './components/ToolPage.tsx';
import { YouTubeManagementWorkspace } from './components/ytm/YouTubeManagementWorkspace.tsx';
import { AppProvider, useApp } from './context/AppContext.tsx';

function RouteView() {
  const { currentPath, tools, navigate } = useApp();
  const clean = currentPath.split('?')[0].replace(/\/+$/, '') || '/';

  if (clean === '/') return <HomePage />;
  if (clean === '/youtube-management' || clean.startsWith('/youtube-management/')) {
    return <YouTubeManagementWorkspace />;
  }
  if (clean === '/tools') return <ToolDirectoryPage />;
  if (clean === '/blog') return <BlogIndexPage />;
  if (clean.startsWith('/blog/')) {
    return <BlogDetailPage slug={clean.slice('/blog/'.length)} />;
  }
  if (clean === '/contact') return <ContactPage />;
  if (clean === '/dmca') return <DmcaReportPage />;
  if (clean === '/pricing') return <PricingPage />;
  if (clean === '/api-docs') return <ApiDocsPage />;
  if (clean === '/account') return <AccountPage />;
  if (clean === '/admin') return <AdminDashboard />;

  if (
    [
      '/about',
      '/privacy-policy',
      '/terms-of-service',
      '/disclaimer',
      '/copyright-policy',
      '/cookie-policy',
      '/sitemap',
    ].includes(clean)
  ) {
    return <StaticLegalPage page={clean.slice(1)} />;
  }

  const matchedTool = tools.find((t) => t.routePath === clean);
  if (matchedTool) {
    return <ToolPage tool={matchedTool} />;
  }

  return (
    <div className="max-w-xl mx-auto px-4 py-20 text-center space-y-4">
      <h1 className="font-display text-3xl font-bold text-slate-950 dark:text-white">
        Page Not Found
      </h1>
      <p className="text-sm text-slate-600 dark:text-slate-400">
        The requested route <span className="font-mono">{clean}</span> does not match an active MediaToolsHub page.
      </p>
      <div className="flex justify-center gap-3">
        <button
          type="button"
          onClick={() => navigate('/')}
          className="px-5 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold"
        >
          Return Home
        </button>
        <button
          type="button"
          onClick={() => navigate('/tools')}
          className="px-5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold"
        >
          Browse Tools
        </button>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Layout>
        <RouteView />
      </Layout>
    </AppProvider>
  );
}
