import { useApp } from '../context/AppContext.tsx';

export function AdSlot({
  placementKey,
  className = '',
}: {
  placementKey:
    | 'header_banner'
    | 'hero_lower'
    | 'category_between'
    | 'desktop_sidebar'
    | 'below_results'
    | 'content_between'
    | 'blog_article'
    | 'footer_banner';
  className?: string;
}) {
  const { adPlacements, adsensePublisherId, integrations } = useApp();
  const slot = adPlacements.find((p) => p.placementKey === placementKey);

  if (!slot || !slot.isEnabled || !slot.adUnitId.trim()) {
    return null;
  }

  if (slot.provider === 'google_adsense' && (!integrations.adsenseEnabled || !adsensePublisherId)) {
    return null;
  }

  const responsiveVisibility =
    slot.desktopEnabled && slot.mobileEnabled
      ? 'block'
      : slot.desktopEnabled
        ? 'hidden md:block'
        : slot.mobileEnabled
          ? 'block md:hidden'
          : 'hidden';

  return (
    <aside
      aria-label="Advertisement"
      className={`${responsiveVisibility} my-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/60 px-4 py-3 text-center ${className}`}
    >
      <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-1.5">
        <span>Advertisement</span>
        <span>{slot.provider.replace('_', ' ')}</span>
      </div>
      <div className="py-3 text-xs text-slate-500 dark:text-slate-400 font-mono">
        {slot.label} · Unit {slot.adUnitId}
        {adsensePublisherId ? ` · ${adsensePublisherId}` : ''}
      </div>
    </aside>
  );
}
