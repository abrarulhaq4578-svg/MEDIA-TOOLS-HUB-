import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ChevronDown,
  KeyRound,
  LogIn,
  LogOut,
  Menu,
  Moon,
  Search,
  Shield,
  Sun,
  X,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { AdSlot } from './AdSlot.tsx';
import { PlatformIcon } from './PlatformIcon.tsx';

export function Layout({ children }: { children: React.ReactNode }) {
  const {
    theme,
    toggleTheme,
    currentPath,
    navigate,
    tools,
    firebaseUser,
    dbUser,
    signInWithGoogle,
    signOutUser,
  } = useApp();

  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [accountOpen, setAccountOpen] = useState(false);
  const navRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onDocClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) {
        setOpenMenu(null);
        setAccountOpen(false);
      }
    };
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setSearchOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        setSearchOpen(false);
        setOpenMenu(null);
        setAccountOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDocClick);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  const enabledTools = useMemo(
    () => tools.filter((t) => t.isEnabled !== false),
    [tools]
  );

  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return enabledTools.slice(0, 8);
    return enabledTools
      .filter(
        (t) =>
          t.name.toLowerCase().includes(q) ||
          t.shortDescription.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q) ||
          t.platformSlug.toLowerCase().includes(q)
      )
      .slice(0, 10);
  }, [enabledTools, searchQuery]);

  const youtubeTools = useMemo(
    () => enabledTools.filter((t) => t.platformSlug === 'youtube'),
    [enabledTools]
  );
  const instagramTools = useMemo(
    () => enabledTools.filter((t) => t.platformSlug === 'instagram'),
    [enabledTools]
  );
  const pinterestTools = useMemo(
    () => enabledTools.filter((t) => t.platformSlug === 'pinterest'),
    [enabledTools]
  );
  const otherTools = useMemo(
    () =>
      enabledTools.filter(
        (t) =>
          t.platformSlug !== 'youtube' &&
          t.platformSlug !== 'instagram' &&
          t.platformSlug !== 'pinterest'
      ),
    [enabledTools]
  );

  const handleNav = (path: string) => {
    setOpenMenu(null);
    setMobileOpen(false);
    setSearchOpen(false);
    setAccountOpen(false);
    navigate(path);
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-[#090D16] dark:text-slate-100">
      {/* Top Navigation */}
      <header
        ref={navRef}
        className="sticky top-0 z-40 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-[#090D16]/95 backdrop-blur-md"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-6">
          {/* Zone 1: Clean single-line wordmark */}
          <button
            type="button"
            onClick={() => handleNav('/')}
            className="flex items-center gap-2.5 text-lg font-bold tracking-tight text-slate-950 dark:text-white whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded-md px-1"
          >
            <span className="w-7 h-7 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white flex items-center justify-center">
              <svg viewBox="0 0 24 24" fill="none" className="w-4 h-4" aria-hidden="true">
                <path
                  d="M5 7h14M5 12h9M5 17h14"
                  stroke="currentColor"
                  strokeWidth="2.2"
                  strokeLinecap="round"
                />
              </svg>
            </span>
            <span className="font-display">MediaToolsHub</span>
          </button>

          {/* Zone 2: Single-line navigation links + category dropdowns */}
          <nav className="hidden lg:flex items-center gap-5 text-sm font-medium text-slate-600 dark:text-slate-300">
            <button
              type="button"
              onClick={() => handleNav('/')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-950 dark:hover:text-white ${
                currentPath === '/' ? 'text-blue-600 dark:text-blue-400 font-semibold' : ''
              }`}
            >
              Home
            </button>

            <button
              type="button"
              onClick={() => handleNav('/youtube-management')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-950 dark:hover:text-white ${
                currentPath.startsWith('/youtube-management')
                  ? 'text-[#FF0000] dark:text-rose-400 font-semibold'
                  : ''
              }`}
            >
              YouTube OS
            </button>

            {/* YouTube Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setOpenMenu(openMenu === 'youtube' ? null : 'youtube')}
                className="flex items-center gap-1 whitespace-nowrap shrink-0 py-1 hover:text-slate-950 dark:hover:text-white transition-colors"
              >
                <span>YouTube Tools</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {openMenu === 'youtube' && (
                <div className="absolute left-0 top-full mt-2 w-72 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg p-2 z-50">
                  {youtubeTools.map((tool) => (
                    <button
                      key={tool.slug}
                      type="button"
                      onClick={() => handleNav(tool.routePath)}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {tool.name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                        {tool.shortDescription}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Instagram Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setOpenMenu(openMenu === 'instagram' ? null : 'instagram')}
                className="flex items-center gap-1 whitespace-nowrap shrink-0 py-1 hover:text-slate-950 dark:hover:text-white transition-colors"
              >
                <span>Instagram Tools</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {openMenu === 'instagram' && (
                <div className="absolute left-0 top-full mt-2 w-72 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg p-2 z-50">
                  {instagramTools.map((tool) => (
                    <button
                      key={tool.slug}
                      type="button"
                      onClick={() => handleNav(tool.routePath)}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {tool.name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                        {tool.shortDescription}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Pinterest Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setOpenMenu(openMenu === 'pinterest' ? null : 'pinterest')}
                className="flex items-center gap-1 whitespace-nowrap shrink-0 py-1 hover:text-slate-950 dark:hover:text-white transition-colors"
              >
                <span>Pinterest Tools</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {openMenu === 'pinterest' && (
                <div className="absolute left-0 top-full mt-2 w-72 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg p-2 z-50">
                  {pinterestTools.map((tool) => (
                    <button
                      key={tool.slug}
                      type="button"
                      onClick={() => handleNav(tool.routePath)}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                    >
                      <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
                        {tool.name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">
                        {tool.shortDescription}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Other Tools Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => setOpenMenu(openMenu === 'other' ? null : 'other')}
                className="flex items-center gap-1 whitespace-nowrap shrink-0 py-1 hover:text-slate-950 dark:hover:text-white transition-colors"
              >
                <span>Other Tools</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
              {openMenu === 'other' && (
                <div className="absolute right-0 top-full mt-2 w-[540px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg p-3 z-50">
                  <div className="grid grid-cols-2 gap-1 max-h-96 overflow-y-auto">
                    {otherTools.map((tool) => (
                      <button
                        key={tool.slug}
                        type="button"
                        onClick={() => handleNav(tool.routePath)}
                        className="text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      >
                        <div className="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
                          {tool.name}
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400">
                          {tool.category}
                        </div>
                      </button>
                    ))}
                  </div>
                  <div className="mt-2 pt-2 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center px-2">
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {enabledTools.length} utilities available
                    </span>
                    <button
                      type="button"
                      onClick={() => handleNav('/tools')}
                      className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      View Full Directory
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => handleNav('/blog')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-950 dark:hover:text-white ${
                currentPath.startsWith('/blog') ? 'text-blue-600 dark:text-blue-400 font-semibold' : ''
              }`}
            >
              Blog
            </button>
            <button
              type="button"
              onClick={() => handleNav('/about')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-950 dark:hover:text-white ${
                currentPath === '/about' ? 'text-blue-600 dark:text-blue-400 font-semibold' : ''
              }`}
            >
              About
            </button>
            <button
              type="button"
              onClick={() => handleNav('/contact')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-950 dark:hover:text-white ${
                currentPath === '/contact' ? 'text-blue-600 dark:text-blue-400 font-semibold' : ''
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Zone 3: Search, Theme Toggle, Account / Primary Action */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              aria-label="Search tools"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0"
            >
              <Search className="w-4 h-4" />
              <span className="hidden sm:inline">Search</span>
            </button>

            <button
              type="button"
              onClick={toggleTheme}
              aria-label={theme === 'dark' ? 'Switch to light theme' : 'Switch to dark theme'}
              className="h-10 w-10 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-center transition-colors shrink-0"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            {firebaseUser ? (
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setAccountOpen(!accountOpen)}
                  className="h-10 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold flex items-center gap-2 hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
                >
                  <span className="max-w-[100px] truncate">
                    {dbUser?.displayName || firebaseUser.email?.split('@')[0] || 'Account'}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>
                {accountOpen && (
                  <div className="absolute right-0 top-full mt-2 w-56 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-lg p-1.5 z-50">
                    <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                      <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                        {firebaseUser.email}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        {dbUser?.role === 'admin' ? 'Administrator' : 'Member'} · {dbUser?.plan || 'free'} plan
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleNav('/account')}
                      className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-slate-700 dark:text-slate-200"
                    >
                      <KeyRound className="w-4 h-4" />
                      <span>Account & API Keys</span>
                    </button>
                    {dbUser?.role === 'admin' && (
                      <button
                        type="button"
                        onClick={() => handleNav('/admin')}
                        className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-blue-600 dark:text-blue-400 font-medium"
                      >
                        <Shield className="w-4 h-4" />
                        <span>Admin Dashboard</span>
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setAccountOpen(false);
                        void signOutUser();
                      }}
                      className="w-full text-left px-3 py-2 text-sm rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2 text-rose-600 dark:text-rose-400"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                type="button"
                onClick={() => void signInWithGoogle()}
                className="h-10 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors whitespace-nowrap shrink-0"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setMobileOpen(!mobileOpen)}
              aria-label="Toggle navigation menu"
              className="lg:hidden h-10 w-10 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-700 dark:text-slate-200"
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Drawer */}
        {mobileOpen && (
          <div className="lg:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 py-4 space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleNav('/')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                Home
              </button>
              <button
                type="button"
                onClick={() => handleNav('/youtube-management')}
                className="px-3 py-2.5 text-left text-sm font-semibold rounded-lg bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300"
              >
                YouTube Management
              </button>
              <button
                type="button"
                onClick={() => handleNav('/tools')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                All Tools
              </button>
              <button
                type="button"
                onClick={() => handleNav('/youtube-thumbnail-downloader')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                YouTube Tools
              </button>
              <button
                type="button"
                onClick={() => handleNav('/ai-scriptwriting-studio')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                AI Script Studio
              </button>
              <button
                type="button"
                onClick={() => handleNav('/youtube-competitor-intelligence')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                Competitor Intel
              </button>
              <button
                type="button"
                onClick={() => handleNav('/instagram-reel-tools')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                Instagram Tools
              </button>
              <button
                type="button"
                onClick={() => handleNav('/pinterest-pin-info')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                Pinterest Tools
              </button>
              <button
                type="button"
                onClick={() => handleNav('/blog')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                Blog
              </button>
              <button
                type="button"
                onClick={() => handleNav('/about')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                About
              </button>
              <button
                type="button"
                onClick={() => handleNav('/contact')}
                className="px-3 py-2.5 text-left text-sm font-medium rounded-lg bg-slate-100 dark:bg-slate-900"
              >
                Contact
              </button>
            </div>
          </div>
        )}
      </header>

      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6">
        <AdSlot placementKey="header_banner" />
      </div>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      <div className="max-w-7xl mx-auto w-full px-4 sm:px-6">
        <AdSlot placementKey="footer_banner" />
      </div>

      {/* Search Modal */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-start justify-center pt-20 px-4">
          <div className="w-full max-w-xl rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl overflow-hidden">
            <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-200 dark:border-slate-800">
              <Search className="w-4 h-4 text-slate-400" />
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tools by platform, format, or keyword..."
                className="w-full bg-transparent text-sm text-slate-900 dark:text-slate-100 focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setSearchOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-96 overflow-y-auto p-2 space-y-1">
              {searchResults.length === 0 ? (
                <p className="py-8 text-center text-sm text-slate-500">
                  No matching tools found for "{searchQuery}".
                </p>
              ) : (
                searchResults.map((tool) => (
                  <button
                    key={tool.slug}
                    type="button"
                    onClick={() => handleNav(tool.routePath)}
                    className="w-full text-left px-3 py-2.5 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-3 transition-colors"
                  >
                    <span className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center shrink-0">
                      <PlatformIcon platform={tool.platformSlug} className="w-4 h-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {tool.name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                        {tool.category} · {tool.shortDescription}
                      </div>
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B101B] mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            <div>
              <div className="font-display text-lg font-bold text-slate-950 dark:text-white">
                MediaToolsHub
              </div>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Online social media utilities built for creators, marketers, and researchers. Processes public metadata and local media formats without bypassing platform protections.
              </p>
              <div className="mt-4 flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400">
                <a
                  href="/sitemap.xml"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-blue-600 dark:hover:text-blue-400"
                >
                  XML Sitemap
                </a>
                <a
                  href="/robots.txt"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-blue-600 dark:hover:text-blue-400"
                >
                  Robots.txt
                </a>
              </div>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-950 dark:text-white mb-3">
                Popular Tools
              </h3>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li>
                  <button type="button" onClick={() => handleNav('/youtube-management')} className="hover:text-blue-600 dark:hover:text-blue-400 font-medium">
                    YouTube Management OS
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/youtube-thumbnail-downloader')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    YouTube Thumbnail Extractor
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/youtube-video-details-extractor')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    YouTube Video Details
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/image-converter')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Image Format Converter
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/qr-code-generator')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    QR Code Generator
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/ai-scriptwriting-studio')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    AI Video Scriptwriting Studio
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/youtube-competitor-intelligence')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    YouTube Competitor Intelligence
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/tiktok-video-info')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    TikTok Video Info
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-950 dark:text-white mb-3">
                Platform & Company
              </h3>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li>
                  <button type="button" onClick={() => handleNav('/tools')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Tool Directory
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/blog')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Blog & Guides
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/pricing')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Plans & API Access
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/api-docs')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Developer API Docs
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/about')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    About Us
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/contact')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Contact
                  </button>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-sm font-semibold text-slate-950 dark:text-white mb-3">
                Legal & Compliance
              </h3>
              <ul className="space-y-2 text-sm text-slate-600 dark:text-slate-400">
                <li>
                  <button type="button" onClick={() => handleNav('/privacy-policy')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/terms-of-service')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Terms of Service
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/disclaimer')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Disclaimer
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/copyright-policy')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Copyright Policy
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/dmca')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    DMCA & Takedown
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/cookie-policy')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Cookie Policy
                  </button>
                </li>
                <li>
                  <button type="button" onClick={() => handleNav('/sitemap')} className="hover:text-blue-600 dark:hover:text-blue-400">
                    Sitemap
                  </button>
                </li>
              </ul>
            </div>
          </div>

          <div className="mt-10 pt-6 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
            <p>© {new Date().getFullYear()} MediaToolsHub. Built for authorized media workflows and creator utilities.</p>
            <div className="flex items-center gap-4">
              <button type="button" onClick={() => handleNav('/dmca')} className="hover:text-slate-800 dark:hover:text-slate-200">
                Report Copyright Issue
              </button>
              <button type="button" onClick={() => handleNav('/admin')} className="hover:text-slate-800 dark:hover:text-slate-200">
                Admin Console
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
