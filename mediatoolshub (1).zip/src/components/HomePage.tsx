import React, { useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  ChevronDown,
  FileText,
  Image as ImageIcon,
  Info,
  Lock,
  PenTool,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { parseSafeJsonResponse } from '../lib/apiClient.ts';
import { PLATFORMS_CATALOG } from '../shared/toolsCatalog.ts';
import type { PlatformSlug } from '../shared/types.ts';
import { AdSlot } from './AdSlot.tsx';
import { PlatformIcon } from './PlatformIcon.tsx';

const HOME_FAQS = [
  {
    question: 'Do I need to create an account to use MediaToolsHub?',
    answer:
      'No. All public thumbnail, metadata, image conversion, QR code, and text utilities work immediately without registration. Signing in with Google is optional and only needed for personal API keys, saved history, or admin access.',
  },
  {
    question: 'Why are direct video downloads disabled on certain platforms?',
    answer:
      'MediaToolsHub strictly respects copyright law, DRM protections, and official platform Terms of Service. When a platform restricts third-party video stream downloads, we provide verified metadata, official viewing or Creator Studio links, and compliant embed snippets instead.',
  },
  {
    question: 'Are my uploaded images or videos stored on your servers?',
    answer:
      'No. Image conversion, image/video metadata inspection, QR generation, and text/JSON formatting execute locally in your browser memory without uploading media files.',
  },
  {
    question: 'Why do some YouTube videos lack a 1280x720 MaxRes thumbnail?',
    answer:
      'YouTube only generates maxresdefault.jpg when the source upload or custom cover meets HD dimensions. Our tool probes YouTube image servers in real time and marks only verified available resolutions.',
  },
  {
    question: 'How does MediaToolsHub secure server-side URL lookups?',
    answer:
      'Every URL submitted to our API passes strict protocol checks, hostname allowlisting where applicable, and DNS resolution filtering to block private networks, localhost, and cloud metadata endpoints (SSRF protection).',
  },
];

export function HomePage() {
  const { tools, navigate } = useApp();
  const [heroUrl, setHeroUrl] = useState('');
  const [selectedAction, setSelectedAction] = useState<
    'thumbnail' | 'details' | 'transcript' | 'script'
  >('thumbnail');
  const [selectedPlatform, setSelectedPlatform] = useState<'auto' | PlatformSlug>('auto');
  const [heroError, setHeroError] = useState<string | null>(null);
  const [heroLoading, setHeroLoading] = useState(false);
  const [activeCategory, setActiveCategory] = useState<'all' | PlatformSlug>('all');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const actionMeta = {
    thumbnail: {
      label: 'Thumbnail',
      cta: 'Get Thumbnail',
      route: '/youtube-thumbnail-downloader',
    },
    details: {
      label: 'Details',
      cta: 'Get Details',
      route: '/youtube-video-details-extractor',
    },
    transcript: {
      label: 'Transcript',
      cta: 'Get Transcript',
      route: '/youtube-transcript-extractor',
    },
    script: {
      label: 'Script Studio',
      cta: 'Open Studio',
      route: '/ai-scriptwriting-studio',
    },
  } as const;

  const enabledTools = useMemo(
    () => tools.filter((t) => t.isEnabled !== false),
    [tools]
  );

  const popularTools = useMemo(
    () => enabledTools.filter((t) => t.isPopular),
    [enabledTools]
  );

  const visiblePlatforms = useMemo(() => {
    if (activeCategory === 'all') return PLATFORMS_CATALOG;
    return PLATFORMS_CATALOG.filter((p) => p.slug === activeCategory);
  }, [activeCategory]);

  const handleHeroSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setHeroError(null);

    const trimmed = heroUrl.trim();
    if (selectedAction === 'script') {
      return navigate('/ai-scriptwriting-studio', trimmed || undefined);
    }

    if (!trimmed) {
      if (selectedPlatform === 'auto' || selectedPlatform === 'youtube') {
        return navigate(actionMeta[selectedAction].route);
      }
      if (selectedPlatform === 'instagram') return navigate('/instagram-reel-tools');
      if (selectedPlatform === 'pinterest') return navigate('/pinterest-pin-info');
      if (selectedPlatform === 'tiktok') return navigate('/tiktok-video-info');
      if (selectedPlatform === 'facebook') return navigate('/facebook-video-metadata');
      if (selectedPlatform === 'twitter') return navigate('/twitter-metadata-extractor');
      return navigate('/tools');
    }

    setHeroLoading(true);
    try {
      const res = await fetch('/api/v1/url/validate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed }),
      });
      const data = await parseSafeJsonResponse<{
        valid: boolean;
        platform: PlatformSlug;
        normalizedUrl?: string;
        reason?: string;
      }>(res);

      if (!data.valid) {
        setHeroError(data.reason || 'Please enter a valid public URL starting with https://.');
        setHeroLoading(false);
        return;
      }

      const targetPlatform = selectedPlatform === 'auto' ? data.platform : selectedPlatform;
      if (targetPlatform === 'youtube') {
        navigate(actionMeta[selectedAction].route, data.normalizedUrl || trimmed);
        return;
      }
      const routeMap: Record<PlatformSlug, string> = {
        youtube: actionMeta[selectedAction].route,
        instagram: '/instagram-reel-tools',
        pinterest: '/pinterest-pin-info',
        tiktok: '/tiktok-video-info',
        facebook: '/facebook-video-metadata',
        twitter: '/twitter-metadata-extractor',
        general: '/url-analyzer',
      };
      navigate(routeMap[targetPlatform], data.normalizedUrl || trimmed);
    } catch (err) {
      setHeroError(
        err instanceof Error
          ? err.message
          : 'Unable to validate URL right now. Please try again.'
      );
    } finally {
      setHeroLoading(false);
    }
  };

  return (
    <div>
      {/* Section 1: Hero */}
      <section className="border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B101B]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14 sm:py-20">
          <div className="max-w-3xl mx-auto text-center">
            <h1
              style={{ textWrap: 'balance' }}
              className="font-display font-bold tracking-tight text-slate-950 dark:text-white text-[clamp(2.25rem,4vw,3.5rem)] leading-[1.1]"
            >
              All Your Social Media Tools in One Place
            </h1>
            <p className="mt-4 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl mx-auto">
              Free online tools to extract thumbnails, analyze video details, and manage your social media content.
            </p>
          </div>

          {/* Main URL Launcher */}
          <form
            onSubmit={handleHeroSubmit}
            className="mt-9 max-w-3xl mx-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 p-3 sm:p-4 shadow-sm"
          >
            {/* Quick-Select Options Above Input */}
            <div
              role="group"
              aria-label="Choose extraction mode"
              className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 mb-3 rounded-xl bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
            >
              {(
                [
                  { id: 'thumbnail', label: 'Thumbnail', icon: ImageIcon },
                  { id: 'details', label: 'Details', icon: Info },
                  { id: 'transcript', label: 'Transcript', icon: FileText },
                  { id: 'script', label: 'Script Studio', icon: PenTool },
                ] as const
              ).map((opt) => {
                const Icon = opt.icon;
                const active = selectedAction === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setSelectedAction(opt.id);
                      if (heroError) setHeroError(null);
                    }}
                    aria-pressed={active}
                    className={`h-10 px-3 rounded-lg text-xs sm:text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap ${
                      active
                        ? 'bg-[#0F172A] dark:bg-blue-600 text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 hover:text-slate-950 dark:hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{opt.label}</span>
                  </button>
                );
              })}
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5">
              <div className="sm:w-44 shrink-0">
                <label htmlFor="hero-platform" className="sr-only">
                  Platform selection
                </label>
                <select
                  id="hero-platform"
                  value={selectedPlatform}
                  onChange={(e) => setSelectedPlatform(e.target.value as 'auto' | PlatformSlug)}
                  className="w-full h-12 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm font-medium text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
                >
                  <option value="auto">Auto-detect URL</option>
                  <option value="youtube">YouTube</option>
                  <option value="instagram">Instagram</option>
                  <option value="pinterest">Pinterest</option>
                  <option value="tiktok">TikTok</option>
                  <option value="facebook">Facebook</option>
                  <option value="twitter">Twitter / X</option>
                  <option value="general">Web / OpenGraph</option>
                </select>
              </div>
              <div className="flex-1">
                <label htmlFor="hero-url" className="sr-only">
                  {selectedAction === 'script'
                    ? 'Enter a video topic or leave blank'
                    : 'Paste supported social media URL'}
                </label>
                <input
                  id="hero-url"
                  type={selectedAction === 'script' ? 'text' : 'url'}
                  value={heroUrl}
                  onChange={(e) => {
                    setHeroUrl(e.target.value);
                    if (heroError) setHeroError(null);
                  }}
                  placeholder={
                    selectedAction === 'script'
                      ? 'Enter a video topic idea (or leave blank to brainstorm in Script Studio)...'
                      : 'Paste a YouTube, Instagram, TikTok, Pinterest, Facebook, or X URL...'
                  }
                  className="w-full h-12 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>
              <button
                type="submit"
                disabled={heroLoading}
                className="h-12 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
              >
                <span>{heroLoading ? 'Checking...' : actionMeta[selectedAction].cta}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {heroError && (
              <p role="alert" className="mt-2.5 text-xs font-medium text-rose-600 dark:text-rose-400 px-1">
                {heroError}
              </p>
            )}

            {/* Supported Platforms Row + Short Privacy Notice */}
            <div className="mt-4 pt-3 border-t border-slate-200/80 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
              <div className="flex flex-wrap items-center gap-4">
                {(['youtube', 'instagram', 'pinterest', 'tiktok', 'facebook', 'twitter'] as PlatformSlug[]).map(
                  (slug) => (
                    <button
                      key={slug}
                      type="button"
                      onClick={() => {
                        const target = enabledTools.find((t) => t.platformSlug === slug);
                        if (target) navigate(target.routePath);
                      }}
                      className="flex items-center gap-1.5 hover:text-slate-900 dark:hover:text-slate-200 transition-colors capitalize"
                    >
                      <PlatformIcon platform={slug} className="w-4 h-4" />
                      <span>{slug === 'twitter' ? 'X' : slug}</span>
                    </button>
                  )
                )}
              </div>
              <div className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 shrink-0" />
                <span>Public metadata & authorized assets only · No DRM bypass</span>
              </div>
            </div>
          </form>

          <AdSlot placementKey="hero_lower" className="max-w-4xl mx-auto mt-8" />
        </div>
      </section>

      {/* Flagship Operating System Section: YouTube Management */}
      <section className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#0D1322]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-7 sm:p-10 lg:p-12 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
            <div className="max-w-3xl space-y-4">
              <div className="flex items-center gap-3.5">
                <span
                  aria-hidden="true"
                  className="w-14 h-10 rounded-xl bg-[#FF0000] text-white flex items-center justify-center shrink-0"
                >
                  <svg viewBox="0 0 24 24" className="w-6 h-6 fill-current">
                    <path d="M9.75 15.5V8.5L16 12L9.75 15.5Z" />
                  </svg>
                </span>
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Creator Operating System
                </span>
              </div>

              <h2
                style={{ textWrap: 'balance' }}
                className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white tracking-tight"
              >
                YouTube Management
              </h2>
              <p className="font-display text-lg sm:text-xl font-semibold text-slate-800 dark:text-slate-200">
                Your complete YouTube Creator Operating System.
              </p>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl">
                Plan, create, publish, analyze, and grow your YouTube channel from one workspace.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2 text-xs text-slate-600 dark:text-slate-400">
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">Content Planner</div>
                  <div>Calendar, Board & Deadlines</div>
                </div>
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">6-Stage Workflow</div>
                  <div>Title, Script Studio & SEO</div>
                </div>
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">Channel Analytics</div>
                  <div>Official OAuth Metrics</div>
                </div>
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">Earn & Team</div>
                  <div>Brand CRM & 8 RBAC Roles</div>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-3 shrink-0">
              <button
                type="button"
                onClick={() => navigate('/youtube-management')}
                className="h-12 px-7 rounded-xl bg-[#FF0000] hover:bg-[#DC2626] text-white text-sm font-semibold flex items-center justify-center gap-2.5 transition-colors whitespace-nowrap"
              >
                <span>Open YouTube Management</span>
                <ArrowRight className="w-4 h-4 shrink-0" />
              </button>
              <button
                type="button"
                onClick={() => navigate('/youtube-management/workflow')}
                className="h-10 px-5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold whitespace-nowrap transition-colors"
              >
                Open Production Workflow
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Studio Card: Competitor Intelligence */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pt-12 pb-2">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-3xl">
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Competitor Intelligence · New Studio
            </div>
            <h2 className="font-display text-2xl font-bold text-slate-950 dark:text-white tracking-tight">
              COMPETITOR INTELLIGENCE
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Discover what makes successful YouTube channels work — benchmark 1 to 10 channels using real YouTube Data API metrics, outlier math, reusable title formulas, thumbnail DNA, content gaps, and a 30-day growth plan connected straight to Script Studio.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => navigate('/youtube-competitor-intelligence')}
              className="h-11 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <span>Analyze Competitors</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Section 2: Popular Tools */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white tracking-tight">
              Popular Utilities
            </h2>
            <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-400">
              Frequently used extraction, conversion, and verification tools ready with zero sign-up.
            </p>
          </div>
          <button
            type="button"
            onClick={() => navigate('/tools')}
            className="text-sm font-semibold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 whitespace-nowrap shrink-0"
          >
            <span>Browse all {enabledTools.length} tools</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {popularTools.map((tool) => (
            <article
              key={tool.slug}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between transition-colors hover:border-slate-300 dark:hover:border-slate-700"
            >
              <div>
                <div className="flex items-center justify-between gap-3 mb-3">
                  <span className="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-800 text-[#0F172A] dark:text-blue-400 flex items-center justify-center">
                    <PlatformIcon platform={tool.platformSlug} className="w-4 h-4" />
                  </span>
                  <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {tool.category} · Popular
                  </span>
                </div>
                <h3 className="font-display text-lg font-semibold text-slate-950 dark:text-white">
                  {tool.name}
                </h3>
                <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {tool.shortDescription}
                </p>
              </div>
              <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => navigate(tool.routePath)}
                  className="px-4 py-2 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors whitespace-nowrap"
                >
                  Open Tool
                </button>
                <span className="text-xs font-mono tabular-nums text-slate-400">
                  {tool.routePath}
                </span>
              </div>
            </article>
          ))}
        </div>
      </section>

      {/* Section 3: Platform Categories */}
      <section className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B101B] py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-10">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white tracking-tight">
                Tools by Platform
              </h2>
              <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-400">
                Dedicated SEO tool pages tailored to each social network’s API rules and media formats.
              </p>
            </div>

            {/* Interactive Segmented Filter */}
            <div className="flex flex-wrap items-center gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setActiveCategory('all')}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                  activeCategory === 'all'
                    ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                All Platforms
              </button>
              {PLATFORMS_CATALOG.map((p) => (
                <button
                  key={p.slug}
                  type="button"
                  onClick={() => setActiveCategory(p.slug)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                    activeCategory === p.slug
                      ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {p.slug === 'twitter'
                    ? 'Twitter / X'
                    : p.slug === 'general'
                      ? 'General Media'
                      : p.slug.charAt(0).toUpperCase() + p.slug.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-12">
            {visiblePlatforms.map((platform, idx) => {
              const platformTools = enabledTools.filter(
                (t) => t.platformSlug === platform.slug
              );
              if (platformTools.length === 0) return null;

              return (
                <div key={platform.slug}>
                  {idx === 2 && <AdSlot placementKey="category_between" />}
                  <div className="flex items-start gap-3 mb-5">
                    <span className="w-10 h-10 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-[#0F172A] dark:text-blue-400 flex items-center justify-center shrink-0">
                      <PlatformIcon platform={platform.slug} className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className="font-display text-xl font-bold text-slate-950 dark:text-white">
                        {platform.name}
                      </h3>
                      <p className="text-sm text-slate-600 dark:text-slate-400">
                        {platform.description}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {platformTools.map((tool) => (
                      <button
                        key={tool.slug}
                        type="button"
                        onClick={() => navigate(tool.routePath)}
                        className="text-left rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/60 hover:bg-white dark:hover:bg-slate-900 hover:border-blue-500/40 p-5 transition-colors flex flex-col justify-between group"
                      >
                        <div>
                          <div className="flex items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400 mb-1.5">
                            <span>{tool.category}</span>
                            {(tool.isNew || tool.isPopular) && (
                              <span className="text-blue-600 dark:text-blue-400 font-medium">
                                {tool.isNew ? 'New' : 'Popular'}
                              </span>
                            )}
                          </div>
                          <div className="font-display text-base font-semibold text-slate-950 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                            {tool.name}
                          </div>
                          <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-2">
                            {tool.shortDescription}
                          </p>
                        </div>
                        <div className="mt-4 flex items-center gap-1 text-xs font-semibold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                          <span>Open Tool</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Section 4: How It Works */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
        <div className="max-w-2xl mb-10">
          <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white tracking-tight">
            How MediaToolsHub Works
          </h2>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Designed for predictable, compliant results without bloat or intrusive popups.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6">
            <div className="font-mono text-sm font-semibold text-blue-600 dark:text-blue-400 mb-2">
              01. Paste a supported URL
            </div>
            <h3 className="font-display text-lg font-semibold text-slate-950 dark:text-white">
              Validate & Detect Platform
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Submit a public YouTube, TikTok, Pinterest, Instagram, Facebook, or X link, or select local images and videos directly from your device.
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6">
            <div className="font-mono text-sm font-semibold text-blue-600 dark:text-blue-400 mb-2">
              02. Process the available information
            </div>
            <h3 className="font-display text-lg font-semibold text-slate-950 dark:text-white">
              Official APIs & Local Engines
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Our SSRF-protected backend queries permitted oEmbed and API endpoints, while image conversion and QR tools run instantaneously in browser memory.
            </p>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6">
            <div className="font-mono text-sm font-semibold text-blue-600 dark:text-blue-400 mb-2">
              03. View, copy, or download permitted results
            </div>
            <h3 className="font-display text-lg font-semibold text-slate-950 dark:text-white">
              Export Clean Assets
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
              Inspect verified dimensions, copy embed snippets or clean URLs, or save authorized images and converted files directly.
            </p>
          </div>
        </div>
      </section>

      {/* Section 5: Why Choose Our Platform */}
      <section className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#0B101B] py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            <div className="lg:col-span-5">
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white tracking-tight">
                Why Creators & Teams Choose MediaToolsHub
              </h2>
              <p className="mt-3 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                Every utility reports real server or browser capabilities transparently. We never fake download buttons or fabricate missing analytics.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => navigate('/api-docs')}
                  className="px-4 py-2.5 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors"
                >
                  Explore Developer API
                </button>
                <button
                  type="button"
                  onClick={() => navigate('/pricing')}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  View Plans
                </button>
              </div>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                {
                  icon: CheckCircle2,
                  title: 'Free Core Tools',
                  desc: 'All primary extractors, converters, QR generators, and text utilities are free for everyday workflows.',
                },
                {
                  icon: Zap,
                  title: 'No Unnecessary Registration',
                  desc: 'Run checks immediately without creating an account or verifying an email address.',
                },
                {
                  icon: ShieldCheck,
                  title: 'Privacy-Conscious Processing',
                  desc: 'Client-side tools keep files on your device; server URL lookups enforce strict SSRF and timeout rules.',
                },
                {
                  icon: Lock,
                  title: 'Transparent Limitations',
                  desc: 'Clear notices whenever API keys, creator permissions, or platform DRM restrict direct downloads.',
                },
              ].map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.title}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/70 p-5"
                  >
                    <Icon className="w-5 h-5 text-blue-600 dark:text-blue-400 mb-3" />
                    <h3 className="font-display text-base font-semibold text-slate-950 dark:text-white">
                      {item.title}
                    </h3>
                    <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                      {item.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* Section 6: Frequently Asked Questions */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 py-14">
        <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white tracking-tight text-center mb-8">
          Frequently Asked Questions
        </h2>
        <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl bg-white dark:bg-slate-900 overflow-hidden">
          {HOME_FAQS.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div key={faq.question}>
                <button
                  type="button"
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  aria-expanded={isOpen}
                  className="w-full px-6 py-4 text-left flex items-center justify-between gap-4 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <span className="font-display text-sm sm:text-base font-semibold text-slate-950 dark:text-white">
                    {faq.question}
                  </span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-500 shrink-0 transition-transform ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-6 pb-5 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}
