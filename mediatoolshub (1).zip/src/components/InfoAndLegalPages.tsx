import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Copy,
  KeyRound,
  Plus,
  Search,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { parseSafeJsonResponse } from '../lib/apiClient.ts';
import { PLATFORMS_CATALOG } from '../shared/toolsCatalog.ts';
import { PlatformIcon } from './PlatformIcon.tsx';

export function ToolDirectoryPage() {
  const { tools, navigate } = useApp();
  const [query, setQuery] = useState('');
  const [platformFilter, setPlatformFilter] = useState('all');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return tools.filter((t) => {
      if (t.isEnabled === false) return false;
      if (platformFilter !== 'all' && t.platformSlug !== platformFilter) return false;
      if (!q) return true;
      return (
        t.name.toLowerCase().includes(q) ||
        t.shortDescription.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q)
      );
    });
  }, [tools, query, platformFilter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white tracking-tight">
          Complete Tool Directory
        </h1>
        <p className="mt-2 text-base text-slate-600 dark:text-slate-300">
          Every MediaToolsHub extractor, embed generator, converter, and creator utility in one searchable catalog.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 justify-between">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Filter tools by name or format..."
            className="w-full h-11 pl-10 pr-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-sm"
          />
        </div>

        <div className="flex flex-wrap gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={() => setPlatformFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
              platformFilter === 'all'
                ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            All ({tools.filter((t) => t.isEnabled !== false).length})
          </button>
          {PLATFORMS_CATALOG.map((p) => (
            <button
              key={p.slug}
              type="button"
              onClick={() => setPlatformFilter(p.slug)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${
                platformFilter === p.slug
                  ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {p.slug}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filtered.map((tool) => (
          <button
            key={tool.slug}
            type="button"
            onClick={() => navigate(tool.routePath)}
            className="text-left rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 hover:border-blue-500/40 transition-colors flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-3">
                <span className="inline-flex items-center gap-1.5">
                  <PlatformIcon platform={tool.platformSlug} className="w-4 h-4" />
                  <span>{tool.category}</span>
                </span>
                <span className="font-mono">{tool.routePath}</span>
              </div>
              <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
                {tool.name}
              </h2>
              <p className="mt-1.5 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                {tool.shortDescription}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-blue-600 dark:text-blue-400">
              <span>Open Tool</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

export function ContactPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState<'idle' | 'submitting' | 'sent' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('submitting');
    setErrorMsg('');
    try {
      const res = await fetch('/api/v1/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, subject, message }),
      });
      await parseSafeJsonResponse(res);
      setStatus('sent');
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    } catch (err: unknown) {
      setStatus('error');
      setErrorMsg(err instanceof Error ? err.message : 'Unable to send message.');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-slate-950 dark:text-white">
          Contact MediaToolsHub
        </h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          Questions about developer API access, enterprise partnerships, advertising inquiries, or technical support.
        </p>
      </div>

      {status === 'sent' ? (
        <div className="rounded-2xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 p-6 flex items-start gap-3 text-emerald-900 dark:text-emerald-200">
          <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold">Message Received</div>
            <p className="text-sm mt-1">
              Thank you for contacting MediaToolsHub. Your message has been logged in our support queue.
            </p>
          </div>
        </div>
      ) : (
        <form
          onSubmit={handleSubmit}
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Full Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Email Address
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Subject
            </label>
            <input
              type="text"
              required
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Message
            </label>
            <textarea
              rows={5}
              required
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          {status === 'error' && <p className="text-xs text-rose-600">{errorMsg}</p>}
          <button
            type="submit"
            disabled={status === 'submitting'}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold"
          >
            {status === 'submitting' ? 'Sending...' : 'Send Message'}
          </button>
        </form>
      )}
    </div>
  );
}

export function DmcaReportPage() {
  const [targetUrl, setTargetUrl] = useState('');
  const [reportType, setReportType] = useState<'dmca' | 'abuse' | 'privacy'>('dmca');
  const [reporterEmail, setReporterEmail] = useState('');
  const [details, setDetails] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const submitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/v1/abuse-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ targetUrl, reportType, reporterEmail, details }),
      });
      await parseSafeJsonResponse(res);
      setSubmitted(true);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to submit report.');
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-slate-950 dark:text-white">
          DMCA Notice & Takedown Procedure
        </h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
          MediaToolsHub does not permanently host user media from third-party social networks. If you believe an endpoint, metadata reference, or blog article infringes copyright or privacy rights, submit an official notice below for immediate administrator review.
        </p>
      </div>

      {submitted ? (
        <div className="rounded-2xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 p-6 text-sm text-emerald-900 dark:text-emerald-200">
          Your DMCA/abuse report has been logged with status <strong>open</strong> and routed to the compliance administrator queue.
        </div>
      ) : (
        <form
          onSubmit={submitReport}
          className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4"
        >
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Report Category
            </label>
            <select
              value={reportType}
              onChange={(e) => setReportType(e.target.value as 'dmca' | 'abuse' | 'privacy')}
              className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="dmca">DMCA / Copyright Takedown</option>
              <option value="privacy">Privacy Request</option>
              <option value="abuse">Platform Abuse Report</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Affected URL
            </label>
            <input
              type="url"
              required
              placeholder="https://..."
              value={targetUrl}
              onChange={(e) => setTargetUrl(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Rights Holder Contact Email
            </label>
            <input
              type="email"
              required
              value={reporterEmail}
              onChange={(e) => setReporterEmail(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Ownership Statement & Details
            </label>
            <textarea
              rows={5}
              required
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          {error && <p className="text-xs text-rose-600">{error}</p>}
          <button
            type="submit"
            className="px-6 py-2.5 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-sm font-semibold"
          >
            Submit Compliance Notice
          </button>
        </form>
      )}
    </div>
  );
}

export function PricingPage() {
  const { navigate } = useApp();
  const plans = [
    {
      name: 'Free Utilities',
      audience: 'For creators & everyday users',
      price: '$0',
      cadence: 'forever',
      limits: [
        '60 API / metadata lookups per minute',
        'Unlimited client-side image & QR tools',
        'No account required for core tools',
        'Supported by non-intrusive display ads',
      ],
      cta: 'Use Free Tools',
      action: () => navigate('/tools'),
    },
    {
      name: 'Pro Creator',
      audience: 'For agencies & high-volume researchers',
      price: 'Coming Soon',
      cadence: 'payment gateway pending',
      limits: [
        'Ad-free workspace experience',
        'Saved lookup history & batch URL checks',
        'Priority processing queue',
        'Billing inactive until payment processor is connected',
      ],
      cta: 'Contact for Early Access',
      action: () => navigate('/contact'),
    },
    {
      name: 'Developer API',
      audience: 'For engineering teams & CMS plugins',
      price: 'Key-Based',
      cadence: '300 req / min',
      limits: [
        'Authenticated X-API-Key header access',
        'YouTube thumbnail probing & oEmbed proxy',
        'SSRF-safe URL validation endpoint',
        'Per-key usage telemetry in Account console',
      ],
      cta: 'View API v1 Docs',
      action: () => navigate('/api-docs'),
    },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12 space-y-10">
      <div className="max-w-2xl">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
          Plans & Developer Access
        </h1>
        <p className="mt-2 text-base text-slate-600 dark:text-slate-300">
          Core utilities remain free. Paid billing plans remain inactive until a payment provider is securely configured.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {plans.map((p) => (
          <div
            key={p.name}
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col justify-between"
          >
            <div>
              <div className="text-xs font-medium text-blue-600 dark:text-blue-400">
                {p.audience}
              </div>
              <h2 className="mt-1 font-display text-xl font-bold text-slate-950 dark:text-white">
                {p.name}
              </h2>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="font-display text-3xl font-bold text-slate-950 dark:text-white tabular-nums">
                  {p.price}
                </span>
                <span className="text-xs text-slate-500">{p.cadence}</span>
              </div>
              <ul className="mt-6 space-y-2.5 text-sm text-slate-600 dark:text-slate-300">
                {p.limits.map((l) => (
                  <li key={l} className="flex items-start gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{l}</span>
                  </li>
                ))}
              </ul>
            </div>
            <button
              type="button"
              onClick={p.action}
              className="mt-8 w-full py-2.5 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold"
            >
              {p.cta}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ApiDocsPage() {
  const endpoints = [
    { method: 'GET', path: '/api/v1/health', desc: 'Checks API & Cloud SQL database connectivity.' },
    { method: 'GET', path: '/api/v1/tools', desc: 'Lists all enabled tools, route paths, and categories.' },
    { method: 'POST', path: '/api/v1/url/validate', desc: 'Validates public URL syntax, SSRF safety, and detects social platform.' },
    { method: 'POST', path: '/api/v1/youtube/thumbnail', desc: 'Probes verified YouTube thumbnail resolutions (MaxRes, SD, HQ, MQ, Default).' },
    { method: 'POST', path: '/api/v1/youtube/details', desc: 'Retrieves YouTube Data API v3 or official oEmbed metadata.' },
    { method: 'POST', path: '/api/v1/tiktok/metadata', desc: 'Fetches public TikTok oEmbed details and embed markup.' },
    { method: 'POST', path: '/api/v1/pinterest/metadata', desc: 'Parses Pinterest API v5 or SSRF-safe public pin OpenGraph tags.' },
    { method: 'POST', path: '/api/v1/instagram/metadata', desc: 'Returns Meta Graph oEmbed data (with token) or compliant embed markup.' },
    { method: 'POST', path: '/api/v1/facebook/metadata', desc: 'Returns Meta Graph oEmbed data (with token) or compliant embed markup.' },
    { method: 'POST', path: '/api/v1/media/metadata', desc: 'Unified router detecting platform and returning authorized metadata.' },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-slate-950 dark:text-white">
          MediaToolsHub REST API v1 Documentation
        </h1>
        <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">
          Pass an optional <code className="font-mono px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800">X-API-Key</code> header generated in your Account console for dedicated rate limits and per-key usage tracking.
        </p>
      </div>

      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
        <div className="divide-y divide-slate-200 dark:divide-slate-800">
          {endpoints.map((ep) => (
            <div key={ep.path} className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs font-bold px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400">
                  {ep.method}
                </span>
                <code className="font-mono text-sm text-slate-950 dark:text-white">{ep.path}</code>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">{ep.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 text-slate-100 p-6 space-y-3">
        <div className="text-xs font-semibold text-slate-400">Example Request</div>
        <pre className="text-xs font-mono overflow-x-auto">{`curl -X POST https://your-host/api/v1/youtube/thumbnail \\
  -H "Content-Type: application/json" \\
  -H "X-API-Key: mth_live_your_key" \\
  -d '{"url":"https://www.youtube.com/watch?v=dQw4w9WgXcQ"}'`}</pre>
      </div>
    </div>
  );
}

export function AccountPage() {
  const { firebaseUser, dbUser, signInWithGoogle, authFetch, navigate } = useApp();
  const [keys, setKeys] = useState<
    Array<{
      id: number;
      name: string;
      keyPrefix: string;
      rateLimitPerMin: number;
      isActive: boolean;
      createdAt: string;
    }>
  >([]);
  const [history, setHistory] = useState<
    Array<{ id: number; toolSlug: string; platformSlug: string; status: string; createdAt: string }>
  >([]);
  const [newKeyName, setNewKeyName] = useState('');
  const [revealedKey, setRevealedKey] = useState<string | null>(null);

  const loadAccount = async () => {
    try {
      const res = await authFetch('/api/v1/me');
      const data = await parseSafeJsonResponse<{
        apiKeys?: typeof keys;
        recentHistory?: typeof history;
      }>(res);
      setKeys(data.apiKeys || []);
      setHistory(data.recentHistory || []);
    } catch {
      // Preserve existing state on transient error
    }
  };

  useEffect(() => {
    if (firebaseUser) {
      void loadAccount();
    }
  }, [firebaseUser]);

  if (!firebaseUser) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center space-y-4">
        <KeyRound className="w-10 h-10 text-blue-600 mx-auto" />
        <h1 className="font-display text-2xl font-bold text-slate-950 dark:text-white">
          Sign In to Manage API Keys & History
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Public tools require no registration. Sign in with Google to issue developer API keys or access your account dashboard.
        </p>
        <button
          type="button"
          onClick={() => void signInWithGoogle()}
          className="px-6 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-semibold"
        >
          Sign in with Google
        </button>
      </div>
    );
  }

  const createKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKeyName.trim()) return;
    try {
      const res = await authFetch('/api/v1/me/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newKeyName.trim() }),
      });
      const data = await parseSafeJsonResponse<{ plainTextKey: string }>(res);
      setRevealedKey(data.plainTextKey);
      setNewKeyName('');
      await loadAccount();
    } catch {
      // Handled safely without unhandled JSON parse error
    }
  };

  const revokeKey = async (id: number) => {
    try {
      const res = await authFetch(`/api/v1/me/api-keys/${id}`, { method: 'DELETE' });
      await parseSafeJsonResponse(res);
      await loadAccount();
    } catch {
      // Handled safely
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold text-slate-950 dark:text-white">
            Account & Developer API Keys
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400">
            Signed in as {firebaseUser.email} · {dbUser?.plan || 'free'} plan · Role: {dbUser?.role || 'user'}
          </p>
        </div>
        {dbUser?.role === 'admin' && (
          <button
            type="button"
            onClick={() => navigate('/admin')}
            className="px-4 py-2 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold"
          >
            Open Admin Dashboard
          </button>
        )}
      </div>

      {/* Create API Key */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Developer API Keys
        </h2>
        <form onSubmit={createKey} className="flex gap-3">
          <input
            type="text"
            placeholder="Key label (e.g., Production CMS)"
            value={newKeyName}
            onChange={(e) => setNewKeyName(e.target.value)}
            className="flex-1 h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
          />
          <button
            type="submit"
            className="h-11 px-4 rounded-xl bg-blue-600 text-white text-xs font-semibold flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Create Key</span>
          </button>
        </form>

        {revealedKey && (
          <div className="rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 p-4 text-xs space-y-2">
            <div className="font-semibold text-emerald-900 dark:text-emerald-200">
              Copy this secret key now — it will not be shown again:
            </div>
            <div className="flex items-center justify-between gap-2 bg-white dark:bg-slate-950 px-3 py-2 rounded border border-emerald-200 dark:border-emerald-800 font-mono">
              <span className="truncate">{revealedKey}</span>
              <button
                type="button"
                onClick={() => void navigator.clipboard.writeText(revealedKey)}
                className="text-blue-600 font-semibold flex items-center gap-1 shrink-0"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </button>
            </div>
          </div>
        )}

        <div className="divide-y divide-slate-200 dark:divide-slate-800">
          {keys.map((k) => (
            <div key={k.id} className="py-3 flex items-center justify-between gap-4 text-xs">
              <div>
                <div className="font-semibold text-slate-900 dark:text-white">{k.name}</div>
                <div className="font-mono text-slate-500">
                  {k.keyPrefix}... · {k.rateLimitPerMin} req/min · {k.isActive ? 'Active' : 'Revoked'}
                </div>
              </div>
              {k.isActive && (
                <button
                  type="button"
                  onClick={() => void revokeKey(k.id)}
                  className="text-rose-600 hover:underline flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Revoke</span>
                </button>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-3">
        <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Recent Processing Jobs
        </h2>
        {history.length === 0 ? (
          <p className="text-xs text-slate-500">No tool runs recorded under your account yet.</p>
        ) : (
          <div className="divide-y divide-slate-200 dark:divide-slate-800 text-xs">
            {history.map((h) => (
              <div key={h.id} className="py-2.5 flex items-center justify-between">
                <span className="font-medium text-slate-900 dark:text-white">
                  {h.toolSlug} ({h.platformSlug})
                </span>
                <span className="font-mono text-slate-500">
                  {h.status} · {new Date(h.createdAt).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export function StaticLegalPage({ page }: { page: string }) {
  const { tools, navigate } = useApp();

  if (page === 'sitemap') {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 space-y-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-slate-950 dark:text-white">
            HTML Sitemap
          </h1>
          <p className="mt-2 text-sm text-slate-600 dark:text-slate-400">
            Complete navigation index of MediaToolsHub pages and tools. Search engines can also inspect{' '}
            <a href="/sitemap.xml" className="text-blue-600 hover:underline">
              /sitemap.xml
            </a>
            .
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="font-display text-lg font-bold mb-3">All Utility Pages</h2>
            <ul className="space-y-2 text-sm">
              {tools.map((t) => (
                <li key={t.slug}>
                  <button
                    type="button"
                    onClick={() => navigate(t.routePath)}
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    {t.name} ({t.routePath})
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h2 className="font-display text-lg font-bold mb-3">Company, Docs & Legal</h2>
            <ul className="space-y-2 text-sm">
              {[
                ['/', 'Homepage'],
                ['/tools', 'Tool Directory'],
                ['/blog', 'Blog & Guides'],
                ['/pricing', 'Plans & API Access'],
                ['/api-docs', 'REST API Documentation'],
                ['/about', 'About Us'],
                ['/contact', 'Contact'],
                ['/privacy-policy', 'Privacy Policy'],
                ['/terms-of-service', 'Terms of Service'],
                ['/disclaimer', 'Disclaimer'],
                ['/copyright-policy', 'Copyright Policy'],
                ['/dmca', 'DMCA Takedown Procedure'],
                ['/cookie-policy', 'Cookie Policy'],
              ].map(([path, label]) => (
                <li key={path}>
                  <button
                    type="button"
                    onClick={() => navigate(path)}
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    {label} ({path})
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    );
  }

  const contentMap: Record<string, { title: string; sections: Array<{ h: string; p: string }> }> = {
    about: {
      title: 'About MediaToolsHub',
      sections: [
        {
          h: 'Our Mission',
          p: 'MediaToolsHub consolidates practical social media metadata utilities, thumbnail inspectors, embed generators, and local browser media converters into one clean, fast platform.',
        },
        {
          h: 'Compliance-First Engineering',
          p: 'We strictly honor DRM protections, authentication walls, and platform Terms of Service. Where direct media downloading is restricted, we surface official Creator Studio links, verified embed HTML, and authorized public metadata.',
        },
        {
          h: 'Privacy & Architecture',
          p: 'Built on PostgreSQL, Drizzle ORM, and modern browser APIs so image conversions, QR generation, and text checks stay on your device while backend URL lookups enforce strict SSRF protection.',
        },
      ],
    },
    'privacy-policy': {
      title: 'Privacy Policy',
      sections: [
        {
          h: 'Data Processed Locally',
          p: 'Images, videos, JSON payloads, QR inputs, and text processed by our client-side utilities stay in your browser memory and are never uploaded or stored on MediaToolsHub servers.',
        },
        {
          h: 'Server-Side Metadata Logs',
          p: 'When you submit a public URL to our metadata APIs, we record anonymized processing telemetry (tool slug, platform, status, and duration) for reliability monitoring and rate-limiting.',
        },
        {
          h: 'Account & Contact Information',
          p: 'If you sign in with Google to manage API keys or submit a contact/DMCA form, we store your email, Firebase UID, and submitted message solely to deliver the requested service.',
        },
      ],
    },
    'terms-of-service': {
      title: 'Terms of Service',
      sections: [
        {
          h: 'Permitted Use',
          p: 'You agree to use MediaToolsHub solely for content you own, hold explicit permission to process, or that the originating platform explicitly permits for public metadata inspection.',
        },
        {
          h: 'Prohibited Activity',
          p: 'Automated abuse, circumventing rate limits, attempting SSRF attacks against internal networks, or bypassing DRM and authentication mechanisms is strictly prohibited.',
        },
      ],
    },
    disclaimer: {
      title: 'Platform Disclaimer',
      sections: [
        {
          h: 'No Platform Affiliation',
          p: 'MediaToolsHub is an independent utilities platform and is not affiliated with, endorsed by, or sponsored by YouTube, Google, Meta (Instagram/Facebook), Pinterest, TikTok, or X Corp.',
        },
        {
          h: 'Accuracy of Public Metadata',
          p: 'Extracted metadata reflects what public oEmbed and official platform APIs return at request time. Availability may vary depending on creator privacy settings.',
        },
      ],
    },
    'copyright-policy': {
      title: 'Copyright Policy',
      sections: [
        {
          h: 'Respecting Creator Rights',
          p: 'All thumbnails, video titles, photographs, and embeds remain the intellectual property of their respective creators and rights holders.',
        },
        {
          h: 'Reporting Infringement',
          p: 'Rights holders can file an immediate notice via our DMCA & Takedown procedure page (/dmca).',
        },
      ],
    },
    'cookie-policy': {
      title: 'Cookie Policy',
      sections: [
        {
          h: 'Essential Storage',
          p: 'MediaToolsHub uses local storage solely to remember your Light/Dark theme preference and session storage to prevent duplicate daily visitor counts.',
        },
        {
          h: 'Advertising & Analytics',
          p: 'When advertising networks (such as Google AdSense) or analytics are enabled by the site administrator, appropriate consent notices apply per regional regulations.',
        },
      ],
    },
  };

  const doc = contentMap[page] || contentMap.about;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12 space-y-8">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-slate-950 dark:text-white">
        {doc.title}
      </h1>
      <div className="space-y-6">
        {doc.sections.map((s) => (
          <section
            key={s.h}
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6"
          >
            <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white mb-2">
              {s.h}
            </h2>
            <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed">{s.p}</p>
          </section>
        ))}
      </div>
    </div>
  );
}
