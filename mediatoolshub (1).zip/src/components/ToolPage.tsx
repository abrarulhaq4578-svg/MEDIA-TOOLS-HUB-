import { ArrowRight, ChevronRight, ShieldCheck } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import type { ToolDefinition } from '../shared/types.ts';
import { AdSlot } from './AdSlot.tsx';
import { PlatformIcon } from './PlatformIcon.tsx';
import { MediaClientTools } from './tools/MediaClientTools.tsx';
import { ScriptwritingStudioTool } from './tools/ScriptwritingStudioTool.tsx';
import { CompetitorIntelligenceTool } from './tools/CompetitorIntelligenceTool.tsx';
import { TextAndQrTools } from './tools/TextAndQrTools.tsx';
import { UrlExtractorTools } from './tools/UrlExtractorTools.tsx';

export function ToolPage({ tool }: { tool: ToolDefinition }) {
  const { tools, navigate } = useApp();

  const relatedTools = tool.relatedSlugs
    .map((slug) => tools.find((t) => t.slug === slug))
    .filter((t): t is ToolDefinition => Boolean(t && t.isEnabled !== false));

  const renderWorkspace = () => {
    if (tool.isEnabled === false) {
      return (
        <div className="rounded-2xl border border-amber-200 dark:border-amber-900/50 bg-amber-50 dark:bg-amber-950/20 p-6 text-sm text-amber-900 dark:text-amber-200">
          This utility is temporarily disabled by an administrator for maintenance.
        </div>
      );
    }

    switch (tool.mode) {
      case 'image-converter':
      case 'image-metadata':
      case 'video-metadata':
      case 'video-converter':
      case 'youtube-thumbnail-size':
        return <MediaClientTools tool={tool} />;
      case 'qr-generator':
      case 'url-encoder':
      case 'hashtag-generator':
      case 'text-case':
      case 'word-counter':
      case 'character-counter':
      case 'json-formatter':
        return <TextAndQrTools tool={tool} />;
      case 'scriptwriting-studio':
        return <ScriptwritingStudioTool />;
      case 'competitor-intelligence':
        return <CompetitorIntelligenceTool />;
      default:
        return <UrlExtractorTools tool={tool} />;
    }
  };

  const isStudio = tool.mode === 'scriptwriting-studio' || tool.mode === 'competitor-intelligence';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 mb-6">
        <button type="button" onClick={() => navigate('/')} className="hover:text-slate-900 dark:hover:text-white">
          Home
        </button>
        <ChevronRight className="w-3.5 h-3.5" />
        <button type="button" onClick={() => navigate('/tools')} className="hover:text-slate-900 dark:hover:text-white">
          {tool.category}
        </button>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-slate-900 dark:text-slate-200 font-medium truncate">{tool.name}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Main Column */}
        <div className={`${isStudio ? 'lg:col-span-12' : 'lg:col-span-8'} space-y-8`}>
          <header>
            <div className="flex items-center gap-3 mb-3">
              <span className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 text-[#0F172A] dark:text-blue-400 flex items-center justify-center">
                <PlatformIcon platform={tool.platformSlug} className="w-5 h-5" />
              </span>
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {tool.category} · Free Utility
              </span>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-950 dark:text-white">
              {tool.name}
            </h1>
            <p className="mt-2.5 text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              {tool.shortDescription}
            </p>
          </header>

          {/* Quick Switcher for YouTube Modes */}
          {tool.platformSlug === 'youtube' && (
            <div
              role="navigation"
              aria-label="YouTube tool modes"
              className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 p-1 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800"
            >
              {[
                { path: '/youtube-thumbnail-downloader', label: 'Thumbnail', mode: 'youtube-thumbnail' },
                { path: '/youtube-video-details-extractor', label: 'Details', mode: 'youtube-details' },
                { path: '/youtube-transcript-extractor', label: 'Transcript', mode: 'youtube-transcript' },
                { path: '/ai-scriptwriting-studio', label: 'Script Studio', mode: 'scriptwriting-studio' },
                { path: '/youtube-competitor-intelligence', label: 'Competitor Intel', mode: 'competitor-intelligence' },
              ].map((tab) => {
                const active = tool.mode === tab.mode;
                return (
                  <button
                    key={tab.path}
                    type="button"
                    onClick={() => navigate(tab.path)}
                    className={`h-10 px-3 rounded-lg text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap ${
                      active
                        ? 'bg-[#0F172A] dark:bg-blue-600 text-white'
                        : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {tab.label}
                  </button>
                );
              })}
            </div>
          )}

          {/* Interactive Tool Engine */}
          {renderWorkspace()}

          <AdSlot placementKey="below_results" />

          {/* Instructions & Compliance */}
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
              How to Use {tool.name}
            </h2>
            <ol className="space-y-2.5 text-sm text-slate-600 dark:text-slate-300">
              {tool.instructions.map((step, i) => (
                <li key={step} className="flex items-start gap-3">
                  <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 mt-0.5">
                    0{i + 1}.
                  </span>
                  <span>{step}</span>
                </li>
              ))}
            </ol>
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-start gap-2.5 text-xs text-slate-500 dark:text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <span>{tool.complianceNote}</span>
            </div>
          </section>

          <AdSlot placementKey="content_between" />

          {/* Tool-specific FAQs */}
          <section className="space-y-4">
            <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
              Frequently Asked Questions
            </h2>
            <div className="space-y-3">
              {tool.faqs.map((faq) => (
                <div
                  key={faq.question}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5"
                >
                  <h3 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
                    {faq.question}
                  </h3>
                  <p className="mt-1.5 text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Desktop Sidebar (stacks below on full-width Script Studio) */}
        <aside className={isStudio ? 'lg:col-span-12 grid grid-cols-1 md:grid-cols-2 gap-6 items-start' : 'lg:col-span-4 space-y-6'}>
          {!isStudio && <AdSlot placementKey="desktop_sidebar" />}

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
            <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Related Tools
            </h2>
            <div className="space-y-2.5">
              {relatedTools.map((rel) => (
                <button
                  key={rel.slug}
                  type="button"
                  onClick={() => navigate(rel.routePath)}
                  className="w-full text-left p-3 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-blue-500/40 bg-slate-50/70 dark:bg-slate-950/60 transition-colors flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-slate-950 dark:text-white truncate">
                      {rel.name}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {rel.category}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 shrink-0" />
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
              Automate via REST API
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Integrate URL validation, thumbnail availability checks, and oEmbed metadata endpoints directly into your editorial CMS.
            </p>
            <button
              type="button"
              onClick={() => navigate('/api-docs')}
              className="w-full py-2 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold"
            >
              Read API v1 Docs
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
