import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  Download,
  ExternalLink,
  Loader2,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import { parseSafeJsonResponse } from '../../lib/apiClient.ts';
import type {
  SocialMetadataResult,
  ToolDefinition,
  UrlValidationResult,
  YouTubeDetailsResult,
  YouTubeThumbnailVariant,
  YouTubeTranscriptResult,
} from '../../shared/types.ts';

function formatBytes(bytes?: number | null): string {
  if (!bytes || bytes <= 0) return 'Unknown size';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function UrlExtractorTools({ tool }: { tool: ToolDefinition }) {
  const { prefillUrl, setPrefillUrl, authFetch } = useApp();
  const [urlInput, setUrlInput] = useState(prefillUrl || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const prevModeRef = useRef(tool.mode);

  const [thumbResult, setThumbResult] = useState<{
    videoId: string;
    canonicalUrl: string;
    thumbnails: YouTubeThumbnailVariant[];
  } | null>(null);
  const [ytDetails, setYtDetails] = useState<YouTubeDetailsResult | null>(null);
  const [ytTranscript, setYtTranscript] = useState<YouTubeTranscriptResult | null>(null);
  const [transcriptFilter, setTranscriptFilter] = useState('');
  const [socialResult, setSocialResult] = useState<SocialMetadataResult | null>(null);
  const [urlValidation, setUrlValidation] = useState<UrlValidationResult | null>(null);
  const [includeCaption, setIncludeCaption] = useState(true);
  const [fbWidth, setFbWidth] = useState(500);

  const runExtraction = async (targetUrl: string, transcriptLang?: string) => {
    setError(null);
    setThumbResult(null);
    setYtDetails(null);
    if (!transcriptLang) setYtTranscript(null);
    setSocialResult(null);
    setUrlValidation(null);

    const trimmed = targetUrl.trim();
    if (!trimmed) {
      setError('Please paste a supported public URL first.');
      return;
    }

    setLoading(true);
    try {
      if (tool.mode === 'youtube-thumbnail') {
        const res = await authFetch('/api/v1/youtube/thumbnail', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed }),
        });
        const data = await parseSafeJsonResponse<{
          videoId: string;
          canonicalUrl: string;
          thumbnails: YouTubeThumbnailVariant[];
        }>(res);
        setThumbResult(data);
      } else if (tool.mode === 'youtube-details') {
        const res = await authFetch('/api/v1/youtube/details', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed }),
        });
        const data = await parseSafeJsonResponse<YouTubeDetailsResult>(res);
        setYtDetails(data);
      } else if (tool.mode === 'youtube-transcript') {
        const res = await authFetch('/api/v1/youtube/transcript', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed, lang: transcriptLang }),
        });
        const data = await parseSafeJsonResponse<YouTubeTranscriptResult>(res);
        setYtTranscript(data);
      } else if (tool.mode === 'instagram-metadata' || tool.mode === 'instagram-embed') {
        const res = await authFetch('/api/v1/instagram/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed, toolSlug: tool.slug }),
        });
        const data = await parseSafeJsonResponse<SocialMetadataResult>(res);
        setSocialResult(data);
      } else if (tool.mode === 'pinterest-metadata') {
        const res = await authFetch('/api/v1/pinterest/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed, toolSlug: tool.slug }),
        });
        const data = await parseSafeJsonResponse<SocialMetadataResult>(res);
        setSocialResult(data);
      } else if (tool.mode === 'tiktok-metadata' || tool.mode === 'tiktok-embed') {
        const res = await authFetch('/api/v1/tiktok/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed, toolSlug: tool.slug }),
        });
        const data = await parseSafeJsonResponse<SocialMetadataResult>(res);
        setSocialResult(data);
      } else if (tool.mode === 'facebook-metadata' || tool.mode === 'facebook-embed') {
        const res = await authFetch('/api/v1/facebook/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed, toolSlug: tool.slug }),
        });
        const data = await parseSafeJsonResponse<SocialMetadataResult>(res);
        setSocialResult(data);
      } else if (tool.mode === 'twitter-metadata') {
        const res = await authFetch('/api/v1/twitter/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed }),
        });
        const data = await parseSafeJsonResponse<SocialMetadataResult>(res);
        setSocialResult(data);
      } else if (tool.mode === 'url-analyzer') {
        const res = await authFetch('/api/v1/media/metadata', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ url: trimmed }),
        });
        const data = await parseSafeJsonResponse<{
          validation: UrlValidationResult;
          social?: SocialMetadataResult;
          youtube?: YouTubeDetailsResult;
        }>(res);
        setUrlValidation(data.validation);
        if (data.social) setSocialResult(data.social);
        if (data.youtube) setYtDetails(data.youtube);
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Request failed.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (prefillUrl) {
      setUrlInput(prefillUrl);
      const next = prefillUrl;
      setPrefillUrl('');
      prevModeRef.current = tool.mode;
      void runExtraction(next);
      return;
    }

    if (prevModeRef.current !== tool.mode) {
      prevModeRef.current = tool.mode;
      setError(null);
      setThumbResult(null);
      setYtDetails(null);
      setYtTranscript(null);
      setSocialResult(null);
      setUrlValidation(null);
      if (urlInput.trim()) {
        void runExtraction(urlInput);
      }
    }
  }, [prefillUrl, setPrefillUrl, tool.mode]);

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 1800);
    } catch {
      try {
        const el = document.createElement('textarea');
        el.value = text;
        el.setAttribute('readonly', '');
        el.style.position = 'fixed';
        el.style.opacity = '0';
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
        setCopiedKey(key);
        setTimeout(() => setCopiedKey(null), 1800);
      } catch {
        // Clipboard unavailable
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await runExtraction(urlInput);
  };

  // Build customized embed code for embed tools
  const computedEmbedCode = (() => {
    if (!socialResult) return '';
    if (tool.mode === 'instagram-embed') {
      const captionAttr = includeCaption ? ' data-instgrm-captioned' : '';
      return `<blockquote class="instagram-media"${captionAttr} data-instgrm-permalink="${socialResult.canonicalUrl}" data-instgrm-version="14"></blockquote>\n<script async src="//www.instagram.com/embed.js"></script>`;
    }
    if (tool.mode === 'facebook-embed') {
      const cls = socialResult.mediaType === 'video' ? 'fb-video' : 'fb-post';
      return `<div class="${cls}" data-href="${socialResult.canonicalUrl}" data-width="${fbWidth}" data-show-text="${includeCaption}"></div>`;
    }
    return socialResult.embedHtml || '';
  })();

  return (
    <div className="space-y-6">
      {/* Input Card */}
      <form
        onSubmit={handleSubmit}
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6"
      >
        <label
          htmlFor="tool-url-input"
          className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-2"
        >
          Supported Public URL
        </label>
        <div className="flex flex-col sm:flex-row gap-3">
          <input
            id="tool-url-input"
            type="url"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder={tool.urlPlaceholder || 'https://...'}
            className="flex-1 h-12 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          <button
            type="submit"
            disabled={loading}
            className="h-12 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
          >
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{loading ? 'Processing...' : 'Process URL'}</span>
          </button>
        </div>

        {(tool.mode === 'instagram-embed' || tool.mode === 'facebook-embed') && (
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-5 text-xs text-slate-600 dark:text-slate-300">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeCaption}
                onChange={(e) => setIncludeCaption(e.target.checked)}
                className="rounded border-slate-300"
              />
              <span>Include post caption</span>
            </label>
            {tool.mode === 'facebook-embed' && (
              <label className="flex items-center gap-2">
                <span>Embed width (px):</span>
                <input
                  type="number"
                  min={350}
                  max={750}
                  value={fbWidth}
                  onChange={(e) => setFbWidth(Number(e.target.value) || 500)}
                  className="w-20 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 font-mono tabular-nums"
                />
              </label>
            )}
          </div>
        )}

        {tool.urlPlaceholder && (
          <div className="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>
              Example:{' '}
              <button
                type="button"
                onClick={() => setUrlInput(tool.urlPlaceholder!)}
                className="font-mono text-blue-600 dark:text-blue-400 hover:underline break-all text-left"
              >
                {tool.urlPlaceholder}
              </button>
            </span>
          </div>
        )}

        {error && (
          <div
            role="alert"
            className="mt-4 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/30 p-4 flex items-start gap-3 text-sm text-rose-800 dark:text-rose-200"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}
      </form>

      {/* YouTube Thumbnails Result */}
      {thumbResult && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
            <span>
              Video ID: <strong className="font-mono text-slate-900 dark:text-white">{thumbResult.videoId}</strong>
            </span>
            <a
              href={thumbResult.canonicalUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 hover:underline"
            >
              <span>Open on YouTube</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {thumbResult.thumbnails.map((variant) => (
              <div
                key={variant.key}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden flex flex-col"
              >
                <div className="aspect-video bg-slate-100 dark:bg-slate-950 relative flex items-center justify-center">
                  {variant.available ? (
                    <img
                      src={variant.url}
                      alt={`${variant.label} preview`}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="px-4 text-center text-xs text-slate-500 dark:text-slate-400">
                      Not generated by YouTube for this video (HTTP 404)
                    </div>
                  )}
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between gap-3">
                  <div>
                    <div className="flex items-center justify-between gap-2">
                      <h3 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
                        {variant.label}
                      </h3>
                      <span
                        className={`text-xs font-medium ${
                          variant.available
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-slate-400'
                        }`}
                      >
                        {variant.available ? 'Verified' : 'Unavailable'}
                      </span>
                    </div>
                    <div className="mt-1 text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                      {variant.width} × {variant.height} px · {formatBytes(variant.fileSizeBytes)}
                    </div>
                  </div>

                  {variant.available && (
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                      {variant.downloadPath && (
                        <a
                          href={variant.downloadPath}
                          className="flex-1 h-9 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5 hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>Download JPG</span>
                        </a>
                      )}
                      <button
                        type="button"
                        onClick={() => copyText(variant.key, variant.url)}
                        className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 transition-colors"
                      >
                        {copiedKey === variant.key ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedKey === variant.key ? 'Copied' : 'Copy URL'}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* YouTube Details & Download Compliance Result */}
      {ytDetails && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
          <div className="flex flex-col md:flex-row gap-6">
            {ytDetails.thumbnails.find((t) => t.available) && (
              <div className="md:w-72 shrink-0 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950">
                <img
                  src={ytDetails.thumbnails.find((t) => t.available)!.url}
                  alt={ytDetails.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover"
                />
              </div>
            )}

            <div className="flex-1 min-w-0">
              <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                Data source: {ytDetails.dataSource} · ID <span className="font-mono">{ytDetails.videoId}</span>
              </div>

              {/* Title Box */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4">
                <div className="flex items-center justify-between gap-2 pb-2 mb-2 border-b border-slate-200/80 dark:border-slate-800">
                  <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                    Title
                  </h4>
                  <button
                    type="button"
                    onClick={() => copyText('yt-title', ytDetails.title)}
                    className="h-7 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors"
                  >
                    {copiedKey === 'yt-title' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedKey === 'yt-title' ? 'Copied' : 'Copy'}</span>
                  </button>
                </div>
                <h3 className="font-display text-lg sm:text-xl font-bold text-slate-950 dark:text-white leading-snug break-words">
                  {ytDetails.title}
                </h3>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-slate-600 dark:text-slate-300">
                <span>Channel: {ytDetails.channelName}</span>
                {ytDetails.channelUrl && (
                  <a
                    href={ytDetails.channelUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1 text-xs"
                  >
                    <span>Visit Channel</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>

              {/* Real Statistics Grid (Never fabricated) */}
              <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  {
                    label: 'Views',
                    val:
                      ytDetails.viewCount !== null
                        ? ytDetails.viewCount.toLocaleString()
                        : 'API Key Needed',
                  },
                  {
                    label: 'Likes',
                    val:
                      ytDetails.likeCount !== null
                        ? ytDetails.likeCount.toLocaleString()
                        : 'API Key Needed',
                  },
                  {
                    label: 'Comments',
                    val:
                      ytDetails.commentCount !== null
                        ? ytDetails.commentCount.toLocaleString()
                        : 'API Key Needed',
                  },
                  {
                    label: 'Duration',
                    val: ytDetails.duration || 'API Key Needed',
                  },
                ].map((stat) => (
                  <div
                    key={stat.label}
                    className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-3 py-2"
                  >
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {stat.label}
                    </div>
                    <div className="mt-0.5 text-sm font-semibold font-mono tabular-nums text-slate-900 dark:text-white">
                      {stat.val}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/70 dark:bg-amber-950/20 p-4 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{ytDetails.notice}</span>
          </div>

          {/* Description Box */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4">
            <div className="flex items-center justify-between gap-2 pb-2.5 mb-3 border-b border-slate-200/80 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                Description
              </h4>
              {ytDetails.description && (
                <button
                  type="button"
                  onClick={() => copyText('yt-description', ytDetails.description!)}
                  className="h-7 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors"
                >
                  {copiedKey === 'yt-description' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedKey === 'yt-description' ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>
            {ytDetails.description ? (
              <pre className="whitespace-pre-wrap text-xs text-slate-700 dark:text-slate-300 max-h-56 overflow-y-auto font-sans leading-relaxed">
                {ytDetails.description}
              </pre>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {ytDetails.dataSource === 'youtube-oembed'
                  ? 'Full description requires a YouTube Data API v3 key.'
                  : 'No public description provided for this video.'}
              </p>
            )}
          </div>

          {/* Tags Box */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4">
            <div className="flex items-center justify-between gap-2 pb-2.5 mb-3 border-b border-slate-200/80 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                Tags{ytDetails.tags.length > 0 ? ` (${ytDetails.tags.length})` : ''}
              </h4>
              {ytDetails.tags.length > 0 && (
                <button
                  type="button"
                  onClick={() => copyText('yt-tags', ytDetails.tags.join(', '))}
                  className="h-7 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors"
                >
                  {copiedKey === 'yt-tags' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedKey === 'yt-tags' ? 'Copied' : 'Copy'}</span>
                </button>
              )}
            </div>
            {ytDetails.tags.length > 0 ? (
              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto">
                {ytDetails.tags.map((tag, idx) => (
                  <button
                    key={`${tag}-${idx}`}
                    type="button"
                    onClick={() => copyText(`yt-tag-${idx}`, tag)}
                    title="Click to copy tag"
                    className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-500/50 text-xs font-medium text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
                  >
                    <span>{tag}</span>
                    {copiedKey === `yt-tag-${idx}` && (
                      <Check className="w-3 h-3 text-emerald-600" />
                    )}
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {ytDetails.dataSource === 'youtube-oembed'
                  ? 'Video tags require a YouTube Data API v3 key.'
                  : 'No public tags listed for this video.'}
              </p>
            )}
          </div>

          {/* Official Actions & Permitted Thumbnails */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex flex-wrap gap-3">
              <a
                href={ytDetails.videoUrl}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <span>Watch on YouTube</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <a
                href={`https://studio.youtube.com/video/${ytDetails.videoId}/edit`}
                target="_blank"
                rel="noreferrer"
                className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5"
              >
                <span>Open in YouTube Studio (Owner Export)</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
              <button
                type="button"
                onClick={() => copyText('yt-embed', ytDetails.embedHtml)}
                className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5"
              >
                {copiedKey === 'yt-embed' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copiedKey === 'yt-embed' ? 'Copied Embed HTML' : 'Copy Embed HTML'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* YouTube Transcript Result */}
      {ytTranscript && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs text-slate-500 dark:text-slate-400">
                Video ID: <span className="font-mono">{ytTranscript.videoId}</span> · Track: {ytTranscript.languageName}
              </div>
              <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white mt-0.5">
                {ytTranscript.title}
              </h3>
            </div>
            {ytTranscript.availableTracks.length > 1 && (
              <select
                value={ytTranscript.languageCode}
                onChange={(e) => void runExtraction(urlInput, e.target.value)}
                className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium"
              >
                {ytTranscript.availableTracks.map((tr) => (
                  <option key={tr.languageCode} value={tr.languageCode}>
                    {tr.name} {tr.isAutoGenerated ? '(Auto)' : ''}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <input
              type="text"
              value={transcriptFilter}
              onChange={(e) => setTranscriptFilter(e.target.value)}
              placeholder="Search inside transcript..."
              className="h-10 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs w-full sm:w-64"
            />
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => copyText('yt-transcript-txt', ytTranscript.plainText)}
                className="h-10 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5"
              >
                {copiedKey === 'yt-transcript-txt' ? (
                  <Check className="w-3.5 h-3.5 text-emerald-600" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
                <span>{copiedKey === 'yt-transcript-txt' ? 'Copied Text' : 'Copy Plain Text'}</span>
              </button>
              <a
                href={`data:text/plain;charset=utf-8,${encodeURIComponent(ytTranscript.plainText)}`}
                download={`youtube-${ytTranscript.videoId}-transcript.txt`}
                className="h-10 px-3.5 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>.TXT</span>
              </a>
              <a
                href={`data:text/plain;charset=utf-8,${encodeURIComponent(ytTranscript.srtText)}`}
                download={`youtube-${ytTranscript.videoId}-subtitles.srt`}
                className="h-10 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>.SRT</span>
              </a>
            </div>
          </div>

          <div className="max-h-96 overflow-y-auto rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 divide-y divide-slate-200/70 dark:divide-slate-800/70">
            {ytTranscript.segments
              .filter(
                (seg) =>
                  !transcriptFilter.trim() ||
                  seg.text.toLowerCase().includes(transcriptFilter.trim().toLowerCase())
              )
              .map((seg, i) => (
                <div key={`${seg.startSec}-${i}`} className="px-4 py-2.5 flex items-start gap-4 text-xs sm:text-sm">
                  <span className="font-mono tabular-nums text-blue-600 dark:text-blue-400 shrink-0 mt-0.5">
                    {seg.timestamp}
                  </span>
                  <span className="text-slate-800 dark:text-slate-200 leading-relaxed">
                    {seg.text}
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Social Media / General URL Result */}
      {(socialResult || urlValidation) && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          {urlValidation && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">Detected Platform</div>
                <div className="mt-1 font-semibold capitalize text-slate-900 dark:text-white">
                  {urlValidation.platform}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">Entity Type / ID</div>
                <div className="mt-1 font-mono text-slate-900 dark:text-white truncate">
                  {urlValidation.entityType || 'link'}
                  {urlValidation.entityId ? ` · ${urlValidation.entityId}` : ''}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">SSRF Security Check</div>
                <div className="mt-1 font-semibold text-emerald-600 dark:text-emerald-400">
                  {urlValidation.ssrfSafe ? 'Public Host Verified' : 'Blocked'}
                </div>
              </div>
            </div>
          )}

          {socialResult && (
            <>
              <div className="flex flex-col md:flex-row gap-5">
                {socialResult.thumbnailUrl && (
                  <div className="md:w-64 shrink-0 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950">
                    <img
                      src={socialResult.thumbnailUrl}
                      alt={socialResult.title || 'Media preview'}
                      referrerPolicy="no-referrer"
                      className="w-full h-auto object-cover"
                    />
                  </div>
                )}
                <div className="flex-1 min-w-0 space-y-2">
                  <div className="text-xs text-slate-500 dark:text-slate-400">
                    {socialResult.platform.toUpperCase()} · Source: {socialResult.dataSource}
                  </div>
                  <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
                    {socialResult.title || 'Public Social Media Resource'}
                  </h3>
                  {socialResult.authorName && (
                    <div className="text-sm text-slate-600 dark:text-slate-300">
                      Creator:{' '}
                      {socialResult.authorUrl ? (
                        <a
                          href={socialResult.authorUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="text-blue-600 dark:text-blue-400 hover:underline"
                        >
                          {socialResult.authorName}
                        </a>
                      ) : (
                        socialResult.authorName
                      )}
                    </div>
                  )}
                  {socialResult.description && (
                    <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                      {socialResult.description}
                    </p>
                  )}
                  <div className="text-xs font-mono text-slate-500 break-all pt-1">
                    Canonical: {socialResult.canonicalUrl}
                  </div>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                <span>{socialResult.downloadPolicyMessage}</span>
              </div>

              {computedEmbedCode && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                      Official Embed HTML Snippet
                    </span>
                    <button
                      type="button"
                      onClick={() => copyText('social-embed', computedEmbedCode)}
                      className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1"
                    >
                      {copiedKey === 'social-embed' ? (
                        <Check className="w-3.5 h-3.5" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                      <span>{copiedKey === 'social-embed' ? 'Copied' : 'Copy Embed Code'}</span>
                    </button>
                  </div>
                  <pre className="p-3.5 rounded-xl bg-slate-950 text-slate-100 text-xs font-mono overflow-x-auto">
                    {computedEmbedCode}
                  </pre>
                </div>
              )}

              <div className="flex flex-wrap gap-3 pt-2">
                <a
                  href={socialResult.officialUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-2 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                >
                  <span>Open Official Post</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  type="button"
                  onClick={() => copyText('canonical-url', socialResult.canonicalUrl)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5"
                >
                  {copiedKey === 'canonical-url' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {copiedKey === 'canonical-url' ? 'Copied Clean URL' : 'Copy Clean URL'}
                  </span>
                </button>
                {socialResult.authorizedDownloadUrl && (
                  <a
                    href={socialResult.authorizedDownloadUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-lg border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-200 text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Open Authorized Media Asset</span>
                  </a>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
