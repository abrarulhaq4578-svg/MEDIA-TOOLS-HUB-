import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowUpRight,
  BookmarkPlus,
  Check,
  Copy,
  Database,
  History,
  Loader2,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  UserCheck,
  X,
} from 'lucide-react';
import {
  formatCompactNumber,
  formatSecondsAsClock,
} from '../../../shared/competitorHelpers.ts';
import type {
  ChannelDeepDiveAnalysis,
  CompetitorCachedChannelSummary,
  CompetitorChannelCollection,
  CompetitorChannelProfile,
  CompetitorChannelSearchResult,
  CompetitorHubSummary,
  CompetitorReportRecord,
  ScriptAiModelId,
} from '../../../shared/types.ts';
import type { SaveInspirationDraft } from '../../ytm/SaveInspirationModal.tsx';

function ChannelAvatar({
  src,
  title,
  sizeClass = 'w-11 h-11',
}: {
  src: string | null | undefined;
  title: string;
  sizeClass?: string;
}) {
  const [failed, setFailed] = useState(false);
  const initial = (title || 'Y').trim().charAt(0).toUpperCase();

  if (!src || failed) {
    return (
      <div
        className={`${sizeClass} rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-display font-bold flex items-center justify-center shrink-0`}
      >
        {initial}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={title}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={`${sizeClass} rounded-xl border border-slate-200 dark:border-slate-700 object-cover shrink-0 bg-slate-100 dark:bg-slate-800`}
    />
  );
}

function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      // Clipboard blocked in non-HTTPS contexts
    }
  };
  return (
    <button
      type="button"
      onClick={() => void onCopy()}
      className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 transition-colors shrink-0"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
      <span>{copied ? 'Copied' : label}</span>
    </button>
  );
}

export function HubAndBuilderView(props: {
  hub: CompetitorHubSummary;
  selectedChannels: CompetitorChannelProfile[];
  ownChannelInput: string;
  onOwnChannelInputChange: (val: string) => void;
  sampleSize: number;
  onSampleSizeChange: (val: number) => void;
  modelName: ScriptAiModelId;
  onModelNameChange: (val: ScriptAiModelId) => void;
  searchQuery: string;
  onSearchQueryChange: (val: string) => void;
  searchResults: CompetitorChannelSearchResult[];
  searching: boolean;
  onSearchChannels: () => void;
  directInput: string;
  onDirectInputChange: (val: string) => void;
  resolving: boolean;
  onResolveAndAdd: (inputOverride?: string) => void;
  onRemoveChannel: (channelId: string) => void;
  onStartAnalysis: () => void;
  onOpenSavedReport: (reportKey: string) => void;
  onDeleteReport: (reportKey: string) => void;
  running: boolean;
  errorMsg: string | null;
}) {
  const [showBuilder, setShowBuilder] = useState(true);

  return (
    <div className="space-y-8">
      {/* Entry Hero / Overview */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="max-w-2xl space-y-2.5">
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Competitor Intelligence · Live YouTube Data API v3
            </div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white tracking-tight">
              YouTube Competitor Intelligence Studio
            </h2>
            <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
              Discover what makes successful YouTube channels work — from viral outlier math and packaging DNA to underserved content gaps and an original 30-day growth blueprint.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={() => setShowBuilder(true)}
              className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold flex items-center gap-2 transition-colors"
            >
              <Sparkles className="w-4 h-4" />
              <span>Analyze Competitors</span>
            </button>
          </div>
        </div>
      </section>

      {props.errorMsg && (
        <div
          role="alert"
          className="rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/30 p-4 flex items-start gap-3 text-sm text-rose-800 dark:text-rose-200"
        >
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="font-semibold">Unable to complete request</div>
            <p className="text-xs sm:text-sm opacity-90">{props.errorMsg}</p>
          </div>
        </div>
      )}

      {/* Main Selection Builder */}
      {showBuilder && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
                Step 1 · Select 1 to 10 Competitor Channels (Recommended: 3–5)
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Search by channel name or paste any YouTube channel URL, @handle, or UC channel ID.
              </p>
            </div>
            <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
              {props.selectedChannels.length} / 10 selected
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Direct URL / @handle / ID */}
            <div className="space-y-2.5">
              <label htmlFor="ci-direct-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                Add by Channel URL, @handle, or UC Channel ID
              </label>
              <div className="flex gap-2">
                <input
                  id="ci-direct-input"
                  type="text"
                  value={props.directInput}
                  onChange={(e) => props.onDirectInputChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      props.onResolveAndAdd();
                    }
                  }}
                  placeholder="https://www.youtube.com/@mkbhd or @veritasium or UC..."
                  className="flex-1 h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  disabled={props.resolving || !props.directInput.trim() || props.selectedChannels.length >= 10}
                  onClick={() => props.onResolveAndAdd()}
                  className="h-11 px-4 rounded-xl bg-[#0F172A] dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-500 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  {props.resolving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                  <span>Validate & Add</span>
                </button>
              </div>
            </div>

            {/* Channel Search by Name */}
            <div className="space-y-2.5">
              <label htmlFor="ci-search-input" className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                Or Search YouTube Channels by Name
              </label>
              <div className="flex gap-2">
                <input
                  id="ci-search-input"
                  type="text"
                  value={props.searchQuery}
                  onChange={(e) => props.onSearchQueryChange(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      props.onSearchChannels();
                    }
                  }}
                  placeholder="e.g. Ali Abdaal, Kurzgesagt, Johnny Harris..."
                  className="flex-1 h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
                <button
                  type="button"
                  disabled={props.searching || props.searchQuery.trim().length < 2}
                  onClick={props.onSearchChannels}
                  className="h-11 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-50 text-slate-800 dark:text-slate-200 text-xs sm:text-sm font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  {props.searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                  <span>Search</span>
                </button>
              </div>
            </div>
          </div>

          {/* Search Results List */}
          {props.searchResults.length > 0 && (
            <div className="space-y-2 pt-2">
              <div className="text-xs font-semibold text-slate-600 dark:text-slate-400">
                Channel Search Results
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {props.searchResults.map((item) => {
                  const alreadyAdded = props.selectedChannels.some((c) => c.channelId === item.channelId);
                  return (
                    <div
                      key={item.channelId}
                      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-3 flex items-center justify-between gap-3"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <ChannelAvatar src={item.thumbnailUrl} title={item.title} sizeClass="w-10 h-10" />
                        <div className="min-w-0">
                          <div className="text-sm font-semibold text-slate-950 dark:text-white truncate">
                            {item.title}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                            {item.description || item.channelId}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        disabled={alreadyAdded || props.resolving || props.selectedChannels.length >= 10}
                        onClick={() => props.onResolveAndAdd(item.channelId)}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-blue-500 disabled:opacity-50 text-xs font-semibold text-slate-800 dark:text-slate-200 shrink-0"
                      >
                        {alreadyAdded ? 'Added' : 'Add'}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Selected Validated Channels */}
          <div className="space-y-3">
            <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
              Validated Competitor Basket
            </div>
            {props.selectedChannels.length === 0 ? (
              <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-6 text-center text-xs sm:text-sm text-slate-500 dark:text-slate-400">
                No competitor channels added yet. Add 1 to 10 public YouTube channels above or click any cached channel below.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                {props.selectedChannels.map((ch) => (
                  <div
                    key={ch.channelId}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-4 flex items-start justify-between gap-3"
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <ChannelAvatar src={ch.thumbnailUrl} title={ch.title} sizeClass="w-12 h-12" />
                      <div className="min-w-0 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="font-display text-sm font-bold text-slate-950 dark:text-white truncate">
                            {ch.title}
                          </span>
                          <a
                            href={ch.channelUrl}
                            target="_blank"
                            rel="noreferrer"
                            aria-label={`Open ${ch.title} on YouTube`}
                            className="text-slate-400 hover:text-blue-600 dark:hover:text-blue-400"
                          >
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          </a>
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                          {ch.handle || ch.channelId} ·{' '}
                          {ch.hiddenSubscriberCount
                            ? 'Subscribers hidden'
                            : `${formatCompactNumber(ch.subscriberCount)} subs`}{' '}
                          · {formatCompactNumber(ch.videoCount)} videos · {formatCompactNumber(ch.viewCount)} views
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2">
                          {ch.description || 'No public channel description available.'}
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => props.onRemoveChannel(ch.channelId)}
                      aria-label={`Remove ${ch.title}`}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 hover:bg-slate-200/60 dark:hover:bg-slate-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Optional My Channel & Collection Settings */}
          <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
            <div className="space-y-1.5">
              <label htmlFor="ci-own-channel" className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                My YouTube Channel (Optional · Module 11)
              </label>
              <input
                id="ci-own-channel"
                type="text"
                value={props.ownChannelInput}
                onChange={(e) => props.onOwnChannelInputChange(e.target.value)}
                placeholder="Paste your @handle or channel URL to compare..."
                className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
              />
            </div>

            <div className="space-y-1.5">
              <label htmlFor="ci-sample-size" className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                Recent Uploads Sample Size / Channel
              </label>
              <select
                id="ci-sample-size"
                value={props.sampleSize}
                onChange={(e) => props.onSampleSizeChange(Number(e.target.value))}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-medium text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value={10}>10 recent uploads (Fastest)</option>
                <option value={20}>20 recent uploads (Recommended)</option>
                <option value={35}>35 recent uploads (Deeper median)</option>
                <option value={50}>50 recent uploads (Maximum per call)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="ci-model-select" className="block text-xs font-semibold text-slate-700 dark:text-slate-200">
                AI Strategy Model (Free Tier)
              </label>
              <select
                id="ci-model-select"
                value={props.modelName}
                onChange={(e) => props.onModelNameChange(e.target.value as ScriptAiModelId)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-medium text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
              >
                <option value="gemini-4-hydrogen">Gemini 4 Hydrogen (Default Deep Analyst)</option>
                <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite (Fast / High Quota)</option>
              </select>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
            <div className="text-xs text-slate-500 dark:text-slate-400">
              All metrics are fetched strictly from official YouTube Data API v3 and computed dynamically via format-aware medians.
            </div>
            <button
              type="button"
              disabled={props.running || props.selectedChannels.length < 1}
              onClick={props.onStartAnalysis}
              className="h-12 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              {props.running ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              <span>Start Competitor Analysis</span>
            </button>
          </div>
        </section>
      )}

      {/* Hub Persistence: Saved Reports & Previously Analyzed Channels */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Saved Reports & History */}
        <section className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Saved Reports & Recent History
              </h3>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
              {props.hub.reports.length} saved
            </span>
          </div>

          {props.hub.reports.length === 0 ? (
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 py-4">
              No saved competitor reports yet. Run your first analysis above and it will automatically persist here for reopening or comparison.
            </p>
          ) : (
            <div className="divide-y divide-slate-200 dark:divide-slate-800">
              {props.hub.reports.map((rep) => (
                <div key={rep.reportKey} className="py-3.5 flex items-center justify-between gap-3">
                  <div className="min-w-0 space-y-0.5">
                    <div className="text-sm font-semibold text-slate-950 dark:text-white truncate">
                      {rep.title}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                      {rep.status.toUpperCase()} · {rep.channelCount} channels · {rep.modelName} ·{' '}
                      {new Date(rep.updatedAt).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => props.onOpenSavedReport(rep.reportKey)}
                      className="px-3 py-1.5 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold hover:bg-slate-800 dark:hover:bg-blue-500"
                    >
                      Open
                    </button>
                    <button
                      type="button"
                      onClick={() => props.onDeleteReport(rep.reportKey)}
                      aria-label={`Delete ${rep.title}`}
                      className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 dark:hover:text-rose-400"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Previously Analyzed Cached Channels */}
        <section className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Previously Analyzed Channels
              </h3>
            </div>
            <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
              Cached 6h
            </span>
          </div>

          {props.hub.cachedChannels.length === 0 ? (
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 py-4">
              Channels you analyze are cached cleanly to save YouTube API quota on repeat comparisons.
            </p>
          ) : (
            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {props.hub.cachedChannels.map((ch: CompetitorCachedChannelSummary) => {
                const alreadyAdded = props.selectedChannels.some((c) => c.channelId === ch.channelId);
                return (
                  <div
                    key={ch.channelId}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 p-3 flex items-center justify-between gap-2.5"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <ChannelAvatar src={ch.thumbnailUrl} title={ch.title} sizeClass="w-9 h-9" />
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-950 dark:text-white truncate">
                          {ch.title}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                          {formatCompactNumber(ch.subscriberCount, 'Hidden')} subs · {ch.sampleSize} videos
                        </div>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={alreadyAdded || props.resolving || props.selectedChannels.length >= 10}
                      onClick={() => props.onResolveAndAdd(ch.channelId)}
                      className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:border-blue-500 disabled:opacity-50 shrink-0"
                    >
                      {alreadyAdded ? 'Selected' : '+ Select'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

export function SingleChannelDeepDiveView({
  report,
  onRunSingleChannelAi,
  runningChannelId,
  onSaveToPlanner,
}: {
  report: CompetitorReportRecord;
  onRunSingleChannelAi: (channelId: string) => void;
  runningChannelId: string | null;
  onSaveToPlanner?: (draft: SaveInspirationDraft) => void;
}) {
  const [selectedChannelId, setSelectedChannelId] = useState<string>(
    report.collections[0]?.profile.channelId || ''
  );
  const [moduleTab, setModuleTab] = useState<
    'videos' | 'dna' | 'titles' | 'thumbnails' | 'strategy' | 'production' | 'blueprint'
  >('videos');
  const [videoSort, setVideoSort] = useState<
    'outlier' | 'views' | 'newest' | 'long_form' | 'shorts'
  >('outlier');

  const activeCollection: CompetitorChannelCollection | undefined =
    report.collections.find((c) => c.profile.channelId === selectedChannelId) ||
    report.collections[0];

  const activeAnalysis: ChannelDeepDiveAnalysis | undefined = activeCollection
    ? report.channelAnalyses[activeCollection.profile.channelId]
    : undefined;

  const displayedVideos = useMemo(() => {
    if (!activeCollection) return [];
    let list = [...activeCollection.videos];
    if (videoSort === 'long_form') {
      list = list.filter((v) => v.formatType === 'long_form');
    } else if (videoSort === 'shorts') {
      list = list.filter((v) => v.formatType === 'short');
    }

    if (videoSort === 'views') {
      list.sort((a, b) => (b.viewCount ?? -1) - (a.viewCount ?? -1));
    } else if (videoSort === 'newest') {
      list.sort((a, b) => (b.publishedAt || '').localeCompare(a.publishedAt || ''));
    } else {
      list.sort((a, b) => (b.outlierRatio ?? -1) - (a.outlierRatio ?? -1));
    }
    return list;
  }, [activeCollection, videoSort]);

  if (!activeCollection) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
        No channel metrics collected yet.
      </div>
    );
  }

  const { profile, metrics } = activeCollection;
  const isAnalyzingThis = runningChannelId === profile.channelId;

  return (
    <div className="space-y-6">
      {/* Channel Selector Bar */}
      <div className="flex flex-wrap items-center gap-2">
        {report.collections.map((col) => {
          const active = col.profile.channelId === profile.channelId;
          const hasAi = Boolean(report.channelAnalyses[col.profile.channelId]);
          return (
            <button
              key={col.profile.channelId}
              type="button"
              onClick={() => setSelectedChannelId(col.profile.channelId)}
              className={`h-10 px-3.5 rounded-xl border text-xs sm:text-sm font-semibold flex items-center gap-2 transition-colors ${
                active
                  ? 'border-[#0F172A] dark:border-blue-500 bg-[#0F172A] dark:bg-blue-600 text-white'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <span className="truncate max-w-[180px]">{col.profile.title}</span>
              <span className="text-[11px] font-mono opacity-80">
                {hasAi ? 'AI Ready' : 'Metrics'}
              </span>
            </button>
          );
        })}
      </div>

      {/* Channel Header & Verified Quantitative Strip */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div className="flex items-start gap-4 min-w-0">
            <ChannelAvatar src={profile.thumbnailUrl} title={profile.title} sizeClass="w-14 h-14" />
            <div className="min-w-0 space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-display text-xl font-bold text-slate-950 dark:text-white">
                  {profile.title}
                </h3>
                <a
                  href={profile.channelUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-xs text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <span>{profile.handle || profile.channelId}</span>
                  <ArrowUpRight className="w-3.5 h-3.5" />
                </a>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 max-w-3xl">
                {profile.description || 'No public channel description provided.'}
              </p>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">
                {metrics.dataWindowNote} · {profile.availabilityNote}
              </div>
            </div>
          </div>

          <button
            type="button"
            disabled={isAnalyzingThis}
            onClick={() => onRunSingleChannelAi(profile.channelId)}
            className="h-10 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 hover:border-blue-500 text-xs font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5 shrink-0"
          >
            {isAnalyzingThis ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
            <span>{activeAnalysis ? 'Re-run Channel AI' : 'Analyze Channel AI'}</span>
          </button>
        </div>

        {/* Observed & Calculated KPI Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
          {[
            {
              label: 'Subscribers (Observed)',
              value: profile.hiddenSubscriberCount
                ? 'Hidden'
                : formatCompactNumber(profile.subscriberCount),
            },
            {
              label: 'Sample Median Views',
              value: formatCompactNumber(metrics.medianViewsOverall, 'Unavailable'),
            },
            {
              label: 'Long / Shorts Split',
              value: `${metrics.longFormCount} / ${metrics.shortsCount}`,
            },
            {
              label: 'Avg Long Duration',
              value: formatSecondsAsClock(metrics.avgDurationSecLongForm),
            },
            {
              label: 'Est. Cadence',
              value:
                metrics.uploadsPerMonthEstimate !== null
                  ? `${metrics.uploadsPerMonthEstimate}/mo`
                  : 'Unavailable',
            },
            {
              label: 'Strong Outliers',
              value: `${metrics.strongOrExceptionalOutliersCount} / ${metrics.sampleSize}`,
            },
          ].map((stat) => (
            <div
              key={stat.label}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-3"
            >
              <div className="text-[11px] text-slate-500 dark:text-slate-400">{stat.label}</div>
              <div className="mt-1 font-mono text-base font-bold tabular-nums text-slate-950 dark:text-white">
                {stat.value}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Module Navigation Sub-Tabs */}
      <div
        role="tablist"
        aria-label="Single channel intelligence modules"
        className="flex flex-wrap gap-1.5 p-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
      >
        {(
          [
            { id: 'videos', label: 'Viral Videos & Outliers' },
            { id: 'dna', label: '1–2 · DNA & Topics' },
            { id: 'titles', label: '3 · Title Formulas' },
            { id: 'thumbnails', label: '4–5 · Thumbnails & Formats' },
            { id: 'strategy', label: '6–7 · Strategy & Hooks' },
            { id: 'production', label: '8 · Production DNA' },
            { id: 'blueprint', label: '9 · Master Blueprint' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setModuleTab(tab.id)}
            className={`px-3 py-2 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              moduleTab === tab.id
                ? 'bg-[#0F172A] dark:bg-blue-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {moduleTab === 'videos' && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Public Uploads & Outlier Ratio Breakdown
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Outlier Ratio = Video Views / Median Views of comparable uploads ({formatCompactNumber(metrics.medianViewsOverall)} overall median).
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label htmlFor="ci-video-sort" className="text-xs text-slate-500 dark:text-slate-400">
                Sort / Filter:
              </label>
              <select
                id="ci-video-sort"
                value={videoSort}
                onChange={(e) => setVideoSort(e.target.value as typeof videoSort)}
                className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium text-slate-800 dark:text-slate-100"
              >
                <option value="outlier">Highest outlier ratio</option>
                <option value="views">Most views</option>
                <option value="newest">Newest uploads</option>
                <option value="long_form">Long-form videos only</option>
                <option value="shorts">Shorts only</option>
              </select>
            </div>
          </div>

          {displayedVideos.length === 0 ? (
            <p className="text-sm text-slate-500 py-6 text-center">
              No videos match the current filter in this sample.
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayedVideos.map((vid) => (
                <article
                  key={vid.videoId}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60 overflow-hidden flex flex-col justify-between"
                >
                  <div>
                    <a
                      href={vid.videoUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="block aspect-video bg-slate-200 dark:bg-slate-800 overflow-hidden"
                    >
                      {vid.thumbnailUrl && (
                        <img
                          src={vid.thumbnailUrl}
                          alt={vid.title}
                          referrerPolicy="no-referrer"
                          loading="lazy"
                          className="w-full h-full object-cover"
                        />
                      )}
                    </a>
                    <div className="p-4 space-y-2">
                      <div className="flex items-center justify-between gap-2 text-[11px] font-mono tabular-nums text-slate-500 dark:text-slate-400">
                        <span>
                          {vid.formatType === 'short' ? 'Short' : 'Long-form'} · {vid.durationLabel}
                        </span>
                        <span
                          className={`font-semibold ${
                            (vid.outlierRatio ?? 0) >= 3
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : (vid.outlierRatio ?? 0) >= 1.75
                                ? 'text-blue-600 dark:text-blue-400'
                                : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {vid.outlierRatio !== null ? `${vid.outlierRatio}x median` : 'N/A'}
                        </span>
                      </div>
                      <a
                        href={vid.videoUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="block font-display text-sm font-semibold text-slate-950 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 line-clamp-2"
                      >
                        {vid.title}
                      </a>
                    </div>
                  </div>
                  <div className="px-4 py-2.5 border-t border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-2 text-xs font-mono tabular-nums text-slate-600 dark:text-slate-300">
                    <span className="truncate">
                      {formatCompactNumber(vid.viewCount, 'Views hidden')} · {vid.outlierClassification}
                    </span>
                    {onSaveToPlanner && (
                      <button
                        type="button"
                        onClick={() =>
                          onSaveToPlanner({
                            originalVideoTitle: vid.title,
                            originalVideoUrl: vid.videoUrl,
                            competitorChannelName: profile.title,
                            competitorChannelId: profile.channelId,
                            thumbnailUrl: vid.thumbnailUrl,
                            inspirationCategory: 'video_topic',
                            inspirationSnippet: `${vid.formatType === 'short' ? 'Short' : 'Long-form'} (${vid.durationLabel}) · ${formatCompactNumber(vid.viewCount, 'Hidden')} views${vid.outlierRatio !== null ? ` · ${vid.outlierRatio}x median outlier` : ''}`,
                          })
                        }
                        className="font-sans px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50/70 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                      >
                        <BookmarkPlus className="w-3 h-3" />
                        <span>Save to Planner</span>
                      </button>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      )}

      {moduleTab !== 'videos' && !activeAnalysis && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center space-y-3">
          <p className="text-sm text-slate-600 dark:text-slate-300">
            AI deep-dive modules (1–9) have not been generated for <strong>{profile.title}</strong> yet.
          </p>
          <button
            type="button"
            disabled={isAnalyzingThis}
            onClick={() => onRunSingleChannelAi(profile.channelId)}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-2"
          >
            {isAnalyzingThis ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>Generate Modules 1–9 for {profile.title}</span>
          </button>
        </section>
      )}

      {moduleTab === 'dna' && activeAnalysis && (
        <div className="space-y-6">
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Module 1 · Channel DNA [INFERRED FROM OBSERVED CONTENT]
              </h4>
              <CopyButton
                text={`${activeAnalysis.module1ChannelDna.primaryNiche}\nPositioning: ${activeAnalysis.module1ChannelDna.channelPositioning}\nAudience: ${activeAnalysis.module1ChannelDna.targetAudience}`}
              />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Primary Niche & Sub-Niches</div>
                <div className="font-semibold text-slate-950 dark:text-white">{activeAnalysis.module1ChannelDna.primaryNiche}</div>
                <div className="text-xs text-slate-600 dark:text-slate-300">
                  Sub-niches: {activeAnalysis.module1ChannelDna.subNiches.join(' · ')}
                </div>
                <div className="text-xs text-slate-500 dark:text-slate-400">
                  Micro-niches: {activeAnalysis.module1ChannelDna.microNiches.join(' · ')}
                </div>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Target Audience & Promise</div>
                <div className="text-slate-800 dark:text-slate-200">{activeAnalysis.module1ChannelDna.targetAudience}</div>
                <div className="text-xs text-slate-600 dark:text-slate-400 pt-1">
                  <strong>Promise:</strong> {activeAnalysis.module1ChannelDna.valuePropositionAndPromise}
                </div>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Positioning & Personality</div>
                <div className="text-slate-800 dark:text-slate-200">{activeAnalysis.module1ChannelDna.channelPositioning}</div>
                <div className="text-xs text-slate-600 dark:text-slate-400 pt-1">
                  <strong>Voice & Tone:</strong> {activeAnalysis.module1ChannelDna.creatorPersonalityAndTone}
                </div>
              </div>
              <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">Unique Advantage & Audience Desires</div>
                <div className="text-slate-800 dark:text-slate-200">{activeAnalysis.module1ChannelDna.uniqueCompetitiveAdvantage}</div>
                <ul className="text-xs text-slate-600 dark:text-slate-400 list-disc pl-4 space-y-0.5 pt-1">
                  {activeAnalysis.module1ChannelDna.audienceProblemsAndDesires.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Module 2 · Viral Topic Discovery & Outlier Drivers
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {activeAnalysis.module2ViralTopics.map((topic) => (
                <div
                  key={topic.videoId || topic.title}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2"
                >
                  <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    {topic.title}
                  </div>
                  <div className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                    Topic: {topic.mainTopic} · Trigger: {topic.psychologicalTrigger}
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {topic.whyItMayHaveWorked}
                  </p>
                  <div className="text-xs text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                    <span>
                      <strong>Original Angle:</strong> {topic.repeatableAngle}
                    </span>
                    {onSaveToPlanner && (
                      <button
                        type="button"
                        onClick={() =>
                          onSaveToPlanner({
                            originalVideoTitle: topic.title,
                            originalVideoUrl: topic.videoId
                              ? `https://www.youtube.com/watch?v=${topic.videoId}`
                              : profile.channelUrl,
                            competitorChannelName: profile.title,
                            competitorChannelId: profile.channelId,
                            inspirationCategory: 'video_topic',
                            inspirationSnippet: `Topic: ${topic.mainTopic} | Trigger: ${topic.psychologicalTrigger} | Original angle: ${topic.repeatableAngle}`,
                            userNotes: topic.whyItMayHaveWorked,
                          })
                        }
                        className="px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                      >
                        <BookmarkPlus className="w-3 h-3" />
                        <span>Save to Planner</span>
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      )}

      {moduleTab === 'titles' && activeAnalysis && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Module 3 · Complete Title Intelligence & Reusable Formulas
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono tabular-nums">
                Calculated from {metrics.sampleSize} titles · Avg {metrics.avgTitleLength} chars ·{' '}
                {metrics.titleQuestionPercent}% questions · {metrics.titleNumberPercent}% contain numbers
              </p>
            </div>
            <CopyButton
              text={activeAnalysis.module3TitleIntelligence.formulas
                .map((f) => `${f.formulaName}: ${f.template}\nExample: ${f.competitorExample}\nOriginal: ${f.originalAdaptation}`)
                .join('\n\n')}
              label="Copy Formulas"
            />
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 text-sm text-slate-700 dark:text-slate-300 space-y-2">
            <p>{activeAnalysis.module3TitleIntelligence.observedTitleHabitsSummary}</p>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              <strong>Top Observed Opening Words:</strong>{' '}
              {metrics.topOpeningWords.map((w) => `${w.word} (${w.count})`).join(' · ') || 'None'}
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              <strong>Power Words & Modifiers:</strong>{' '}
              {activeAnalysis.module3TitleIntelligence.powerVerbsAndModifiers.join(' · ')}
            </div>
          </div>

          <div className="space-y-3">
            {activeAnalysis.module3TitleIntelligence.formulas.map((f) => (
              <div
                key={f.formulaName + f.template}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    {f.formulaName}
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-500 dark:text-slate-400">
                      {f.contentCategory} · {f.psychologicalMechanism}
                    </span>
                    {onSaveToPlanner && (
                      <button
                        type="button"
                        onClick={() =>
                          onSaveToPlanner({
                            originalVideoTitle: f.competitorExample || f.formulaName,
                            originalVideoUrl: profile.channelUrl,
                            competitorChannelName: profile.title,
                            competitorChannelId: profile.channelId,
                            inspirationCategory: 'video_title',
                            inspirationSnippet: `Formula: ${f.template} | Mechanism: ${f.psychologicalMechanism}`,
                            userNotes: `Original adaptation seed: ${f.originalAdaptation}`,
                          })
                        }
                        className="px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                      >
                        <BookmarkPlus className="w-3 h-3" />
                        <span>Save to Planner</span>
                      </button>
                    )}
                  </div>
                </div>
                <div className="font-mono text-xs sm:text-sm p-2.5 rounded-lg bg-slate-100 dark:bg-slate-950 text-blue-700 dark:text-blue-300">
                  {f.template}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="font-semibold text-slate-500 dark:text-slate-400">Competitor Example (Observed): </span>
                    <span className="text-slate-800 dark:text-slate-200">{f.competitorExample}</span>
                  </div>
                  <div>
                    <span className="font-semibold text-slate-500 dark:text-slate-400">Original Adaptation: </span>
                    <span className="text-slate-800 dark:text-slate-200">{f.originalAdaptation}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
            <strong>Title Format Blueprint:</strong> {activeAnalysis.module3TitleIntelligence.titleFormatBlueprint}
          </div>
        </section>
      )}

      {moduleTab === 'thumbnails' && activeAnalysis && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Module 4 · Thumbnail Design Intelligence
              </h4>
              {onSaveToPlanner && (
                <button
                  type="button"
                  onClick={() =>
                    onSaveToPlanner({
                      originalVideoTitle: `${profile.title} — Thumbnail Concept Pattern`,
                      originalVideoUrl: profile.channelUrl,
                      competitorChannelName: profile.title,
                      competitorChannelId: profile.channelId,
                      inspirationCategory: 'thumbnail_concept',
                      inspirationSnippet: `${activeAnalysis.module4ThumbnailIntelligence.compositionAndTypography} | ${activeAnalysis.module4ThumbnailIntelligence.colorAndContrastNotes}`,
                      userNotes: activeAnalysis.module4ThumbnailIntelligence.originalVisualOpportunities.join(' • '),
                    })
                  }
                  className="px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                >
                  <BookmarkPlus className="w-3 h-3" />
                  <span>Save to Planner</span>
                </button>
              )}
            </div>
            <div className="space-y-3 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Observable Visual Patterns</div>
                <ul className="list-disc pl-4 space-y-1">
                  {activeAnalysis.module4ThumbnailIntelligence.observableVisualPatterns.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Composition & Typography</div>
                <p>{activeAnalysis.module4ThumbnailIntelligence.compositionAndTypography}</p>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Color, Contrast & Visual Storytelling</div>
                <p>{activeAnalysis.module4ThumbnailIntelligence.colorAndContrastNotes}</p>
                <p className="mt-1 text-slate-600 dark:text-slate-400">
                  {activeAnalysis.module4ThumbnailIntelligence.visualStorytellingMechanism}
                </p>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Original Thumbnail Opportunities</div>
                <ul className="list-disc pl-4 space-y-1">
                  {activeAnalysis.module4ThumbnailIntelligence.originalVisualOpportunities.map((o) => (
                    <li key={o}>{o}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Module 5 · Video Format Intelligence
              </h4>
              {onSaveToPlanner && (
                <button
                  type="button"
                  onClick={() =>
                    onSaveToPlanner({
                      originalVideoTitle: `${profile.title} — Video Format Structure`,
                      originalVideoUrl: profile.channelUrl,
                      competitorChannelName: profile.title,
                      competitorChannelId: profile.channelId,
                      inspirationCategory: 'video_format',
                      inspirationSnippet: activeAnalysis.module5VideoFormatIntelligence.observableFormatBreakdown,
                      userNotes: activeAnalysis.module5VideoFormatIntelligence.pacingAndStructuralObservations,
                    })
                  }
                  className="px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                >
                  <BookmarkPlus className="w-3 h-3" />
                  <span>Save to Planner</span>
                </button>
              )}
            </div>
            <div className="space-y-3 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Format Breakdown</div>
                <p>{activeAnalysis.module5VideoFormatIntelligence.observableFormatBreakdown}</p>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Pacing & Structural Observations</div>
                <p>{activeAnalysis.module5VideoFormatIntelligence.pacingAndStructuralObservations}</p>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Narration & Presentation Style</div>
                <p>{activeAnalysis.module5VideoFormatIntelligence.narrationAndPresentationStyle}</p>
              </div>
              <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-500 dark:text-slate-400">
                <strong>Evidence Boundary:</strong> {activeAnalysis.module5VideoFormatIntelligence.evidenceLimitationNote}
              </div>
            </div>
          </section>
        </div>
      )}

      {moduleTab === 'strategy' && activeAnalysis && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Module 6 · Content Strategy [INFERRED]
              </h4>
              {onSaveToPlanner && (
                <button
                  type="button"
                  onClick={() =>
                    onSaveToPlanner({
                      originalVideoTitle: `${profile.title} — Content Strategy & Pillars`,
                      originalVideoUrl: profile.channelUrl,
                      competitorChannelName: profile.title,
                      competitorChannelId: profile.channelId,
                      inspirationCategory: 'content_strategy',
                      inspirationSnippet: `Pillars: ${activeAnalysis.module6ContentStrategy.contentPillars.join(', ')}`,
                      userNotes: activeAnalysis.module6ContentStrategy.competitivePositioningSummary,
                    })
                  }
                  className="px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                >
                  <BookmarkPlus className="w-3 h-3" />
                  <span>Save to Planner</span>
                </button>
              )}
            </div>
            <div className="space-y-3 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Core Content Pillars</div>
                <ul className="list-disc pl-4 space-y-1">
                  {activeAnalysis.module6ContentStrategy.contentPillars.map((p) => (
                    <li key={p}>{p}</li>
                  ))}
                </ul>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Series & Topic Clusters</div>
                <p><strong>Clusters:</strong> {activeAnalysis.module6ContentStrategy.topicClusters.join(' · ')}</p>
                <p className="mt-1"><strong>Series:</strong> {activeAnalysis.module6ContentStrategy.seriesFormats.join(' · ')}</p>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Evergreen vs. Trend Mix & Cadence</div>
                <p>{activeAnalysis.module6ContentStrategy.evergreenVsTrendMix}</p>
                <p className="mt-1">{activeAnalysis.module6ContentStrategy.cadenceAndConsistencyAssessment}</p>
              </div>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Shorts vs. Long-Form & Positioning</div>
                <p>{activeAnalysis.module6ContentStrategy.shortsVsLongFormRelationship}</p>
                <p className="mt-1">{activeAnalysis.module6ContentStrategy.competitivePositioningSummary}</p>
              </div>
            </div>
          </section>

          <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                Module 7 · Hook & Storytelling Framework
              </h4>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400">
                  {activeAnalysis.module7HookAndStorytelling.transcriptEvidenceStatus === 'transcript_sampled'
                    ? 'Caption-informed'
                    : 'Metadata-inferred'}
                </span>
                {onSaveToPlanner && (
                  <button
                    type="button"
                    onClick={() =>
                      onSaveToPlanner({
                        originalVideoTitle: `${profile.title} — Hook & Storytelling Framework`,
                        originalVideoUrl: profile.channelUrl,
                        competitorChannelName: profile.title,
                        competitorChannelId: profile.channelId,
                        inspirationCategory: 'storytelling_structure',
                        inspirationSnippet: `Opening Hook: ${activeAnalysis.module7HookAndStorytelling.openingHookPattern} | Curiosity Gap: ${activeAnalysis.module7HookAndStorytelling.contextAndCuriosityGap}`,
                        userNotes: activeAnalysis.module7HookAndStorytelling.reusableHookBlueprints.join(' • '),
                      })
                    }
                    className="px-2.5 py-1 rounded-lg border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-[11px] font-semibold inline-flex items-center gap-1 shrink-0 transition-colors"
                  >
                    <BookmarkPlus className="w-3 h-3" />
                    <span>Save to Planner</span>
                  </button>
                )}
              </div>
            </div>
            <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-xs text-slate-600 dark:text-slate-300">
              {activeAnalysis.module7HookAndStorytelling.limitationNotice}
            </div>
            <div className="space-y-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              <p><strong>Opening Hook Pattern:</strong> {activeAnalysis.module7HookAndStorytelling.openingHookPattern}</p>
              <p><strong>Context & Curiosity Gap:</strong> {activeAnalysis.module7HookAndStorytelling.contextAndCuriosityGap}</p>
              <p><strong>Contrast / Common Belief:</strong> {activeAnalysis.module7HookAndStorytelling.commonBeliefOrContrast}</p>
              <p><strong>Proof & Promise Handling:</strong> {activeAnalysis.module7HookAndStorytelling.proofAndPromiseHandling}</p>
              <p><strong>Open Loops & Transitions:</strong> {activeAnalysis.module7HookAndStorytelling.openLoopsAndTransitions}</p>
              <p><strong>Payoff & CTA Style:</strong> {activeAnalysis.module7HookAndStorytelling.payoffAndCtaStyle}</p>
              <div>
                <div className="font-semibold text-slate-950 dark:text-white mb-1">Original Hook Blueprints</div>
                <ul className="list-disc pl-4 space-y-1">
                  {activeAnalysis.module7HookAndStorytelling.reusableHookBlueprints.map((h) => (
                    <li key={h}>{h}</li>
                  ))}
                </ul>
              </div>
            </div>
          </section>
        </div>
      )}

      {moduleTab === 'production' && activeAnalysis && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Module 8 · Competitor Production DNA (Strict Evidence Separation)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">
                <UserCheck className="w-4 h-4" />
                <span>Observable Production Traits [OBSERVED]</span>
              </div>
              <ul className="list-disc pl-4 space-y-1.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                {activeAnalysis.module8ProductionDna.observableProductionTraits.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Unknown Technical Details [NOT PUBLICLY AVAILABLE]
              </div>
              <ul className="list-disc pl-4 space-y-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                {activeAnalysis.module8ProductionDna.unknownTechnicalDetails.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300">
            <strong>Original Replication Guidance:</strong> {activeAnalysis.module8ProductionDna.replicationGuidanceNote}
          </p>
        </section>
      )}

      {moduleTab === 'blueprint' && activeAnalysis && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Module 9 · Master Channel Blueprint (13-Part Original Strategy)
            </h4>
            <CopyButton
              text={activeAnalysis.module9MasterBlueprint.masterChannelPrompt}
              label="Copy Master Prompt"
            />
          </div>

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
            <div className="text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              Master Original Channel Prompt
            </div>
            <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-wrap">
              {activeAnalysis.module9MasterBlueprint.masterChannelPrompt}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
            {[
              { label: '01 · Niche Prompt', body: activeAnalysis.module9MasterBlueprint.nichePrompt },
              { label: '02 · Channel Positioning', body: activeAnalysis.module9MasterBlueprint.positioningStatement },
              { label: '03 · Target Audience Profile', body: activeAnalysis.module9MasterBlueprint.audienceProfile },
              { label: '04 · Channel Promise', body: activeAnalysis.module9MasterBlueprint.channelPromise },
              { label: '05 · Publishing Strategy', body: activeAnalysis.module9MasterBlueprint.publishingStrategy },
              { label: '06 · Differentiation Strategy', body: activeAnalysis.module9MasterBlueprint.differentiationStrategy },
            ].map((item) => (
              <div key={item.label} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">{item.label}</div>
                <div className="text-slate-800 dark:text-slate-200">{item.body}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {[
              { label: 'Content Pillars', items: activeAnalysis.module9MasterBlueprint.contentPillars },
              { label: 'Title DNA Rules', items: activeAnalysis.module9MasterBlueprint.titleDnaRules },
              { label: 'Thumbnail DNA Rules', items: activeAnalysis.module9MasterBlueprint.thumbnailDnaRules },
              { label: 'Format DNA Rules', items: activeAnalysis.module9MasterBlueprint.formatDnaRules },
              { label: 'Storytelling DNA Rules', items: activeAnalysis.module9MasterBlueprint.storytellingDnaRules },
              { label: 'Production DNA Guidelines', items: activeAnalysis.module9MasterBlueprint.productionDnaGuidelines },
            ].map((listBlock) => (
              <div key={listBlock.label} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="font-semibold text-slate-950 dark:text-white">{listBlock.label}</div>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-300">
                  {listBlock.items.map((x) => (
                    <li key={x}>{x}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
