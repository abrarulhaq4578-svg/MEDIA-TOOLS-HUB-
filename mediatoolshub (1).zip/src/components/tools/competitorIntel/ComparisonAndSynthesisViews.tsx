import React, { useState } from 'react';
import {
  BookmarkPlus,
  Check,
  Copy,
  Download,
  PenTool,
  Sparkles,
} from 'lucide-react';
import {
  exportCompetitorReportToMarkdown,
  formatCompactNumber,
  formatSecondsAsClock,
} from '../../../shared/competitorHelpers.ts';
import type {
  CompetitorReportRecord,
  ContentGapOpportunity,
  ScriptStudioSeed,
} from '../../../shared/types.ts';
import type { SaveInspirationDraft } from '../../ytm/SaveInspirationModal.tsx';

function CopyTextButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      // Clipboard blocked
    }
  };
  return (
    <button
      type="button"
      onClick={() => void handleCopy()}
      className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 transition-colors shrink-0"
    >
      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
      <span>{copied ? 'Copied' : label}</span>
    </button>
  );
}

export function CompetitorComparisonView({
  report,
}: {
  report: CompetitorReportRecord;
}) {
  const maxMedianViews = Math.max(
    1,
    ...report.collections.map((c) => c.metrics.medianViewsOverall ?? 0)
  );
  const maxOutliers = Math.max(
    1,
    ...report.collections.map((c) => c.metrics.strongOrExceptionalOutliersCount)
  );

  return (
    <div className="space-y-6">
      {/* Side-by-Side Comparison Matrix */}
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div>
          <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Competitor Comparison Dashboard [OBSERVED & CALCULATED]
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Side-by-side comparison across up to {report.sampleSize} recent public uploads per channel. Unavailable fields reflect creator privacy settings or missing samples.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs sm:text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
                <th className="py-3 pr-4 font-semibold">Channel</th>
                <th className="py-3 px-3 font-semibold">Subscribers</th>
                <th className="py-3 px-3 font-semibold">Sample Median</th>
                <th className="py-3 px-3 font-semibold">Long / Shorts</th>
                <th className="py-3 px-3 font-semibold">Avg Long Dur.</th>
                <th className="py-3 px-3 font-semibold">Cadence</th>
                <th className="py-3 px-3 font-semibold">Outliers</th>
                <th className="py-3 pl-3 font-semibold">Avg Title</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 dark:divide-slate-800 font-mono tabular-nums">
              {report.collections.map((col) => (
                <tr key={col.profile.channelId}>
                  <td className="py-3 pr-4 font-sans font-semibold text-slate-950 dark:text-white">
                    {col.profile.title}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {col.profile.hiddenSubscriberCount
                      ? 'Hidden'
                      : formatCompactNumber(col.profile.subscriberCount)}
                  </td>
                  <td className="py-3 px-3 font-semibold text-blue-600 dark:text-blue-400">
                    {formatCompactNumber(col.metrics.medianViewsOverall, 'N/A')}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {col.metrics.longFormCount} / {col.metrics.shortsCount}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {formatSecondsAsClock(col.metrics.avgDurationSecLongForm)}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {col.metrics.uploadsPerMonthEstimate !== null
                      ? `${col.metrics.uploadsPerMonthEstimate}/mo`
                      : 'N/A'}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {col.metrics.strongOrExceptionalOutliersCount}/{col.metrics.sampleSize}
                  </td>
                  <td className="py-3 pl-3 text-slate-700 dark:text-slate-300">
                    {col.metrics.avgTitleLength} chars
                  </td>
                </tr>
              ))}
              {report.ownChannelCollection && (
                <tr className="bg-blue-50/50 dark:bg-blue-950/20">
                  <td className="py-3 pr-4 font-sans font-bold text-blue-700 dark:text-blue-300">
                    {report.ownChannelCollection.profile.title} (Your Channel)
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {report.ownChannelCollection.profile.hiddenSubscriberCount
                      ? 'Hidden'
                      : formatCompactNumber(report.ownChannelCollection.profile.subscriberCount)}
                  </td>
                  <td className="py-3 px-3 font-semibold text-blue-600 dark:text-blue-400">
                    {formatCompactNumber(report.ownChannelCollection.metrics.medianViewsOverall, 'N/A')}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {report.ownChannelCollection.metrics.longFormCount} / {report.ownChannelCollection.metrics.shortsCount}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {formatSecondsAsClock(report.ownChannelCollection.metrics.avgDurationSecLongForm)}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {report.ownChannelCollection.metrics.uploadsPerMonthEstimate !== null
                      ? `${report.ownChannelCollection.metrics.uploadsPerMonthEstimate}/mo`
                      : 'N/A'}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {report.ownChannelCollection.metrics.strongOrExceptionalOutliersCount}/{report.ownChannelCollection.metrics.sampleSize}
                  </td>
                  <td className="py-3 pl-3 text-slate-700 dark:text-slate-300">
                    {report.ownChannelCollection.metrics.avgTitleLength} chars
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>

      {/* Clean Visual Bar Comparisons */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Median Views per Upload (Sample Window)
          </h4>
          <div className="space-y-3">
            {report.collections.map((col) => {
              const median = col.metrics.medianViewsOverall ?? 0;
              const pct = Math.max(4, Math.round((median / maxMedianViews) * 100));
              return (
                <div key={col.profile.channelId} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                      {col.profile.title}
                    </span>
                    <span className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      {formatCompactNumber(col.metrics.medianViewsOverall, 'Unavailable')}
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div
                      className="h-full bg-blue-600 dark:bg-blue-500 rounded-full"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Format Split & Strong Outliers Density
          </h4>
          <div className="space-y-3">
            {report.collections.map((col) => {
              const total = Math.max(1, col.metrics.sampleSize);
              const longPct = Math.round((col.metrics.longFormCount / total) * 100);
              const outPct = Math.max(
                4,
                Math.round((col.metrics.strongOrExceptionalOutliersCount / maxOutliers) * 100)
              );
              return (
                <div key={col.profile.channelId} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate">
                      {col.profile.title}
                    </span>
                    <span className="font-mono tabular-nums text-slate-600 dark:text-slate-300">
                      {longPct}% Long-form · {col.metrics.strongOrExceptionalOutliersCount} outliers
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden flex">
                    <div
                      className="h-full bg-[#0F172A] dark:bg-emerald-500"
                      style={{ width: `${outPct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Cross-Channel AI Strategic Synthesis */}
      {report.synthesis && (
        <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Cross-Competitor Strategic Landscape [INFERRED]
          </h4>
          <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
            {report.synthesis.nicheLandscapeComparison}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Shared Winning Patterns
              </div>
              <ul className="list-disc pl-4 space-y-1 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                {report.synthesis.crossChannelPatterns.map((p) => (
                  <li key={p}>{p}</li>
                ))}
              </ul>
            </div>
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
              <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                Key Strategic Differentiators
              </div>
              <ul className="list-disc pl-4 space-y-1 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                {report.synthesis.strategicDifferences.map((d) => (
                  <li key={d}>{d}</li>
                ))}
              </ul>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

export function GapFinderOpportunitiesView({
  report,
  onCreateScriptFromOpportunity,
  onSaveToPlanner,
}: {
  report: CompetitorReportRecord;
  onCreateScriptFromOpportunity: (seed: ScriptStudioSeed) => void;
  onSaveToPlanner?: (draft: SaveInspirationDraft) => void;
}) {
  const gaps = report.synthesis?.module10ContentGaps;
  if (!gaps) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
        Complete synthesis to generate Content Gap Opportunities.
      </div>
    );
  }

  const handleLaunchScript = (opp: ContentGapOpportunity) => {
    onCreateScriptFromOpportunity({
      sourceLabel: `Competitor Intelligence (${report.title})`,
      topic: opp.topic,
      suggestedTitle: opp.suggestedTitle,
      targetAudience: opp.targetViewer,
      contentAngle: opp.uniqueAngle,
      thumbnailDirection: opp.thumbnailConcept,
      competitorInsights: `${opp.whyOpportunityExists} (${opp.competitorContext})`,
      recommendedFormat: opp.recommendedFormat,
      recommendedDurationMinutes: opp.recommendedDurationMinutes,
    });
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Module 10 · Content Gap Finder [INFERRED]
        </h3>
        <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          {gaps.whiteSpaceOpportunitiesSummary}
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-emerald-700 dark:text-emerald-400 uppercase tracking-wider">
              Underserved High-Potential Topics
            </div>
            <ul className="list-disc pl-4 space-y-1 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              {gaps.underservedTopics.map((t) => (
                <li key={t}>{t}</li>
              ))}
            </ul>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
            <div className="text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
              Overcrowded Angles to Avoid
            </div>
            <ul className="list-disc pl-4 space-y-1 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
              {gaps.overcrowdedAnglesToAvoid.map((a) => (
                <li key={a}>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
            10 Original Video Opportunities (Ready for Scriptwriting Studio)
          </h4>
          <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {gaps.videoOpportunities.length} opportunities
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {gaps.videoOpportunities.map((opp, idx) => (
            <article
              key={opp.id || opp.suggestedTitle}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-2 text-xs font-mono tabular-nums text-blue-600 dark:text-blue-400">
                  <span>OPPORTUNITY {String(idx + 1).padStart(2, '0')}</span>
                  <span>
                    {opp.recommendedFormat} · ~{opp.recommendedDurationMinutes} min
                  </span>
                </div>
                <h5 className="font-display text-base font-bold text-slate-950 dark:text-white">
                  {opp.suggestedTitle}
                </h5>
                <div className="text-xs text-slate-700 dark:text-slate-300 space-y-1.5 leading-relaxed">
                  <p><strong>Topic:</strong> {opp.topic}</p>
                  <p><strong>Target Viewer:</strong> {opp.targetViewer}</p>
                  <p><strong>Viewer Problem:</strong> {opp.viewerProblem}</p>
                  <p><strong>Unique Angle:</strong> {opp.uniqueAngle}</p>
                  <p><strong>Why Gap Exists:</strong> {opp.whyOpportunityExists}</p>
                  <p><strong>Thumbnail Concept:</strong> {opp.thumbnailConcept}</p>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <CopyTextButton
                    text={`Title: ${opp.suggestedTitle}\nTopic: ${opp.topic}\nAngle: ${opp.uniqueAngle}\nThumbnail: ${opp.thumbnailConcept}`}
                    label="Copy Brief"
                  />
                  {onSaveToPlanner && (
                    <button
                      type="button"
                      onClick={() =>
                        onSaveToPlanner({
                          originalVideoTitle: opp.suggestedTitle,
                          originalVideoUrl: report.collections[0]?.profile.channelUrl || '',
                          competitorChannelName: report.title,
                          inspirationCategory: 'content_strategy',
                          inspirationSnippet: `Topic: ${opp.topic} | Unique Angle: ${opp.uniqueAngle} | Thumbnail: ${opp.thumbnailConcept}`,
                          userNotes: `${opp.whyOpportunityExists} (${opp.competitorContext})`,
                        })
                      }
                      className="px-3 py-1.5 rounded-lg border border-blue-200 dark:border-blue-800 bg-blue-50/70 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300 hover:bg-blue-600 hover:text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
                    >
                      <BookmarkPlus className="w-3.5 h-3.5" />
                      <span>Save to Planner</span>
                    </button>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => handleLaunchScript(opp)}
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 transition-colors"
                >
                  <PenTool className="w-3.5 h-3.5" />
                  <span>Create Script</span>
                </button>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
}

export function GrowthBlueprintView({
  report,
}: {
  report: CompetitorReportRecord;
}) {
  const growth = report.synthesis?.module11GrowthStrategy;
  if (!growth) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
        Complete synthesis to generate your Personalized Growth Strategy & 30-Day Plan.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Module 11 · {growth.hasOwnChannelComparison ? 'Personalized Channel Growth Strategy' : 'Niche Entry & Growth Blueprint'}
          </h3>
          <CopyTextButton
            text={[
              growth.ownChannelSummary,
              growth.competitiveEdgeDiagnosis,
              ...growth.growthBlueprint10Points.map((p, i) => `${i + 1}. ${p}`),
            ].join('\n')}
            label="Copy Blueprint"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              {growth.hasOwnChannelComparison ? 'Your Channel Position Summary' : 'Strategic Entry Benchmark'}
            </div>
            <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{growth.ownChannelSummary}</p>
          </div>
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-1">
            <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
              Competitive Edge Diagnosis
            </div>
            <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{growth.competitiveEdgeDiagnosis}</p>
          </div>
        </div>

        <div className="space-y-2 pt-2">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            10-Point Growth Action Plan
          </div>
          <ol className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
            {growth.growthBlueprint10Points.map((pt, idx) => (
              <li
                key={pt}
                className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 flex items-start gap-2.5"
              >
                <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 mt-0.5">
                  {String(idx + 1).padStart(2, '0')}
                </span>
                <span>{pt}</span>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
            30-Day Execution & Publishing Content Plan
          </h4>
          <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
        </div>
        <div className="divide-y divide-slate-200 dark:divide-slate-800">
          {growth.thirtyDayContentPlan.map((step) => (
            <div key={step.dayRange + step.focus} className="py-3.5 grid grid-cols-1 md:grid-cols-12 gap-2 md:gap-4 text-xs sm:text-sm">
              <div className="md:col-span-2 font-mono font-bold text-blue-600 dark:text-blue-400">
                {step.dayRange}
              </div>
              <div className="md:col-span-3 font-semibold text-slate-950 dark:text-white">
                {step.focus}
              </div>
              <div className="md:col-span-4 text-slate-700 dark:text-slate-300">
                {step.actionableDeliverable}
              </div>
              <div className="md:col-span-3 text-slate-500 dark:text-slate-400">
                {step.targetTopicOrFormat}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export function FullReport19View({
  report,
}: {
  report: CompetitorReportRecord;
}) {
  const sections = report.synthesis?.report19Sections || [];
  const fullMarkdown = exportCompetitorReportToMarkdown(report);

  const downloadFile = (content: string, ext: 'md' | 'json', mime: string) => {
    const blob = new Blob([content], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${report.reportKey}-competitor-intelligence.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <section className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Complete 19-Section Competitor Intelligence Report
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Transparent epistemic labeling distinguishes Observed API metrics, Calculated ratios, Inferred strategies, and Unknown production details.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <CopyTextButton text={fullMarkdown} label="Copy Markdown" />
          <button
            type="button"
            onClick={() => downloadFile(fullMarkdown, 'md', 'text/markdown')}
            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export .MD</span>
          </button>
          <button
            type="button"
            onClick={() =>
              downloadFile(JSON.stringify(report, null, 2), 'json', 'application/json')
            }
            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export .JSON</span>
          </button>
        </div>
      </section>

      {sections.length === 0 ? (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-sm text-slate-500">
          Complete synthesis to assemble all 19 sections.
        </div>
      ) : (
        <div className="space-y-4">
          {sections.map((sec) => (
            <section
              key={sec.number + sec.title}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-3"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-sm font-bold text-blue-600 dark:text-blue-400">
                    {sec.number}.
                  </span>
                  <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
                    {sec.title}
                  </h4>
                  <span className="text-[11px] font-mono uppercase text-slate-500 dark:text-slate-400">
                    [{sec.epistemicLabel}]
                  </span>
                </div>
                <CopyTextButton
                  text={`${sec.number}. ${sec.title}\n\n${sec.summary}\n\n${sec.bulletPoints.map((b) => `- ${b}`).join('\n')}`}
                />
              </div>
              <p className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                {sec.summary}
              </p>
              {sec.bulletPoints.length > 0 && (
                <ul className="list-disc pl-5 space-y-1 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  {sec.bulletPoints.map((bp) => (
                    <li key={bp}>{bp}</li>
                  ))}
                </ul>
              )}
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
