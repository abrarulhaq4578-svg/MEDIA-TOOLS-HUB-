import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  Download,
  FileImage,
  FileVideo,
  Upload,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import type { ToolDefinition } from '../../shared/types.ts';

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function gcd(a: number, b: number): number {
  return b === 0 ? a : gcd(b, a % b);
}

async function detectJpegExifMarker(file: File): Promise<boolean> {
  if (!file.type.includes('jpeg') && !file.name.toLowerCase().endsWith('.jpg')) {
    return false;
  }
  const buffer = await file.slice(0, 65536).arrayBuffer();
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.length - 6; i += 1) {
    if (
      bytes[i] === 0x45 &&
      bytes[i + 1] === 0x78 &&
      bytes[i + 2] === 0x69 &&
      bytes[i + 3] === 0x66
    ) {
      return true;
    }
  }
  return false;
}

export function MediaClientTools({ tool }: { tool: ToolDefinition }) {
  const { authFetch } = useApp();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  // Image converter state
  const [targetFormat, setTargetFormat] = useState<'image/webp' | 'image/jpeg' | 'image/png'>(
    'image/webp'
  );
  const [quality, setQuality] = useState<number>(85);
  const [maxWidth, setMaxWidth] = useState<string>('');
  const [convertedUrl, setConvertedUrl] = useState<string | null>(null);
  const [convertedSize, setConvertedSize] = useState<number | null>(null);
  const [convertedDims, setConvertedDims] = useState<{ w: number; h: number } | null>(null);

  // Image metadata state
  const [imageMeta, setImageMeta] = useState<{
    name: string;
    mime: string;
    sizeBytes: number;
    width: number;
    height: number;
    aspectRatio: string;
    megapixels: string;
    hasExif: boolean;
    lastModified: string;
  } | null>(null);

  // Video metadata & converter state
  const [videoMeta, setVideoMeta] = useState<{
    name: string;
    mime: string;
    sizeBytes: number;
    width: number;
    height: number;
    durationSec: number;
    aspectRatio: string;
    estimatedBitrateKbps: number;
  } | null>(null);
  const [convertingVideo, setConvertingVideo] = useState(false);
  const [videoOutputUrl, setVideoOutputUrl] = useState<string | null>(null);
  const [videoOutputSize, setVideoOutputSize] = useState<number | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      if (convertedUrl) URL.revokeObjectURL(convertedUrl);
      if (videoOutputUrl) URL.revokeObjectURL(videoOutputUrl);
    };
  }, [previewUrl, convertedUrl, videoOutputUrl]);

  const isVideoMode = tool.mode === 'video-metadata' || tool.mode === 'video-converter';

  const handleFileChange = async (file: File | undefined) => {
    if (!file) return;
    setError(null);
    setConvertedUrl(null);
    setConvertedSize(null);
    setImageMeta(null);
    setVideoMeta(null);
    setVideoOutputUrl(null);
    setSelectedFile(file);

    const objUrl = URL.createObjectURL(file);
    setPreviewUrl(objUrl);

    if (isVideoMode) {
      if (!file.type.startsWith('video/')) {
        setError('Please select a valid video file (MP4, WebM, MOV).');
        return;
      }
      const probe = document.createElement('video');
      probe.preload = 'metadata';
      probe.src = objUrl;
      probe.onloadedmetadata = () => {
        const w = probe.videoWidth;
        const h = probe.videoHeight;
        const d = gcd(w || 1, h || 1);
        const dur = probe.duration || 0;
        const kbps = dur > 0 ? Math.round((file.size * 8) / dur / 1000) : 0;
        setVideoMeta({
          name: file.name,
          mime: file.type || 'video/unknown',
          sizeBytes: file.size,
          width: w,
          height: h,
          durationSec: dur,
          aspectRatio: w && h ? `${w / d}:${h / d}` : 'Unknown',
          estimatedBitrateKbps: kbps,
        });
      };
      probe.onerror = () => {
        setError('Browser could not decode this video container/codec.');
      };
    } else {
      if (!file.type.startsWith('image/')) {
        setError('Please select a valid image file (PNG, JPEG, WebP, GIF).');
        return;
      }
      const img = new Image();
      img.src = objUrl;
      img.onload = async () => {
        const w = img.naturalWidth;
        const h = img.naturalHeight;
        const d = gcd(w || 1, h || 1);
        const hasExif = await detectJpegExifMarker(file);
        setImageMeta({
          name: file.name,
          mime: file.type,
          sizeBytes: file.size,
          width: w,
          height: h,
          aspectRatio: `${w / d}:${h / d}`,
          megapixels: ((w * h) / 1_000_000).toFixed(2),
          hasExif,
          lastModified: new Date(file.lastModified).toISOString().slice(0, 10),
        });
      };
      img.onerror = () => {
        setError('Unable to decode image file.');
      };
    }
  };

  const handleImageConvert = () => {
    if (!selectedFile || !previewUrl || !imageMeta) return;
    setError(null);

    const img = new Image();
    img.src = previewUrl;
    img.onload = () => {
      const requestedW = Number.parseInt(maxWidth, 10);
      let outW = img.naturalWidth;
      let outH = img.naturalHeight;
      if (Number.isFinite(requestedW) && requestedW > 0 && requestedW < outW) {
        outH = Math.round((outH * requestedW) / outW);
        outW = requestedW;
      }

      const canvas = document.createElement('canvas');
      canvas.width = outW;
      canvas.height = outH;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        setError('Canvas 2D context unavailable in this browser.');
        return;
      }
      if (targetFormat === 'image/jpeg') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, outW, outH);
      }
      ctx.drawImage(img, 0, 0, outW, outH);

      canvas.toBlob(
        (blob) => {
          if (!blob) {
            setError('Target format is not supported by this browser.');
            return;
          }
          const outUrl = URL.createObjectURL(blob);
          setConvertedUrl(outUrl);
          setConvertedSize(blob.size);
          setConvertedDims({ w: outW, h: outH });

          authFetch('/api/v1/media/convert/log', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              sourceFormat: selectedFile.type || 'image',
              targetFormat,
              sourceSizeBytes: selectedFile.size,
              outputSizeBytes: blob.size,
            }),
          }).catch(() => {});
        },
        targetFormat,
        quality / 100
      );
    };
  };

  const supportedWebmMime =
    typeof MediaRecorder !== 'undefined'
      ? ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8', 'video/webm'].find((m) =>
          MediaRecorder.isTypeSupported(m)
        ) || ''
      : '';

  const handleBrowserVideoConvert = () => {
    const el = videoRef.current;
    if (!el || !selectedFile) return;
    if (!supportedWebmMime || typeof (el as HTMLVideoElement & { captureStream?: () => MediaStream }).captureStream !== 'function') {
      setError('Your browser does not support HTMLVideoElement.captureStream + WebM MediaRecorder.');
      return;
    }

    setError(null);
    setConvertingVideo(true);
    setVideoOutputUrl(null);

    const stream = (el as HTMLVideoElement & { captureStream: () => MediaStream }).captureStream();
    const chunks: Blob[] = [];
    const recorder = new MediaRecorder(stream, { mimeType: supportedWebmMime });

    recorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };
    recorder.onstop = () => {
      const outBlob = new Blob(chunks, { type: 'video/webm' });
      setVideoOutputUrl(URL.createObjectURL(outBlob));
      setVideoOutputSize(outBlob.size);
      setConvertingVideo(false);
    };

    el.currentTime = 0;
    recorder.start(250);
    void el.play();
    el.onended = () => {
      if (recorder.state !== 'inactive') {
        recorder.stop();
      }
    };
  };

  const copyJsonReport = async (obj: unknown) => {
    await navigator.clipboard.writeText(JSON.stringify(obj, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const outExt =
    targetFormat === 'image/webp' ? 'webp' : targetFormat === 'image/jpeg' ? 'jpg' : 'png';

  return (
    <div className="space-y-6">
      {/* YouTube Thumbnail Size Specification Card */}
      {tool.mode === 'youtube-thumbnail-size' && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Official YouTube Thumbnail Specifications
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5">
              <div className="text-slate-500">Recommended Size</div>
              <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white tabular-nums">
                1280 × 720 px
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5">
              <div className="text-slate-500">Aspect Ratio</div>
              <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white">
                16:9
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5">
              <div className="text-slate-500">Max File Size</div>
              <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white tabular-nums">
                2.00 MB
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5">
              <div className="text-slate-500">Allowed Formats</div>
              <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white">
                JPG, PNG, GIF
              </div>
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400">
            Upload your custom thumbnail draft below to verify exact pixel dimensions, 16:9 alignment, and file weight compliance.
          </p>
        </div>
      )}

      {/* Dropzone */}
      <label className="block rounded-2xl border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 bg-white dark:bg-slate-900 p-8 text-center cursor-pointer transition-colors">
        <input
          type="file"
          accept={isVideoMode ? 'video/*' : 'image/*'}
          onChange={(e) => void handleFileChange(e.target.files?.[0])}
          className="sr-only"
        />
        <div className="w-12 h-12 rounded-xl bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 flex items-center justify-center mx-auto mb-3">
          {isVideoMode ? <FileVideo className="w-6 h-6" /> : <FileImage className="w-6 h-6" />}
        </div>
        <div className="font-display text-base font-semibold text-slate-950 dark:text-white">
          {selectedFile
            ? selectedFile.name
            : isVideoMode
              ? 'Select a local video file (MP4, WebM, MOV)'
              : 'Select a local image file (PNG, JPG, WebP, GIF)'}
        </div>
        <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 flex items-center justify-center gap-1.5">
          <Upload className="w-3.5 h-3.5" />
          <span>Processed locally in browser memory · Zero server upload</span>
        </div>
      </label>

      {error && (
        <div
          role="alert"
          className="rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/30 p-4 flex items-center gap-2.5 text-sm text-rose-800 dark:text-rose-200"
        >
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Image Metadata / Thumbnail Safe-Zone Check */}
      {imageMeta && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <div className="flex flex-col md:flex-row gap-6">
            {previewUrl && (
              <div className="md:w-72 shrink-0 rounded-xl overflow-hidden border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 relative">
                <img
                  src={previewUrl}
                  alt={imageMeta.name}
                  className="w-full h-auto object-contain"
                />
                {tool.mode === 'youtube-thumbnail-size' && (
                  <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono">
                    12:45 timestamp safe-zone
                  </div>
                )}
              </div>
            )}

            <div className="flex-1 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">Dimensions</div>
                <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                  {imageMeta.width} × {imageMeta.height} px
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">Aspect Ratio</div>
                <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white">
                  {imageMeta.aspectRatio}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">File Size</div>
                <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                  {formatBytes(imageMeta.sizeBytes)}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">MIME Format</div>
                <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white">
                  {imageMeta.mime}
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">Resolution</div>
                <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                  {imageMeta.megapixels} MP
                </div>
              </div>
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
                <div className="text-slate-500">EXIF APP1 Marker</div>
                <div className="mt-1 font-semibold text-slate-950 dark:text-white">
                  {imageMeta.hasExif ? 'Present' : 'None detected'}
                </div>
              </div>
            </div>
          </div>

          {tool.mode === 'youtube-thumbnail-size' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs space-y-1">
              <div className="font-semibold text-slate-900 dark:text-white">
                YouTube Upload Readiness Check
              </div>
              <div className={imageMeta.width >= 1280 && imageMeta.height >= 720 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-600 dark:text-amber-400'}>
                • Width/Height: {imageMeta.width >= 640 ? 'Meets minimum 640px width' : 'Below 640px minimum width'} ({imageMeta.width}×{imageMeta.height})
              </div>
              <div className={imageMeta.sizeBytes <= 2 * 1024 * 1024 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}>
                • File weight: {formatBytes(imageMeta.sizeBytes)} {imageMeta.sizeBytes <= 2 * 1024 * 1024 ? '(Under 2 MB limit)' : '(Exceeds 2 MB YouTube limit)'}
              </div>
            </div>
          )}

          {tool.mode === 'image-metadata' && (
            <button
              type="button"
              onClick={() => void copyJsonReport(imageMeta)}
              className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold inline-flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied JSON' : 'Copy Metadata JSON'}</span>
            </button>
          )}
        </div>
      )}

      {/* Image Format Converter Controls */}
      {tool.mode === 'image-converter' && imageMeta && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Target Format
              </label>
              <select
                value={targetFormat}
                onChange={(e) =>
                  setTargetFormat(e.target.value as 'image/webp' | 'image/jpeg' | 'image/png')
                }
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="image/webp">WebP (.webp)</option>
                <option value="image/jpeg">JPEG (.jpg)</option>
                <option value="image/png">PNG (.png)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Quality ({quality}%)
              </label>
              <input
                type="range"
                min={20}
                max={100}
                value={quality}
                disabled={targetFormat === 'image/png'}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full mt-2 accent-blue-600"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Max Width (optional px)
              </label>
              <input
                type="number"
                min={64}
                max={8000}
                placeholder={`Original (${imageMeta.width})`}
                value={maxWidth}
                onChange={(e) => setMaxWidth(e.target.value)}
                className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono tabular-nums"
              />
            </div>
          </div>

          <button
            type="button"
            onClick={handleImageConvert}
            className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold transition-colors"
          >
            Convert Image
          </button>

          {convertedUrl && convertedSize !== null && convertedDims && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="text-sm">
                <div className="font-semibold text-slate-950 dark:text-white">
                  Conversion Ready ({convertedDims.w}×{convertedDims.h} px)
                </div>
                <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
                  Original: {formatBytes(imageMeta.sizeBytes)} → Output: {formatBytes(convertedSize)}
                </div>
              </div>
              <a
                href={convertedUrl}
                download={`${selectedFile?.name.replace(/\.[^.]+$/, '') || 'converted'}.${outExt}`}
                className="px-5 py-2.5 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5"
              >
                <Download className="w-4 h-4" />
                <span>Download .{outExt.toUpperCase()}</span>
              </a>
            </div>
          )}
        </div>
      )}

      {/* Video Metadata & Browser Converter */}
      {videoMeta && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
          {previewUrl && (
            <video
              ref={videoRef}
              src={previewUrl}
              controls
              className="w-full max-h-80 rounded-xl bg-black"
            />
          )}

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-slate-500">Resolution</div>
              <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                {videoMeta.width} × {videoMeta.height} px
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-slate-500">Duration</div>
              <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                {videoMeta.durationSec.toFixed(2)} sec
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-slate-500">Aspect Ratio</div>
              <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white">
                {videoMeta.aspectRatio}
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-slate-500">File Size</div>
              <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                {formatBytes(videoMeta.sizeBytes)}
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-slate-500">Est. Bitrate</div>
              <div className="mt-1 font-mono font-semibold tabular-nums text-slate-950 dark:text-white">
                {videoMeta.estimatedBitrateKbps.toLocaleString()} kbps
              </div>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-slate-500">Container MIME</div>
              <div className="mt-1 font-mono font-semibold text-slate-950 dark:text-white truncate">
                {videoMeta.mime}
              </div>
            </div>
          </div>

          {tool.mode === 'video-metadata' && (
            <button
              type="button"
              onClick={() => void copyJsonReport(videoMeta)}
              className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold inline-flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied JSON' : 'Copy Video Spec JSON'}</span>
            </button>
          )}

          {tool.mode === 'video-converter' && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="text-xs text-slate-600 dark:text-slate-400">
                Detected browser encoder: <span className="font-mono">{supportedWebmMime || 'Unsupported in this browser'}</span>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  disabled={!supportedWebmMime || convertingVideo}
                  onClick={handleBrowserVideoConvert}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs font-semibold"
                >
                  {convertingVideo ? 'Recording WebM Stream (plays clip)...' : 'Convert to WebM'}
                </button>
                {videoOutputUrl && videoOutputSize !== null && (
                  <a
                    href={videoOutputUrl}
                    download={`${selectedFile?.name.replace(/\.[^.]+$/, '') || 'video'}.webm`}
                    className="px-5 py-2.5 rounded-xl bg-[#0F172A] dark:bg-emerald-600 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download WebM ({formatBytes(videoOutputSize)})</span>
                  </a>
                )}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
