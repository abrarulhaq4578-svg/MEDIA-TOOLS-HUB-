import React from 'react';
import {
  BookOpen,
  Clock,
  FolderOpen,
  History,
  Plus,
  SlidersHorizontal,
  Trash2,
  X,
} from 'lucide-react';
import {
  ALLOWED_SCRIPT_MODELS,
  BEGINNER_GLOSSARY,
  computeTargetWordCount,
} from '../../../shared/scriptStudioHelpers.ts';
import type {
  ScriptAiModelId,
  ScriptPersonalizationSettings,
  ScriptProjectRecord,
  ScriptRevisionEntry,
} from '../../../shared/types.ts';

export function PersonalizationPanel({
  settings,
  modelName,
  saving,
  onChangeSettings,
  onChangeModel,
  onSave,
  onClose,
}: {
  settings: ScriptPersonalizationSettings;
  modelName: ScriptAiModelId;
  saving: boolean;
  onChangeSettings: (next: ScriptPersonalizationSettings) => void;
  onChangeModel: (model: ScriptAiModelId) => void;
  onSave: () => void;
  onClose: () => void;
}) {
  const computedWords = computeTargetWordCount(settings);
  const computedMins = Number((computedWords / Math.max(80, settings.narrationSpeedWpm || 140)).toFixed(1));

  const update = <K extends keyof ScriptPersonalizationSettings>(
    key: K,
    val: ScriptPersonalizationSettings[K]
  ) => {
    const next = { ...settings, [key]: val };
    if (key === 'targetDurationMinutes' || key === 'narrationSpeedWpm') {
      const wpm = key === 'narrationSpeedWpm' ? Number(val) : next.narrationSpeedWpm;
      const mins = key === 'targetDurationMinutes' ? Number(val) : next.targetDurationMinutes;
      next.targetWordCount = Math.round(Math.max(1, mins) * Math.max(80, wpm));
      next.targetCharacterCount = Math.round(next.targetWordCount * 5.8);
    }
    onChangeSettings(next);
  };

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-5">
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Creator Personalization & Duration Budget
          </h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close settings"
          className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Channel Niche
          </label>
          <input
            type="text"
            value={settings.channelNiche}
            onChange={(e) => update('channelNiche', e.target.value)}
            placeholder="e.g., Psychology, Personal Finance, Tech"
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          />
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Target Audience
          </label>
          <input
            type="text"
            value={settings.targetAudience}
            onChange={(e) => update('targetAudience', e.target.value)}
            placeholder="e.g., College students, solo founders"
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          />
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Viewer Age Group & Region
          </label>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              value={settings.viewerAgeGroup}
              onChange={(e) => update('viewerAgeGroup', e.target.value)}
              placeholder="18-35"
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            />
            <input
              type="text"
              value={settings.countryOrRegion}
              onChange={(e) => update('countryOrRegion', e.target.value)}
              placeholder="Global / India / US"
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Script Language
          </label>
          <input
            type="text"
            value={settings.scriptLanguage}
            onChange={(e) => update('scriptLanguage', e.target.value)}
            placeholder="English, Hinglish, Simple English, Spanish..."
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          />
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Language Style & Tone
          </label>
          <input
            type="text"
            value={settings.contentTone}
            onChange={(e) => update('contentTone', e.target.value)}
            placeholder="Conversational, calm documentary, witty..."
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          />
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Video Format & Presentation
          </label>
          <div className="grid grid-cols-2 gap-2">
            <select
              value={settings.presentationMode}
              onChange={(e) =>
                update('presentationMode', e.target.value === 'faceless' ? 'faceless' : 'on-camera')
              }
              className="h-10 px-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="on-camera">On-Camera</option>
              <option value="faceless">Faceless Channel</option>
            </select>
            <select
              value={settings.storytellingIntensity}
              onChange={(e) =>
                update(
                  'storytellingIntensity',
                  e.target.value as ScriptPersonalizationSettings['storytellingIntensity']
                )
              }
              className="h-10 px-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
            >
              <option value="light">Light Stories</option>
              <option value="balanced">Balanced Stories</option>
              <option value="deep">Deep Narrative</option>
            </select>
          </div>
        </div>
      </div>

      {/* Length, Narration Speed & Model */}
      <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Priority Constraint
          </label>
          <select
            value={settings.constraintPriority}
            onChange={(e) =>
              update(
                'constraintPriority',
                e.target.value as ScriptPersonalizationSettings['constraintPriority']
              )
            }
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          >
            <option value="duration">Target Duration (Minutes)</option>
            <option value="words">Target Word Count</option>
            <option value="characters">Target Character Count</option>
          </select>
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Target Duration (min) · Speed (WPM)
          </label>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              min={1}
              max={60}
              value={settings.targetDurationMinutes}
              onChange={(e) => update('targetDurationMinutes', Number(e.target.value) || 8)}
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono tabular-nums"
            />
            <input
              type="number"
              min={90}
              max={220}
              value={settings.narrationSpeedWpm}
              onChange={(e) => update('narrationSpeedWpm', Number(e.target.value) || 140)}
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono tabular-nums"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Word / Character Target
          </label>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              min={150}
              max={15000}
              value={settings.targetWordCount}
              onChange={(e) => update('targetWordCount', Number(e.target.value) || 1120)}
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono tabular-nums"
              title="Target spoken words"
            />
            <input
              type="number"
              min={500}
              max={90000}
              value={settings.targetCharacterCount}
              onChange={(e) => update('targetCharacterCount', Number(e.target.value) || 6500)}
              className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono tabular-nums"
              title="Target character count"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            AI Studio Model
          </label>
          <select
            value={modelName}
            onChange={(e) => onChangeModel(e.target.value as ScriptAiModelId)}
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100"
          >
            {ALLOWED_SCRIPT_MODELS.map((m) => (
              <option key={m.id} value={m.id}>
                {m.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            CTA Preferences
          </label>
          <input
            type="text"
            value={settings.ctaPreferences}
            onChange={(e) => update('ctaPreferences', e.target.value)}
            placeholder="e.g., Suggest next playlist video organically"
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
          />
        </div>
        <div>
          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Standing Custom Instructions
          </label>
          <input
            type="text"
            value={settings.customInstructions}
            onChange={(e) => update('customInstructions', e.target.value)}
            placeholder="e.g., Keep sentences short, avoid corporate buzzwords"
            className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
          />
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums flex items-center gap-2">
          <Clock className="w-3.5 h-3.5" />
          <span>
            Active budget: ~{computedWords.toLocaleString()} words (~{computedMins} min at{' '}
            {settings.narrationSpeedWpm} WPM)
          </span>
        </div>
        <button
          type="button"
          disabled={saving}
          onClick={onSave}
          className="h-9 px-4 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold hover:bg-slate-800 dark:hover:bg-blue-500 transition-colors"
        >
          {saving ? 'Saving...' : 'Save Studio Preferences'}
        </button>
      </div>
    </div>
  );
}

export function ProjectsDrawer({
  projects,
  activeProjectKey,
  onSelectProject,
  onCreateProject,
  onDeleteProject,
  onClose,
}: {
  projects: ScriptProjectRecord[];
  activeProjectKey: string | null;
  onSelectProject: (projectKey: string) => void;
  onCreateProject: () => void;
  onDeleteProject: (projectKey: string) => void;
  onClose: () => void;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <FolderOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Saved Script Projects ({projects.length})
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onCreateProject}
            className="h-8 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Project</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close saved projects"
            className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {projects.length === 0 ? (
        <p className="text-xs text-slate-500 dark:text-slate-400 py-4">
          No saved projects yet. Start below and your approved decisions will automatically persist.
        </p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-80 overflow-y-auto">
          {projects.map((p) => {
            const isActive = p.projectKey === activeProjectKey;
            return (
              <div
                key={p.projectKey}
                className={`rounded-xl border p-3.5 flex items-center justify-between gap-3 transition-colors ${
                  isActive
                    ? 'border-blue-600 bg-blue-50/60 dark:bg-blue-950/20'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onSelectProject(p.projectKey)}
                  className="text-left min-w-0 flex-1"
                >
                  <div className="text-sm font-semibold text-slate-950 dark:text-white truncate">
                    {p.title}
                  </div>
                  <div className="mt-1 text-xs text-slate-500 dark:text-slate-400 font-mono tabular-nums">
                    Stage {p.currentStage}/7 · Approved {p.highestApprovedStage}/7 ·{' '}
                    {new Date(p.updatedAt).toLocaleDateString()}
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => onDeleteProject(p.projectKey)}
                  aria-label={`Delete ${p.title}`}
                  className="p-2 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors shrink-0"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

export function GlossaryDrawer({ onClose }: { onClose: () => void }) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Beginner Scriptwriting Glossary
          </h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close glossary"
          className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {BEGINNER_GLOSSARY.map((item) => (
          <div
            key={item.term}
            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5"
          >
            <div className="text-xs font-bold text-slate-950 dark:text-white">{item.term}</div>
            <p className="mt-1 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {item.explanation}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export function RevisionHistoryDrawer({
  history,
  onClose,
}: {
  history: ScriptRevisionEntry[];
  onClose: () => void;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Session Decisions & Revision History
          </h3>
        </div>
        <button
          type="button"
          onClick={onClose}
          aria-label="Close history"
          className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {history.length === 0 ? (
        <p className="text-xs text-slate-500 dark:text-slate-400">
          No actions logged in this project yet.
        </p>
      ) : (
        <div className="max-h-72 overflow-y-auto divide-y divide-slate-200 dark:divide-slate-800">
          {history.map((entry) => (
            <div key={entry.id} className="py-2.5 flex items-start justify-between gap-4 text-xs">
              <div>
                <span className="font-semibold text-slate-900 dark:text-white">
                  Stage {entry.stage} · {entry.action}
                </span>
                <p className="text-slate-600 dark:text-slate-400 mt-0.5">{entry.summary}</p>
              </div>
              <span className="font-mono tabular-nums text-[11px] text-slate-400 shrink-0">
                {new Date(entry.timestamp).toLocaleTimeString()}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
