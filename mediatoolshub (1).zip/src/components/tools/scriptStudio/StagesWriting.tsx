import React, { useState } from 'react';
import {
  AlertCircle,
  Check,
  Copy,
  Download,
  Loader2,
  Lock,
  Sparkles,
} from 'lucide-react';
import {
  countSpokenWords,
  formatDurationFromWords,
  stripProductionNotes,
} from '../../../shared/scriptStudioHelpers.ts';
import type { ScriptProjectRecord } from '../../../shared/types.ts';

export function Stage4IntroView({
  project,
  busy,
  onPatchStage,
  onGenerate,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  onPatchStage: (stage: 4, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
}) {
  const { stage4 } = project.state;
  const liveWords = countSpokenWords(stage4.spokenNarration);
  const liveSec = Math.round((liveWords / Math.max(80, project.settings.narrationSpeedWpm || 140)) * 60);

  if (!stage4.spokenNarration) {
    return (
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 text-center space-y-3">
        <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Stage 4 · 5-Part Video Introduction
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
          Using your approved outline and packaging, we will write a natural opening built on Context, Common Belief, Contrast, Proof, and Plan—without generic greetings or channel filler.
        </p>
        <button
          type="button"
          disabled={busy}
          onClick={() => void onGenerate('intro')}
          className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
        >
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span>Draft 5-Part Introduction</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {stage4.directorComment && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-1">
            Creative Director Hook Analysis
          </div>
          {stage4.directorComment}
        </div>
      )}

      {stage4.parts && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          {[
            { num: '01', label: 'Context', text: stage4.parts.context },
            { num: '02', label: 'Common Belief', text: stage4.parts.commonBelief },
            { num: '03', label: 'Contrast', text: stage4.parts.contrast },
            { num: '04', label: 'Proof', text: stage4.parts.proof },
            { num: '05', label: 'Plan', text: stage4.parts.plan },
          ].map((p) => (
            <div
              key={p.label}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5 text-xs space-y-1.5"
            >
              <div className="font-mono font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                {p.num}. {p.label}
              </div>
              <p className="text-slate-700 dark:text-slate-300 leading-relaxed">{p.text}</p>
            </div>
          ))}
        </div>
      )}

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <label className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Spoken Introduction Narration (Editable)
          </label>
          <span className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
            {liveWords} words · ~{liveSec}s read time
          </span>
        </div>
        <textarea
          rows={8}
          value={stage4.spokenNarration}
          onChange={(e) => void onPatchStage(4, { spokenNarration: e.target.value })}
          className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
      </div>
    </div>
  );
}

export function Stage5BodyView({
  project,
  busy,
  onPatchStage,
  onGenerate,
  onApproveSection,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  onPatchStage: (stage: 5, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
  onApproveSection: (sectionIndex: number) => Promise<void>;
}) {
  const { stage3, stage5 } = project.state;
  const activeIdx = Math.min(
    Math.max(0, stage5.activeSectionIndex),
    Math.max(0, stage3.sections.length - 1)
  );
  const outlineSection = stage3.sections[activeIdx];
  const draft = stage5.sections[activeIdx];
  const canOpenSection = (idx: number) =>
    idx === 0 || Boolean(stage5.sections[idx - 1]?.approved);

  return (
    <div className="space-y-6">
      {/* Section-by-Section Progress Rail */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-semibold uppercase tracking-wide text-slate-600 dark:text-slate-300">
            Section-by-Section Writing Workflow ({stage5.sections.filter((s) => s.approved).length}/
            {stage3.sections.length} Approved)
          </span>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Each section is reviewed and approved before drafting the next.
          </span>
        </div>
        <div className="flex flex-wrap gap-2">
          {stage3.sections.map((sec, idx) => {
            const secDraft = stage5.sections[idx];
            const approved = Boolean(secDraft?.approved);
            const active = idx === activeIdx;
            const unlocked = canOpenSection(idx);
            return (
              <button
                key={sec.id}
                type="button"
                disabled={!unlocked}
                onClick={() => void onPatchStage(5, { activeSectionIndex: idx })}
                className={`h-9 px-3 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap ${
                  active
                    ? 'border-blue-600 bg-[#0F172A] dark:bg-blue-600 text-white'
                    : approved
                      ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-200'
                      : unlocked
                        ? 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900/40 text-slate-400 cursor-not-allowed'
                }`}
              >
                {approved ? (
                  <Check className="w-3.5 h-3.5" />
                ) : !unlocked ? (
                  <Lock className="w-3 h-3" />
                ) : null}
                <span>
                  {idx + 1}. {sec.heading}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Active Outline Blueprint */}
      {outlineSection && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 text-xs space-y-1.5">
          <div className="font-mono font-bold text-blue-600 dark:text-blue-400">
            OUTLINE BLUEPRINT · SECTION {activeIdx + 1} OF {stage3.sections.length}
          </div>
          <div className="font-display text-base font-bold text-slate-950 dark:text-white">
            {outlineSection.heading}
          </div>
          <p className="text-slate-600 dark:text-slate-300">
            <strong>Goal:</strong> {outlineSection.mainIdea} ·{' '}
            <strong>Viewer learns:</strong> {outlineSection.whatViewerLearns}
          </p>
        </div>
      )}

      {!draft ? (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 text-center space-y-3">
          <h4 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Ready to Draft Section {activeIdx + 1}: {outlineSection?.heading}
          </h4>
          <p className="text-xs text-slate-600 dark:text-slate-400 max-w-lg mx-auto">
            I will craft human conversational narration weaving all 7 storytelling beats—explanation, relatable example, scenario, practical takeaway, unexpected insight, and transition.
          </p>
          <button
            type="button"
            disabled={busy}
            onClick={() => void onGenerate('body-section', { sectionIndex: activeIdx })}
            className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>Write Section {activeIdx + 1}</span>
          </button>
        </div>
      ) : (
        <div className="space-y-5">
          {draft.directorComment && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-1">
                Creative Director Notes · Section {activeIdx + 1}
              </div>
              {draft.directorComment}
            </div>
          )}

          {draft.beats && (
            <details className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 text-xs">
              <summary className="font-semibold text-slate-800 dark:text-slate-200 cursor-pointer">
                View 7 Storytelling Beats Used in This Section
              </summary>
              <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2.5 text-slate-600 dark:text-slate-300">
                <div><strong>1. Main point:</strong> {draft.beats.mainPoint}</div>
                <div><strong>2. Simple explanation:</strong> {draft.beats.simpleExplanation}</div>
                <div><strong>3. Relatable example:</strong> {draft.beats.relatableExample}</div>
                <div><strong>4. Story / scenario:</strong> {draft.beats.storyOrScenario}</div>
                <div><strong>5. Practical application:</strong> {draft.beats.practicalApplication}</div>
                <div><strong>6. Unexpected insight:</strong> {draft.beats.unexpectedInsight}</div>
                <div className="md:col-span-2"><strong>7. Transition:</strong> {draft.beats.transition}</div>
              </div>
            </details>
          )}

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="font-display text-sm font-bold text-slate-950 dark:text-white">
                Section {activeIdx + 1} Spoken Narration (Editable)
              </label>
              <span className="text-xs font-mono tabular-nums text-slate-500">
                {countSpokenWords(draft.spokenNarration)} words ·{' '}
                {draft.approved ? 'Approved' : 'Awaiting your approval'}
              </span>
            </div>
            <textarea
              rows={11}
              value={draft.spokenNarration}
              onChange={(e) =>
                void onPatchStage(5, {
                  sectionIndex: activeIdx,
                  spokenNarration: e.target.value,
                })
              }
              className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-600"
            />
            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <button
                type="button"
                disabled={busy}
                onClick={() => void onGenerate('body-section', { sectionIndex: activeIdx })}
                className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Regenerate Section {activeIdx + 1}
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => void onApproveSection(activeIdx)}
                className="h-9 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold hover:bg-slate-800 dark:hover:bg-blue-500 inline-flex items-center gap-1.5"
              >
                <Check className="w-3.5 h-3.5" />
                <span>
                  {activeIdx < stage3.sections.length - 1
                    ? `Approve Section ${activeIdx + 1} & Unlock Section ${activeIdx + 2}`
                    : `Approve Final Body Section & Continue to Outro`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export function Stage6OutroView({
  project,
  busy,
  onPatchStage,
  onGenerate,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  onPatchStage: (stage: 6, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
}) {
  const { outro } = project.state.stage6;

  if (!outro) {
    return (
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 text-center space-y-3">
        <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Stage 6 · Fortune Cookie Outro & Native Call to Action
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
          Instead of an abrupt sign-off or robotic plea to subscribe, we will close with one memorable Fortune Cookie insight tied to a natural, viewer-helpful CTA.
        </p>
        <button
          type="button"
          disabled={busy}
          onClick={() => void onGenerate('outro')}
          className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
        >
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span>Draft Outro & CTA</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {outro.directorComment && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-1">
            Creative Director Closing Note
          </div>
          {outro.directorComment}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
        {[
          { label: '1. Final Fortune Cookie Insight', val: outro.finalInsight },
          { label: '2. Central Message Connection', val: outro.connectionToCentralMessage },
          { label: '3. Emotional / Practical Takeaway', val: outro.takeaway },
          { label: '4. Natural Call to Action', val: outro.naturalCta },
          { label: '5. Recommended Next Video', val: outro.nextVideoRecommendation },
        ].map((item) => (
          <div
            key={item.label}
            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5 space-y-1"
          >
            <div className="font-semibold text-slate-500 dark:text-slate-400">{item.label}</div>
            <p className="text-slate-800 dark:text-slate-200 leading-relaxed">{item.val}</p>
          </div>
        ))}
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <label className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Spoken Outro & CTA Narration (Editable)
          </label>
          <span className="text-xs font-mono tabular-nums text-slate-500">
            {countSpokenWords(outro.spokenNarration)} words
          </span>
        </div>
        <textarea
          rows={7}
          value={outro.spokenNarration}
          onChange={(e) => void onPatchStage(6, { spokenNarration: e.target.value })}
          className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-600"
        />
      </div>
    </div>
  );
}

export function Stage7AssemblyView({
  project,
  busy,
  onPatchStage,
  onGenerate,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  onPatchStage: (stage: 7, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
}) {
  const { assembled } = project.state.stage7;
  const [includeProductionNotes, setIncludeProductionNotes] = useState(
    assembled?.includeProductionNotes ?? true
  );
  const [viewMode, setViewMode] = useState<'full' | 'spoken'>('full');
  const [copiedType, setCopiedType] = useState<string | null>(null);

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const el = document.createElement('textarea');
      el.value = text;
      el.style.position = 'fixed';
      el.style.opacity = '0';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
    }
    setCopiedType(key);
    setTimeout(() => setCopiedType(null), 1800);
  };

  if (!assembled) {
    return (
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 text-center space-y-4">
        <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Stage 7 · Final Production Assembly & Quality Control
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
          All previous sections are approved. We will assemble your exact approved Introduction, Body Sections, and Outro—without overwriting your wording—calculate speaking duration, and run an 11-point quality check.
        </p>
        <label className="inline-flex items-center gap-2 text-xs font-medium text-slate-700 dark:text-slate-200 cursor-pointer">
          <input
            type="checkbox"
            checked={includeProductionNotes}
            onChange={(e) => setIncludeProductionNotes(e.target.checked)}
            className="rounded border-slate-300"
          />
          <span>Include separate [VISUAL], [B-ROLL], [ON-SCREEN TEXT], [SFX], and [PAUSE] production cues</span>
        </label>
        <div>
          <button
            type="button"
            disabled={busy}
            onClick={() => void onGenerate('assemble', { includeProductionNotes })}
            className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>Assemble Production Script</span>
          </button>
        </div>
      </div>
    );
  }

  const liveSpokenOnly = stripProductionNotes(assembled.fullScriptText);
  const liveWordCount = countSpokenWords(assembled.fullScriptText);
  const liveDur = formatDurationFromWords(
    liveWordCount,
    project.settings.narrationSpeedWpm || assembled.narrationSpeedWpm || 140
  );

  const exportMarkdown = [
    `# VIDEO TITLE: ${assembled.videoTitle}`,
    `THUMBNAIL TEXT: ${assembled.thumbnailText}`,
    `TARGET AUDIENCE: ${assembled.targetAudience}`,
    `VIDEO PROMISE: ${assembled.videoPromise}`,
    `ESTIMATED DURATION: ${liveDur.formatted} (${project.settings.narrationSpeedWpm} WPM)`,
    `ESTIMATED WORD COUNT: ${liveWordCount} spoken words`,
    '',
    '---',
    '',
    '## FULL SCRIPT',
    '',
    viewMode === 'full' ? assembled.fullScriptText : liveSpokenOnly,
  ].join('\n');

  return (
    <div className="space-y-6">
      {/* Production Sheet Summary Header */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-5 space-y-3 text-xs">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <span className="font-semibold text-slate-500">VIDEO TITLE:</span>{' '}
            <strong className="text-slate-950 dark:text-white text-sm">{assembled.videoTitle}</strong>
          </div>
          <div>
            <span className="font-semibold text-slate-500">THUMBNAIL TEXT:</span>{' '}
            <strong className="text-slate-950 dark:text-white">{assembled.thumbnailText}</strong>
          </div>
          <div>
            <span className="font-semibold text-slate-500">TARGET AUDIENCE:</span>{' '}
            <span className="text-slate-800 dark:text-slate-200">{assembled.targetAudience}</span>
          </div>
          <div>
            <span className="font-semibold text-slate-500">VIDEO PROMISE:</span>{' '}
            <span className="text-slate-800 dark:text-slate-200">{assembled.videoPromise}</span>
          </div>
        </div>
        <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-5 font-mono tabular-nums text-slate-700 dark:text-slate-200">
            <span>ESTIMATED DURATION: {liveDur.formatted}</span>
            <span>ESTIMATED WORD COUNT: {liveWordCount.toLocaleString()} words</span>
            <span>SPEED: {project.settings.narrationSpeedWpm} WPM</span>
          </div>
          <div className="flex items-center gap-3">
            <label className="inline-flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={includeProductionNotes}
                onChange={(e) => setIncludeProductionNotes(e.target.checked)}
                className="rounded border-slate-300"
              />
              <span>Production Cues</span>
            </label>
            <button
              type="button"
              disabled={busy}
              onClick={() => void onGenerate('assemble', { includeProductionNotes })}
              className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Re-Assemble
            </button>
          </div>
        </div>
      </div>

      {assembled.durationTradeoffNote && (
        <div className="rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/70 dark:bg-amber-950/20 p-4 text-xs text-amber-900 dark:text-amber-200 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>
            <strong>Duration Trade-Off Note:</strong> {assembled.durationTradeoffNote}
          </span>
        </div>
      )}

      {/* Script Editor & Export Controls */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setViewMode('full')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                viewMode === 'full'
                  ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Full Production Script
            </button>
            <button
              type="button"
              onClick={() => setViewMode('spoken')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-colors ${
                viewMode === 'spoken'
                  ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Spoken-Only Teleprompter
            </button>
          </div>

          <div className="flex flex-wrap gap-2 text-xs">
            <button
              type="button"
              onClick={() =>
                void copyText(
                  'full',
                  viewMode === 'full' ? assembled.fullScriptText : liveSpokenOnly
                )
              }
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {copiedType === 'full' ? (
                <Check className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Copy className="w-3.5 h-3.5" />
              )}
              <span>{copiedType === 'full' ? 'Copied' : 'Copy Script'}</span>
            </button>
            <a
              href={`data:text/plain;charset=utf-8,${encodeURIComponent(exportMarkdown)}`}
              download={`${assembled.videoTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 48) || 'video-script'}.txt`}
              className="h-9 px-3.5 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export .TXT</span>
            </a>
            <a
              href={`data:text/markdown;charset=utf-8,${encodeURIComponent(exportMarkdown)}`}
              download={`${assembled.videoTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 48) || 'video-script'}.md`}
              className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export .MD</span>
            </a>
          </div>
        </div>

        {viewMode === 'full' ? (
          <textarea
            rows={20}
            value={assembled.fullScriptText}
            onChange={(e) => void onPatchStage(7, { fullScriptText: e.target.value })}
            className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 leading-relaxed focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
        ) : (
          <pre className="whitespace-pre-wrap p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-sm text-slate-900 dark:text-slate-100 leading-relaxed max-h-[34rem] overflow-y-auto font-sans">
            {liveSpokenOnly}
          </pre>
        )}
      </div>

      {/* 11-Point Final Quality Control Audit */}
      {assembled.qualityChecks.length > 0 && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Final Quality Control Audit
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs">
            {assembled.qualityChecks.map((qc, idx) => (
              <div
                key={idx}
                className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 flex items-start gap-2.5"
              >
                {qc.passed ? (
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                )}
                <div>
                  <div className="font-semibold text-slate-900 dark:text-white">
                    {qc.label} · {qc.passed ? 'Passed' : 'Review Recommended'}
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 mt-0.5">{qc.note}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
