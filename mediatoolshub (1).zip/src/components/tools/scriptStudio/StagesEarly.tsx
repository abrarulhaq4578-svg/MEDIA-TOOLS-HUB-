import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowDown,
  ArrowUp,
  Check,
  Edit3,
  Lightbulb,
  Loader2,
  Plus,
  RefreshCw,
  Search,
  ShieldAlert,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { parseSafeJsonResponse } from '../../../lib/apiClient.ts';
import { WELCOME_SCRIPT_MESSAGE } from '../../../shared/scriptStudioHelpers.ts';
import type {
  OutlineSection,
  ScriptCompetitorResearchContext,
  ScriptProjectRecord,
  TopicIdea,
} from '../../../shared/types.ts';

export function Stage1TopicView({
  project,
  busy,
  onPatchStage,
  onGenerate,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  onPatchStage: (stage: 1, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
}) {
  const { stage1 } = project.state;
  const [niche, setNiche] = useState(
    stage1.nicheInput || project.settings.channelNiche || ''
  );
  const [customTopic, setCustomTopic] = useState(stage1.customTopicInput || '');
  const [editingSelected, setEditingSelected] = useState(false);

  const selectIdea = async (idea: TopicIdea) => {
    await onPatchStage(1, { selectedTopic: idea });
  };

  return (
    <div className="space-y-6">
      {/* Creative Director Welcome Banner */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-5">
        <div className="text-xs font-semibold uppercase tracking-wide text-blue-600 dark:text-blue-400 mb-1.5">
          Stage 1 · Topic Discovery
        </div>
        <p className="text-sm sm:text-base text-slate-900 dark:text-slate-100 leading-relaxed font-medium">
          {WELCOME_SCRIPT_MESSAGE}
        </p>
      </div>

      {/* Two Clear Starting Paths */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Path A: Generate 10 Topic Ideas */}
        <div
          className={`rounded-xl border p-5 space-y-3 transition-colors ${
            stage1.entryMode === 'ideas'
              ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/10'
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
          }`}
        >
          <div className="text-xs font-mono font-semibold text-blue-600 dark:text-blue-400">
            OPTION A · TOPIC BRAINSTORMING
          </div>
          <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Generate 10 Specific Topic Ideas
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Tell me your niche or channel category and I will generate 10 non-generic topics with clear audience problems and storytelling angles.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 pt-1">
            <input
              type="text"
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              placeholder="e.g., Personal Finance for Beginners"
              className="flex-1 h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
            />
            <button
              type="button"
              disabled={busy}
              onClick={() => void onGenerate('topics', { niche })}
              className="h-10 px-4 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold hover:bg-slate-800 dark:hover:bg-blue-500 disabled:opacity-60 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
            >
              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Lightbulb className="w-3.5 h-3.5" />}
              <span>Generate Ideas</span>
            </button>
          </div>
        </div>

        {/* Path B: Enter My Own Topic */}
        <div
          className={`rounded-xl border p-5 space-y-3 transition-colors ${
            stage1.entryMode === 'custom'
              ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/10'
              : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
          }`}
        >
          <div className="text-xs font-mono font-semibold text-blue-600 dark:text-blue-400">
            OPTION B · BRING YOUR IDEA
          </div>
          <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
            Enter & Analyze My Own Topic
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Already have a rough idea? I will identify the central viewer tension, desired transformation, curiosity gap, and opportunities.
          </p>
          <div className="flex flex-col sm:flex-row gap-2 pt-1">
            <input
              type="text"
              value={customTopic}
              onChange={(e) => setCustomTopic(e.target.value)}
              placeholder="e.g., Why smart people still procrastinate"
              className="flex-1 h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs text-slate-900 dark:text-slate-100"
            />
            <button
              type="button"
              disabled={busy || !customTopic.trim()}
              onClick={() => void onGenerate('analyze-topic', { customTopic })}
              className="h-10 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold disabled:opacity-60 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0"
            >
              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
              <span>Analyze Topic</span>
            </button>
          </div>
        </div>
      </div>

      {/* Creative Director Recommendation Note */}
      {stage1.directorComment && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-1">
            Creative Director Recommendation
          </div>
          {stage1.directorComment}
        </div>
      )}

      {/* Generated 10 Topic Cards */}
      {stage1.generatedIdeas.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Select One Topic to Develop ({stage1.generatedIdeas.length} Generated)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
            {stage1.generatedIdeas.map((idea, idx) => {
              const selected = stage1.selectedTopic?.id === idea.id;
              return (
                <button
                  key={idea.id}
                  type="button"
                  onClick={() => void selectIdea(idea)}
                  className={`text-left rounded-xl border p-4 space-y-2 transition-colors ${
                    selected
                      ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/20'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                      0{idx + 1}.
                    </span>
                    {selected && (
                      <span className="text-xs font-semibold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" /> Selected
                      </span>
                    )}
                  </div>
                  <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    {idea.title}
                  </div>
                  <div className="text-xs text-slate-600 dark:text-slate-300 space-y-1 leading-relaxed">
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200">Audience:</strong>{' '}
                      {idea.targetAudience}
                    </div>
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200">Problem:</strong>{' '}
                      {idea.mainAudienceProblem}
                    </div>
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200">Transformation:</strong>{' '}
                      {idea.viewerTransformation}
                    </div>
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200">Why it clicks:</strong>{' '}
                      {idea.whyAttractive}
                    </div>
                    <div>
                      <strong className="text-slate-800 dark:text-slate-200">Story angle:</strong>{' '}
                      {idea.storytellingAngle}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Custom Topic Analysis */}
      {stage1.topicAnalysis && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Topic Breakdown & Opportunity Analysis
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            {[
              { label: 'Central Idea', val: stage1.topicAnalysis.centralIdea },
              { label: 'Target Viewer', val: stage1.topicAnalysis.targetViewer },
              { label: 'Main Problem', val: stage1.topicAnalysis.mainProblem },
              { label: 'Desired Outcome', val: stage1.topicAnalysis.desiredOutcome },
              { label: 'Curiosity Gap', val: stage1.topicAnalysis.curiosityGap },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3"
              >
                <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                  {item.label}
                </div>
                <p className="mt-1 text-slate-800 dark:text-slate-200 leading-relaxed">{item.val}</p>
              </div>
            ))}
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                Content Opportunities
              </div>
              <ul className="mt-1 space-y-1 text-slate-800 dark:text-slate-200 list-disc pl-4">
                {stage1.topicAnalysis.contentOpportunities.map((opp, i) => (
                  <li key={i}>{opp}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* Selected Topic Inline Edit Box */}
      {stage1.selectedTopic && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
              Selected Topic Ready for Packaging
            </span>
            <button
              type="button"
              onClick={() => setEditingSelected(!editingSelected)}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>{editingSelected ? 'Done Editing' : 'Edit Topic Details'}</span>
            </button>
          </div>
          {editingSelected ? (
            <div className="space-y-2.5 text-xs">
              <input
                type="text"
                value={stage1.selectedTopic.title}
                onChange={(e) =>
                  void onPatchStage(1, {
                    selectedTopic: { ...stage1.selectedTopic!, title: e.target.value },
                  })
                }
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
              />
              <input
                type="text"
                value={stage1.selectedTopic.storytellingAngle}
                onChange={(e) =>
                  void onPatchStage(1, {
                    selectedTopic: { ...stage1.selectedTopic!, storytellingAngle: e.target.value },
                  })
                }
                placeholder="Storytelling angle"
                className="w-full h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>
          ) : (
            <div>
              <div className="font-display text-base font-bold text-slate-950 dark:text-white">
                {stage1.selectedTopic.title}
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                Target Viewer: {stage1.selectedTopic.targetAudience} · Storytelling Angle:{' '}
                {stage1.selectedTopic.storytellingAngle}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

interface SavedCompetitorOptionResponse {
  workspaceCompetitors?: Array<{
    id: number;
    channelId: string;
    title: string;
    handle: string;
    channelUrl: string;
    thumbnailUrl: string;
    subscriberCount: number;
    notes: string;
  }>;
  reports?: Array<{
    reportKey: string;
    title: string;
    status: string;
    updatedAt: string;
    channelTitles: string[];
    channelIds: string[];
    executiveSummary: string;
    titlePatterns: string[];
    hookAngles: string[];
    contentGaps: string[];
  }>;
  cachedChannels?: Array<{
    channelId: string;
    handle: string;
    title: string;
    channelUrl: string;
  }>;
}

export function Stage2PackagingView({
  project,
  busy,
  studioFetch,
  onSaveCompetitorResearch,
  onPatchStage,
  onGenerate,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  studioFetch: (url: string, init?: RequestInit) => Promise<Response>;
  onSaveCompetitorResearch: (
    payload: Omit<ScriptCompetitorResearchContext, 'updatedAt'>
  ) => Promise<void>;
  onPatchStage: (stage: 2, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
}) {
  const { stage1, stage2, competitorResearch } = project.state;
  const wordCountThumb = stage2.selectedThumbnailText.trim()
    ? stage2.selectedThumbnailText.trim().split(/\s+/).length
    : 0;

  const [showResearchPanel, setShowResearchPanel] = useState<boolean>(
    () => !competitorResearch && !stage2.videoPromise && stage2.titleConcepts.length === 0
  );
  const [loadingCompOptions, setLoadingCompOptions] = useState<boolean>(false);
  const [compOptions, setCompOptions] = useState<SavedCompetitorOptionResponse>({});
  const [selectedChannelIds, setSelectedChannelIds] = useState<string[]>(
    competitorResearch?.selectedChannelIds || []
  );
  const [selectedChannelTitles, setSelectedChannelTitles] = useState<string[]>(
    competitorResearch?.selectedChannelTitles || []
  );
  const [selectedReportKey, setSelectedReportKey] = useState<string | null>(
    competitorResearch?.reportKey || null
  );
  const [competitorSummary, setCompetitorSummary] = useState<string>(
    competitorResearch?.competitorSummary || ''
  );
  const [keyTitlePatterns, setKeyTitlePatterns] = useState<string>(
    (competitorResearch?.keyTitlePatterns || []).join('\n')
  );
  const [keyHookAngles, setKeyHookAngles] = useState<string>(
    (competitorResearch?.keyHookAngles || []).join('\n')
  );
  const [contentGaps, setContentGaps] = useState<string>(
    (competitorResearch?.contentGaps || []).join('\n')
  );

  useEffect(() => {
    if (!showResearchPanel) return;
    let cancelled = false;
    setLoadingCompOptions(true);
    studioFetch('/api/v1/script-studio/competitor-options')
      .then((res) => parseSafeJsonResponse<SavedCompetitorOptionResponse>(res))
      .then((data) => {
        if (!cancelled) setCompOptions(data);
      })
      .catch(() => {})
      .finally(() => {
        if (!cancelled) setLoadingCompOptions(false);
      });
    return () => {
      cancelled = true;
    };
  }, [showResearchPanel, studioFetch]);

  const savedChannels = [
    ...(compOptions.workspaceCompetitors || []).map((c) => ({
      channelId: c.channelId,
      title: c.title,
      handle: c.handle,
      notes: c.notes,
    })),
    ...(compOptions.cachedChannels || [])
      .filter(
        (c) =>
          !(compOptions.workspaceCompetitors || []).some((w) => w.channelId === c.channelId)
      )
      .map((c) => ({
        channelId: c.channelId,
        title: c.title,
        handle: c.handle,
        notes: '',
      })),
  ];

  const toggleCompetitorChannel = (ch: { channelId: string; title: string; notes?: string }) => {
    const exists = selectedChannelIds.includes(ch.channelId);
    if (exists) {
      const nextIds = selectedChannelIds.filter((id) => id !== ch.channelId);
      const nextTitles = selectedChannelTitles.filter((t) => t !== ch.title);
      setSelectedChannelIds(nextIds);
      setSelectedChannelTitles(nextTitles);
    } else {
      setSelectedChannelIds([...selectedChannelIds, ch.channelId]);
      setSelectedChannelTitles([...selectedChannelTitles, ch.title]);
      if (ch.notes && !competitorSummary.includes(ch.notes)) {
        setCompetitorSummary((prev) => (prev ? `${prev}\n${ch.title}: ${ch.notes}` : `${ch.title}: ${ch.notes}`));
      }
    }
  };

  const applySavedReport = (rep: NonNullable<SavedCompetitorOptionResponse['reports']>[number]) => {
    setSelectedReportKey(rep.reportKey);
    setSelectedChannelIds(rep.channelIds);
    setSelectedChannelTitles(rep.channelTitles);
    if (rep.executiveSummary) setCompetitorSummary(rep.executiveSummary);
    if (rep.titlePatterns.length > 0) setKeyTitlePatterns(rep.titlePatterns.join('\n'));
    if (rep.hookAngles.length > 0) setKeyHookAngles(rep.hookAngles.join('\n'));
    if (rep.contentGaps.length > 0) setContentGaps(rep.contentGaps.join('\n'));
  };

  const handleApplyResearch = async (skip: boolean) => {
    await onSaveCompetitorResearch({
      selectedChannelIds: skip ? [] : selectedChannelIds,
      selectedChannelTitles: skip ? [] : selectedChannelTitles,
      reportKey: skip ? null : selectedReportKey,
      competitorSummary: skip ? '' : competitorSummary.trim(),
      keyTitlePatterns: skip
        ? []
        : keyTitlePatterns
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean),
      keyHookAngles: skip
        ? []
        : keyHookAngles
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean),
      contentGaps: skip
        ? []
        : contentGaps
            .split('\n')
            .map((s) => s.trim())
            .filter(Boolean),
      skipped: skip,
    });
    setShowResearchPanel(false);
  };

  if (!stage2.videoPromise && stage2.titleConcepts.length === 0) {
    return (
      <div className="space-y-4">
        {/* Optional Competitor Research Step (Between Stage 1 Topic & Stage 2 Packaging) */}
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <div className="text-xs font-semibold text-blue-600 dark:text-blue-400">
                Optional Pre-Packaging Step · Competitor Research
              </div>
              <h3 className="font-display text-base font-bold text-slate-950 dark:text-white mt-0.5">
                Analyze Saved Competitors Before Packaging
              </h3>
              <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
                Select previously saved competitor channels or a Competitor Intelligence report without re-entering URLs—or skip directly to packaging.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setShowResearchPanel(!showResearchPanel)}
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 whitespace-nowrap"
            >
              {showResearchPanel ? 'Collapse Panel' : 'Choose Saved Competitors'}
            </button>
          </div>

          {competitorResearch && !competitorResearch.skipped && !showResearchPanel && (
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-xs text-slate-700 dark:text-slate-200 flex flex-wrap items-center justify-between gap-2">
              <span>
                Active research context:{' '}
                <strong>
                  {competitorResearch.selectedChannelTitles.join(', ') || 'Custom competitor notes'}
                </strong>
                {competitorResearch.contentGaps.length > 0
                  ? ` · ${competitorResearch.contentGaps.length} content gap(s) loaded`
                  : ''}
              </span>
              <button
                type="button"
                onClick={() => setShowResearchPanel(true)}
                className="text-blue-600 dark:text-blue-400 font-semibold underline"
              >
                Edit Research
              </button>
            </div>
          )}

          {showResearchPanel && (
            <div className="space-y-4 pt-2 border-t border-slate-100 dark:border-slate-800">
              {loadingCompOptions ? (
                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  <span>Loading saved competitors and reports...</span>
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                      Saved Competitor Channels ({savedChannels.length})
                    </div>
                    {savedChannels.length === 0 ? (
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        No saved channels yet. Add competitors inside YouTube Management or Competitor Intelligence Studio, or paste notes on the right.
                      </p>
                    ) : (
                      <div className="max-h-44 overflow-y-auto space-y-1.5 pr-1">
                        {savedChannels.map((ch) => {
                          const active = selectedChannelIds.includes(ch.channelId);
                          return (
                            <button
                              key={ch.channelId}
                              type="button"
                              onClick={() => toggleCompetitorChannel(ch)}
                              className={`w-full text-left px-3 py-2 rounded-lg border text-xs flex items-center justify-between gap-2 transition-colors ${
                                active
                                  ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-950 dark:text-white'
                                  : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300'
                              }`}
                            >
                              <span className="truncate font-medium">
                                {ch.title} {ch.handle ? `(${ch.handle})` : ''}
                              </span>
                              {active && <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {(compOptions.reports || []).length > 0 && (
                      <div className="pt-2 space-y-1.5">
                        <div className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                          Import From Saved Competitor Reports
                        </div>
                        <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                          {(compOptions.reports || []).map((rep) => (
                            <button
                              key={rep.reportKey}
                              type="button"
                              onClick={() => applySavedReport(rep)}
                              className={`w-full text-left px-3 py-2 rounded-lg border text-xs transition-colors ${
                                selectedReportKey === rep.reportKey
                                  ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/30'
                                  : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                              }`}
                            >
                              <div className="font-semibold text-slate-900 dark:text-white truncate">
                                {rep.title}
                              </div>
                              <div className="text-[11px] text-slate-500 truncate">
                                {rep.channelTitles.join(', ') || rep.status}
                              </div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">
                        Competitor Summary & Positioning Notes
                      </label>
                      <textarea
                        rows={2}
                        value={competitorSummary}
                        onChange={(e) => setCompetitorSummary(e.target.value)}
                        placeholder="Key patterns you want Stage 2 titles, thumbnails, and hooks to beat..."
                        className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      <div>
                        <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">
                          Winning Title Patterns (1 per line)
                        </label>
                        <textarea
                          rows={3}
                          value={keyTitlePatterns}
                          onChange={(e) => setKeyTitlePatterns(e.target.value)}
                          placeholder="Why X Fails After Y Days..."
                          className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                        />
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">
                          Content Gaps / Hook Angles (1 per line)
                        </label>
                        <textarea
                          rows={3}
                          value={contentGaps}
                          onChange={(e) => setContentGaps(e.target.value)}
                          placeholder="Competitors skip step-by-step budget breakdown..."
                          className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void handleApplyResearch(true)}
                  className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
                >
                  Skip Competitor Research
                </button>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void handleApplyResearch(false)}
                  className="h-9 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>Save Competitor Context for Packaging</span>
                </button>
              </div>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 text-center space-y-3">
          <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Stage 2 · Packaging Comes Before Scriptwriting
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
            Based on your approved topic (“{stage1.selectedTopic?.title}”), we will define the core{' '}
            <strong>Expectations vs. Reality</strong> promise, craft 5 distinct title angles, design 3 visual thumbnail concepts, and test 2–4 word thumbnail text.
          </p>
          <button
            type="button"
            disabled={busy}
            onClick={() => void onGenerate('packaging', { scope: 'all' })}
            className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
          >
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>Generate Packaging Strategy</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {stage2.directorComment && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-1">
            Creative Director Packaging Note
          </div>
          {stage2.directorComment}
        </div>
      )}

      {/* 2.1 Video Promise */}
      {stage2.videoPromise && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            2.1 The Video Promise (Expectations vs. Reality)
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3">
              <div className="font-semibold text-slate-500">What It Is About</div>
              <p className="mt-1 text-slate-800 dark:text-slate-200">{stage2.videoPromise.whatVideoIsAbout}</p>
            </div>
            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3">
              <div className="font-semibold text-slate-500">Viewer Expectation</div>
              <p className="mt-1 text-slate-800 dark:text-slate-200">{stage2.videoPromise.viewerExpectation}</p>
            </div>
            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3">
              <div className="font-semibold text-slate-500">Problem Solved & Why Interesting</div>
              <p className="mt-1 text-slate-800 dark:text-slate-200">
                {stage2.videoPromise.problemSolved} — {stage2.videoPromise.whyInteresting}
              </p>
            </div>
            <div className="rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3">
              <div className="font-semibold text-slate-500">Central Curiosity Gap</div>
              <p className="mt-1 text-slate-800 dark:text-slate-200">{stage2.videoPromise.centralCuriosityGap}</p>
            </div>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            <strong>Expectations vs. Reality Alignment:</strong> {stage2.videoPromise.expectationsVsRealityNote}
          </p>
        </div>
      )}

      {/* 2.2 Five Distinct Video Titles */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            2.2 Choose or Customize Your Video Title (5 Angles)
          </h4>
          <button
            type="button"
            disabled={busy}
            onClick={() => void onGenerate('packaging', { scope: 'titles' })}
            className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>New Title Options</span>
          </button>
        </div>

        <div className="space-y-2.5">
          {stage2.titleConcepts.map((tc) => {
            const active = stage2.selectedTitleId === tc.id;
            return (
              <button
                key={tc.id}
                type="button"
                onClick={() =>
                  void onPatchStage(2, {
                    selectedTitleId: tc.id,
                    customTitleText: tc.title,
                  })
                }
                className={`w-full text-left rounded-xl border p-4 transition-colors ${
                  active
                    ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/20'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 dark:text-slate-400">
                  <span>
                    {tc.angleLabel} · {tc.psychologicalAngle}
                  </span>
                  <span className="font-semibold text-blue-600 dark:text-blue-400">
                    {tc.isRecommended ? 'Recommended' : ''}
                    {tc.isRecommended && active ? ' · ' : ''}
                    {active ? 'Selected' : ''}
                  </span>
                </div>
                <div className="font-display text-base font-bold text-slate-950 dark:text-white mt-1">
                  {tc.title}
                </div>
                <div className="mt-2 grid grid-cols-1 md:grid-cols-3 gap-2 text-xs text-slate-600 dark:text-slate-300">
                  <div>
                    <strong>Promise:</strong> {tc.viewerPromise}
                  </div>
                  <div>
                    <strong>Why clicks:</strong> {tc.whyItAttractsClicks}
                  </div>
                  <div>
                    <strong>Watch out:</strong> {tc.potentialLimitation}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        <div className="pt-2">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
            Active Working Title (edit directly if desired)
          </label>
          <input
            type="text"
            value={stage2.customTitleText}
            onChange={(e) => void onPatchStage(2, { customTitleText: e.target.value })}
            className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-semibold text-slate-950 dark:text-white"
          />
        </div>
      </div>

      {/* 2.3 Thumbnail Concepts & 2.4 Thumbnail Text */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            2.3 Visual Thumbnail Concepts & 2.4 Short Thumbnail Text
          </h4>
          <button
            type="button"
            disabled={busy}
            onClick={() => void onGenerate('packaging', { scope: 'thumbnails' })}
            className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>New Thumbnail Ideas</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {stage2.thumbnailConcepts.map((th) => {
            const active = stage2.selectedThumbnailId === th.id;
            return (
              <button
                key={th.id}
                type="button"
                onClick={() => void onPatchStage(2, { selectedThumbnailId: th.id })}
                className={`text-left rounded-xl border p-4 space-y-2 transition-colors text-xs ${
                  active
                    ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/20'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    {th.conceptName}
                  </span>
                  {active && (
                    <span className="font-semibold text-blue-600 dark:text-blue-400">Selected</span>
                  )}
                </div>
                <div className="space-y-1 text-slate-600 dark:text-slate-300 leading-relaxed">
                  <div><strong>Subject:</strong> {th.mainSubject}</div>
                  <div><strong>Positioning:</strong> {th.positioning}</div>
                  <div><strong>Expression:</strong> {th.facialExpression}</div>
                  <div><strong>Background:</strong> {th.background}</div>
                  <div><strong>Composition & Lighting:</strong> {th.composition} · {th.lighting}</div>
                  <div><strong>Visual Contrast:</strong> {th.visualContrast}</div>
                  <div><strong>Emotion:</strong> {th.emotionalTrigger}</div>
                  <div><strong>Story:</strong> {th.visualStorytelling}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* 2.4 Thumbnail Text */}
        <div className="pt-2 space-y-2.5">
          <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300">
            2.4 Thumbnail Text (2–4 words recommended for mobile legibility)
          </label>
          <div className="flex flex-wrap gap-2">
            {stage2.thumbnailTextOptions.map((opt) => {
              const selected = stage2.selectedThumbnailText === opt;
              return (
                <button
                  key={opt}
                  type="button"
                  onClick={() => void onPatchStage(2, { selectedThumbnailText: opt })}
                  className={`h-9 px-3.5 rounded-lg border text-xs font-bold transition-colors ${
                    selected
                      ? 'border-blue-600 bg-[#0F172A] dark:bg-blue-600 text-white'
                      : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-800 dark:text-slate-200'
                  }`}
                >
                  {opt}
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-3">
            <input
              type="text"
              value={stage2.selectedThumbnailText}
              onChange={(e) => void onPatchStage(2, { selectedThumbnailText: e.target.value })}
              placeholder="Or type custom 2-4 word thumbnail text"
              className="flex-1 h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-bold uppercase tracking-wide"
            />
            <span
              className={`text-xs font-mono tabular-nums ${
                wordCountThumb > 4 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-500'
              }`}
            >
              {wordCountThumb} words
            </span>
          </div>
        </div>
      </div>

      {/* 2.5 Final Packaging Approval Summary */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-5 space-y-2 text-xs">
        <div className="text-[11px] font-semibold uppercase tracking-wide text-blue-600 dark:text-blue-400">
          2.5 Packaging Summary Ready for Approval
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-slate-700 dark:text-slate-200">
          <div><strong>Selected Title:</strong> {stage2.customTitleText || 'None selected'}</div>
          <div><strong>Thumbnail Text:</strong> {stage2.selectedThumbnailText || 'None selected'}</div>
          <div>
            <strong>Thumbnail Concept:</strong>{' '}
            {stage2.thumbnailConcepts.find((c) => c.id === stage2.selectedThumbnailId)?.conceptName || 'None'}
          </div>
          <div><strong>Target Audience:</strong> {stage1.selectedTopic?.targetAudience}</div>
        </div>
        <p className="text-slate-600 dark:text-slate-300 pt-1">
          <strong>Core Promise:</strong> {stage2.videoPromise?.whatVideoIsAbout}
        </p>
        <p className="font-semibold text-slate-950 dark:text-white pt-1">
          Do you approve this video packaging, or would you like to make changes?
        </p>
      </div>
    </div>
  );
}

export function Stage3OutlineView({
  project,
  busy,
  onPatchStage,
  onGenerate,
}: {
  project: ScriptProjectRecord;
  busy: boolean;
  onPatchStage: (stage: 3, data: Record<string, unknown>) => Promise<void>;
  onGenerate: (operation: string, extra?: Record<string, unknown>) => Promise<void>;
}) {
  const { stage3 } = project.state;
  const [editingId, setEditingId] = useState<string | null>(null);

  if (stage3.sections.length === 0) {
    return (
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 text-center space-y-3">
        <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
          Stage 3 · Research, Originality & Retention Outline
        </h3>
        <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
          Before writing any narration, we will map out verified claims vs. illustrations, remove repetitive common filler, place your second-best insight early, and build toward your strongest payoff.
        </p>
        <button
          type="button"
          disabled={busy}
          onClick={() => void onGenerate('outline')}
          className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 disabled:opacity-60"
        >
          {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
          <span>Build Content Outline</span>
        </button>
      </div>
    );
  }

  const moveSection = async (index: number, delta: -1 | 1) => {
    const target = index + delta;
    if (target < 0 || target >= stage3.sections.length) return;
    const copy = [...stage3.sections];
    const [moved] = copy.splice(index, 1);
    copy.splice(target, 0, moved);
    await onPatchStage(3, {
      sections: copy.map((s, idx) => ({ ...s, order: idx + 1 })),
    });
  };

  const deleteSection = async (index: number) => {
    if (stage3.sections.length <= 1) return;
    const copy = stage3.sections.filter((_s, i) => i !== index);
    await onPatchStage(3, {
      sections: copy.map((s, idx) => ({ ...s, order: idx + 1 })),
    });
  };

  const addCustomSection = async () => {
    const newSec: OutlineSection = {
      id: `sec-custom-${Date.now()}`,
      order: stage3.sections.length + 1,
      heading: `New Section ${stage3.sections.length + 1}`,
      mainIdea: 'Key takeaway for this segment',
      whatViewerLearns: 'Practical insight or perspective',
      supportingExplanation: 'Clear human explanation',
      exampleOrStory: 'Real-world scenario or concrete example',
      curiosityElement: 'Open question leading to the payoff',
      transitionToNext: 'Smooth bridge into next section',
      estimatedMinutes: 1.5,
    };
    await onPatchStage(3, { sections: [...stage3.sections, newSec] });
    setEditingId(newSec.id);
  };

  const updateSectionField = (
    id: string,
    field: keyof OutlineSection,
    value: string | number
  ) => {
    const updated = stage3.sections.map((s) =>
      s.id === id ? { ...s, [field]: value } : s
    );
    void onPatchStage(3, { sections: updated });
  };

  return (
    <div className="space-y-6">
      {stage3.directorComment && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs sm:text-sm text-slate-700 dark:text-slate-200 leading-relaxed">
          <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400 mb-1">
            Creative Director Outline Strategy
          </div>
          {stage3.directorComment}
          {stage3.retentionArchitectureNote && (
            <p className="mt-2 text-xs text-slate-600 dark:text-slate-400">
              <strong>Retention Architecture:</strong> {stage3.retentionArchitectureNote}
            </p>
          )}
        </div>
      )}

      {/* 3.1 Research & Originality Notes */}
      {stage3.research && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            3.1 Research, Fact Verification & Originality Filter
          </h4>

          {stage3.research.verifiedFactsNeeded.length > 0 && (
            <div className="rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50/70 dark:bg-amber-950/20 p-4 text-xs text-amber-900 dark:text-amber-200 space-y-1.5">
              <div className="font-semibold flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 shrink-0" />
                <span>Claims Requiring Verification Before Filming</span>
              </div>
              <ul className="list-disc pl-5 space-y-1">
                {stage3.research.verifiedFactsNeeded.map((claim, i) => (
                  <li key={i}>{claim}</li>
                ))}
              </ul>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="font-semibold text-slate-500 mb-1">Less Obvious Insights</div>
              <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                {stage3.research.lessObviousInsights.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="font-semibold text-slate-500 mb-1">Common Knowledge to Keep Brief</div>
              <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                {stage3.research.commonKnowledgeToAvoid.map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="font-semibold text-slate-500 mb-1">Frameworks & Unique Angles</div>
              <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                {[...stage3.research.usefulFrameworks, ...stage3.research.uniquePerspectives].map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3">
              <div className="font-semibold text-slate-500 mb-1">Stories & Practical Examples</div>
              <ul className="list-disc pl-4 space-y-1 text-slate-700 dark:text-slate-300">
                {[...stage3.research.memorableStories, ...stage3.research.practicalExamples].map((x, i) => (
                  <li key={i}>{x}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}

      {/* 3.2 Ordered Outline Sections */}
      <div className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            3.2 Content Architecture ({stage3.sections.length} Sections)
          </h4>
          <button
            type="button"
            onClick={() => void addCustomSection()}
            className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Section</span>
          </button>
        </div>

        <div className="space-y-3">
          {stage3.sections.map((sec, idx) => {
            const isEditing = editingId === sec.id;
            return (
              <div
                key={sec.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 tabular-nums">
                      0{idx + 1}.
                    </span>
                    <span className="font-display text-sm font-bold text-slate-950 dark:text-white truncate">
                      {sec.heading}
                    </span>
                    <span className="text-xs font-mono tabular-nums text-slate-500">
                      · ~{sec.estimatedMinutes} min
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => void moveSection(idx, -1)}
                      aria-label="Move section up"
                      className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                    >
                      <ArrowUp className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === stage3.sections.length - 1}
                      onClick={() => void moveSection(idx, 1)}
                      aria-label="Move section down"
                      className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-30"
                    >
                      <ArrowDown className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingId(isEditing ? null : sec.id)}
                      className="px-2.5 py-1 rounded-lg text-xs font-semibold text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/30"
                    >
                      {isEditing ? 'Done' : 'Edit'}
                    </button>
                    {stage3.sections.length > 1 && (
                      <button
                        type="button"
                        onClick={() => void deleteSection(idx)}
                        aria-label="Remove section"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {isEditing ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="block font-semibold text-slate-500 mb-1">Heading</label>
                      <input
                        type="text"
                        value={sec.heading}
                        onChange={(e) => updateSectionField(sec.id, 'heading', e.target.value)}
                        className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-500 mb-1">Main Idea</label>
                      <input
                        type="text"
                        value={sec.mainIdea}
                        onChange={(e) => updateSectionField(sec.id, 'mainIdea', e.target.value)}
                        className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-500 mb-1">What Viewer Learns</label>
                      <input
                        type="text"
                        value={sec.whatViewerLearns}
                        onChange={(e) => updateSectionField(sec.id, 'whatViewerLearns', e.target.value)}
                        className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-500 mb-1">Example or Story</label>
                      <input
                        type="text"
                        value={sec.exampleOrStory}
                        onChange={(e) => updateSectionField(sec.id, 'exampleOrStory', e.target.value)}
                        className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-500 mb-1">Curiosity Element</label>
                      <input
                        type="text"
                        value={sec.curiosityElement}
                        onChange={(e) => updateSectionField(sec.id, 'curiosityElement', e.target.value)}
                        className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-slate-500 mb-1">Transition</label>
                      <input
                        type="text"
                        value={sec.transitionToNext}
                        onChange={(e) => updateSectionField(sec.id, 'transitionToNext', e.target.value)}
                        className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    <div><strong>Main idea:</strong> {sec.mainIdea}</div>
                    <div><strong>Viewer learns:</strong> {sec.whatViewerLearns}</div>
                    <div><strong>Explanation:</strong> {sec.supportingExplanation}</div>
                    <div><strong>Example / story:</strong> {sec.exampleOrStory}</div>
                    <div><strong>Curiosity hook:</strong> {sec.curiosityElement}</div>
                    <div><strong>Transition:</strong> {sec.transitionToNext}</div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <span>
            You can reorder, edit, add, or remove outline sections above before approving. Once approved, we will write the Introduction and each Main Body section one by one.
          </span>
        </div>
      </div>
    </div>
  );
}
