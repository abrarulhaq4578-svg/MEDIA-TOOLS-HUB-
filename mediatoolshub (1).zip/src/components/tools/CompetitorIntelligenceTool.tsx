import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Loader2,
  RefreshCw,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import { ApiClientError, parseSafeJsonResponse } from '../../lib/apiClient.ts';
import type {
  CompetitorChannelProfile,
  CompetitorChannelSearchResult,
  CompetitorHubSummary,
  CompetitorReportRecord,
  ScriptAiModelId,
  ScriptStudioSeed,
  YtmChannelProfileWithDna,
} from '../../shared/types.ts';
import {
  HubAndBuilderView,
  SingleChannelDeepDiveView,
} from './competitorIntel/ChannelViews.tsx';
import {
  CompetitorComparisonView,
  FullReport19View,
  GapFinderOpportunitiesView,
  GrowthBlueprintView,
} from './competitorIntel/ComparisonAndSynthesisViews.tsx';
import {
  SaveInspirationModal,
  type SaveInspirationDraft,
} from '../ytm/SaveInspirationModal.tsx';

function getOrCreateGuestToken(): string {
  if (typeof window === 'undefined') return 'guest_ssr_default';
  const existing = window.localStorage.getItem('mth_script_guest_token');
  if (existing && /^[a-zA-Z0-9_-]{8,120}$/.test(existing)) return existing;
  const generated = `mth_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
  window.localStorage.setItem('mth_script_guest_token', generated);
  return generated;
}

export interface CompetitorIntelligenceToolProps {
  embeddedInYtm?: boolean;
  workspaceKey?: string;
  channelProfiles?: YtmChannelProfileWithDna[];
  activeChannelProfileId?: number | null;
  initialReportKey?: string | null;
  onSendOpportunityToWorkflow?: (seed: ScriptStudioSeed) => void;
  onOpenPlanner?: () => void;
}

export function CompetitorIntelligenceTool({
  embeddedInYtm = false,
  workspaceKey,
  channelProfiles,
  activeChannelProfileId,
  initialReportKey,
  onSendOpportunityToWorkflow,
  onOpenPlanner,
}: CompetitorIntelligenceToolProps = {}) {
  const { authFetch, firebaseUser, signInWithGoogle, openScriptStudioWithSeed } = useApp();
  const [guestToken] = useState<string>(() => getOrCreateGuestToken());
  const [saveDraft, setSaveDraft] = useState<SaveInspirationDraft | null>(null);
  const [plannerNotice, setPlannerNotice] = useState<string | null>(null);

  const [hub, setHub] = useState<CompetitorHubSummary>({
    reports: [],
    cachedChannels: [],
  });
  const [loadingHub, setLoadingHub] = useState(true);
  const [activeReport, setActiveReport] = useState<CompetitorReportRecord | null>(null);

  // Builder state
  const [selectedChannels, setSelectedChannels] = useState<CompetitorChannelProfile[]>([]);
  const [ownChannelInput, setOwnChannelInput] = useState('');
  const [sampleSize, setSampleSize] = useState(20);
  const [modelName, setModelName] = useState<ScriptAiModelId>('gemini-4-hydrogen');
  const [directInput, setDirectInput] = useState('');
  const [resolving, setResolving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<CompetitorChannelSearchResult[]>([]);
  const [searching, setSearching] = useState(false);

  // Pipeline state
  const [runningPipeline, setRunningPipeline] = useState(false);
  const [progressStage, setProgressStage] = useState<string | null>(null);
  const [runningChannelId, setRunningChannelId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [errorCode, setErrorCode] = useState<string | null>(null);

  // Workspace view switcher
  const [workspaceTab, setWorkspaceTab] = useState<
    'comparison' | 'individual' | 'gaps' | 'growth' | 'report19'
  >('comparison');

  const intelFetch = useCallback(
    async (url: string, init: RequestInit = {}) => {
      const headers = new Headers(init.headers || {});
      headers.set('x-script-guest-token', guestToken);
      if (init.body && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json');
      }
      return authFetch(url, { ...init, headers });
    },
    [authFetch, guestToken]
  );

  const loadHub = useCallback(async () => {
    try {
      const res = await intelFetch('/api/v1/competitor-intel/hub');
      const data = await parseSafeJsonResponse<{
        reports?: CompetitorHubSummary['reports'];
        cachedChannels?: CompetitorHubSummary['cachedChannels'];
      }>(res);
      setHub({
        reports: data.reports || [],
        cachedChannels: data.cachedChannels || [],
      });
    } catch {
      // Non-blocking hub refresh
    } finally {
      setLoadingHub(false);
    }
  }, [intelFetch]);

  useEffect(() => {
    void loadHub();
  }, [loadHub, firebaseUser?.uid]);

  const handleSearchChannels = async () => {
    const q = searchQuery.trim();
    if (q.length < 2) return;
    setErrorMsg(null);
    setErrorCode(null);
    setSearching(true);
    try {
      const res = await intelFetch(
        `/api/v1/competitor-intel/channels/search?q=${encodeURIComponent(q)}`
      );
      const data = await parseSafeJsonResponse<{ results?: CompetitorChannelSearchResult[] }>(res);
      setSearchResults(data.results || []);
      if ((data.results || []).length === 0) {
        setErrorMsg(`No YouTube channels found matching "${q}". Try pasting the @handle or channel URL.`);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to search channels.');
      if (err instanceof ApiClientError) setErrorCode(err.code || null);
    } finally {
      setSearching(false);
    }
  };

  const handleResolveAndAdd = async (inputOverride?: string) => {
    const target = (inputOverride ?? directInput).trim();
    if (!target || selectedChannels.length >= 10) return;
    setErrorMsg(null);
    setErrorCode(null);
    setResolving(true);
    try {
      const res = await intelFetch('/api/v1/competitor-intel/channels/resolve', {
        method: 'POST',
        body: JSON.stringify({ input: target }),
      });
      const data = await parseSafeJsonResponse<{ channels?: CompetitorChannelProfile[] }>(res);
      const added = data.channels || [];
      if (added.length > 0) {
        setSelectedChannels((prev) => {
          const next = [...prev];
          for (const ch of added) {
            if (!next.some((existing) => existing.channelId === ch.channelId) && next.length < 10) {
              next.push(ch);
            }
          }
          return next;
        });
        if (!inputOverride) setDirectInput('');
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to resolve channel.');
      if (err instanceof ApiClientError) setErrorCode(err.code || null);
    } finally {
      setResolving(false);
    }
  };

  const handleRemoveChannel = (channelId: string) => {
    setSelectedChannels((prev) => prev.filter((c) => c.channelId !== channelId));
  };

  const runFullOrRemainingPipeline = async (
    startingReport: CompetitorReportRecord,
    modelOverride?: ScriptAiModelId
  ) => {
    const useModel = modelOverride || startingReport.modelName || modelName;
    setRunningPipeline(true);
    setErrorMsg(null);
    setErrorCode(null);
    let latest = startingReport;

    try {
      if (modelOverride && modelOverride !== startingReport.modelName) {
        const patchRes = await intelFetch(
          `/api/v1/competitor-intel/reports/${latest.reportKey}`,
          {
            method: 'PATCH',
            body: JSON.stringify({ modelName: useModel }),
          }
        );
        const patched = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(patchRes);
        latest = patched.report;
        setActiveReport(latest);
      }

      // 1. Collect if not yet collected
      if (latest.collections.length === 0) {
        setProgressStage(
          `Collecting live YouTube metrics & upload samples for ${latest.channelInputs.length} channels...`
        );
        const collectRes = await intelFetch(
          `/api/v1/competitor-intel/reports/${latest.reportKey}/collect`,
          {
            method: 'POST',
            body: JSON.stringify({ sampleSize: latest.sampleSize }),
          }
        );
        const collectedData = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(
          collectRes
        );
        latest = collectedData.report;
        setActiveReport(latest);
      }

      // 2. Run Modules 1-9 AI Deep-Dive sequentially for each un-analyzed channel (preserves partial progress)
      for (let i = 0; i < latest.collections.length; i++) {
        const col = latest.collections[i];
        if (latest.channelAnalyses[col.profile.channelId]) continue;

        setRunningChannelId(col.profile.channelId);
        setProgressStage(
          `Running AI Modules 1–9 for ${col.profile.title} (${i + 1}/${latest.collections.length}) using ${useModel}...`
        );

        const aiRes = await intelFetch(
          `/api/v1/competitor-intel/reports/${latest.reportKey}/analyze-channel`,
          {
            method: 'POST',
            body: JSON.stringify({
              channelId: col.profile.channelId,
              modelName: useModel,
            }),
          }
        );
        const aiData = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(aiRes);
        latest = aiData.report;
        setActiveReport(latest);
      }
      setRunningChannelId(null);

      // 3. Cross-Competitor Synthesis + Module 10 Gaps + Module 11 Plan + 19-Section Report
      if (!latest.synthesis) {
        setProgressStage(
          `Synthesizing cross-competitor comparison, 10 video gaps, 30-day plan & 19-section report...`
        );
        const synthRes = await intelFetch(
          `/api/v1/competitor-intel/reports/${latest.reportKey}/synthesize`,
          {
            method: 'POST',
            body: JSON.stringify({ modelName: useModel }),
          }
        );
        const synthData = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(synthRes);
        latest = synthData.report;
        setActiveReport(latest);
      }

      setProgressStage(null);
      await loadHub();
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : 'Competitor intelligence analysis interrupted.'
      );
      if (err instanceof ApiClientError) {
        setErrorCode(err.code || null);
      }
      setProgressStage(null);
    } finally {
      setRunningPipeline(false);
      setRunningChannelId(null);
    }
  };

  const handleStartAnalysis = async () => {
    if (selectedChannels.length < 1) return;
    setErrorMsg(null);
    setErrorCode(null);
    setRunningPipeline(true);
    setProgressStage('Initializing competitor research workspace...');
    try {
      const res = await intelFetch('/api/v1/competitor-intel/reports', {
        method: 'POST',
        body: JSON.stringify({
          title:
            selectedChannels
              .map((c) => c.title)
              .slice(0, 3)
              .join(' vs ') +
            (selectedChannels.length > 3 ? ` +${selectedChannels.length - 3}` : ''),
          channelInputs: selectedChannels.map((c) => c.channelId),
          ownChannelInput: ownChannelInput.trim() || null,
          sampleSize,
          modelName,
        }),
      });
      const data = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(res);
      setActiveReport(data.report);
      setWorkspaceTab('comparison');
      await runFullOrRemainingPipeline(data.report, modelName);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to start analysis.');
      if (err instanceof ApiClientError) setErrorCode(err.code || null);
      setRunningPipeline(false);
      setProgressStage(null);
    }
  };

  const handleOpenSavedReport = async (reportKey: string) => {
    setErrorMsg(null);
    setErrorCode(null);
    try {
      const res = await intelFetch(`/api/v1/competitor-intel/reports/${reportKey}`);
      const data = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(res);
      setActiveReport(data.report);
      setWorkspaceTab(data.report.synthesis ? 'comparison' : 'individual');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load saved report.');
    }
  };

  const handleDeleteReport = async (reportKey: string) => {
    try {
      await intelFetch(`/api/v1/competitor-intel/reports/${reportKey}`, {
        method: 'DELETE',
      });
      if (activeReport?.reportKey === reportKey) {
        setActiveReport(null);
      }
      await loadHub();
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to delete report.');
    }
  };

  const handleRunSingleChannelAi = async (channelId: string) => {
    if (!activeReport) return;
    setRunningChannelId(channelId);
    setErrorMsg(null);
    setErrorCode(null);
    try {
      const res = await intelFetch(
        `/api/v1/competitor-intel/reports/${activeReport.reportKey}/analyze-channel`,
        {
          method: 'POST',
          body: JSON.stringify({
            channelId,
            modelName: activeReport.modelName,
          }),
        }
      );
      const data = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(res);
      setActiveReport(data.report);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to analyze channel.');
      if (err instanceof ApiClientError) setErrorCode(err.code || null);
    } finally {
      setRunningChannelId(null);
    }
  };

  const handleSwitchModelAndResume = async () => {
    if (!activeReport) return;
    setModelName('gemini-3.1-flash-lite');
    await runFullOrRemainingPipeline(activeReport, 'gemini-3.1-flash-lite');
  };

  const handleSaveToPlanner = (draft: SaveInspirationDraft) => {
    if (!firebaseUser) {
      setPlannerNotice('Sign in with Google to save competitor inspiration directly into your Content Planner.');
      return;
    }
    setPlannerNotice(null);
    setSaveDraft(draft);
  };

  if (loadingHub && !activeReport) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-10 flex items-center justify-center gap-3 text-sm text-slate-600 dark:text-slate-300">
        <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
        <span>Loading Competitor Intelligence Studio...</span>
      </div>
    );
  }

  if (!activeReport) {
    return (
      <HubAndBuilderView
        hub={hub}
        selectedChannels={selectedChannels}
        ownChannelInput={ownChannelInput}
        onOwnChannelInputChange={setOwnChannelInput}
        sampleSize={sampleSize}
        onSampleSizeChange={setSampleSize}
        modelName={modelName}
        onModelNameChange={setModelName}
        searchQuery={searchQuery}
        onSearchQueryChange={setSearchQuery}
        searchResults={searchResults}
        searching={searching}
        onSearchChannels={() => void handleSearchChannels()}
        directInput={directInput}
        onDirectInputChange={setDirectInput}
        resolving={resolving}
        onResolveAndAdd={(override) => void handleResolveAndAdd(override)}
        onRemoveChannel={handleRemoveChannel}
        onStartAnalysis={() => void handleStartAnalysis()}
        onOpenSavedReport={(key) => void handleOpenSavedReport(key)}
        onDeleteReport={(key) => void handleDeleteReport(key)}
        running={runningPipeline}
        errorMsg={errorMsg}
      />
    );
  }

  const totalChannels = activeReport.collections.length;
  const analyzedCount = activeReport.collections.filter(
    (c) => Boolean(activeReport.channelAnalyses[c.profile.channelId])
  ).length;
  const isComplete = Boolean(activeReport.synthesis) && analyzedCount === totalChannels && totalChannels > 0;

  return (
    <div className="space-y-6">
      {/* Top Workspace Control Bar */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-start gap-3 min-w-0">
          <button
            type="button"
            onClick={() => {
              setActiveReport(null);
              setErrorMsg(null);
              setErrorCode(null);
              void loadHub();
            }}
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Hub & Channels</span>
          </button>
          <div className="min-w-0">
            <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white truncate">
              {activeReport.title}
            </h2>
            <div className="text-xs font-mono tabular-nums text-slate-500 dark:text-slate-400">
              {totalChannels} channels · {analyzedCount}/{totalChannels} AI deep-dives · Model:{' '}
              {activeReport.modelName} · Updated {new Date(activeReport.updatedAt).toLocaleString()}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {!isComplete && !runningPipeline && (
            <button
              type="button"
              onClick={() => void runFullOrRemainingPipeline(activeReport)}
              className="h-9 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Resume Remaining Analysis</span>
            </button>
          )}
          {isComplete && (
            <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400 inline-flex items-center gap-1.5 px-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>All 11 Modules + 19 Sections Complete</span>
            </span>
          )}
          <button
            type="button"
            disabled={runningPipeline}
            onClick={async () => {
              if (!activeReport) return;
              setRunningPipeline(true);
              setProgressStage('Refreshing live YouTube API metrics & outlier scores...');
              try {
                const res = await intelFetch(
                  `/api/v1/competitor-intel/reports/${activeReport.reportKey}/collect`,
                  {
                    method: 'POST',
                    body: JSON.stringify({ forceRefresh: true, sampleSize: activeReport.sampleSize }),
                  }
                );
                const data = await parseSafeJsonResponse<{ report: CompetitorReportRecord }>(res);
                setActiveReport(data.report);
              } catch (err) {
                setErrorMsg(err instanceof Error ? err.message : 'Unable to refresh YouTube metrics.');
              } finally {
                setRunningPipeline(false);
                setProgressStage(null);
              }
            }}
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh Data</span>
          </button>
        </div>
      </div>

      {/* Live Pipeline Progress */}
      {(runningPipeline || progressStage) && (
        <div className="rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/70 dark:bg-blue-950/30 p-4 flex items-center gap-3 text-sm text-blue-900 dark:text-blue-200">
          <Loader2 className="w-5 h-5 animate-spin shrink-0 text-blue-600 dark:text-blue-400" />
          <div className="space-y-0.5">
            <div className="font-semibold">Competitor Intelligence Pipeline Running</div>
            <div className="text-xs opacity-90">{progressStage || 'Processing...'}</div>
          </div>
        </div>
      )}

      {/* Error Recovery Banner with Preserved Partial Results */}
      {errorMsg && (
        <div
          role="alert"
          className="rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/30 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-sm text-rose-900 dark:text-rose-200"
        >
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold">Step Interrupted (Collected Data Preserved)</div>
              <p className="text-xs sm:text-sm opacity-90">{errorMsg}</p>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              disabled={runningPipeline}
              onClick={() => void runFullOrRemainingPipeline(activeReport)}
              className="px-3.5 py-2 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold"
            >
              Retry Step
            </button>
            {(errorCode === 'GEMINI_QUOTA_EXCEEDED' || activeReport.modelName !== 'gemini-3.1-flash-lite') && (
              <button
                type="button"
                disabled={runningPipeline}
                onClick={() => void handleSwitchModelAndResume()}
                className="px-3.5 py-2 rounded-lg border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-900 text-rose-800 dark:text-rose-200 text-xs font-semibold"
              >
                Switch to Gemini 3.1 Flash Lite & Retry
              </button>
            )}
          </div>
        </div>
      )}

      {/* Primary Workspace View Switcher */}
      <div
        role="tablist"
        aria-label="Competitor Intelligence workspace views"
        className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 p-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
      >
        {(
          [
            { id: 'comparison', label: 'Comparison Dashboard' },
            { id: 'individual', label: 'Single Channel (1–9)' },
            { id: 'gaps', label: '10 Gap Opportunities' },
            { id: 'growth', label: 'Growth & 30-Day Plan' },
            { id: 'report19', label: 'Full 19-Section Report' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setWorkspaceTab(tab.id)}
            className={`h-10 px-3 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
              workspaceTab === tab.id
                ? 'bg-[#0F172A] dark:bg-blue-600 text-white'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Planner Save Notification */}
      {plannerNotice && (
        <div className="rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/70 dark:bg-blue-950/30 p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs text-blue-900 dark:text-blue-200">
          <span>{plannerNotice}</span>
          <div className="flex items-center gap-2">
            {!firebaseUser && (
              <button
                type="button"
                onClick={() => void signInWithGoogle()}
                className="px-3 py-1.5 rounded-lg bg-blue-600 text-white font-semibold"
              >
                Sign in with Google
              </button>
            )}
            <button
              type="button"
              onClick={() => setPlannerNotice(null)}
              className="underline font-semibold"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* Active View */}
      {workspaceTab === 'comparison' && <CompetitorComparisonView report={activeReport} />}
      {workspaceTab === 'individual' && (
        <SingleChannelDeepDiveView
          report={activeReport}
          onRunSingleChannelAi={(id) => void handleRunSingleChannelAi(id)}
          runningChannelId={runningChannelId}
          onSaveToPlanner={handleSaveToPlanner}
        />
      )}
      {workspaceTab === 'gaps' && (
        <GapFinderOpportunitiesView
          report={activeReport}
          onCreateScriptFromOpportunity={(seed) => {
            if (embeddedInYtm && onSendOpportunityToWorkflow) {
              onSendOpportunityToWorkflow(seed);
            } else {
              openScriptStudioWithSeed(seed);
            }
          }}
          onSaveToPlanner={handleSaveToPlanner}
        />
      )}
      {workspaceTab === 'growth' && <GrowthBlueprintView report={activeReport} />}
      {workspaceTab === 'report19' && <FullReport19View report={activeReport} />}

      {/* Save to Planner Modal (stays inside Competitor Analysis without navigating away) */}
      <SaveInspirationModal
        open={Boolean(saveDraft)}
        draft={saveDraft}
        onClose={() => setSaveDraft(null)}
        authFetch={authFetch}
        workspaceKey={workspaceKey}
        channelProfiles={channelProfiles}
        defaultChannelProfileId={activeChannelProfileId}
        onSaved={(saved) => {
          setPlannerNotice(
            `Saved "${saved.originalVideoTitle}" to Content Planner → Saved Inspiration.`
          );
        }}
      />
      {embeddedInYtm && plannerNotice && onOpenPlanner && (
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onOpenPlanner}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
          >
            Open Content Planner → Saved Inspiration
          </button>
        </div>
      )}
    </div>
  );
}
