import { useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { Check, Copy, Download } from 'lucide-react';
import type { ToolDefinition } from '../../shared/types.ts';

function sortJsonDeep(val: unknown): unknown {
  if (Array.isArray(val)) return val.map(sortJsonDeep);
  if (val && typeof val === 'object') {
    const sorted: Record<string, unknown> = {};
    for (const k of Object.keys(val as Record<string, unknown>).sort()) {
      sorted[k] = sortJsonDeep((val as Record<string, unknown>)[k]);
    }
    return sorted;
  }
  return val;
}

export function TextAndQrTools({ tool }: { tool: ToolDefinition }) {
  const [copied, setCopied] = useState(false);

  const copyVal = async (val: string) => {
    await navigator.clipboard.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  // QR Generator state
  const [qrText, setQrText] = useState('https://mediatoolshub.app');
  const [qrFg, setQrFg] = useState('#0F172A');
  const [qrBg, setQrBg] = useState('#FFFFFF');
  const [qrSize, setQrSize] = useState(320);
  const [qrEcc, setQrEcc] = useState<'L' | 'M' | 'Q' | 'H'>('M');
  const [qrPngUrl, setQrPngUrl] = useState('');
  const [qrSvg, setQrSvg] = useState('');

  useEffect(() => {
    if (tool.mode !== 'qr-generator') return;
    const payload = qrText.trim() || 'https://mediatoolshub.app';
    void QRCode.toDataURL(payload, {
      width: qrSize,
      margin: 2,
      errorCorrectionLevel: qrEcc,
      color: { dark: qrFg, light: qrBg },
    }).then(setQrPngUrl);

    void QRCode.toString(payload, {
      type: 'svg',
      margin: 2,
      errorCorrectionLevel: qrEcc,
      color: { dark: qrFg, light: qrBg },
    }).then(setQrSvg);
  }, [tool.mode, qrText, qrFg, qrBg, qrSize, qrEcc]);

  // URL Encoder state
  const [urlStr, setUrlStr] = useState('https://example.com/search?q=social media tools&lang=en');
  const [urlComponentMode, setUrlComponentMode] = useState(true);
  const [urlOutput, setUrlOutput] = useState('');
  const [urlErr, setUrlErr] = useState<string | null>(null);

  // Hashtag state
  const [topicInput, setTopicInput] = useState('youtube growth, video editing, thumbnail design');
  const [tagPlatform, setTagPlatform] = useState<'youtube' | 'instagram' | 'tiktok' | 'twitter'>('youtube');
  const generatedTags = useMemo(() => {
    const words = topicInput
      .split(/[,;\n]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    const set = new Set<string>();
    for (const phrase of words) {
      const clean = phrase.replace(/[^a-zA-Z0-9\s]/g, '').trim();
      if (!clean) continue;
      const parts = clean.split(/\s+/);
      const camel = parts.map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join('');
      set.add(`#${camel}`);
      set.add(`#${clean.toLowerCase().replace(/\s+/g, '')}`);
      for (const p of parts) {
        if (p.length > 2) set.add(`#${p.toLowerCase()}`);
      }
      if (tagPlatform === 'youtube') set.add(`#${camel}Tips`);
      if (tagPlatform === 'instagram') set.add(`#${camel}Creators`);
      if (tagPlatform === 'tiktok') set.add(`#${camel}Tok`);
    }
    const maxMap = { youtube: 5, instagram: 12, tiktok: 6, twitter: 3 };
    return Array.from(set).slice(0, maxMap[tagPlatform]);
  }, [topicInput, tagPlatform]);

  // Text & Counter state
  const [textInput, setTextInput] = useState(
    'Paste or type your video title, script, or social caption here to transform case or inspect character limits.'
  );

  // JSON Formatter state
  const [jsonInput, setJsonInput] = useState(
    '{"platform":"youtube","tool":"thumbnail-extractor","resolutions":["maxresdefault","sddefault","hqdefault"]}'
  );
  const [sortKeys, setSortKeys] = useState(false);

  const jsonFormatted = useMemo(() => {
    if (tool.mode !== 'json-formatter') return { ok: true, output: '' };
    try {
      const parsed = JSON.parse(jsonInput);
      const target = sortKeys ? sortJsonDeep(parsed) : parsed;
      return { ok: true, output: JSON.stringify(target, null, 2) };
    } catch (e: unknown) {
      return { ok: false, output: e instanceof Error ? e.message : 'Invalid JSON' };
    }
  }, [tool.mode, jsonInput, sortKeys]);

  if (tool.mode === 'qr-generator') {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        <div className="md:col-span-7 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Destination URL or Text
            </label>
            <textarea
              rows={3}
              value={qrText}
              onChange={(e) => setQrText(e.target.value)}
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Foreground Color
              </label>
              <input
                type="color"
                value={qrFg}
                onChange={(e) => setQrFg(e.target.value)}
                className="w-full h-10 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Background Color
              </label>
              <input
                type="color"
                value={qrBg}
                onChange={(e) => setQrBg(e.target.value)}
                className="w-full h-10 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Size ({qrSize}px)
              </label>
              <select
                value={qrSize}
                onChange={(e) => setQrSize(Number(e.target.value))}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value={256}>256 × 256 px</option>
                <option value={320}>320 × 320 px</option>
                <option value={512}>512 × 512 px</option>
                <option value={1024}>1024 × 1024 px</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                Error Correction
              </label>
              <select
                value={qrEcc}
                onChange={(e) => setQrEcc(e.target.value as 'L' | 'M' | 'Q' | 'H')}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
              >
                <option value="L">Low (7%)</option>
                <option value="M">Medium (15%)</option>
                <option value="Q">Quartile (25%)</option>
                <option value="H">High (30%)</option>
              </select>
            </div>
          </div>
        </div>

        <div className="md:col-span-5 flex flex-col items-center justify-center rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-6 space-y-4">
          {qrPngUrl && (
            <img
              src={qrPngUrl}
              alt="Generated QR Code"
              className="w-52 h-52 rounded-lg border border-slate-200 dark:border-slate-800 bg-white"
            />
          )}
          <div className="flex flex-wrap gap-2 w-full">
            {qrPngUrl && (
              <a
                href={qrPngUrl}
                download="mediatoolshub-qr.png"
                className="flex-1 h-10 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>PNG</span>
              </a>
            )}
            {qrSvg && (
              <a
                href={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(qrSvg)}`}
                download="mediatoolshub-qr.svg"
                className="flex-1 h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>SVG</span>
              </a>
            )}
          </div>
        </div>
      </div>
    );
  }

  if (tool.mode === 'url-encoder') {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <label className="text-xs font-semibold text-slate-600 dark:text-slate-300">
            Input String or URL
          </label>
          <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
            <input
              type="checkbox"
              checked={urlComponentMode}
              onChange={(e) => setUrlComponentMode(e.target.checked)}
            />
            <span>Component Mode (encodeURIComponent)</span>
          </label>
        </div>
        <textarea
          rows={4}
          value={urlStr}
          onChange={(e) => setUrlStr(e.target.value)}
          className="w-full p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
        />
        <div className="flex flex-wrap gap-2.5">
          <button
            type="button"
            onClick={() => {
              setUrlErr(null);
              setUrlOutput(
                urlComponentMode ? encodeURIComponent(urlStr) : encodeURI(urlStr)
              );
            }}
            className="px-5 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold"
          >
            Encode URL
          </button>
          <button
            type="button"
            onClick={() => {
              try {
                setUrlErr(null);
                setUrlOutput(
                  urlComponentMode ? decodeURIComponent(urlStr) : decodeURI(urlStr)
                );
              } catch {
                setUrlErr('Malformed percent-encoded sequence.');
              }
            }}
            className="px-5 py-2.5 rounded-xl bg-[#0F172A] dark:bg-slate-800 text-white text-xs font-semibold"
          >
            Decode URL
          </button>
        </div>
        {urlErr && <p className="text-xs text-rose-600">{urlErr}</p>}
        {urlOutput && (
          <div className="space-y-2 pt-2">
            <div className="flex justify-between items-center text-xs">
              <span className="font-semibold text-slate-600 dark:text-slate-300">Output</span>
              <button
                type="button"
                onClick={() => void copyVal(urlOutput)}
                className="text-blue-600 dark:text-blue-400 font-semibold flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <pre className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs font-mono whitespace-pre-wrap break-all">
              {urlOutput}
            </pre>
          </div>
        )}
      </div>
    );
  }

  if (tool.mode === 'hashtag-generator') {
    const joined = generatedTags.join(' ');
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
          <div className="sm:col-span-3">
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Topics / Keywords (comma-separated)
            </label>
            <input
              type="text"
              value={topicInput}
              onChange={(e) => setTopicInput(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
              Platform Limit
            </label>
            <select
              value={tagPlatform}
              onChange={(e) =>
                setTagPlatform(e.target.value as 'youtube' | 'instagram' | 'tiktok' | 'twitter')
              }
              className="w-full h-11 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
            >
              <option value="youtube">YouTube (5 tags)</option>
              <option value="instagram">Instagram (12 tags)</option>
              <option value="tiktok">TikTok (6 tags)</option>
              <option value="twitter">X / Twitter (3 tags)</option>
            </select>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-500">
              Formatted Tags ({generatedTags.length})
            </span>
            <button
              type="button"
              onClick={() => void copyVal(joined)}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied All' : 'Copy All'}</span>
            </button>
          </div>
          <p className="text-sm font-mono text-slate-900 dark:text-slate-100 leading-relaxed">
            {joined || 'Enter at least one keyword above.'}
          </p>
        </div>
      </div>
    );
  }

  if (tool.mode === 'json-formatter') {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <label className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300">
            <input
              type="checkbox"
              checked={sortKeys}
              onChange={(e) => setSortKeys(e.target.checked)}
            />
            <span>Sort object keys alphabetically</span>
          </label>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => {
                if (jsonFormatted.ok) setJsonInput(jsonFormatted.output);
              }}
              className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold"
            >
              Beautify (2 spaces)
            </button>
            <button
              type="button"
              onClick={() => {
                try {
                  setJsonInput(JSON.stringify(JSON.parse(jsonInput)));
                } catch {
                  // Invalid state handled in panel
                }
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold"
            >
              Minify
            </button>
            {jsonFormatted.ok && (
              <button
                type="button"
                onClick={() => void copyVal(jsonFormatted.output)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy</span>
              </button>
            )}
          </div>
        </div>

        <textarea
          rows={10}
          value={jsonInput}
          onChange={(e) => setJsonInput(e.target.value)}
          className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-mono"
        />

        <div
          className={`text-xs font-medium ${
            jsonFormatted.ok ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
          }`}
        >
          {jsonFormatted.ok ? 'Valid JSON syntax' : `Syntax Error: ${jsonFormatted.output}`}
        </div>
      </div>
    );
  }

  // Text Case, Word Counter, Character Counter
  const words = textInput.trim() ? textInput.trim().split(/\s+/).length : 0;
  const chars = textInput.length;
  const charsNoSpace = textInput.replace(/\s/g, '').length;
  const sentences = textInput.split(/[.!?]+/).filter((s) => s.trim().length > 0).length;
  const readMins = Math.max(1, Math.ceil(words / 200));
  const speakMins = Math.max(1, Math.ceil(words / 140));

  const transformCase = (mode: string) => {
    if (mode === 'upper') setTextInput(textInput.toUpperCase());
    if (mode === 'lower') setTextInput(textInput.toLowerCase());
    if (mode === 'title') {
      setTextInput(
        textInput.replace(/\w\S*/g, (w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
      );
    }
    if (mode === 'sentence') {
      setTextInput(
        textInput
          .toLowerCase()
          .replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => c.toUpperCase())
      );
    }
    if (mode === 'kebab') {
      setTextInput(
        textInput
          .trim()
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '-')
          .replace(/^-|-$/g, '')
      );
    }
    if (mode === 'snake') {
      setTextInput(
        textInput
          .trim()
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, '_')
          .replace(/^_|_$/g, '')
      );
    }
  };

  const limits = [
    { name: 'YouTube Video Title', max: 100 },
    { name: 'SEO Meta Description', max: 160 },
    { name: 'X / Twitter Post', max: 280 },
    { name: 'TikTok Caption', max: 2200 },
    { name: 'Instagram Caption', max: 2200 },
  ];

  return (
    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">
          Text Editor
        </span>
        <button
          type="button"
          onClick={() => void copyVal(textInput)}
          className="text-xs font-semibold text-blue-600 dark:text-blue-400 flex items-center gap-1"
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          <span>{copied ? 'Copied' : 'Copy Text'}</span>
        </button>
      </div>

      <textarea
        rows={6}
        value={textInput}
        onChange={(e) => setTextInput(e.target.value)}
        className="w-full p-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
      />

      {tool.mode === 'text-case' && (
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'title', label: 'Title Case' },
            { id: 'sentence', label: 'Sentence case' },
            { id: 'upper', label: 'UPPERCASE' },
            { id: 'lower', label: 'lowercase' },
            { id: 'kebab', label: 'kebab-case' },
            { id: 'snake', label: 'snake_case' },
          ].map((btn) => (
            <button
              key={btn.id}
              type="button"
              onClick={() => transformCase(btn.id)}
              className="px-3.5 py-2 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold"
            >
              {btn.label}
            </button>
          ))}
        </div>
      )}

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
        {[
          { label: 'Words', val: words },
          { label: 'Characters', val: chars },
          { label: 'No Spaces', val: charsNoSpace },
          { label: 'Sentences', val: sentences },
          { label: 'Read / Speak', val: `${readMins}m / ${speakMins}m` },
        ].map((m) => (
          <div
            key={m.label}
            className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3"
          >
            <div className="text-slate-500">{m.label}</div>
            <div className="mt-1 font-mono font-bold tabular-nums text-base text-slate-950 dark:text-white">
              {m.val}
            </div>
          </div>
        ))}
      </div>

      {tool.mode === 'character-counter' && (
        <div className="space-y-3 pt-2">
          {limits.map((lim) => {
            const pct = Math.min(100, Math.round((chars / lim.max) * 100));
            const over = chars > lim.max;
            return (
              <div key={lim.name} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-700 dark:text-slate-300">{lim.name}</span>
                  <span
                    className={`font-mono tabular-nums ${
                      over ? 'text-rose-600 font-semibold' : 'text-slate-500'
                    }`}
                  >
                    {chars} / {lim.max}
                  </span>
                </div>
                <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div
                    className={`h-full transition-all ${over ? 'bg-rose-600' : 'bg-blue-600'}`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
