import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowLeft,
  BookOpen,
  Check,
  FolderOpen,
  HelpCircle,
  History,
  Loader2,
  Lock,
  Plus,
  RefreshCw,
  RotateCcw,
  SlidersHorizontal,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import { ApiClientError, parseSafeJsonResponse } from '../../lib/apiClient.ts';
import {
  computeTargetWordCount,
  countSpokenWords,
  SCRIPT_STAGE_META,
} from '../../shared/scriptStudioHelpers.ts';
import type {
  ScriptAiModelId,
  ScriptCompetitorResearchContext,
  ScriptPersonalizationSettings,
  ScriptProjectRecord,
  ScriptStageNumber,
  ScriptStudioSeed,
  ScriptStudioWorkflowContext,
} from '../../shared/types.ts';
import {
  GlossaryDrawer,
  PersonalizationPanel,
  ProjectsDrawer,
  RevisionHistoryDrawer,
} from './scriptStudio/SettingsAndDrawers.tsx';
import {
  Stage1TopicView,
  Stage2PackagingView,
  Stage3OutlineView,
} from './scriptStudio/StagesEarly.tsx';
import {
  Stage4IntroView,
  Stage5BodyView,
  Stage6OutroView,
  Stage7AssemblyView,
} from './scriptStudio/StagesWriting.tsx';

function getOrCreateGuestToken(): string {
  if (typeof window === 'undefined') return 'guest_ssr_default';
  const existing = window.localStorage.getItem('mth_script_guest_token');
  if (existing && /^[a-zA-Z0-9_-]{8,120}$/.test(existing)) return existing;
  const generated = `mth_${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36)}`;
  window.localStorage.setItem('mth_script_guest_token', generated);
  return generated;
}

const COLLABORATION_PRESETS = [
  'Make it more emotional',
  'Use simple English',
  'Write in Hinglish',
  'Add relatable real-world examples',
  'Remove any generic AI phrases',
];

export interface ScriptwritingStudioToolProps {
  mode?: 'standalone' | 'workflow';
  workflowContext?: ScriptStudioWorkflowContext;
  onScriptProjectLinked?: (projectKey: string) => void;
  onScriptApproved?: (project: ScriptProjectRecord) => Promise<void> | void;
}

export function ScriptwritingStudioTool({
  mode = 'standalone',
  workflowContext,
  onScriptProjectLinked,
  onScriptApproved,
}: ScriptwritingStudioToolProps = {}) {
  const isWorkflowMode = mode === 'workflow' && Boolean(workflowContext);
  const { authFetch, firebaseUser, prefillUrl, setPrefillUrl, scriptSeed, setScriptSeed, navigate } = useApp();
  const [guestToken] = useState<string>(() => getOrCreateGuestToken());
  const [returnFromYtm] = useState<boolean>(() => {
    if (isWorkflowMode || typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('from') === 'ytm-workflow';
  });

  const [projects, setProjects] = useState<ScriptProjectRecord[]>([]);
  const [activeProject, setActiveProject] = useState<ScriptProjectRecord | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [busy, setBusy] = useState<boolean>(false);
  const [savingSettings, setSavingSettings] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [lastFailedOp, setLastFailedOp] = useState<{
    operation: string;
    extra?: Record<string, unknown>;
    code?: string;
  } | null>(null);

  const [activeDrawer, setActiveDrawer] = useState<
    null | 'settings' | 'projects' | 'glossary' | 'history'
  >(null);

  const [instruction, setInstruction] = useState<string>('');
  const [explanationText, setExplanationText] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState<boolean>(false);
  const [projectVersion, setProjectVersion] = useState<number>(0);

  const patchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingPatchRef = useRef<{
    projectKey: string;
    stage: ScriptStageNumber;
    payload: { stagePatch: { stage: ScriptStageNumber; data: Record<string, unknown> } };
  } | null>(null);

  const studioFetch = useCallback(
    async (url: string, init: RequestInit = {}) => {
      const headers = new Headers(init.headers || {});
      headers.set('x-script-guest-token', guestToken);
      if (init.body && !headers.has('Content-Type')) {
        headers.set('Content-Type', 'application/json');
      }
      return authFetch(url, { ...init, headers });
    },
    [authFetch, guestToken]
  );

  const flushPendingPatch = useCallback(async () => {
    if (patchTimerRef.current) {
      clearTimeout(patchTimerRef.current);
      patchTimerRef.current = null;
    }
    const pending = pendingPatchRef.current;
    if (!pending) return;
    pendingPatchRef.current = null;
    try {
      const res = await studioFetch(`/api/v1/script-studio/projects/${pending.projectKey}`, {
        method: 'PATCH',
        body: JSON.stringify(pending.payload),
      });
      const data = await parseSafeJsonResponse<{ project: ScriptProjectRecord }>(res);
      setActiveProject(data.project);
      setProjects((prev) =>
        prev.map((p) => (p.projectKey === data.project.projectKey ? data.project : p))
      );
    } catch {
      // Optimistic state remains intact; subsequent explicit save/action will persist
    }
  }, [studioFetch]);

  useEffect(() => {
    return () => {
      if (patchTimerRef.current) clearTimeout(patchTimerRef.current);
    };
  }, []);

  const createFreshProject = useCallback(
    async (initialCustomTopic?: string, seedPayload?: ScriptStudioSeed) => {
      setErrorMsg(null);
      setLastFailedOp(null);
      const res = await studioFetch('/api/v1/script-studio/projects', {
        method: 'POST',
        body: JSON.stringify({
          title:
            seedPayload?.suggestedTitle ||
            (initialCustomTopic ? initialCustomTopic.slice(0, 120) : 'Untitled Video Script'),
          seed: seedPayload,
        }),
      });
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (!data.project) {
        throw new Error('Unable to create a script project.');
      }
      let created = data.project;
      if (!seedPayload && initialCustomTopic && !/^https?:\/\//i.test(initialCustomTopic)) {
        const patchRes = await studioFetch(
          `/api/v1/script-studio/projects/${created.projectKey}`,
          {
            method: 'PATCH',
            body: JSON.stringify({
              stagePatch: { stage: 1, data: { customTopicInput: initialCustomTopic } },
            }),
          }
        );
        const patched = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(patchRes);
        if (patched.project) {
          created = patched.project;
        }
      }
      setProjects((prev) => [created, ...prev]);
      setActiveProject(created);
      setProjectVersion((v) => v + 1);
      setExplanationText(null);
      setConfirmReset(false);
    },
    [studioFetch]
  );

  // Initial load + reload cleanly if signed-in Firebase user or workflowContext changes
  useEffect(() => {
    let cancelled = false;
    const init = async () => {
      setLoading(true);
      setErrorMsg(null);
      try {
        if (isWorkflowMode && workflowContext) {
          const linkRes = await authFetch(
            `/api/v1/ytm/workflow/projects/${workflowContext.workflowProjectId}/link-script?workspaceKey=${encodeURIComponent(
              workflowContext.workspaceKey
            )}`,
            {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'x-ytm-workspace': workflowContext.workspaceKey,
              },
              body: JSON.stringify({ workspaceKey: workflowContext.workspaceKey }),
            }
          );
          const payload = await parseSafeJsonResponse<{
            data?: { scriptProject?: ScriptProjectRecord; scriptProjectKey?: string };
          }>(linkRes);
          if (cancelled) return;
          const linkedProject = payload.data?.scriptProject;
          if (!linkedProject) {
            throw new Error('Unable to initialize workflow-linked Script Studio project.');
          }
          setActiveProject(linkedProject);
          setProjects([linkedProject]);
          setProjectVersion((v) => v + 1);
          if (payload.data?.scriptProjectKey) {
            onScriptProjectLinked?.(payload.data.scriptProjectKey);
          }
          return;
        }

        const res = await studioFetch('/api/v1/script-studio/projects');
        const data = await parseSafeJsonResponse<{ projects?: ScriptProjectRecord[] }>(res);
        const list = data.projects || [];
        if (cancelled) return;
        setProjects(list);

        const cleanPrefill = prefillUrl.trim();
        const topicPrefill =
          cleanPrefill && !/^https?:\/\//i.test(cleanPrefill) ? cleanPrefill : '';
        if (cleanPrefill) setPrefillUrl('');

        const requestedKey =
          typeof window !== 'undefined'
            ? new URLSearchParams(window.location.search).get('projectKey')?.trim() || ''
            : '';

        if (scriptSeed) {
          const seedCopy = scriptSeed;
          setScriptSeed(null);
          await createFreshProject(seedCopy.topic, seedCopy);
        } else if (requestedKey) {
          const matched = list.find((p) => p.projectKey === requestedKey);
          if (matched) {
            setActiveProject(matched);
            setProjectVersion((v) => v + 1);
          } else {
            try {
              const singleRes = await studioFetch(`/api/v1/script-studio/projects/${requestedKey}`);
              const singleData = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(singleRes);
              if (singleData.project) {
                setProjects((prev) => [singleData.project!, ...prev]);
                setActiveProject(singleData.project);
                setProjectVersion((v) => v + 1);
              } else if (list.length > 0) {
                setActiveProject(list[0]);
              } else {
                await createFreshProject();
              }
            } catch {
              if (list.length > 0) setActiveProject(list[0]);
              else await createFreshProject();
            }
          }
        } else if (topicPrefill) {
          await createFreshProject(topicPrefill);
        } else if (list.length > 0) {
          setActiveProject(list[0]);
          setProjectVersion((v) => v + 1);
        } else {
          await createFreshProject();
        }
      } catch (err) {
        if (!cancelled) {
          setErrorMsg(err instanceof Error ? err.message : 'Unable to initialize Script Studio.');
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    void init();
    return () => {
      cancelled = true;
    };
  }, [
    firebaseUser?.uid,
    isWorkflowMode,
    workflowContext?.workflowProjectId,
    workflowContext?.approvedTitle,
    workflowContext?.approvedTopic,
  ]); // eslint-disable-line react-hooks/exhaustive-deps

  const syncUpdatedProject = (updated: ScriptProjectRecord) => {
    setActiveProject(updated);
    setProjects((prev) => {
      const exists = prev.some((p) => p.projectKey === updated.projectKey);
      if (!exists) return [updated, ...prev];
      return prev.map((p) => (p.projectKey === updated.projectKey ? updated : p));
    });
  };

  const handleSaveCompetitorResearch = async (
    payload: Omit<ScriptCompetitorResearchContext, 'updatedAt'>
  ) => {
    if (!activeProject) return;
    await flushPendingPatch();
    setBusy(true);
    setErrorMsg(null);
    try {
      const res = await studioFetch(`/api/v1/script-studio/projects/${activeProject.projectKey}`, {
        method: 'PATCH',
        body: JSON.stringify({ competitorResearch: payload }),
      });
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (data.project) {
        syncUpdatedProject(data.project);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to save competitor research.');
    } finally {
      setBusy(false);
    }
  };

  // Optimistic local state + debounced DB PATCH for inline edits
  const handlePatchStage = useCallback(
    async (stage: ScriptStageNumber, data: Record<string, unknown>) => {
      if (!activeProject) return;
      const key = activeProject.projectKey;

      setActiveProject((prev) => {
        if (!prev || prev.projectKey !== key) return prev;
        const nextState = { ...prev.state };
        if (stage === 1) {
          nextState.stage1 = { ...nextState.stage1, ...data, approved: false, approvedAt: null };
        } else if (stage === 2) {
          nextState.stage2 = { ...nextState.stage2, ...data, approved: false, approvedAt: null };
        } else if (stage === 3) {
          nextState.stage3 = { ...nextState.stage3, ...data, approved: false, approvedAt: null };
        } else if (stage === 4) {
          const narration =
            typeof data.spokenNarration === 'string'
              ? data.spokenNarration
              : nextState.stage4.spokenNarration;
          nextState.stage4 = {
            ...nextState.stage4,
            ...data,
            spokenNarration: narration,
            wordCount: countSpokenWords(narration),
            approved: false,
            approvedAt: null,
          };
        } else if (stage === 5) {
          const idx =
            typeof data.sectionIndex === 'number'
              ? data.sectionIndex
              : nextState.stage5.activeSectionIndex;
          const sections = [...nextState.stage5.sections];
          if (sections[idx] && typeof data.spokenNarration === 'string') {
            sections[idx] = {
              ...sections[idx],
              spokenNarration: data.spokenNarration,
              wordCount: countSpokenWords(data.spokenNarration),
              approved: false,
              approvedAt: null,
            };
          }
          nextState.stage5 = {
            ...nextState.stage5,
            activeSectionIndex:
              typeof data.activeSectionIndex === 'number' ? data.activeSectionIndex : idx,
            sections,
            approved: false,
            approvedAt: null,
          };
        } else if (stage === 6 && nextState.stage6.outro) {
          const narration =
            typeof data.spokenNarration === 'string'
              ? data.spokenNarration
              : nextState.stage6.outro.spokenNarration;
          nextState.stage6 = {
            ...nextState.stage6,
            outro: {
              ...nextState.stage6.outro,
              ...data,
              spokenNarration: narration,
              wordCount: countSpokenWords(narration),
            },
            approved: false,
            approvedAt: null,
          };
        } else if (stage === 7 && nextState.stage7.assembled) {
          const full =
            typeof data.fullScriptText === 'string'
              ? data.fullScriptText
              : nextState.stage7.assembled.fullScriptText;
          nextState.stage7 = {
            ...nextState.stage7,
            assembled: {
              ...nextState.stage7.assembled,
              ...data,
              fullScriptText: full,
              estimatedWordCount: countSpokenWords(full),
            },
          };
        }
        return { ...prev, state: nextState };
      });

      if (
        pendingPatchRef.current &&
        (pendingPatchRef.current.projectKey !== key || pendingPatchRef.current.stage !== stage)
      ) {
        await flushPendingPatch();
      }

      const mergedPayload =
        pendingPatchRef.current &&
        pendingPatchRef.current.projectKey === key &&
        pendingPatchRef.current.stage === stage
          ? {
              stagePatch: {
                stage,
                data: {
                  ...pendingPatchRef.current.payload.stagePatch.data,
                  ...data,
                },
              },
            }
          : { stagePatch: { stage, data } };

      pendingPatchRef.current = { projectKey: key, stage, payload: mergedPayload };
      if (patchTimerRef.current) clearTimeout(patchTimerRef.current);
      patchTimerRef.current = setTimeout(() => {
        void flushPendingPatch();
      }, 450);
    },
    [activeProject, flushPendingPatch]
  );

  const handleGenerate = async (operation: string, extra: Record<string, unknown> = {}) => {
    if (!activeProject) return;
    await flushPendingPatch();
    setBusy(true);
    setErrorMsg(null);
    setLastFailedOp(null);
    setExplanationText(null);
    setConfirmReset(false);

    const requestedModel =
      typeof extra.modelName === 'string' ? extra.modelName : activeProject.modelName;

    try {
      const res = await studioFetch(
        `/api/v1/script-studio/projects/${activeProject.projectKey}/generate`,
        {
          method: 'POST',
          body: JSON.stringify({
            operation,
            modelName: requestedModel,
            instruction:
              typeof extra.instruction === 'string'
                ? extra.instruction
                : instruction.trim() || undefined,
            ...extra,
          }),
        }
      );
      const data = await parseSafeJsonResponse<{
        project?: ScriptProjectRecord;
        explanation?: string;
      }>(res);
      if (operation === 'explain' && data.explanation) {
        setExplanationText(data.explanation);
        return;
      }
      if (data.project) {
        syncUpdatedProject(data.project);
        if (operation === 'topics' || operation === 'analyze-topic') {
          setProjectVersion((v) => v + 1);
        }
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to run AI script studio.');
      setLastFailedOp({
        operation,
        extra,
        code: err instanceof ApiClientError ? err.code : undefined,
      });
    } finally {
      setBusy(false);
    }
  };

  const handleSwitchToFlashLiteAndRetry = async () => {
    if (!activeProject || !lastFailedOp) return;
    const { operation, extra } = lastFailedOp;
    setBusy(true);
    setErrorMsg(null);
    try {
      const patchRes = await studioFetch(
        `/api/v1/script-studio/projects/${activeProject.projectKey}`,
        {
          method: 'PATCH',
          body: JSON.stringify({ modelName: 'gemini-3.1-flash-lite' }),
        }
      );
      const patchData = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(patchRes);
      if (patchData.project) {
        syncUpdatedProject(patchData.project);
      }
    } catch {
      // Proceed to pass modelName directly in generate payload
    } finally {
      setBusy(false);
    }
    await handleGenerate(operation, { ...extra, modelName: 'gemini-3.1-flash-lite' });
  };

  const handleApproveStage = async (stage: ScriptStageNumber, sectionIndex?: number) => {
    if (!activeProject) return;
    await flushPendingPatch();
    setBusy(true);
    setErrorMsg(null);
    setLastFailedOp(null);
    setExplanationText(null);

    try {
      const res = await studioFetch(
        `/api/v1/script-studio/projects/${activeProject.projectKey}/approve`,
        {
          method: 'POST',
          body: JSON.stringify({ stage, sectionIndex }),
        }
      );
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (!data.project) {
        throw new Error('Unable to approve stage.');
      }
      syncUpdatedProject(data.project);
      if (stage === 7 && onScriptApproved) {
        await onScriptApproved(data.project);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Approval failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleNavigateStage = async (targetStage: ScriptStageNumber) => {
    if (!activeProject) return;
    if (isWorkflowMode && targetStage < 3) return;
    if (targetStage > activeProject.highestApprovedStage + 1) return;
    await flushPendingPatch();
    setErrorMsg(null);
    setLastFailedOp(null);
    setExplanationText(null);

    try {
      const res = await studioFetch(
        `/api/v1/script-studio/projects/${activeProject.projectKey}`,
        {
          method: 'PATCH',
          body: JSON.stringify({ currentStage: targetStage }),
        }
      );
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (!data.project) {
        throw new Error('Unable to change stage.');
      }
      syncUpdatedProject(data.project);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Stage switch failed.');
    }
  };

  const handleSaveSettings = async () => {
    if (!activeProject) return;
    await flushPendingPatch();
    setSavingSettings(true);
    setErrorMsg(null);
    setLastFailedOp(null);
    try {
      const res = await studioFetch(
        `/api/v1/script-studio/projects/${activeProject.projectKey}`,
        {
          method: 'PATCH',
          body: JSON.stringify({
            settings: activeProject.settings,
            modelName: activeProject.modelName,
          }),
        }
      );
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (!data.project) {
        throw new Error('Failed to save preferences.');
      }
      syncUpdatedProject(data.project);
      setActiveDrawer(null);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save settings.');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleResetProject = async () => {
    if (!activeProject) return;
    await flushPendingPatch();
    setBusy(true);
    setErrorMsg(null);
    setLastFailedOp(null);
    try {
      const res = await studioFetch(
        `/api/v1/script-studio/projects/${activeProject.projectKey}`,
        {
          method: 'PATCH',
          body: JSON.stringify(isWorkflowMode ? { resetScriptOnly: true } : { resetAll: true }),
        }
      );
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (!data.project) {
        throw new Error('Unable to reset project.');
      }
      syncUpdatedProject(data.project);
      setProjectVersion((v) => v + 1);
      setConfirmReset(false);
      setExplanationText(null);
      setInstruction('');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Reset failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleSelectProject = async (projectKey: string) => {
    await flushPendingPatch();
    setBusy(true);
    setErrorMsg(null);
    setLastFailedOp(null);
    try {
      const res = await studioFetch(`/api/v1/script-studio/projects/${projectKey}`);
      const data = await parseSafeJsonResponse<{ project?: ScriptProjectRecord }>(res);
      if (!data.project) {
        throw new Error('Failed to open saved project.');
      }
      syncUpdatedProject(data.project);
      setProjectVersion((v) => v + 1);
      setActiveDrawer(null);
      setExplanationText(null);
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to load project.');
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteProject = async (projectKey: string) => {
    setErrorMsg(null);
    setLastFailedOp(null);
    try {
      const res = await studioFetch(`/api/v1/script-studio/projects/${projectKey}`, {
        method: 'DELETE',
      });
      await parseSafeJsonResponse<{ deleted?: boolean }>(res);
      const remaining = projects.filter((p) => p.projectKey !== projectKey);
      setProjects(remaining);
      if (activeProject?.projectKey === projectKey) {
        if (remaining.length > 0) {
          setActiveProject(remaining[0]);
          setProjectVersion((v) => v + 1);
        } else {
          await createFreshProject();
        }
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Unable to delete project.');
    }
  };

  const handleGenerateAlternativesForCurrentStage = (customInstruction?: string) => {
    if (!activeProject) return;
    const { currentStage, state, settings } = activeProject;
    const extraInstr = typeof customInstruction === 'string' ? { instruction: customInstruction } : {};

    if (currentStage === 1) {
      if (state.stage1.entryMode === 'custom' && state.stage1.customTopicInput.trim()) {
        void handleGenerate('analyze-topic', {
          customTopic: state.stage1.customTopicInput,
          ...extraInstr,
        });
      } else {
        void handleGenerate('topics', {
          niche: state.stage1.nicheInput || settings.channelNiche || 'Self-Improvement & Creator Growth',
          ...extraInstr,
        });
      }
      return;
    }
    if (currentStage === 2) {
      void handleGenerate('packaging', { scope: 'all', ...extraInstr });
      return;
    }
    if (currentStage === 3) {
      void handleGenerate('outline', extraInstr);
      return;
    }
    if (currentStage === 4) {
      void handleGenerate('intro', extraInstr);
      return;
    }
    if (currentStage === 5) {
      void handleGenerate('body-section', {
        sectionIndex: state.stage5.activeSectionIndex,
        ...extraInstr,
      });
      return;
    }
    if (currentStage === 6) {
      void handleGenerate('outro', extraInstr);
      return;
    }
    if (currentStage === 7) {
      void handleGenerate('assemble', {
        includeProductionNotes: state.stage7.assembled?.includeProductionNotes ?? true,
        ...extraInstr,
      });
    }
  };

  if (loading || !activeProject) {
    return (
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-10 text-center space-y-3">
        {errorMsg ? (
          <div className="max-w-lg mx-auto space-y-3">
            <AlertCircle className="w-6 h-6 text-rose-600 mx-auto" />
            <p className="text-sm text-rose-600 dark:text-rose-400 font-medium">{errorMsg}</p>
            <button
              type="button"
              onClick={() => void createFreshProject()}
              className="h-10 px-4 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold"
            >
              Retry Studio Initialization
            </button>
          </div>
        ) : (
          <div className="flex items-center justify-center gap-2 text-sm text-slate-600 dark:text-slate-300">
            <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
            <span>Loading AI Video Scriptwriting Studio...</span>
          </div>
        )}
      </div>
    );
  }

  const stage = activeProject.currentStage;
  const { state, settings } = activeProject;
  const activeStageMeta = SCRIPT_STAGE_META.find((s) => s.stage === stage) || SCRIPT_STAGE_META[0];
  const targetWordBudget = computeTargetWordCount(settings);

  const canApproveCurrentStage = (() => {
    if (stage === 1) return Boolean(state.stage1.selectedTopic);
    if (stage === 2) {
      return Boolean(
        (state.stage2.customTitleText.trim() || state.stage2.selectedTitleId) &&
          state.stage2.selectedThumbnailId &&
          state.stage2.selectedThumbnailText.trim()
      );
    }
    if (stage === 3) return state.stage3.sections.length > 0;
    if (stage === 4) return Boolean(state.stage4.spokenNarration.trim());
    if (stage === 5) {
      const idx = state.stage5.activeSectionIndex;
      return Boolean(state.stage5.sections[idx]?.spokenNarration?.trim()) || state.stage5.approved;
    }
    if (stage === 6) return Boolean(state.stage6.outro?.spokenNarration.trim());
    if (stage === 7) return Boolean(state.stage7.assembled);
    return false;
  })();

  const approveButtonLabel = (() => {
    if (stage === 1) return 'Approve Topic & Continue to Packaging';
    if (stage === 2) return 'Approve Packaging & Continue to Outline';
    if (stage === 3) return 'Approve Outline & Write Introduction';
    if (stage === 4) return 'Approve Introduction & Draft Body';
    if (stage === 5) {
      const idx = state.stage5.activeSectionIndex;
      if (state.stage5.approved) return 'Continue to Outro & CTA';
      if (idx < state.stage3.sections.length - 1) {
        return `Approve Section ${idx + 1} & Unlock Next`;
      }
      return 'Approve Final Section & Continue to Outro';
    }
    if (stage === 6) return 'Approve Outro & Assemble Full Script';
    return state.stage7.approved ? 'Script Approved & Production Ready' : 'Finalize Complete Script';
  })();

  const visibleStages = isWorkflowMode
    ? SCRIPT_STAGE_META.filter((item) => item.stage >= 3)
    : SCRIPT_STAGE_META;

  return (
    <div className="space-y-5">
      {returnFromYtm && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 flex items-center justify-between gap-3 text-xs">
          <span className="text-slate-600 dark:text-slate-300">
            Linked with your YouTube Management Workflow Stage 3 (Script). Changes save automatically to both workspaces.
          </span>
          <button
            type="button"
            onClick={() => navigate('/youtube-management/workflow')}
            className="h-8 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Workflow</span>
          </button>
        </div>
      )}

      {isWorkflowMode && workflowContext && (
        <div className="rounded-xl border border-blue-200 dark:border-blue-900/50 bg-blue-50/50 dark:bg-blue-950/20 px-4 py-3 grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
          <div className="min-w-0">
            <span className="font-semibold text-blue-700 dark:text-blue-300">Synced Title (Stage 1): </span>
            <span className="text-slate-900 dark:text-white font-medium truncate">{workflowContext.approvedTitle}</span>
          </div>
          <div className="min-w-0">
            <span className="font-semibold text-blue-700 dark:text-blue-300">Synced Topic (Stage 2): </span>
            <span className="text-slate-800 dark:text-slate-200 truncate">{workflowContext.approvedTopic || 'Aligned'}</span>
          </div>
          <div className="min-w-0">
            <span className="font-semibold text-blue-700 dark:text-blue-300">Target Audience: </span>
            <span className="text-slate-800 dark:text-slate-200 truncate">{workflowContext.targetAudience || settings.targetAudience}</span>
          </div>
        </div>
      )}

      {/* Studio Command Header */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="font-mono font-semibold text-blue-600 dark:text-blue-400">
                {isWorkflowMode
                  ? `SCRIPT STEP ${Math.max(1, stage - 2)}/5 · ${activeStageMeta.label.toUpperCase()}`
                  : `STAGE ${stage}/7 · ${activeStageMeta.label.toUpperCase()}`}
              </span>
              <span>·</span>
              <span className="font-mono font-semibold uppercase text-slate-700 dark:text-slate-200">
                {activeProject.projectStatus || (activeProject.highestApprovedStage >= 7 ? 'COMPLETED' : activeProject.highestApprovedStage > 0 ? 'IN PROGRESS' : 'NOT STARTED')}
              </span>
              <span>·</span>
              <span className="font-mono tabular-nums">
                Target: ~{settings.targetDurationMinutes}m ({targetWordBudget.toLocaleString()} words)
              </span>
              <span>·</span>
              <span>{settings.scriptLanguage}</span>
            </div>
            <h2 className="mt-1 font-display text-lg sm:text-xl font-bold text-slate-950 dark:text-white truncate">
              {activeProject.title}
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {!isWorkflowMode && (
              <button
                type="button"
                onClick={() => setActiveDrawer(activeDrawer === 'projects' ? null : 'projects')}
                className={`h-9 px-3 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                  activeDrawer === 'projects'
                    ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300'
                    : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <FolderOpen className="w-3.5 h-3.5" />
                <span>Projects ({projects.length})</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setActiveDrawer(activeDrawer === 'settings' ? null : 'settings')}
              className={`h-9 px-3 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeDrawer === 'settings'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Personalize</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveDrawer(activeDrawer === 'glossary' ? null : 'glossary')}
              className={`h-9 px-3 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeDrawer === 'glossary'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Glossary</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveDrawer(activeDrawer === 'history' ? null : 'history')}
              className={`h-9 px-3 rounded-lg border text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                activeDrawer === 'history'
                  ? 'border-blue-600 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300'
                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>History</span>
            </button>

            {!isWorkflowMode && (
              <button
                type="button"
                disabled={busy}
                onClick={() => void createFreshProject()}
                className="h-9 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap hover:bg-slate-800 dark:hover:bg-blue-500"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New</span>
              </button>
            )}
          </div>
        </div>

        {/* Approval Stepper (7 stages in standalone; 5 focused script stages 3..7 in workflow) */}
        <div
          role="navigation"
          aria-label="Scriptwriting studio stages"
          className={`grid gap-1.5 pt-2 border-t border-slate-100 dark:border-slate-800 ${
            isWorkflowMode
              ? 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'
              : 'grid-cols-2 sm:grid-cols-4 lg:grid-cols-7'
          }`}
        >
          {visibleStages.map((item, idx) => {
            const isActive = item.stage === stage;
            const isApproved = item.stage <= activeProject.highestApprovedStage;
            const isUnlocked = item.stage <= activeProject.highestApprovedStage + 1;
            const needsReview =
              state.needsReviewFromStage !== null && item.stage >= state.needsReviewFromStage;
            const displayLabel = isWorkflowMode
              ? `${idx + 1}. ${item.label === 'Complete Script' ? 'Complete Script' : item.shortLabel.replace(/^\d+\.\s*/, '')}`
              : item.shortLabel;

            return (
              <button
                key={item.stage}
                type="button"
                disabled={!isUnlocked || busy}
                onClick={() => void handleNavigateStage(item.stage)}
                className={`h-10 px-2.5 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                  isActive
                    ? 'border-blue-600 bg-[#0F172A] dark:bg-blue-600 text-white'
                    : isApproved
                      ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-200 hover:bg-emerald-100 dark:hover:bg-emerald-950/50'
                      : isUnlocked
                        ? needsReview
                          ? 'border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20 text-amber-800 dark:text-amber-200'
                          : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/40 text-slate-400 cursor-not-allowed'
                }`}
              >
                {isApproved ? (
                  <Check className="w-3.5 h-3.5 shrink-0" />
                ) : !isUnlocked ? (
                  <Lock className="w-3 h-3 shrink-0" />
                ) : null}
                <span className="truncate">{displayLabel}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Expandable Drawers */}
      {activeDrawer === 'settings' && (
        <PersonalizationPanel
          settings={settings}
          modelName={activeProject.modelName}
          saving={savingSettings}
          onChangeSettings={(next: ScriptPersonalizationSettings) =>
            setActiveProject((prev) => (prev ? { ...prev, settings: next } : prev))
          }
          onChangeModel={(model: ScriptAiModelId) =>
            setActiveProject((prev) => (prev ? { ...prev, modelName: model } : prev))
          }
          onSave={() => void handleSaveSettings()}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {activeDrawer === 'projects' && (
        <ProjectsDrawer
          projects={projects}
          activeProjectKey={activeProject.projectKey}
          onSelectProject={(k) => void handleSelectProject(k)}
          onCreateProject={() => {
            setActiveDrawer(null);
            void createFreshProject();
          }}
          onDeleteProject={(k) => void handleDeleteProject(k)}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {activeDrawer === 'glossary' && (
        <GlossaryDrawer onClose={() => setActiveDrawer(null)} />
      )}

      {activeDrawer === 'history' && (
        <RevisionHistoryDrawer
          history={state.revisionHistory || []}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {/* Completed Script Archival Notice (Standalone Mode) */}
      {!isWorkflowMode &&
        (activeProject.projectStatus === 'COMPLETED' || activeProject.highestApprovedStage >= 7) && (
          <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50/70 dark:bg-emerald-950/20 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-emerald-900 dark:text-emerald-200">
            <div>
              <strong>Script Completed &amp; Saved in Project History:</strong>{' '}
              Your final approved script is permanently archived under Projects ({projects.length}) and will remain intact when you start a new video.
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={() => void createFreshProject()}
              className="h-8 px-3.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Start Fresh New Project</span>
            </button>
          </div>
        )}

      {/* Dependency Invalidation Warning Banner */}
      {state.dependencyWarning && (
        <div
          role="status"
          className="rounded-xl border border-amber-200 dark:border-amber-900/50 bg-amber-50 dark:bg-amber-950/20 p-4 text-xs sm:text-sm text-amber-900 dark:text-amber-200 flex items-start gap-2.5"
        >
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <div>
            <strong className="font-semibold">Creative Consistency Notice:</strong>{' '}
            {state.dependencyWarning}
          </div>
        </div>
      )}

      {/* Real Error Alert */}
      {errorMsg && (
        <div
          role="alert"
          className="rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50 dark:bg-rose-950/20 p-4 text-xs sm:text-sm text-rose-800 dark:text-rose-200 space-y-3"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setErrorMsg(null);
                setLastFailedOp(null);
              }}
              className="text-xs font-semibold underline shrink-0"
            >
              Dismiss
            </button>
          </div>
          {lastFailedOp && (
            <div className="flex flex-wrap items-center gap-2 pl-6">
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleGenerate(lastFailedOp.operation, lastFailedOp.extra)}
                className="h-8 px-3 rounded-lg bg-rose-700 hover:bg-rose-800 text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-60"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry</span>
              </button>
              {activeProject.modelName !== 'gemini-3.1-flash-lite' &&
                (lastFailedOp.code === 'AI_RATE_LIMITED' ||
                  lastFailedOp.code === 'AI_TIMEOUT' ||
                  lastFailedOp.code === 'GEMINI_MODEL_NOT_FOUND' ||
                  lastFailedOp.code === 'AI_GENERATION_FAILED') && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleSwitchToFlashLiteAndRetry()}
                    className="h-8 px-3 rounded-lg border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-900 text-rose-900 dark:text-rose-100 hover:bg-rose-100 dark:hover:bg-slate-800 text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-60"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Switch to Gemini 3.1 Flash Lite & Retry</span>
                  </button>
                )}
            </div>
          )}
        </div>
      )}

      {/* Active Stage Workspace */}
      <div
        key={`${activeProject.projectKey}-${projectVersion}-${stage}`}
        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6"
      >
        {stage === 1 && (
          <Stage1TopicView
            project={activeProject}
            busy={busy}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
          />
        )}
        {stage === 2 && (
          <Stage2PackagingView
            project={activeProject}
            busy={busy}
            studioFetch={studioFetch}
            onSaveCompetitorResearch={handleSaveCompetitorResearch}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
          />
        )}
        {stage === 3 && (
          <Stage3OutlineView
            project={activeProject}
            busy={busy}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
          />
        )}
        {stage === 4 && (
          <Stage4IntroView
            project={activeProject}
            busy={busy}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
          />
        )}
        {stage === 5 && (
          <Stage5BodyView
            project={activeProject}
            busy={busy}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
            onApproveSection={(idx) => handleApproveStage(5, idx)}
          />
        )}
        {stage === 6 && (
          <Stage6OutroView
            project={activeProject}
            busy={busy}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
          />
        )}
        {stage === 7 && (
          <Stage7AssemblyView
            project={activeProject}
            busy={busy}
            onPatchStage={(s, d) => handlePatchStage(s, d)}
            onGenerate={(op, extra) => handleGenerate(op, extra)}
          />
        )}
      </div>

      {/* Inline Creative Director Explanation Box */}
      {explanationText && (
        <div className="rounded-2xl border border-blue-200 dark:border-blue-900/50 bg-blue-50/70 dark:bg-blue-950/20 p-5 text-xs sm:text-sm text-slate-800 dark:text-slate-200 space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="font-display font-bold text-blue-900 dark:text-blue-200">
              Creative Director Explanation
            </span>
            <button
              type="button"
              onClick={() => setExplanationText(null)}
              className="text-xs font-semibold text-blue-700 dark:text-blue-300 underline"
            >
              Close
            </button>
          </div>
          <p className="leading-relaxed whitespace-pre-line">{explanationText}</p>
        </div>
      )}

      {/* Creative Director Collaboration & Approval Gate Bar */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
              Collaborate Before Approving Stage {stage}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Discuss edits, ask why, switch language/tone, or approve to unlock the next stage.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {COLLABORATION_PRESETS.map((preset) => (
              <button
                key={preset}
                type="button"
                disabled={busy}
                onClick={() => {
                  setInstruction(preset);
                  handleGenerateAlternativesForCurrentStage(preset);
                }}
                className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-[11px] font-medium text-slate-700 dark:text-slate-300 hover:border-blue-500/50 hover:text-blue-600 dark:hover:text-blue-400 transition-colors whitespace-nowrap"
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2.5">
          <input
            type="text"
            value={instruction}
            onChange={(e) => setInstruction(e.target.value)}
            placeholder="Give feedback or ask a question (e.g., Write in Hindi, Target Indian students, Make it more punchy)..."
            className="flex-1 h-11 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs sm:text-sm text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-600"
          />
          <button
            type="button"
            disabled={busy}
            onClick={() => handleGenerateAlternativesForCurrentStage()}
            className="h-11 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 disabled:opacity-60"
          >
            {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
            <span>{instruction.trim() ? 'Apply Feedback' : 'Generate Alternatives'}</span>
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={() =>
              void handleGenerate('explain', {
                stage,
                question: instruction.trim() || undefined,
              })
            }
            className="h-11 px-4 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-xs font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center justify-center gap-1.5 whitespace-nowrap shrink-0 disabled:opacity-60"
          >
            <HelpCircle className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Explain Why</span>
          </button>
        </div>

        {/* Navigation & Explicit Approval Action Row */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            {stage > (isWorkflowMode ? 3 : 1) && (
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleNavigateStage((stage - 1) as ScriptStageNumber)}
                className="h-10 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Go Back</span>
              </button>
            )}

            {confirmReset ? (
              <div className="inline-flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void handleResetProject()}
                  className="h-10 px-3.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold whitespace-nowrap"
                >
                  Confirm Start Again
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                disabled={busy}
                onClick={() => setConfirmReset(true)}
                className="h-10 px-3.5 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-rose-600 hover:border-rose-200 dark:hover:border-rose-900 inline-flex items-center gap-1.5 whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Start Again</span>
              </button>
            )}
          </div>

          <button
            type="button"
            disabled={busy || !canApproveCurrentStage}
            onClick={() => {
              if (stage === 5 && state.stage5.approved) {
                void handleNavigateStage(6);
              } else if (stage === 5) {
                void handleApproveStage(5, state.stage5.activeSectionIndex);
              } else {
                void handleApproveStage(stage);
              }
            }}
            className="h-11 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white text-xs sm:text-sm font-semibold inline-flex items-center gap-2 whitespace-nowrap transition-colors"
          >
            {busy ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : state.stage7.approved && stage === 7 ? (
              <Check className="w-4 h-4" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span>{approveButtonLabel}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
