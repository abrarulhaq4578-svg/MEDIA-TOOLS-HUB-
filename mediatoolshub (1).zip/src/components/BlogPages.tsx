import { useEffect, useState } from 'react';
import { ArrowLeft, ArrowRight, BookOpen } from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { parseSafeJsonResponse } from '../lib/apiClient.ts';
import type { BlogPostRecord } from '../shared/types.ts';
import { AdSlot } from './AdSlot.tsx';

function CoverImageWithFallback({ src, alt }: { src: string; alt: string }) {
  const [failed, setFailed] = useState(false);

  if (failed || !src) {
    return (
      <div className="w-full h-full bg-gradient-to-br from-slate-900 via-slate-800 to-blue-950 flex flex-col items-center justify-center p-6 text-center text-white">
        <BookOpen className="w-8 h-8 text-blue-400 mb-2" />
        <span className="text-xs font-medium text-slate-300 line-clamp-2">{alt}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className="w-full h-full object-cover"
    />
  );
}

function renderMarkdownBlocks(md: string) {
  const blocks = md.split(/\n\n+/);
  return blocks.map((block, idx) => {
    const trimmed = block.trim();
    if (trimmed.startsWith('## ')) {
      return (
        <h2 key={idx} className="font-display text-xl sm:text-2xl font-bold text-slate-950 dark:text-white mt-8 mb-3">
          {trimmed.slice(3)}
        </h2>
      );
    }
    if (trimmed.startsWith('### ')) {
      return (
        <h3 key={idx} className="font-display text-lg font-bold text-slate-950 dark:text-white mt-6 mb-2">
          {trimmed.slice(4)}
        </h3>
      );
    }
    if (trimmed.startsWith('- ') || trimmed.startsWith('1. ')) {
      const lines = trimmed.split('\n');
      const isOrdered = trimmed.startsWith('1. ');
      const ListTag = isOrdered ? 'ol' : 'ul';
      return (
        <ListTag
          key={idx}
          className={`space-y-2 my-4 pl-5 text-sm sm:text-base text-slate-700 dark:text-slate-300 ${
            isOrdered ? 'list-decimal' : 'list-disc'
          }`}
        >
          {lines.map((line, i) => (
            <li key={i}>{line.replace(/^(\d+\.|-)\s+/, '').replace(/\*\*/g, '')}</li>
          ))}
        </ListTag>
      );
    }
    return (
      <p key={idx} className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed my-4">
        {trimmed.replace(/\*\*/g, '')}
      </p>
    );
  });
}

export function BlogIndexPage() {
  const { navigate } = useApp();
  const [posts, setPosts] = useState<BlogPostRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/v1/blog')
      .then((r) => parseSafeJsonResponse<{ posts?: BlogPostRecord[] }>(r))
      .then((d) => setPosts(d.posts || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
      <div className="max-w-2xl mb-10">
        <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-950 dark:text-white">
          Editorial Guides & Technical Tutorials
        </h1>
        <p className="mt-2.5 text-base text-slate-600 dark:text-slate-300">
          In-depth documentation on thumbnail specifications, official oEmbed metadata protocols, and privacy-conscious browser utilities.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div
              key={n}
              className="h-80 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse"
            />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {posts.map((post) => (
            <article
              key={post.id}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden flex flex-col"
            >
              <div className="aspect-video bg-slate-100 dark:bg-slate-950 overflow-hidden">
                <CoverImageWithFallback src={post.coverImage} alt={post.title} />
              </div>
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">
                    {post.category} · {post.readTimeMinutes} min read ·{' '}
                    {new Date(post.publishedAt).toLocaleDateString('en-US', {
                      month: 'short',
                      year: 'numeric',
                    })}
                  </div>
                  <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white leading-snug">
                    {post.title}
                  </h2>
                  <p className="mt-2 text-sm text-slate-600 dark:text-slate-400 line-clamp-3">
                    {post.excerpt}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => navigate(`/blog/${post.slug}`)}
                  className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline"
                >
                  <span>Read Article</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

export function BlogDetailPage({ slug }: { slug: string }) {
  const { navigate } = useApp();
  const [post, setPost] = useState<BlogPostRecord | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/v1/blog/${encodeURIComponent(slug)}`)
      .then((r) => parseSafeJsonResponse<{ post: BlogPostRecord }>(r))
      .then((d) => {
        setPost(d.post);
        document.title = d.post.seoTitle;
      })
      .catch(() => setPost(null))
      .finally(() => setLoading(false));
  }, [slug]);

  if (loading) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-14 space-y-4">
        <div className="h-8 w-3/4 rounded bg-slate-200 dark:bg-slate-800 animate-pulse" />
        <div className="aspect-video rounded-2xl bg-slate-200 dark:bg-slate-800 animate-pulse" />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16 text-center space-y-4">
        <h1 className="font-display text-2xl font-bold text-slate-950 dark:text-white">
          Article Not Found
        </h1>
        <button
          type="button"
          onClick={() => navigate('/blog')}
          className="px-4 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold"
        >
          Back to Blog
        </button>
      </div>
    );
  }

  return (
    <article className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
      <button
        type="button"
        onClick={() => navigate('/blog')}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-950 dark:hover:text-white mb-6"
      >
        <ArrowLeft className="w-3.5 h-3.5" />
        <span>All Articles</span>
      </button>

      <div className="text-xs text-slate-500 dark:text-slate-400 mb-3">
        {post.category} · {post.readTimeMinutes} min read · Published{' '}
        {new Date(post.publishedAt).toLocaleDateString('en-US', {
          month: 'long',
          day: 'numeric',
          year: 'numeric',
        })}
      </div>

      <h1 className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-slate-950 dark:text-white leading-tight">
        {post.title}
      </h1>
      <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
        {post.excerpt}
      </p>

      <div className="mt-8 aspect-video rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800">
        <CoverImageWithFallback src={post.coverImage} alt={post.title} />
      </div>

      <AdSlot placementKey="blog_article" />

      <div className="mt-8">{renderMarkdownBlocks(post.contentMarkdown)}</div>
    </article>
  );
}
