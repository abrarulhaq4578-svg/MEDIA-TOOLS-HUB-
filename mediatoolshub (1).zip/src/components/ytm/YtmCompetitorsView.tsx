import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  BookmarkPlus,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Loader2,
  Plus,
  Radar,
  Search,
  Trash2,
  Video,
  Workflow,
} from 'lucide-react';
import type {
  CompetitorVideoItem,
  ScriptStudioSeed,
  YtmChannelProfileWithDna,
  YtmWorkspaceCompetitorRecord,
} from '../../shared/types.ts';
import { CompetitorIntelligenceTool } from '../tools/CompetitorIntelligenceTool.tsx';
import { formatCompactNumber, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';
import { SaveInspirationModal, type SaveInspirationDraft } from './SaveInspirationModal.tsx';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  channelProfiles: YtmChannelProfileWithDna[];
  activeChannelProfileId: number | null;
  onOpenPlanner?: () => void;
  onSendToWorkflow?: (seed: {
    title: string;
    topic?: string;
    notes?: string;
    targetAudience?: string;
    adaptedAngle?: string;
  }) => Promise<void>;
}

interface CompetitorsResponse {
  competitors: YtmWorkspaceCompetitorRecord[];
  reports: Array<{
    reportKey: string;
    title: string;
    status: string;
    updatedAt: string;
  }>;
  cachedChannels: Array<{
    channelId: string;
    handle: string | null;
    title: string;
    sampleSize: number;
    retrievedAt: string;
  }>;
}

export function YtmCompetitorsView({
  authFetch,
  workspaceKey,
  canWrite,
  channelProfiles,
  activeChannelProfileId,
  onOpenPlanner,
  onSendToWorkflow,
}: Props) {
  // Two views inside the same YouTube Management workspace — NEVER redirects outside YTM
  const [activeTab, setActiveTab] = useState<'studio' | 'roster'>('studio');

  const [data, setData] = useState<CompetitorsResponse>({
    competitors: [],
    reports: [],
    cachedChannels: [],
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [inputUrl, setInputUrl] = useState('');
  const [notes, setNotes] = useState('');
  const [adding, setAdding] = useState(false);

  // Competitor video discovery & Save to Planner / Workflow state
  const [expandedChannelId, setExpandedChannelId] = useState<string | null>(null);
  const [videosByChannel, setVideosByChannel] = useState<Record<string, CompetitorVideoItem[]>>({});
  const [loadingChannelId, setLoadingChannelId] = useState<string | null>(null);
  const [saveDraft, setSaveDraft] = useState<SaveInspirationDraft | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [sendingWfId, setSendingWfId] = useState<string | null>(null);

  const loadCompetitors = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await ytmRequest<CompetitorsResponse>(authFetch, '/competitors', {
        workspaceKey,
      });
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load competitor roster.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadCompetitors();
  }, [workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleAddCompetitor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim() || !canWrite) return;
    setAdding(true);
    setError(null);
    try {
      await ytmRequest(authFetch, '/competitors', {
        workspaceKey,
        method: 'POST',
        body: { input: inputUrl.trim(), notes: notes.trim() },
      });
      setInputUrl('');
      setNotes('');
      await loadCompetitors();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to resolve YouTube competitor channel.');
    } finally {
      setAdding(false);
    }
  };

  const handleDeleteCompetitor = async (id: number) => {
    if (!canWrite) return;
    try {
      await ytmRequest(authFetch, `/competitors/${id}`, {
        workspaceKey,
        method: 'DELETE',
      });
      setData((prev) => ({
        ...prev,
        competitors: prev.competitors.filter((c) => c.id !== id),
      }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to remove competitor.');
    }
  };

  const handleInspectVideos = async (channelId: string) => {
    if (expandedChannelId === channelId) {
      setExpandedChannelId(null);
      return;
    }
    setExpandedChannelId(channelId);
    if (videosByChannel[channelId]) return;

    setLoadingChannelId(channelId);
    setError(null);
    try {
      const res = await ytmRequest<{ videos: CompetitorVideoItem[] }>(
        authFetch,
        `/competitors/${encodeURIComponent(channelId)}/videos?sampleSize=15`,
        { workspaceKey }
      );
      setVideosByChannel((prev) => ({ ...prev, [channelId]: res.videos || [] }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load competitor videos.');
    } finally {
      setLoadingChannelId(null);
    }
  };

  const handleOpportunityToWorkflow = async (seed: ScriptStudioSeed) => {
    if (!onSendToWorkflow) return;
    try {
      await onSendToWorkflow({
        title: seed.suggestedTitle || seed.topic,
        topic: seed.topic,
        targetAudience: seed.targetAudience,
        adaptedAngle: seed.contentAngle,
        notes: [
          seed.sourceLabel ? `Source: ${seed.sourceLabel}` : '',
          seed.competitorInsights ? `Competitor Insights: ${seed.competitorInsights}` : '',
          seed.thumbnailDirection ? `Thumbnail Direction: ${seed.thumbnailDirection}` : '',
          seed.recommendedFormat ? `Format: ${seed.recommendedFormat}` : '',
        ]
          .filter(Boolean)
          .join('\n\n'),
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create workflow from opportunity.');
    }
  };

  const handleVideoToWorkflow = async (v: CompetitorVideoItem, channelTitle: string) => {
    if (!onSendToWorkflow) return;
    setSendingWfId(v.videoId);
    setError(null);
    try {
      await onSendToWorkflow({
        title: v.title,
        topic: `Original angle inspired by ${channelTitle}: ${v.title}`,
        notes: `Public competitor reference: ${v.videoUrl} (${formatCompactNumber(v.viewCount)} views, ${v.durationLabel})`,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to send to Workflow.');
    } finally {
      setSendingWfId(null);
    }
  };

  return (
    <div className="space-y-5">
      {/* Unified Header inside YouTube Management (Never redirects away) */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1 max-w-2xl">
          <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Competitor Intelligence
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Analyze public competitor channels, outlier videos, title patterns, thumbnail styles, content gaps, and audience demand directly inside YouTube Management — then save findings to <strong>Content Planner</strong> or launch a <strong>Workflow</strong> production. Public YouTube data only; private competitor analytics are never estimated.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0 text-xs">
          <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-950">
            <button
              type="button"
              onClick={() => setActiveTab('studio')}
              className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                activeTab === 'studio'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Radar className="w-3.5 h-3.5" />
              <span>Competitor Studio</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('roster')}
              className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                activeTab === 'roster'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Video className="w-3.5 h-3.5" />
              <span>Saved Roster ({data.competitors.length})</span>
            </button>
          </div>

          {canWrite && (
            <button
              type="button"
              onClick={() =>
                setSaveDraft({
                  originalVideoTitle: '',
                  inspirationCategory: 'creative_observation',
                })
              }
              className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 font-semibold inline-flex items-center gap-1.5 whitespace-nowrap"
            >
              <BookmarkPlus className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Save Observation</span>
            </button>
          )}
        </div>
      </div>

      {savedNotice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 p-3.5 text-xs text-emerald-700 dark:text-emerald-300 flex items-center justify-between gap-2">
          <span>{savedNotice}</span>
          <div className="flex items-center gap-3">
            {onOpenPlanner && (
              <button
                type="button"
                onClick={onOpenPlanner}
                className="font-semibold underline"
              >
                Open Content Planner
              </button>
            )}
            <button
              type="button"
              onClick={() => setSavedNotice(null)}
              className="underline font-semibold"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      {error && (
        <div className="rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/20 p-3.5 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* TAB 1: FULL SHARED COMPETITOR INTELLIGENCE ENGINE (Embedded inside YTM) */}
      {activeTab === 'studio' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5">
          <CompetitorIntelligenceTool
            embeddedInYtm
            workspaceKey={workspaceKey}
            channelProfiles={channelProfiles}
            activeChannelProfileId={activeChannelProfileId}
            onSendOpportunityToWorkflow={(seed) => void handleOpportunityToWorkflow(seed)}
            onOpenPlanner={onOpenPlanner}
          />
        </div>
      )}

      {/* TAB 2: SAVED WORKSPACE COMPETITOR ROSTER & QUICK VIDEO FEED */}
      {activeTab === 'roster' && (
        <div className="space-y-5">
          {canWrite && (
            <form
              onSubmit={(e) => void handleAddCompetitor(e)}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3"
            >
              <div className="text-xs font-semibold text-slate-800 dark:text-slate-100">
                Track a Competitor Channel in Workspace Roster
              </div>
              <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 text-xs">
                <div className="md:col-span-5 relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={inputUrl}
                    onChange={(e) => setInputUrl(e.target.value)}
                    placeholder="YouTube channel URL, @handle, or UC... ID"
                    className="w-full h-10 pl-9 pr-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Notes on why you study this channel (hooks, titles, pacing)..."
                  className="md:col-span-5 h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
                <button
                  type="submit"
                  disabled={adding}
                  className="md:col-span-2 h-10 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold inline-flex items-center justify-center gap-1.5 whitespace-nowrap disabled:opacity-60"
                >
                  {adding ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                  <span>{adding ? 'Resolving...' : 'Add Channel'}</span>
                </button>
              </div>
            </form>
          )}

          {loading ? (
            <div className="flex items-center gap-2 text-xs text-slate-500 py-8">
              <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
              <span>Loading saved competitors...</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  Saved Workspace Competitors ({data.competitors.length})
                </h3>
                {data.competitors.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4">
                    No competitor channels saved in this workspace roster yet. Add channels above or switch to <strong>Competitor Studio</strong> to run deep channel &amp; outlier analysis.
                  </p>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800">
                    {data.competitors.map((c) => {
                      const isExpanded = expandedChannelId === c.channelId;
                      const vids = videosByChannel[c.channelId] || [];
                      const isFetchingVids = loadingChannelId === c.channelId;
                      return (
                        <div key={c.id} className="py-3.5 space-y-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-start gap-3 min-w-0">
                              {c.thumbnailUrl && (
                                <img
                                  src={c.thumbnailUrl}
                                  alt={c.title}
                                  referrerPolicy="no-referrer"
                                  className="w-10 h-10 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
                                />
                              )}
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold text-sm text-slate-950 dark:text-white truncate">
                                    {c.title}
                                  </span>
                                  {c.handle && (
                                    <span className="text-xs text-slate-500 truncate">{c.handle}</span>
                                  )}
                                </div>
                                <div className="text-xs text-slate-500 font-mono tabular-nums mt-0.5">
                                  {formatCompactNumber(c.subscriberCount)} subscribers ·{' '}
                                  <a
                                    href={c.channelUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                                  >
                                    <span>Channel</span>
                                    <ExternalLink className="w-3 h-3" />
                                  </a>
                                </div>
                                {c.notes && (
                                  <p className="mt-1 text-xs text-slate-600 dark:text-slate-300">{c.notes}</p>
                                )}
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              <button
                                type="button"
                                onClick={() => void handleInspectVideos(c.channelId)}
                                className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold inline-flex items-center gap-1.5"
                              >
                                <Video className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                                <span>Videos</span>
                                {isExpanded ? (
                                  <ChevronUp className="w-3.5 h-3.5" />
                                ) : (
                                  <ChevronDown className="w-3.5 h-3.5" />
                                )}
                              </button>
                              {canWrite && (
                                <button
                                  type="button"
                                  onClick={() => void handleDeleteCompetitor(c.id)}
                                  className="text-slate-400 hover:text-rose-600 p-1.5"
                                  aria-label="Remove competitor"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              )}
                            </div>
                          </div>

                          {isExpanded && (
                            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 space-y-2.5">
                              {isFetchingVids ? (
                                <div className="py-6 flex items-center justify-center gap-2 text-xs text-slate-500">
                                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                                  <span>Fetching public videos for {c.title}...</span>
                                </div>
                              ) : vids.length === 0 ? (
                                <p className="py-4 text-center text-xs text-slate-500">
                                  No public videos returned for this channel.
                                </p>
                              ) : (
                                <div className="divide-y divide-slate-200/70 dark:divide-slate-800">
                                  {vids.slice(0, 12).map((v) => (
                                    <div
                                      key={v.videoId}
                                      className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                                    >
                                      <div className="flex items-start gap-2.5 min-w-0">
                                        {v.thumbnailUrl && (
                                          <img
                                            src={v.thumbnailUrl}
                                            alt={v.title}
                                            referrerPolicy="no-referrer"
                                            className="w-24 aspect-video rounded object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                                          />
                                        )}
                                        <div className="min-w-0 space-y-0.5">
                                          <a
                                            href={v.videoUrl}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="text-xs font-semibold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 line-clamp-2"
                                          >
                                            {v.title}
                                          </a>
                                          <div className="text-[11px] font-mono tabular-nums text-slate-500">
                                            {formatCompactNumber(v.viewCount)} views · {v.durationLabel}
                                            {v.outlierRatio ? ` · ${v.outlierRatio.toFixed(1)}x baseline` : ''}
                                          </div>
                                        </div>
                                      </div>
                                      {canWrite && (
                                        <div className="flex items-center gap-1.5 shrink-0 self-start sm:self-center">
                                          <button
                                            type="button"
                                            onClick={() =>
                                              setSaveDraft({
                                                originalVideoTitle: v.title,
                                                originalVideoUrl: v.videoUrl,
                                                competitorChannelName: c.title,
                                                competitorChannelId: c.channelId,
                                                thumbnailUrl: v.thumbnailUrl,
                                                inspirationCategory: 'video_topic',
                                                inspirationSnippet: v.outlierRatio
                                                  ? `${formatCompactNumber(v.viewCount)} views (${v.outlierRatio.toFixed(1)}x channel baseline, ${v.outlierClassification})`
                                                  : `${formatCompactNumber(v.viewCount)} views · ${v.durationLabel}`,
                                              })
                                            }
                                            className="h-8 px-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold inline-flex items-center gap-1 whitespace-nowrap"
                                          >
                                            <BookmarkPlus className="w-3.5 h-3.5" />
                                            <span>Save to Planner</span>
                                          </button>
                                          {onSendToWorkflow && (
                                            <button
                                              type="button"
                                              disabled={sendingWfId === v.videoId}
                                              onClick={() => void handleVideoToWorkflow(v, c.title)}
                                              className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 text-[11px] font-semibold inline-flex items-center gap-1 whitespace-nowrap"
                                            >
                                              {sendingWfId === v.videoId ? (
                                                <Loader2 className="w-3 h-3 animate-spin" />
                                              ) : (
                                                <Workflow className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                                              )}
                                              <span>To Workflow</span>
                                            </button>
                                          )}
                                        </div>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  Saved Deep Reports ({data.reports.length})
                </h3>
                {data.reports.length === 0 ? (
                  <p className="text-xs text-slate-500 py-4">
                    Run an analysis in the <strong>Competitor Studio</strong> tab above to generate and save multi-channel outlier &amp; gap reports here.
                  </p>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                    {data.reports.map((rep) => (
                      <div key={rep.reportKey} className="py-3 flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-900 dark:text-white truncate">
                            {rep.title}
                          </div>
                          <div className="text-slate-500 font-mono tabular-nums">
                            {rep.status} · {rep.updatedAt.slice(0, 10)}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => setActiveTab('studio')}
                          className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold whitespace-nowrap shrink-0"
                        >
                          View in Studio
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      <SaveInspirationModal
        open={Boolean(saveDraft)}
        draft={saveDraft}
        onClose={() => setSaveDraft(null)}
        authFetch={authFetch}
        workspaceKey={workspaceKey}
        channelProfiles={channelProfiles}
        defaultChannelProfileId={activeChannelProfileId}
        onSaved={(item) =>
          setSavedNotice(`Saved "${item.originalVideoTitle}" to Content Planner → Saved Inspiration.`)
        }
      />
    </div>
  );
}
