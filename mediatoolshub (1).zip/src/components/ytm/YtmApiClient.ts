import { parseSafeJsonResponse, ApiClientError } from '../../lib/apiClient.ts';
import type {
  YtmConnectedChannelRecord,
  YtmOAuthConfigValidation,
  YtmOAuthConnectionState,
} from '../../shared/types.ts';

export type AuthFetchFn = (input: string, init?: RequestInit) => Promise<Response>;

export interface YtmApiEnvelope<T> {
  ok?: boolean;
  success?: boolean;
  data?: T;
  error?: {
    code?: string;
    message?: string;
    details?: string;
    setupRequired?: boolean;
    missingVars?: string[];
    redirectUri?: string;
  };
}

export async function ytmRequest<T>(
  authFetch: AuthFetchFn,
  path: string,
  options: {
    workspaceKey?: string;
    method?: string;
    body?: unknown;
    isFormData?: boolean;
  } = {}
): Promise<T> {
  const { workspaceKey, method = 'GET', body, isFormData = false } = options;
  const url = path.startsWith('/api/') ? path : `/api/v1/ytm${path}`;
  const sep = url.includes('?') ? '&' : '?';
  const finalUrl = workspaceKey
    ? `${url}${sep}workspaceKey=${encodeURIComponent(workspaceKey)}`
    : url;

  const headers = new Headers();
  if (workspaceKey) {
    headers.set('x-ytm-workspace', workspaceKey);
  }
  let requestBody: BodyInit | undefined;
  if (body !== undefined) {
    if (isFormData && body instanceof FormData) {
      requestBody = body;
    } else {
      headers.set('Content-Type', 'application/json');
      requestBody = JSON.stringify(body);
    }
  }

  const res = await authFetch(finalUrl, {
    method,
    headers,
    body: requestBody,
  });

  const payload = await parseSafeJsonResponse<YtmApiEnvelope<T> & Record<string, unknown>>(res);
  if (payload && 'data' in payload && payload.data !== undefined) {
    return payload.data;
  }
  if (payload && payload.ok === false && payload.error) {
    throw new ApiClientError(
      payload.error.message || 'YouTube Management request failed.',
      {
        status: res.status,
        code: payload.error.code || 'YTM_ERROR',
      }
    );
  }
  return payload as unknown as T;
}

export async function copyToClipboard(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    return false;
  }
}

export function formatMoneyCents(cents: number, currency = 'USD'): string {
  const val = (cents || 0) / 100;
  try {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency || 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(val);
  } catch {
    return `$${val.toFixed(2)}`;
  }
}

export interface YtmAuthStatusData {
  oauthConfigured: boolean;
  configValidation?: YtmOAuthConfigValidation;
  missingVars: string[];
  hasEncryptionKey: boolean;
  redirectUri: string;
  connectionState: YtmOAuthConnectionState;
  statusLabel: string;
  statusMessage: string;
  missingScopes: string[];
  connectedChannel: YtmConnectedChannelRecord | null;
}

export function formatCompactNumber(val: number | null | undefined): string {
  if (val === null || val === undefined || !Number.isFinite(val)) return '—';
  return new Intl.NumberFormat('en-US', { notation: 'compact', maximumFractionDigits: 1 }).format(val);
}

export async function triggerAuthenticatedDownload(
  authFetch: AuthFetchFn,
  url: string,
  filename: string
): Promise<void> {
  const res = await authFetch(url);
  if (!res.ok) {
    const text = await res.text();
    throw new Error(text || `Download failed (${res.status})`);
  }
  const blob = await res.blob();
  const objectUrl = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = objectUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(objectUrl), 1000);
}

