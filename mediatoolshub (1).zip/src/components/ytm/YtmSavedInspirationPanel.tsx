import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertCircle,
  Bookmark,
  CalendarPlus,
  Check,
  Edit3,
  ExternalLink,
  Loader2,
  Search,
  Sparkles,
  Trash2,
} from 'lucide-react';
import type {
  YtmChannelProfileWithDna,
  YtmInspirationCategory,
  YtmInspirationStatus,
  YtmPlannerProjectRecord,
  YtmSavedInspirationRecord,
} from '../../shared/types.ts';
import { YTM_INSPIRATION_CATEGORIES } from '../../shared/ytmHelpers.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';
import { YtmInspirationAdaptModal } from './YtmInspirationAdaptModal.tsx';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  channelProfiles: YtmChannelProfileWithDna[];
  activeChannelProfileId: number | null;
  onConvertedToPlanner: (project: YtmPlannerProjectRecord) => void;
}

const STATUS_LABELS: Record<YtmInspirationStatus, string> = {
  saved: 'Awaiting Review',
  reviewed: 'Reviewed',
  adapted: 'Adapted with AI',
  converted: 'In Content Planner',
  archived: 'Archived',
};

export function YtmSavedInspirationPanel({
  authFetch,
  workspaceKey,
  canWrite,
  channelProfiles,
  activeChannelProfileId,
  onConvertedToPlanner,
}: Props) {
  const [items, setItems] = useState<YtmSavedInspirationRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');

  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [noteDraft, setNoteDraft] = useState('');
  const [savingId, setSavingId] = useState<number | null>(null);
  const [adaptTarget, setAdaptTarget] = useState<YtmSavedInspirationRecord | null>(null);

  const loadInspirations = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams();
      if (search.trim()) qs.set('q', search.trim());
      if (categoryFilter !== 'all') qs.set('category', categoryFilter);
      if (statusFilter !== 'all') qs.set('status', statusFilter);
      if (channelFilter !== 'all') qs.set('channelProfileId', channelFilter);
      qs.set('sort', sortOrder);

      const res = await ytmRequest<{ inspirations: YtmSavedInspirationRecord[] }>(
        authFetch,
        `/inspirations?${qs.toString()}`,
        { workspaceKey }
      );
      setItems(res.inspirations || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load Saved Inspiration library.');
    } finally {
      setLoading(false);
    }
  }, [authFetch, workspaceKey, search, categoryFilter, statusFilter, channelFilter, sortOrder]);

  useEffect(() => {
    void loadInspirations();
  }, [loadInspirations]);

  const handlePatch = async (
    id: number,
    patch: Partial<{
      userNotes: string;
      inspirationCategory: YtmInspirationCategory;
      status: YtmInspirationStatus;
    }>
  ) => {
    if (!canWrite) return;
    setSavingId(id);
    setError(null);
    try {
      await ytmRequest(authFetch, `/inspirations/${id}`, {
        workspaceKey,
        method: 'PATCH',
        body: patch,
      });
      setEditingNoteId(null);
      await loadInspirations();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update inspiration item.');
    } finally {
      setSavingId(null);
    }
  };

  const handleQuickConvert = async (item: YtmSavedInspirationRecord) => {
    if (!canWrite) return;
    setSavingId(item.id);
    setError(null);
    try {
      const res = await ytmRequest<{ project: YtmPlannerProjectRecord }>(
        authFetch,
        `/inspirations/${item.id}/convert-to-planner`,
        {
          workspaceKey,
          method: 'POST',
          body: {
            channelProfileId: item.channelProfileId || activeChannelProfileId || undefined,
            status: 'Selected',
          },
        }
      );
      onConvertedToPlanner(res.project);
      await loadInspirations();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to convert inspiration to planner.');
    } finally {
      setSavingId(null);
    }
  };

  const handleDelete = async (id: number) => {
    if (!canWrite) return;
    setSavingId(id);
    try {
      await ytmRequest(authFetch, `/inspirations/${id}`, {
        workspaceKey,
        method: 'DELETE',
      });
      setItems((prev) => prev.filter((item) => item.id !== id));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete saved inspiration.');
    } finally {
      setSavingId(null);
    }
  };

  const categoryLabel = (cat: string) =>
    YTM_INSPIRATION_CATEGORIES.find((c) => c.id === cat)?.label || cat.replace(/_/g, ' ');

  return (
    <div className="space-y-4">
      {/* Filter Toolbar */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-wrap items-center gap-2.5 text-xs">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search saved titles, competitors, notes..."
            className="w-full h-9 pl-9 pr-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
          />
        </div>

        <select
          value={categoryFilter}
          onChange={(e) => setCategoryFilter(e.target.value)}
          className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
        >
          <option value="all">All Categories</option>
          {YTM_INSPIRATION_CATEGORIES.map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
        >
          <option value="all">All Statuses</option>
          {(Object.keys(STATUS_LABELS) as YtmInspirationStatus[]).map((st) => (
            <option key={st} value={st}>
              {STATUS_LABELS[st]}
            </option>
          ))}
        </select>

        {channelProfiles.length > 1 && (
          <select
            value={channelFilter}
            onChange={(e) => setChannelFilter(e.target.value)}
            className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
          >
            <option value="all">All Channels</option>
            {channelProfiles.map((p) => (
              <option key={p.id} value={String(p.id)}>
                {p.channelName}
              </option>
            ))}
          </select>
        )}

        <select
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value as 'newest' | 'oldest')}
          className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
        >
          <option value="newest">Newest Saved</option>
          <option value="oldest">Oldest Saved</option>
        </select>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30 p-3.5 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {loading ? (
        <div className="py-10 flex items-center justify-center gap-2 text-xs text-slate-500">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
          <span>Loading Saved Inspiration Library...</span>
        </div>
      ) : items.length === 0 ? (
        <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-10 text-center space-y-2">
          <Bookmark className="w-6 h-6 text-slate-400 mx-auto" />
          <div className="text-sm font-semibold text-slate-900 dark:text-white">
            No saved competitor inspirations yet
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
            Browse competitor videos in <strong>Competitor &amp; Analytics</strong> or{' '}
            <strong>Competitor Intelligence Studio</strong> and click <strong>Save to Planner</strong> to collect topics, titles, hooks, thumbnails, and formats here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {items.map((item) => {
            const isEditing = editingNoteId === item.id;
            const busy = savingId === item.id;
            return (
              <div
                key={item.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-col justify-between gap-3"
              >
                <div className="space-y-3">
                  {/* Top Row: Thumbnail + Title + Source */}
                  <div className="flex items-start gap-3">
                    {item.thumbnailUrl ? (
                      <img
                        src={item.thumbnailUrl}
                        alt={item.originalVideoTitle}
                        referrerPolicy="no-referrer"
                        className="w-28 aspect-video rounded-lg object-cover border border-slate-200 dark:border-slate-800 shrink-0"
                      />
                    ) : (
                      <div className="w-28 aspect-video rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950 flex items-center justify-center text-[11px] font-medium text-slate-400 shrink-0">
                        Reference
                      </div>
                    )}

                    <div className="min-w-0 flex-1 space-y-1">
                      <div className="text-sm font-semibold text-slate-950 dark:text-white leading-snug line-clamp-2">
                        {item.originalVideoTitle}
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-x-1.5 gap-y-0.5">
                        <span className="font-medium text-slate-700 dark:text-slate-300">
                          {item.competitorChannelName || 'Competitor'}
                        </span>
                        <span>·</span>
                        <span>{categoryLabel(item.inspirationCategory)}</span>
                        <span>·</span>
                        <span className="font-mono tabular-nums">{item.savedAt.slice(0, 10)}</span>
                        {item.channelProfileName && (
                          <>
                            <span>·</span>
                            <span>{item.channelProfileName}</span>
                          </>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px]">
                        <span
                          className={`font-semibold ${
                            item.status === 'converted'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : item.status === 'adapted'
                                ? 'text-blue-600 dark:text-blue-400'
                                : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          {STATUS_LABELS[item.status]}
                        </span>
                        {item.originalVideoUrl && (
                          <a
                            href={item.originalVideoUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-0.5"
                          >
                            <span>Source URL</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Snippet */}
                  {item.inspirationSnippet && (
                    <p className="text-xs text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800 rounded-lg p-2.5 leading-relaxed">
                      {item.inspirationSnippet}
                    </p>
                  )}

                  {/* Latest AI Adaptation Preview */}
                  {item.latestAdaptedIdea && (
                    <div className="rounded-lg border border-blue-200 dark:border-blue-900/70 bg-blue-50/50 dark:bg-blue-950/20 p-2.5 space-y-1 text-xs">
                      <div className="font-semibold text-blue-800 dark:text-blue-300">
                        Adapted Draft: {item.latestAdaptedIdea.selectedTitle}
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 line-clamp-2">
                        {item.latestAdaptedIdea.freshAngle}
                      </p>
                    </div>
                  )}

                  {/* Personal Notes Inline Editor */}
                  <div className="text-xs">
                    {isEditing ? (
                      <div className="space-y-2">
                        <textarea
                          rows={2}
                          value={noteDraft}
                          onChange={(e) => setNoteDraft(e.target.value)}
                          placeholder="Add your personal angle or observations..."
                          className="w-full p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                        />
                        <div className="flex justify-end gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingNoteId(null)}
                            className="h-7 px-2.5 rounded border border-slate-200 dark:border-slate-700"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => void handlePatch(item.id, { userNotes: noteDraft })}
                            className="h-7 px-3 rounded bg-blue-600 text-white font-semibold"
                          >
                            Save Notes
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start justify-between gap-2">
                        <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                          {item.userNotes ? (
                            <>
                              <span className="font-semibold text-slate-700 dark:text-slate-300">
                                Notes:{' '}
                              </span>
                              {item.userNotes}
                            </>
                          ) : (
                            <span className="text-slate-400">No personal notes yet.</span>
                          )}
                        </p>
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingNoteId(item.id);
                              setNoteDraft(item.userNotes || '');
                            }}
                            className="text-slate-400 hover:text-blue-600 shrink-0 p-1"
                            title="Edit personal notes"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* Action Footer */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex flex-wrap items-center gap-1.5">
                    {canWrite && (
                      <select
                        value={item.inspirationCategory}
                        disabled={busy}
                        onChange={(e) =>
                          void handlePatch(item.id, {
                            inspirationCategory: e.target.value as YtmInspirationCategory,
                          })
                        }
                        aria-label="Edit inspiration category"
                        className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-[11px]"
                      >
                        {YTM_INSPIRATION_CATEGORIES.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.label}
                          </option>
                        ))}
                      </select>
                    )}

                    {canWrite && item.status === 'saved' && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void handlePatch(item.id, { status: 'reviewed' })}
                        className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-[11px] font-semibold inline-flex items-center gap-1"
                      >
                        <Check className="w-3 h-3" />
                        <span>Mark Reviewed</span>
                      </button>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    {canWrite && (
                      <>
                        <button
                          type="button"
                          onClick={() => setAdaptTarget(item)}
                          className="h-8 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold inline-flex items-center gap-1"
                        >
                          <Sparkles className="w-3 h-3" />
                          <span>
                            {item.latestAdaptedIdea ? 'View / Edit Adaptation' : 'Adapt for My Channel'}
                          </span>
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => void handleQuickConvert(item)}
                          className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-[11px] font-semibold inline-flex items-center gap-1"
                        >
                          <CalendarPlus className="w-3 h-3" />
                          <span>To Planner</span>
                        </button>
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() => void handleDelete(item.id)}
                          aria-label="Delete saved inspiration"
                          className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <YtmInspirationAdaptModal
        open={Boolean(adaptTarget)}
        inspiration={adaptTarget}
        onClose={() => setAdaptTarget(null)}
        authFetch={authFetch}
        workspaceKey={workspaceKey}
        channelProfiles={channelProfiles}
        activeChannelProfileId={activeChannelProfileId}
        onConverted={(proj) => {
          onConvertedToPlanner(proj);
          void loadInspirations();
        }}
        onAdaptedUpdated={() => void loadInspirations()}
      />
    </div>
  );
}
