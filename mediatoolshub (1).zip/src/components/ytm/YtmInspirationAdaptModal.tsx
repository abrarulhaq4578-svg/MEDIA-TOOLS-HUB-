import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  CalendarPlus,
  Check,
  Dna,
  ExternalLink,
  Loader2,
  Sparkles,
  X,
} from 'lucide-react';
import type {
  YtmAdaptedIdeaRecord,
  YtmChannelProfileWithDna,
  YtmPlannerProjectRecord,
  YtmSavedInspirationRecord,
} from '../../shared/types.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  open: boolean;
  inspiration: YtmSavedInspirationRecord | null;
  onClose: () => void;
  authFetch: AuthFetchFn;
  workspaceKey: string;
  channelProfiles: YtmChannelProfileWithDna[];
  activeChannelProfileId: number | null;
  onConverted: (project: YtmPlannerProjectRecord) => void;
  onAdaptedUpdated: () => void;
}

export function YtmInspirationAdaptModal({
  open,
  inspiration,
  onClose,
  authFetch,
  workspaceKey,
  channelProfiles,
  activeChannelProfileId,
  onConverted,
  onAdaptedUpdated,
}: Props) {
  const [selectedChannelId, setSelectedChannelId] = useState<number | ''>('');
  const [creatorDirection, setCreatorDirection] = useState('');
  const [adapted, setAdapted] = useState<YtmAdaptedIdeaRecord | null>(null);
  const [generating, setGenerating] = useState(false);
  const [savingEdits, setSavingEdits] = useState(false);
  const [converting, setConverting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  // Editable fields before saving to planner
  const [selectedTitle, setSelectedTitle] = useState('');
  const [freshAngle, setFreshAngle] = useState('');
  const [uniqueHook, setUniqueHook] = useState('');
  const [outlineText, setOutlineText] = useState('');
  const [thumbnailDirection, setThumbnailDirection] = useState('');
  const [userNotes, setUserNotes] = useState('');
  const [plannedDate, setPlannedDate] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'urgent'>('medium');

  const hydrateFieldsFromAdapted = (item: YtmAdaptedIdeaRecord) => {
    setAdapted(item);
    setSelectedTitle(item.selectedTitle || item.titleOptions[0] || '');
    setFreshAngle(item.freshAngle || '');
    setUniqueHook(item.uniqueHook || '');
    setOutlineText((item.videoOutline || []).join('\n'));
    setThumbnailDirection(item.thumbnailDirection || '');
    setUserNotes(item.userNotes || '');
  };

  useEffect(() => {
    if (!open || !inspiration) return;
    setError(null);
    setNotice(null);
    setCreatorDirection('');
    setPlannedDate('');
    setPriority('medium');

    const initialCh =
      inspiration.channelProfileId ||
      activeChannelProfileId ||
      channelProfiles.find((p) => p.isDefault)?.id ||
      channelProfiles[0]?.id ||
      '';
    setSelectedChannelId(initialCh);

    if (inspiration.latestAdaptedIdea) {
      hydrateFieldsFromAdapted(inspiration.latestAdaptedIdea);
    } else {
      setAdapted(null);
      setSelectedTitle('');
      setFreshAngle('');
      setUniqueHook('');
      setOutlineText('');
      setThumbnailDirection('');
      setUserNotes(inspiration.userNotes || '');
    }
  }, [open, inspiration, activeChannelProfileId, channelProfiles]);

  if (!open || !inspiration) return null;

  const chosenChannel = channelProfiles.find((p) => p.id === selectedChannelId) || null;

  const handleGenerate = async () => {
    setGenerating(true);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{ adaptedIdea: YtmAdaptedIdeaRecord }>(
        authFetch,
        `/inspirations/${inspiration.id}/adapt`,
        {
          workspaceKey,
          method: 'POST',
          body: {
            channelProfileId: typeof selectedChannelId === 'number' ? selectedChannelId : undefined,
            creatorDirection: creatorDirection.trim(),
          },
        }
      );
      hydrateFieldsFromAdapted(res.adaptedIdea);
      onAdaptedUpdated();
      setNotice('Original channel-specific adaptation generated using your active Channel DNA.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to adapt idea.');
    } finally {
      setGenerating(false);
    }
  };

  const persistCurrentEdits = async (): Promise<YtmAdaptedIdeaRecord | null> => {
    if (!adapted) return null;
    const outlineLines = outlineText
      .split('\n')
      .map((l) => l.trim())
      .filter(Boolean);
    const res = await ytmRequest<{ adaptedIdea: YtmAdaptedIdeaRecord }>(
      authFetch,
      `/adapted-ideas/${adapted.id}`,
      {
        workspaceKey,
        method: 'PATCH',
        body: {
          selectedTitle: selectedTitle.trim(),
          freshAngle: freshAngle.trim(),
          uniqueHook: uniqueHook.trim(),
          videoOutline: outlineLines,
          thumbnailDirection: thumbnailDirection.trim(),
          userNotes: userNotes.trim(),
        },
      }
    );
    setAdapted(res.adaptedIdea);
    onAdaptedUpdated();
    return res.adaptedIdea;
  };

  const handleSaveEdits = async () => {
    if (!adapted) return;
    setSavingEdits(true);
    setError(null);
    try {
      await persistCurrentEdits();
      setNotice('Your edits to this adapted concept have been saved.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save edits.');
    } finally {
      setSavingEdits(false);
    }
  };

  const handleConvertToPlanner = async () => {
    setConverting(true);
    setError(null);
    try {
      let currentAdapted = adapted;
      if (currentAdapted) {
        currentAdapted = await persistCurrentEdits();
      }
      const res = await ytmRequest<{ project: YtmPlannerProjectRecord }>(
        authFetch,
        `/inspirations/${inspiration.id}/convert-to-planner`,
        {
          workspaceKey,
          method: 'POST',
          body: {
            adaptedIdeaId: currentAdapted?.id,
            channelProfileId: typeof selectedChannelId === 'number' ? selectedChannelId : undefined,
            title: selectedTitle.trim() || inspiration.originalVideoTitle,
            adaptedAngle: freshAngle.trim(),
            notes: userNotes.trim(),
            plannedDate: plannedDate || null,
            priority,
            status: 'Selected',
          },
        }
      );
      onConverted(res.project);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save adapted concept to planner.');
    } finally {
      setConverting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl max-h-[92vh] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <Sparkles className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
            <div className="min-w-0">
              <h2 className="font-display text-base font-bold text-slate-950 dark:text-white truncate">
                Adapt Competitor Inspiration for My Channel
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Creates an original, differentiated concept grounded in your Channel DNA — never copies competitor scripts or exact titles.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close adaptation modal"
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 text-xs">
          {/* Source Inspiration Context */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 flex flex-col sm:flex-row items-start gap-3">
            {inspiration.thumbnailUrl && (
              <img
                src={inspiration.thumbnailUrl}
                alt={inspiration.originalVideoTitle}
                referrerPolicy="no-referrer"
                className="w-32 aspect-video rounded-lg object-cover border border-slate-200 dark:border-slate-800 shrink-0"
              />
            )}
            <div className="min-w-0 flex-1 space-y-1">
              <div className="font-semibold text-sm text-slate-950 dark:text-white">
                {inspiration.originalVideoTitle}
              </div>
              <div className="text-slate-500 dark:text-slate-400">
                Source: {inspiration.competitorChannelName || 'Competitor'} · Category:{' '}
                {inspiration.inspirationCategory.replace(/_/g, ' ')}
                {inspiration.originalVideoUrl && (
                  <>
                    {' '}
                    ·{' '}
                    <a
                      href={inspiration.originalVideoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-0.5"
                    >
                      <span>Original video</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </>
                )}
              </div>
              {inspiration.userNotes && (
                <p className="text-slate-600 dark:text-slate-300">Notes: {inspiration.userNotes}</p>
              )}
            </div>
          </div>

          {/* Channel DNA Selector & Generate Controls */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 p-4 space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
              <div className="md:col-span-5">
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Target Channel DNA Profile
                </label>
                <select
                  value={selectedChannelId}
                  onChange={(e) =>
                    setSelectedChannelId(e.target.value ? Number.parseInt(e.target.value, 10) : '')
                  }
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                >
                  {channelProfiles.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.channelName}
                      {p.niche ? ` — ${p.niche}` : ''}
                    </option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-5">
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Optional Creative Twist / Focus
                </label>
                <input
                  type="text"
                  value={creatorDirection}
                  onChange={(e) => setCreatorDirection(e.target.value)}
                  placeholder="e.g., Focus on zero-budget beginners, add case study..."
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>
              <div className="md:col-span-2">
                <button
                  type="button"
                  disabled={generating}
                  onClick={() => void handleGenerate()}
                  className="w-full h-10 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold inline-flex items-center justify-center gap-1.5"
                >
                  {generating ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Sparkles className="w-3.5 h-3.5" />
                  )}
                  <span>{adapted ? 'Regenerate' : 'Adapt Idea'}</span>
                </button>
              </div>
            </div>

            {chosenChannel && (
              <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-500 dark:text-slate-400">
                <span className="inline-flex items-center gap-1 font-semibold text-slate-700 dark:text-slate-300">
                  <Dna className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  DNA Loaded:
                </span>
                <span>{chosenChannel.dna.preferredLanguage || 'English'}</span>
                {chosenChannel.dna.toneOfVoice && <span>· {chosenChannel.dna.toneOfVoice}</span>}
                {chosenChannel.dna.preferredVideoDuration && (
                  <span>· {chosenChannel.dna.preferredVideoDuration}</span>
                )}
                {chosenChannel.dna.targetAudience && (
                  <span>· Audience: {chosenChannel.dna.targetAudience}</span>
                )}
              </div>
            )}
          </div>

          {error && (
            <div className="rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30 p-3 text-rose-700 dark:text-rose-300 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {notice && (
            <div className="rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 p-3 text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>{notice}</span>
            </div>
          )}

          {/* Adapted Concept Output & Editable Workbench */}
          {adapted ? (
            <div className="space-y-4">
              {/* Analytical Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="rounded-lg border border-slate-200 dark:border-slate-800 p-3.5 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-white">
                    Original Concept Summary
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {adapted.originalConceptSummary}
                  </p>
                </div>
                <div className="rounded-lg border border-slate-200 dark:border-slate-800 p-3.5 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-white">Why It Works</div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {adapted.whyItWorks}
                  </p>
                </div>
                <div className="rounded-lg border border-slate-200 dark:border-slate-800 p-3.5 space-y-1">
                  <div className="font-semibold text-slate-900 dark:text-white">
                    Channel DNA Fit
                  </div>
                  <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                    {adapted.channelFitExplanation}
                  </p>
                </div>
              </div>

              {/* Selectable Original Title Options */}
              <div className="space-y-2">
                <label className="block font-semibold text-slate-800 dark:text-slate-200">
                  Original Title Options (click one or customize below)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {adapted.titleOptions.map((opt, idx) => {
                    const isSelected = selectedTitle === opt;
                    return (
                      <button
                        key={idx}
                        type="button"
                        onClick={() => setSelectedTitle(opt)}
                        className={`text-left p-2.5 rounded-lg border transition-colors ${
                          isSelected
                            ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-950 dark:text-white font-semibold'
                            : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        {opt}
                      </button>
                    );
                  })}
                </div>
                <input
                  type="text"
                  value={selectedTitle}
                  onChange={(e) => setSelectedTitle(e.target.value)}
                  placeholder="Your final working title for Content Planner..."
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-950 dark:text-white font-semibold"
                />
              </div>

              {/* Editable Differentiated Fields */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Fresh Differentiated Angle
                  </label>
                  <textarea
                    rows={3}
                    value={freshAngle}
                    onChange={(e) => setFreshAngle(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Unique Opening Hook (15–30s)
                  </label>
                  <textarea
                    rows={3}
                    value={uniqueHook}
                    onChange={(e) => setUniqueHook(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Brief Video Outline (one section per line)
                  </label>
                  <textarea
                    rows={5}
                    value={outlineText}
                    onChange={(e) => setOutlineText(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white font-mono text-[11px]"
                  />
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Thumbnail Direction
                    </label>
                    <textarea
                      rows={2}
                      value={thumbnailDirection}
                      onChange={(e) => setThumbnailDirection(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                      Production Notes
                    </label>
                    <textarea
                      rows={2}
                      value={userNotes}
                      onChange={(e) => setUserNotes(e.target.value)}
                      className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Optional Scheduling before Convert */}
              <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3.5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Schedule Planned Date (optional)
                  </label>
                  <input
                    type="date"
                    value={plannedDate}
                    onChange={(e) => setPlannedDate(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Planner Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) =>
                      setPriority(e.target.value as 'low' | 'medium' | 'high' | 'urgent')
                    }
                    className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>
            </div>
          ) : (
            <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-700 p-8 text-center space-y-2">
              <p className="text-sm font-semibold text-slate-900 dark:text-white">
                Ready to adapt this idea for {chosenChannel?.channelName || 'your channel'}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-md mx-auto">
                Click <strong>Adapt Idea</strong> to generate an original angle, 5 channel-tailored titles, opening hook, video outline, and thumbnail direction.
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs">
          <button
            type="button"
            onClick={onClose}
            className="h-9 px-4 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold"
          >
            Close
          </button>
          <div className="flex flex-wrap items-center gap-2">
            {adapted && (
              <button
                type="button"
                disabled={savingEdits}
                onClick={() => void handleSaveEdits()}
                className="h-9 px-4 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 font-semibold inline-flex items-center gap-1.5"
              >
                {savingEdits ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                <span>Save Draft Edits</span>
              </button>
            )}
            <button
              type="button"
              disabled={converting || (!adapted && !selectedTitle && !inspiration.originalVideoTitle)}
              onClick={() => void handleConvertToPlanner()}
              className="h-9 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-500 disabled:opacity-50 text-white font-semibold inline-flex items-center gap-1.5"
            >
              {converting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <CalendarPlus className="w-3.5 h-3.5" />
              )}
              <span>Save to Content Planner</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
