import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  Image as ImageIcon,
  Loader2,
  Plus,
  RefreshCw,
  Sparkles,
  Trash2,
  Upload,
} from 'lucide-react';
import type {
  YtmCommunityPostFormat,
  YtmCommunityPostPayload,
  YtmCommunityPostRecord,
} from '../../shared/types.ts';
import { copyToClipboard, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  workflowProjectId?: number | null;
  projectTitle?: string;
  projectTopic?: string;
  channelProfileId?: number | null;
  canWrite: boolean;
  onPostApproved?: () => void;
}

const FOUR_POST_TYPES: Array<{
  id: 'image_post' | 'simple_text' | 'text_poll' | 'poll';
  number: 1 | 2 | 3 | 4;
  label: string;
  description: string;
}> = [
  {
    id: 'image_post',
    number: 1,
    label: 'Image Post',
    description: 'Upload or AI-prompt an image with headline caption, copy & CTA',
  },
  {
    id: 'simple_text',
    number: 2,
    label: 'Text Post',
    description: 'Community update, discussion prompt, or announcement with CTA',
  },
  {
    id: 'text_poll',
    number: 3,
    label: 'Text Poll',
    description: 'Poll question with text voting options and optional caption',
  },
  {
    id: 'poll',
    number: 4,
    label: 'Poll',
    description: 'Interactive Image Poll (visual choices) or Quiz Poll (correct answer)',
  },
];

function emptyPayloadForFormat(format: YtmCommunityPostFormat): YtmCommunityPostPayload {
  switch (format) {
    case 'quiz':
      return {
        question: '',
        options: [
          { id: 'opt_1', label: '' },
          { id: 'opt_2', label: '' },
          { id: 'opt_3', label: '' },
          { id: 'opt_4', label: '' },
        ],
        correctOptionIndex: 0,
        explanation: '',
        callToAction: '',
      };
    case 'text_poll':
      return {
        question: '',
        options: [
          { id: 'opt_1', label: '' },
          { id: 'opt_2', label: '' },
          { id: 'opt_3', label: '' },
        ],
        caption: '',
        callToAction: '',
      };
    case 'image_poll':
      return {
        question: '',
        options: [
          { id: 'opt_1', label: '', imagePrompt: '', imageUrl: null },
          { id: 'opt_2', label: '', imagePrompt: '', imageUrl: null },
        ],
        caption: '',
        callToAction: '',
      };
    case 'image_post':
      return {
        caption: '',
        bodyText: '',
        imagePrompt: '',
        imageUrl: null,
        callToAction: '',
      };
    case 'simple_text':
    default:
      return {
        bodyText: '',
        callToAction: '',
      };
  }
}

function formatCopyablePost(
  format: YtmCommunityPostFormat,
  payload: YtmCommunityPostPayload
): string {
  const lines: string[] = [];
  if (payload.question) lines.push(payload.question);
  if (payload.caption) lines.push(payload.caption);
  if (payload.bodyText) lines.push(payload.bodyText);
  if (payload.options?.length) {
    lines.push('');
    payload.options.forEach((opt, i) => {
      const marker =
        format === 'quiz' && payload.correctOptionIndex === i ? ' [Correct Answer]' : '';
      lines.push(`${i + 1}. ${opt.label}${marker}`);
    });
  }
  if (format === 'quiz' && payload.explanation) {
    lines.push('', `Explanation: ${payload.explanation}`);
  }
  if (payload.callToAction) {
    lines.push('', payload.callToAction);
  }
  return lines.join('\n').trim();
}

export function YtmCommunityPostCreator({
  authFetch,
  workspaceKey,
  workflowProjectId = null,
  projectTitle = '',
  projectTopic,
  channelProfileId,
  canWrite,
  onPostApproved,
}: Props) {
  const [posts, setPosts] = useState<YtmCommunityPostRecord[]>([]);
  const [limitationNotice, setLimitationNotice] = useState(
    'YouTube Data API v3 does not expose a public endpoint to directly publish YouTube Community Posts. Save and approve your post here, then copy or open YouTube Studio to publish.'
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [activePostId, setActivePostId] = useState<number | null>(null);
  const [formatType, setFormatType] = useState<YtmCommunityPostFormat>('image_post');
  const [topic, setTopic] = useState(projectTopic || projectTitle || '');
  const [title, setTitle] = useState('');
  const [payload, setPayload] = useState<YtmCommunityPostPayload>(() =>
    emptyPayloadForFormat('image_post')
  );
  const [status, setStatus] = useState<'draft' | 'approved' | 'manually_published'>('draft');

  const [generating, setGenerating] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploadingKey, setUploadingKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const loadPosts = async () => {
    setLoading(true);
    setError(null);
    try {
      const endpoint = workflowProjectId
        ? `/community-posts?workflowProjectId=${workflowProjectId}`
        : '/community-posts';
      const res = await ytmRequest<{
        posts: YtmCommunityPostRecord[];
        youtubeApiLimitationNotice?: string;
      }>(authFetch, endpoint, {
        workspaceKey,
      });
      setPosts(res.posts || []);
      if (res.youtubeApiLimitationNotice) {
        setLimitationNotice(res.youtubeApiLimitationNotice);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load Community Posts.');
    } finally {
      setLoading(false);
    }
  };

  // Strict per-project isolation whenever workflowProjectId changes
  useEffect(() => {
    setActivePostId(null);
    setTopic(projectTopic || projectTitle || '');
    setTitle('');
    setFormatType('image_post');
    setPayload(emptyPayloadForFormat('image_post'));
    setStatus('draft');
    setNotice(null);
    void loadPosts();
  }, [workflowProjectId, workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSelectFormat = (nextFormat: YtmCommunityPostFormat) => {
    setFormatType(nextFormat);
    if (!activePostId) {
      setPayload(emptyPayloadForFormat(nextFormat));
    }
  };

  const handleLoadSavedPost = (p: YtmCommunityPostRecord) => {
    setActivePostId(p.id);
    setFormatType(p.formatType);
    setTopic(p.topic || projectTitle);
    setTitle(p.title);
    setPayload(p.payload);
    setStatus(p.status);
    setNotice(null);
  };

  const handleStartBlank = () => {
    setActivePostId(null);
    setTopic(projectTopic || projectTitle || '');
    setTitle('');
    setPayload(emptyPayloadForFormat(formatType));
    setStatus('draft');
    setNotice(null);
  };

  const handleGenerate = async () => {
    if (!canWrite) return;
    setGenerating(true);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{
        title: string;
        payload: YtmCommunityPostPayload;
      }>(authFetch, '/community-posts/generate', {
        workspaceKey,
        method: 'POST',
        body: {
          formatType,
          topic: topic.trim() || projectTitle,
          workflowProjectId,
          channelProfileId: channelProfileId ?? null,
        },
      });
      setTitle(res.title || `${formatType.replace(/_/g, ' ')} Draft`);
      setPayload(res.payload || emptyPayloadForFormat(formatType));
      setNotice('AI generated a Channel DNA-aligned Community Post draft. Review and edit before approving.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to generate Community Post.');
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async (nextStatus: 'draft' | 'approved' | 'manually_published') => {
    if (!canWrite) return;
    setSaving(true);
    setError(null);
    setNotice(null);
    try {
      const body = {
        workflowProjectId: workflowProjectId ?? null,
        channelProfileId: channelProfileId ?? null,
        formatType,
        topic: topic.trim() || projectTitle || 'Community Post',
        title:
          title.trim() ||
          `${projectTitle || topic.trim() || 'Community Post'} — ${formatType.replace(/_/g, ' ')}`,
        payload,
        status: nextStatus,
      };
      const res = activePostId
        ? await ytmRequest<{ post: YtmCommunityPostRecord }>(
            authFetch,
            `/community-posts/${activePostId}`,
            { workspaceKey, method: 'PATCH', body }
          )
        : await ytmRequest<{ post: YtmCommunityPostRecord }>(authFetch, '/community-posts', {
            workspaceKey,
            method: 'POST',
            body,
          });
      setActivePostId(res.post.id);
      setStatus(res.post.status);
      setNotice(
        nextStatus === 'approved'
          ? 'Community Post approved and saved to this project queue.'
          : nextStatus === 'manually_published'
            ? 'Marked as manually published in YouTube Studio.'
            : 'Community Post draft saved.'
      );
      await loadPosts();
      if (nextStatus === 'approved' && onPostApproved) {
        onPostApproved();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save Community Post.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!canWrite) return;
    try {
      await ytmRequest(authFetch, `/community-posts/${id}`, {
        workspaceKey,
        method: 'DELETE',
      });
      if (activePostId === id) handleStartBlank();
      await loadPosts();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete Community Post.');
    }
  };

  const handleUploadImage = async (file: File, targetOptionId?: string) => {
    if (!canWrite) return;
    const key = targetOptionId || 'main';
    setUploadingKey(key);
    setError(null);
    try {
      const fd = new FormData();
      fd.append('image', file);
      const res = await authFetch(
        `/api/v1/ytm/community-posts/upload-image?workspaceKey=${encodeURIComponent(workspaceKey)}`,
        { method: 'POST', body: fd }
      );
      const json = (await res.json()) as {
        ok: boolean;
        data?: { imageUrl: string };
        error?: { message?: string };
      };
      if (!res.ok || !json.ok || !json.data?.imageUrl) {
        throw new Error(json.error?.message || 'Image upload failed.');
      }
      if (targetOptionId) {
        setPayload((prev) => ({
          ...prev,
          options: (prev.options || []).map((o) =>
            o.id === targetOptionId ? { ...o, imageUrl: json.data!.imageUrl } : o
          ),
        }));
      } else {
        setPayload((prev) => ({ ...prev, imageUrl: json.data!.imageUrl }));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Image upload failed.');
    } finally {
      setUploadingKey(null);
    }
  };

  const handleCopyPost = async () => {
    const text = formatCopyablePost(formatType, payload);
    if (await copyToClipboard(text)) {
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    }
  };

  const updateOption = (optId: string, patch: { label?: string; imagePrompt?: string }) => {
    setPayload((prev) => ({
      ...prev,
      options: (prev.options || []).map((o) => (o.id === optId ? { ...o, ...patch } : o)),
    }));
  };

  const addOption = () => {
    setPayload((prev) => {
      const list = prev.options || [];
      if (list.length >= 5) return prev;
      return {
        ...prev,
        options: [
          ...list,
          { id: `opt_${list.length + 1}`, label: '', imagePrompt: '', imageUrl: null },
        ],
      };
    });
  };

  return (
    <div className="space-y-4 text-xs">
      {/* Honest YouTube API Limitation Disclosure */}
      <div className="rounded-lg border border-amber-200 dark:border-amber-900 bg-amber-50/70 dark:bg-amber-950/20 p-3 text-amber-900 dark:text-amber-200 leading-relaxed">
        <strong>YouTube Community Post Publishing Note:</strong> {limitationNotice}
      </div>

      {/* 4 Post Types Selector */}
      <div className="space-y-2">
        <div className="font-semibold text-slate-800 dark:text-slate-200">
          Select Post Type
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {FOUR_POST_TYPES.map((fmt) => {
            const active =
              fmt.id === 'poll'
                ? formatType === 'image_poll' || formatType === 'quiz'
                : formatType === fmt.id;
            return (
              <button
                key={fmt.id}
                type="button"
                onClick={() =>
                  handleSelectFormat(
                    fmt.id === 'poll'
                      ? formatType === 'quiz'
                        ? 'quiz'
                        : 'image_poll'
                      : fmt.id
                  )
                }
                className={`p-3 rounded-lg border text-left transition-colors ${
                  active
                    ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-950 dark:text-white'
                    : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 hover:border-slate-300'
                }`}
              >
                <div className="font-semibold">
                  {fmt.number}. {fmt.label}
                </div>
                <div className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">
                  {fmt.description}
                </div>
              </button>
            );
          })}
        </div>

        {(formatType === 'image_poll' || formatType === 'quiz') && (
          <div className="flex items-center gap-2 pt-0.5">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              Poll Style:
            </span>
            <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-950 text-[11px]">
              <button
                type="button"
                onClick={() => handleSelectFormat('image_poll')}
                className={`h-7 px-2.5 rounded-md font-semibold ${
                  formatType === 'image_poll'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Image Poll
              </button>
              <button
                type="button"
                onClick={() => handleSelectFormat('quiz')}
                className={`h-7 px-2.5 rounded-md font-semibold ${
                  formatType === 'quiz'
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-600 dark:text-slate-300'
                }`}
              >
                Quiz Poll
              </button>
            </div>
          </div>
        )}
      </div>

      {error && (
        <div className="rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/20 p-3 text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 p-3 text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Topic + AI Generation Controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-2.5 items-end">
        <div className="md:col-span-5">
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Post Topic / Video Connection
          </label>
          <input
            type="text"
            disabled={!canWrite}
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="Topic or video tie-in..."
            className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
          />
        </div>
        <div className="md:col-span-4">
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Internal Draft Label
          </label>
          <input
            type="text"
            disabled={!canWrite}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g., Pre-launch Poll for Video"
            className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
          />
        </div>
        <div className="md:col-span-3 flex gap-1.5">
          {canWrite && (
            <button
              type="button"
              disabled={generating}
              onClick={() => void handleGenerate()}
              className="flex-1 h-10 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold inline-flex items-center justify-center gap-1.5"
            >
              {generating ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5" />
              )}
              <span>{generating ? 'Drafting...' : 'AI Draft'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={handleStartBlank}
            className="h-10 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
            title="Start fresh blank post"
          >
            New
          </button>
        </div>
      </div>

      {/* Format-Specific Structured Editor */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-4 space-y-3">
        {(formatType === 'quiz' || formatType === 'text_poll' || formatType === 'image_poll') && (
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {formatType === 'quiz' ? 'Quiz Question' : 'Poll Question'}
            </label>
            <input
              type="text"
              disabled={!canWrite}
              value={payload.question || ''}
              onChange={(e) => setPayload({ ...payload, question: e.target.value })}
              placeholder="Write a clear, engaging question for your subscribers..."
              className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
            />
          </div>
        )}

        {(formatType === 'quiz' || formatType === 'text_poll' || formatType === 'image_poll') && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-700 dark:text-slate-300">
                Options ({(payload.options || []).length})
              </span>
              {canWrite && (payload.options || []).length < 5 && (
                <button
                  type="button"
                  onClick={addOption}
                  className="text-blue-600 dark:text-blue-400 font-semibold inline-flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Add Option
                </button>
              )}
            </div>
            {(payload.options || []).map((opt, idx) => (
              <div
                key={opt.id}
                className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5 space-y-2"
              >
                <div className="flex items-center gap-2">
                  {formatType === 'quiz' && (
                    <input
                      type="radio"
                      name="quiz-correct"
                      disabled={!canWrite}
                      checked={(payload.correctOptionIndex ?? 0) === idx}
                      onChange={() => setPayload({ ...payload, correctOptionIndex: idx })}
                      title="Mark as correct quiz answer"
                    />
                  )}
                  <span className="font-mono text-[11px] text-slate-400">#{idx + 1}</span>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={opt.label}
                    onChange={(e) => updateOption(opt.id, { label: e.target.value })}
                    placeholder={`Option ${idx + 1} label...`}
                    className="flex-1 h-8 px-2.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                  {formatType === 'quiz' && (payload.correctOptionIndex ?? 0) === idx && (
                    <span className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400">
                      Correct
                    </span>
                  )}
                </div>

                {formatType === 'image_poll' && (
                  <div className="flex flex-wrap items-center gap-2 pl-5">
                    <input
                      type="text"
                      disabled={!canWrite}
                      value={opt.imagePrompt || ''}
                      onChange={(e) => updateOption(opt.id, { imagePrompt: e.target.value })}
                      placeholder="Visual description / AI image prompt for this option..."
                      className="flex-1 min-w-[200px] h-8 px-2.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-[11px]"
                    />
                    {canWrite && (
                      <label className="h-8 px-2.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 cursor-pointer inline-flex items-center gap-1 font-semibold">
                        {uploadingKey === opt.id ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Upload className="w-3 h-3" />
                        )}
                        <span>{opt.imageUrl ? 'Replace Image' : 'Upload Image'}</span>
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/webp"
                          className="hidden"
                          onChange={(e) => {
                            const f = e.target.files?.[0];
                            if (f) void handleUploadImage(f, opt.id);
                          }}
                        />
                      </label>
                    )}
                    {opt.imageUrl && (
                      <img
                        src={opt.imageUrl}
                        alt={opt.label || `Option ${idx + 1}`}
                        className="w-12 h-12 rounded object-cover border border-slate-200 dark:border-slate-700"
                      />
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {formatType === 'quiz' && (
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Answer Explanation (shown after viewers vote)
            </label>
            <textarea
              rows={2}
              disabled={!canWrite}
              value={payload.explanation || ''}
              onChange={(e) => setPayload({ ...payload, explanation: e.target.value })}
              placeholder="Explain why the correct answer is right..."
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
            />
          </div>
        )}

        {formatType === 'image_post' && (
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-3">
              {canWrite && (
                <label className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 cursor-pointer inline-flex items-center gap-1.5 font-semibold">
                  {uploadingKey === 'main' ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  )}
                  <span>{payload.imageUrl ? 'Replace Post Image' : 'Upload Post Image'}</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) void handleUploadImage(f);
                    }}
                  />
                </label>
              )}
              <input
                type="text"
                disabled={!canWrite}
                value={payload.imagePrompt || ''}
                onChange={(e) => setPayload({ ...payload, imagePrompt: e.target.value })}
                placeholder="AI image concept / visual prompt..."
                className="flex-1 min-w-[220px] h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>
            {payload.imageUrl && (
              <img
                src={payload.imageUrl}
                alt={title || 'Community image post'}
                className="max-h-48 rounded-lg border border-slate-200 dark:border-slate-700 object-contain"
              />
            )}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Image Caption
              </label>
              <input
                type="text"
                disabled={!canWrite}
                value={payload.caption || ''}
                onChange={(e) => setPayload({ ...payload, caption: e.target.value })}
                placeholder="Headline caption for the image..."
                className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
              />
            </div>
          </div>
        )}

        {(formatType === 'image_post' || formatType === 'simple_text') && (
          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              {formatType === 'simple_text' ? 'Post Text / Discussion Prompt' : 'Supporting Post Copy'}
            </label>
            <textarea
              rows={4}
              disabled={!canWrite}
              value={payload.bodyText || ''}
              onChange={(e) => setPayload({ ...payload, bodyText: e.target.value })}
              placeholder="Write your Community Post message..."
              className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
            />
          </div>
        )}

        <div>
          <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Call to Action (optional)
          </label>
          <input
            type="text"
            disabled={!canWrite}
            value={payload.callToAction || ''}
            onChange={(e) => setPayload({ ...payload, callToAction: e.target.value })}
            placeholder="e.g., Drop your vote and tell me why in the comments!"
            className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void handleCopyPost()}
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{copied ? 'Copied Post Text' : 'Copy Post'}</span>
          </button>
          <a
            href="https://studio.youtube.com/"
            target="_blank"
            rel="noopener noreferrer"
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
          >
            <span>Open YouTube Studio</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>

        {canWrite && (
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={generating}
              onClick={() => void handleGenerate()}
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Regenerate</span>
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => void handleSave('draft')}
              className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
            >
              Save Draft
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => void handleSave('approved')}
              className="h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold inline-flex items-center gap-1.5"
            >
              {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
              <span>{status === 'approved' ? 'Update Approved Post' : 'Approve & Save Post'}</span>
            </button>
            {activePostId && status !== 'manually_published' && (
              <button
                type="button"
                disabled={saving}
                onClick={() => void handleSave('manually_published')}
                className="h-9 px-3 rounded-lg border border-blue-600 text-blue-600 dark:text-blue-400 font-semibold"
              >
                Mark Published in Studio
              </button>
            )}
          </div>
        )}
      </div>

      {/* Saved Community Posts Queue */}
      <div className="border-t border-slate-200 dark:border-slate-800 pt-4 space-y-2">
        <div className="font-semibold text-slate-800 dark:text-slate-200">
          {workflowProjectId
            ? `Saved Posts for This Project (${posts.length})`
            : `Saved Workspace Posts (${posts.length})`}
        </div>
        {loading ? (
          <div className="text-slate-500">Loading saved posts...</div>
        ) : posts.length === 0 ? (
          <div className="text-slate-500">
            NOT STARTED — No posts saved yet. Choose one of the 4 post types above and draft your first post.
          </div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg bg-white dark:bg-slate-900">
            {posts.map((p) => (
              <div
                key={p.id}
                className="p-3 flex flex-wrap items-center justify-between gap-2"
              >
                <button
                  type="button"
                  onClick={() => handleLoadSavedPost(p)}
                  className="text-left min-w-0 flex-1"
                >
                  <div className="font-semibold text-slate-900 dark:text-white truncate">
                    {p.title}
                  </div>
                  <div className="font-mono text-[11px] text-slate-500">
                    {p.formatType.replace(/_/g, ' ')} · Status: {p.status.replace(/_/g, ' ')} ·{' '}
                    {p.updatedAt.slice(0, 10)}
                  </div>
                </button>
                {canWrite && (
                  <button
                    type="button"
                    onClick={() => void handleDelete(p.id)}
                    aria-label="Delete community post"
                    className="p-1.5 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
