import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  Check,
  Loader2,
  MessageSquare,
  Plus,
  RefreshCw,
  Send,
  Sparkles,
  Trash2,
  Youtube,
} from 'lucide-react';
import type {
  YtmCommunityItemRecord,
  YtmConnectedChannelRecord,
} from '../../shared/types.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  connectedChannel: YtmConnectedChannelRecord | null;
  onConnectYouTube: () => void;
}

export function YtmCommunityView({
  authFetch,
  workspaceKey,
  canWrite,
  connectedChannel,
  onConnectYouTube,
}: Props) {
  const [items, setItems] = useState<YtmCommunityItemRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'question' | 'feedback' | 'community_post' | 'engagement_task'>('all');
  const [search, setSearch] = useState('');
  const [videoIdFilter, setVideoIdFilter] = useState('');

  // Editable draft replies keyed by item id
  const [replyDrafts, setReplyDrafts] = useState<Record<number, string>>({});
  const [tone, setTone] = useState('helpful and friendly');
  const [busyItemId, setBusyItemId] = useState<number | null>(null);

  // Community post / engagement task form
  const [itemType, setItemType] = useState<'community_post' | 'engagement_task'>('community_post');
  const [newContent, setNewContent] = useState('');
  const [newScheduledAt, setNewScheduledAt] = useState('');
  const [creating, setCreating] = useState(false);

  const loadItems = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await ytmRequest<{ items: YtmCommunityItemRecord[] }>(authFetch, '/community', {
        workspaceKey,
      });
      setItems(res.items || []);
      const map: Record<number, string> = {};
      for (const item of res.items || []) {
        map[item.id] = item.aiDraftReply || '';
      }
      setReplyDrafts(map);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load community feed.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadItems();
  }, [workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSyncComments = async () => {
    setSyncing(true);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{ syncedCount: number; items: YtmCommunityItemRecord[] }>(
        authFetch,
        '/community/sync-comments',
        {
          workspaceKey,
          method: 'POST',
          body: videoIdFilter.trim() ? { videoId: videoIdFilter.trim() } : {},
        }
      );
      setItems(res.items || []);
      setNotice(`Synced ${res.syncedCount} YouTube comments.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to sync YouTube comments.');
    } finally {
      setSyncing(false);
    }
  };

  const handleCreatePostOrTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim() || !canWrite) return;
    setCreating(true);
    setError(null);
    try {
      await ytmRequest(authFetch, '/community/items', {
        workspaceKey,
        method: 'POST',
        body: {
          itemType,
          content: newContent.trim(),
          category: 'general',
          scheduledAt: newScheduledAt || null,
        },
      });
      setNewContent('');
      setNewScheduledAt('');
      await loadItems();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save community item.');
    } finally {
      setCreating(false);
    }
  };

  const handleDraftReply = async (itemId: number) => {
    if (!canWrite) return;
    setBusyItemId(itemId);
    setError(null);
    try {
      const res = await ytmRequest<{ item: YtmCommunityItemRecord }>(
        authFetch,
        `/community/items/${itemId}/draft-reply`,
        { workspaceKey, method: 'POST', body: { tone } }
      );
      setItems((prev) => prev.map((it) => (it.id === itemId ? res.item : it)));
      setReplyDrafts((prev) => ({ ...prev, [itemId]: res.item.aiDraftReply }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to draft AI reply.');
    } finally {
      setBusyItemId(null);
    }
  };

  const handlePublishReply = async (itemId: number, mode: 'api' | 'manual') => {
    if (!canWrite) return;
    const text = (replyDrafts[itemId] || '').trim();
    if (!text) {
      setError('Enter or draft a reply before approving.');
      return;
    }
    setBusyItemId(itemId);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{ item: YtmCommunityItemRecord }>(
        authFetch,
        `/community/items/${itemId}/publish-reply`,
        { workspaceKey, method: 'POST', body: { replyText: text, mode } }
      );
      setItems((prev) => prev.map((it) => (it.id === itemId ? res.item : it)));
      setNotice(
        res.item.replyStatus === 'published_api'
          ? 'Reply published directly via YouTube API.'
          : 'Reply saved and marked handled manually.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to publish reply.');
    } finally {
      setBusyItemId(null);
    }
  };

  const handleDeleteItem = async (id: number) => {
    if (!canWrite) return;
    await ytmRequest(authFetch, `/community/items/${id}`, { workspaceKey, method: 'DELETE' });
    setItems((prev) => prev.filter((it) => it.id !== id));
  };

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((it) => {
      if (filter === 'question' && it.category !== 'question') return false;
      if (filter === 'feedback' && it.category !== 'feedback') return false;
      if (filter === 'community_post' && it.itemType !== 'community_post') return false;
      if (filter === 'engagement_task' && it.itemType !== 'engagement_task') return false;
      if (q && !`${it.content} ${it.authorName} ${it.aiDraftReply}`.toLowerCase().includes(q)) {
        return false;
      }
      return true;
    });
  }, [items, filter, search]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Community &amp; Comment Management
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Sync authorized YouTube comments, draft AI replies requiring creator approval, and plan Community posts.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {connectedChannel ? (
            <>
              <input
                type="text"
                value={videoIdFilter}
                onChange={(e) => setVideoIdFilter(e.target.value)}
                placeholder="Optional videoId filter"
                className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-mono w-40"
              />
              <button
                type="button"
                disabled={syncing || !canWrite}
                onClick={() => void handleSyncComments()}
                className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                {syncing ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <RefreshCw className="w-3.5 h-3.5" />
                )}
                <span>Sync YouTube Comments</span>
              </button>
            </>
          ) : (
            <button
              type="button"
              onClick={onConnectYouTube}
              className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
            >
              <Youtube className="w-3.5 h-3.5" />
              <span>Connect Channel to Sync Comments</span>
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Community Post / Engagement Task Planner */}
      {canWrite && (
        <form
          onSubmit={handleCreatePostOrTask}
          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3 text-xs"
        >
          <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Plan Community Post or Engagement Task
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            <select
              value={itemType}
              onChange={(e) => setItemType(e.target.value as 'community_post' | 'engagement_task')}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="community_post">YouTube Community Post Draft</option>
              <option value="engagement_task">Audience Engagement Task</option>
            </select>
            <input
              type="date"
              value={newScheduledAt}
              onChange={(e) => setNewScheduledAt(e.target.value)}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <input
              type="text"
              required
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder="Write poll prompt, behind-the-scenes update, or follow-up reminder…"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 md:col-span-2"
            />
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={creating}
              className="h-9 px-4 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold inline-flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{creating ? 'Adding…' : 'Add to Community Hub'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Filters & Reply Tone */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            { id: 'all', label: 'All' },
            { id: 'question', label: 'Questions' },
            { id: 'feedback', label: 'Feedback' },
            { id: 'community_post', label: 'Community Posts' },
            { id: 'engagement_task', label: 'Tasks' },
          ].map((f) => (
            <button
              key={f.id}
              type="button"
              onClick={() => setFilter(f.id as typeof filter)}
              className={`h-8 px-3 rounded-lg font-semibold ${
                filter === f.id
                  ? 'bg-blue-600 text-white'
                  : 'border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <select
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
          >
            <option value="helpful and friendly">Tone: Helpful</option>
            <option value="concise and direct">Tone: Concise</option>
            <option value="warm and appreciative">Tone: Appreciative</option>
          </select>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search items…"
            className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
          />
        </div>
      </div>

      {/* Items List */}
      {loading ? (
        <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span>Loading community queue…</span>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-xs text-slate-500">
          No community items match this filter yet.
        </div>
      ) : (
        <div className="space-y-3">
          {filteredItems.map((item) => (
            <div
              key={item.id}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3 text-xs"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-slate-950 dark:text-white flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                      {item.authorName}
                    </span>
                    <span className="font-mono text-[11px] uppercase text-slate-500">
                      {item.itemType.replace('_', ' ')} · {item.category}
                    </span>
                    {item.videoId && (
                      <span className="font-mono text-[11px] text-slate-400">
                        Video: {item.videoId}
                      </span>
                    )}
                    <span
                      className={`font-semibold text-[11px] ${
                        item.replyStatus === 'published_api'
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : item.replyStatus === 'handled_manually'
                          ? 'text-blue-600 dark:text-blue-400'
                          : 'text-slate-500'
                      }`}
                    >
                      Status: {item.replyStatus.replace(/_/g, ' ')}
                    </span>
                  </div>
                  <p className="text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                    {item.content}
                  </p>
                </div>

                {canWrite && (
                  <button
                    type="button"
                    onClick={() => void handleDeleteItem(item.id)}
                    className="p-1 text-slate-400 hover:text-red-600"
                    aria-label="Delete item"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {item.itemType === 'comment' && canWrite && (
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <textarea
                    rows={2}
                    value={replyDrafts[item.id] ?? item.aiDraftReply ?? ''}
                    onChange={(e) =>
                      setReplyDrafts((prev) => ({ ...prev, [item.id]: e.target.value }))
                    }
                    placeholder="Draft or type your reply (requires your explicit approval before sending)…"
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={busyItemId === item.id}
                      onClick={() => void handleDraftReply(item.id)}
                      className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
                    >
                      {busyItemId === item.id ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                      )}
                      <span>AI Draft Reply</span>
                    </button>
                    {item.externalCommentId && connectedChannel && (
                      <button
                        type="button"
                        disabled={busyItemId === item.id}
                        onClick={() => void handlePublishReply(item.id, 'api')}
                        className="h-8 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Approve &amp; Reply on YouTube</span>
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={busyItemId === item.id}
                      onClick={() => void handlePublishReply(item.id, 'manual')}
                      className="h-8 px-3 rounded-lg border border-emerald-300 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 font-semibold inline-flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Mark Handled Manually</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
