import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRightLeft,
  Bookmark,
  Calendar,
  CalendarDays,
  CalendarOff,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Columns3,
  Edit3,
  ExternalLink,
  Inbox,
  Loader2,
  Plus,
  Search,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Workflow,
  X,
} from 'lucide-react';
import type {
  YtmChannelProfileWithDna,
  YtmPlannerChecklistItem,
  YtmPlannerProjectRecord,
  YtmPlannerTaskRecord,
  YtmPriority,
  YtmTaskStatus,
  YtmWorkspaceRecord,
} from '../../shared/types.ts';
import {
  getTodayDateKey,
  YTM_DEFAULT_PIPELINE_STATUSES,
  YTM_DEFAULT_PRODUCTION_CHECKLIST,
} from '../../shared/ytmHelpers.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';
import { YtmSavedInspirationPanel } from './YtmSavedInspirationPanel.tsx';
import { YtmStrategyAssistantPanel } from './YtmStrategyAssistantPanel.tsx';

export type YtmPlannerTab =
  | 'calendar'
  | 'daily'
  | 'weekly'
  | 'backlog'
  | 'saved_inspiration'
  | 'board'
  | 'strategy';

interface Props {
  authFetch: AuthFetchFn;
  workspace: YtmWorkspaceRecord;
  canWrite: boolean;
  channelProfiles: YtmChannelProfileWithDna[];
  activeChannelProfileId: number | null;
  initialTab?: YtmPlannerTab;
  openNewIdeaSignal?: number;
  onOpenInWorkflow: (project: YtmPlannerProjectRecord) => Promise<void>;
}

const TASK_STATUSES: YtmTaskStatus[] = [
  'Not Started',
  'In Progress',
  'Completed',
  'Overdue',
  'Waiting for Approval',
];

function getMonthGrid(year: number, monthIndex: number): Array<{ dateKey: string; inMonth: boolean; dayNum: number }> {
  const firstDay = new Date(Date.UTC(year, monthIndex, 1));
  const startOffset = firstDay.getUTCDay();
  const startDate = new Date(Date.UTC(year, monthIndex, 1 - startOffset));
  return Array.from({ length: 42 }, (_, i) => {
    const d = new Date(startDate.getTime());
    d.setUTCDate(startDate.getUTCDate() + i);
    return {
      dateKey: d.toISOString().slice(0, 10),
      inMonth: d.getUTCMonth() === monthIndex,
      dayNum: d.getUTCDate(),
    };
  });
}

function getWeekDates(anchorDateKey: string): Array<{ dateKey: string; label: string }> {
  const base = new Date(`${anchorDateKey}T00:00:00Z`);
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date(base.getTime());
    d.setUTCDate(base.getUTCDate() + i);
    return {
      dateKey: d.toISOString().slice(0, 10),
      label: d.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        timeZone: 'UTC',
      }),
    };
  });
}

export function YtmPlannerView({
  authFetch,
  workspace,
  canWrite,
  channelProfiles,
  activeChannelProfileId,
  initialTab,
  openNewIdeaSignal = 0,
  onOpenInWorkflow,
}: Props) {
  const todayKey = getTodayDateKey();
  const [projects, setProjects] = useState<YtmPlannerProjectRecord[]>([]);
  const [tasks, setTasks] = useState<YtmPlannerTaskRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<YtmPlannerTab>(initialTab || 'calendar');
  const [quickFilter, setQuickFilter] = useState<'all' | 'scheduled' | 'in_progress' | 'completed'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');

  // Calendar / Daily navigation
  const [selectedDay, setSelectedDay] = useState<string>(todayKey);
  const [monthCursor, setMonthCursor] = useState<{ year: number; month: number }>(() => {
    const now = new Date();
    return { year: now.getUTCFullYear(), month: now.getUTCMonth() };
  });

  // New Project Form
  const [showNewProj, setShowNewProj] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTopic, setNewTopic] = useState('');
  const [newAudience, setNewAudience] = useState('');
  const [newCategory, setNewCategory] = useState('Education');
  const [newPriority, setNewPriority] = useState<YtmPriority>('medium');
  const [newStatus, setNewStatus] = useState<string>('Idea');
  const [newPlannedDate, setNewPlannedDate] = useState('');
  const [newDeadline, setNewDeadline] = useState('');
  const [newChannelProfileId, setNewChannelProfileId] = useState<number | ''>(
    activeChannelProfileId || ''
  );
  const [newNotes, setNewNotes] = useState('');
  const [savingProj, setSavingProj] = useState(false);

  // Edit Project Drawer / Modal
  const [editingProj, setEditingProj] = useState<YtmPlannerProjectRecord | null>(null);
  const [editDraft, setEditDraft] = useState<{
    title: string;
    topic: string;
    targetAudience: string;
    category: string;
    status: string;
    priority: YtmPriority;
    plannedDate: string;
    deadline: string;
    channelProfileId: number | '';
    adaptedAngle: string;
    notes: string;
    productionChecklist: YtmPlannerChecklistItem[];
  } | null>(null);
  const [newChecklistStep, setNewChecklistStep] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  // Quick Task Form
  const [taskName, setTaskName] = useState('');
  const [taskDeadline, setTaskDeadline] = useState(todayKey);
  const [taskPriority, setTaskPriority] = useState<YtmPriority>('medium');
  const [taskSection, setTaskSection] = useState('Workflow');
  const [savingTask, setSavingTask] = useState(false);
  const [openingWfId, setOpeningWfId] = useState<number | null>(null);

  // Calendar Management & Bulk Controls
  const [notice, setNotice] = useState<string | null>(null);
  const [manageCalendarMode, setManageCalendarMode] = useState(false);
  const [selectedProjectIds, setSelectedProjectIds] = useState<number[]>([]);
  const [selectedTaskIds, setSelectedTaskIds] = useState<number[]>([]);
  const [bulkTargetDate, setBulkTargetDate] = useState(todayKey);
  const [includeMonthTasks, setIncludeMonthTasks] = useState(true);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [confirmAction, setConfirmAction] = useState<null | {
    type:
      | 'delete_selected'
      | 'clear_month_unschedule'
      | 'clear_month_delete'
      | 'clear_completed_tasks';
    label: string;
  }>(null);
  const [focusedCalendarDay, setFocusedCalendarDay] = useState<string | null>(null);
  const [dayTaskName, setDayTaskName] = useState('');
  const [savingDayTask, setSavingDayTask] = useState(false);
  const [confirmModalDelete, setConfirmModalDelete] = useState(false);

  useEffect(() => {
    if (initialTab) setActiveTab(initialTab);
  }, [initialTab]);

  useEffect(() => {
    if (openNewIdeaSignal > 0 && canWrite) {
      setShowNewProj(true);
    }
  }, [openNewIdeaSignal, canWrite]);

  useEffect(() => {
    if (activeChannelProfileId && !newChannelProfileId) {
      setNewChannelProfileId(activeChannelProfileId);
    }
  }, [activeChannelProfileId, newChannelProfileId]);

  const pipelineStatuses = useMemo(() => {
    const base = YTM_DEFAULT_PIPELINE_STATUSES;
    const custom = workspace.customStatuses || [];
    const merged = [...base];
    for (const st of custom) {
      if (!merged.includes(st)) merged.push(st);
    }
    return merged;
  }, [workspace.customStatuses]);

  const channelNameMap = useMemo(
    () => new Map(channelProfiles.map((p) => [p.id, p.channelName])),
    [channelProfiles]
  );

  const loadPlanner = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await ytmRequest<{
        projects: YtmPlannerProjectRecord[];
        tasks: YtmPlannerTaskRecord[];
      }>(authFetch, '/planner', { workspaceKey: workspace.workspaceKey });
      setProjects(data.projects || []);
      setTasks(data.tasks || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load Content Planner.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadPlanner();
  }, [workspace.workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const filteredProjects = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return projects.filter((p) => {
      if (quickFilter === 'scheduled' && (!p.plannedDate || p.status === 'Published')) return false;
      if (
        quickFilter === 'in_progress' &&
        !['Selected', 'Researching', 'Scripting', 'Production', 'Ready to Publish', 'Filming', 'Editing'].includes(
          p.status
        )
      ) {
        return false;
      }
      if (quickFilter === 'completed' && p.status !== 'Published') return false;
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;
      if (channelFilter !== 'all' && String(p.channelProfileId || '') !== channelFilter) return false;
      if (!q) return true;
      return (
        p.title.toLowerCase().includes(q) ||
        p.topic.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.adaptedAngle.toLowerCase().includes(q)
      );
    });
  }, [projects, quickFilter, searchQuery, statusFilter, channelFilter]);

  const openEditor = (proj: YtmPlannerProjectRecord) => {
    setEditingProj(proj);
    setConfirmModalDelete(false);
    setNewChecklistStep('');
    setEditDraft({
      title: proj.title,
      topic: proj.topic || '',
      targetAudience: proj.targetAudience || '',
      category: proj.category || 'General',
      status: proj.status || 'Idea',
      priority: proj.priority || 'medium',
      plannedDate: proj.plannedDate ? proj.plannedDate.slice(0, 10) : '',
      deadline: proj.deadline ? proj.deadline.slice(0, 10) : '',
      channelProfileId: proj.channelProfileId ?? '',
      adaptedAngle: proj.adaptedAngle || '',
      notes: proj.notes || '',
      productionChecklist:
        proj.productionChecklist && proj.productionChecklist.length > 0
          ? proj.productionChecklist
          : YTM_DEFAULT_PRODUCTION_CHECKLIST.map((item) => ({ ...item })),
    });
  };

  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !canWrite) return;
    setSavingProj(true);
    try {
      await ytmRequest(authFetch, '/planner/projects', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: {
          title: newTitle.trim(),
          topic: newTopic.trim(),
          targetAudience: newAudience.trim(),
          category: newCategory.trim() || 'General',
          priority: newPriority,
          status: newStatus || 'Idea',
          plannedDate: newPlannedDate || null,
          deadline: newDeadline || null,
          channelProfileId: typeof newChannelProfileId === 'number' ? newChannelProfileId : null,
          notes: newNotes.trim(),
        },
      });
      setNewTitle('');
      setNewTopic('');
      setNewAudience('');
      setNewPlannedDate('');
      setNewDeadline('');
      setNewNotes('');
      setShowNewProj(false);
      await loadPlanner();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create planner video.');
    } finally {
      setSavingProj(false);
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProj || !editDraft || !canWrite) return;
    setSavingEdit(true);
    try {
      const res = await ytmRequest<{ project: YtmPlannerProjectRecord }>(
        authFetch,
        `/planner/projects/${editingProj.id}`,
        {
          workspaceKey: workspace.workspaceKey,
          method: 'PATCH',
          body: {
            title: editDraft.title.trim() || editingProj.title,
            topic: editDraft.topic.trim(),
            targetAudience: editDraft.targetAudience.trim(),
            category: editDraft.category.trim() || 'General',
            status: editDraft.status,
            priority: editDraft.priority,
            plannedDate: editDraft.plannedDate || null,
            deadline: editDraft.deadline || null,
            channelProfileId:
              typeof editDraft.channelProfileId === 'number' ? editDraft.channelProfileId : null,
            adaptedAngle: editDraft.adaptedAngle.trim(),
            notes: editDraft.notes.trim(),
            productionChecklist: editDraft.productionChecklist,
          },
        }
      );
      setProjects((prev) => prev.map((p) => (p.id === editingProj.id ? res.project : p)));
      setEditingProj(null);
      setEditDraft(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update planner project.');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleQuickPatchProject = async (
    projectId: number,
    patch: Partial<{ status: string; plannedDate: string | null }>
  ) => {
    if (!canWrite) return;
    try {
      const res = await ytmRequest<{ project: YtmPlannerProjectRecord }>(
        authFetch,
        `/planner/projects/${projectId}`,
        {
          workspaceKey: workspace.workspaceKey,
          method: 'PATCH',
          body: patch,
        }
      );
      setProjects((prev) => prev.map((p) => (p.id === projectId ? res.project : p)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update planner item.');
    }
  };

  const handleDeleteProject = async (projectId: number) => {
    if (!canWrite) return;
    try {
      await ytmRequest(authFetch, `/planner/projects/${projectId}`, {
        workspaceKey: workspace.workspaceKey,
        method: 'DELETE',
      });
      setProjects((prev) => prev.filter((p) => p.id !== projectId));
      if (editingProj?.id === projectId) {
        setEditingProj(null);
        setEditDraft(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete project.');
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!taskName.trim() || !canWrite) return;
    setSavingTask(true);
    try {
      await ytmRequest(authFetch, '/planner/tasks', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: {
          taskName: taskName.trim(),
          workspaceSection: taskSection,
          scheduledAt: taskDeadline || null,
          deadline: taskDeadline || null,
          priority: taskPriority,
          status: 'Not Started',
        },
      });
      setTaskName('');
      await loadPlanner();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create task.');
    } finally {
      setSavingTask(false);
    }
  };

  const handleUpdateTaskStatus = async (taskId: number, status: YtmTaskStatus) => {
    if (!canWrite) return;
    try {
      await ytmRequest(authFetch, `/planner/tasks/${taskId}`, {
        workspaceKey: workspace.workspaceKey,
        method: 'PATCH',
        body: { status },
      });
      setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, status } : t)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update task.');
    }
  };

  const handleDeleteTask = async (taskId: number) => {
    if (!canWrite) return;
    try {
      await ytmRequest(authFetch, `/planner/tasks/${taskId}`, {
        workspaceKey: workspace.workspaceKey,
        method: 'DELETE',
      });
      setTasks((prev) => prev.filter((t) => t.id !== taskId));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete task.');
    }
  };

  const handleLaunchWorkflow = async (proj: YtmPlannerProjectRecord) => {
    setOpeningWfId(proj.id);
    try {
      await onOpenInWorkflow(proj);
    } finally {
      setOpeningWfId(null);
    }
  };

  const toggleProjectSelected = (projectId: number) => {
    setSelectedProjectIds((prev) =>
      prev.includes(projectId) ? prev.filter((id) => id !== projectId) : [...prev, projectId]
    );
  };

  const toggleTaskSelected = (taskId: number) => {
    setSelectedTaskIds((prev) =>
      prev.includes(taskId) ? prev.filter((id) => id !== taskId) : [...prev, taskId]
    );
  };

  const currentYearMonth = useMemo(() => {
    const m = String(monthCursor.month + 1).padStart(2, '0');
    return `${monthCursor.year}-${m}`;
  }, [monthCursor.year, monthCursor.month]);

  const monthScheduledProjects = useMemo(
    () =>
      filteredProjects.filter(
        (p) => p.plannedDate && p.plannedDate.slice(0, 7) === currentYearMonth
      ),
    [filteredProjects, currentYearMonth]
  );

  const monthScheduledTasks = useMemo(
    () =>
      tasks.filter(
        (t) =>
          (t.scheduledAt && t.scheduledAt.slice(0, 7) === currentYearMonth) ||
          (t.deadline && t.deadline.slice(0, 7) === currentYearMonth)
      ),
    [tasks, currentYearMonth]
  );

  const completedTasksCount = useMemo(
    () => tasks.filter((t) => t.status === 'Completed').length,
    [tasks]
  );

  const runCalendarManage = async (
    payload: Record<string, unknown>,
    successMessage: (res: { affectedProjects?: number; affectedTasks?: number }) => string
  ) => {
    if (!canWrite) return;
    setBulkBusy(true);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{
        affectedProjects?: number;
        affectedTasks?: number;
      }>(authFetch, '/planner/calendar/manage', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: payload,
      });
      setConfirmAction(null);
      setSelectedProjectIds([]);
      setSelectedTaskIds([]);
      setNotice(successMessage(res));
      await loadPlanner();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Calendar management action failed.');
    } finally {
      setBulkBusy(false);
    }
  };

  const handleConfirmPendingAction = async () => {
    if (!confirmAction) return;
    if (confirmAction.type === 'delete_selected') {
      if (selectedProjectIds.length > 0 && selectedTaskIds.length > 0) {
        setBulkBusy(true);
        setError(null);
        setNotice(null);
        try {
          const [projRes, taskRes] = await Promise.all([
            ytmRequest<{ affectedProjects?: number }>(authFetch, '/planner/calendar/manage', {
              workspaceKey: workspace.workspaceKey,
              method: 'POST',
              body: { action: 'delete_projects', projectIds: selectedProjectIds },
            }),
            ytmRequest<{ affectedTasks?: number }>(authFetch, '/planner/calendar/manage', {
              workspaceKey: workspace.workspaceKey,
              method: 'POST',
              body: { action: 'delete_tasks', taskIds: selectedTaskIds },
            }),
          ]);
          setConfirmAction(null);
          setSelectedProjectIds([]);
          setSelectedTaskIds([]);
          setNotice(
            `Deleted ${projRes.affectedProjects || 0} video(s) and ${taskRes.affectedTasks || 0} task(s).`
          );
          await loadPlanner();
        } catch (err) {
          setError(err instanceof Error ? err.message : 'Failed to delete selected items.');
        } finally {
          setBulkBusy(false);
        }
        return;
      }
      if (selectedProjectIds.length > 0) {
        await runCalendarManage(
          { action: 'delete_projects', projectIds: selectedProjectIds },
          (res) => `Deleted ${res.affectedProjects || 0} planned video(s).`
        );
        return;
      }
      if (selectedTaskIds.length > 0) {
        await runCalendarManage(
          { action: 'delete_tasks', taskIds: selectedTaskIds },
          (res) => `Deleted ${res.affectedTasks || 0} task(s).`
        );
      }
      return;
    }

    if (confirmAction.type === 'clear_month_unschedule') {
      await runCalendarManage(
        {
          action: 'clear_month',
          yearMonth: currentYearMonth,
          mode: 'unschedule',
          includeTasks: includeMonthTasks,
        },
        (res) =>
          `Unscheduled ${res.affectedProjects || 0} video(s)${
            includeMonthTasks ? ` and ${res.affectedTasks || 0} task(s)` : ''
          } from ${monthLabel}. Videos are safely in Backlog.`
      );
      return;
    }

    if (confirmAction.type === 'clear_month_delete') {
      await runCalendarManage(
        {
          action: 'clear_month',
          yearMonth: currentYearMonth,
          mode: 'delete',
          includeTasks: includeMonthTasks,
        },
        (res) =>
          `Deleted ${res.affectedProjects || 0} video(s)${
            includeMonthTasks ? ` and ${res.affectedTasks || 0} task(s)` : ''
          } from ${monthLabel}.`
      );
      return;
    }

    if (confirmAction.type === 'clear_completed_tasks') {
      await runCalendarManage(
        { action: 'delete_tasks', completedOnly: true },
        (res) => `Cleared ${res.affectedTasks || 0} completed task(s).`
      );
    }
  };

  const handleQuickAddDayTask = async (e: React.FormEvent, dateKey: string) => {
    e.preventDefault();
    if (!dayTaskName.trim() || !canWrite) return;
    setSavingDayTask(true);
    try {
      await ytmRequest(authFetch, '/planner/tasks', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: {
          taskName: dayTaskName.trim(),
          workspaceSection: 'Content Planner',
          scheduledAt: dateKey,
          deadline: dateKey,
          priority: 'medium',
          status: 'Not Started',
        },
      });
      setDayTaskName('');
      await loadPlanner();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to add task for this day.');
    } finally {
      setSavingDayTask(false);
    }
  };

  const monthGrid = useMemo(
    () => getMonthGrid(monthCursor.year, monthCursor.month),
    [monthCursor.year, monthCursor.month]
  );
  const monthLabel = useMemo(() => {
    const d = new Date(Date.UTC(monthCursor.year, monthCursor.month, 1));
    return d.toLocaleDateString('en-US', { month: 'long', year: 'numeric', timeZone: 'UTC' });
  }, [monthCursor.year, monthCursor.month]);

  const weekDays = useMemo(() => getWeekDates(selectedDay), [selectedDay]);
  const backlogProjects = useMemo(
    () => filteredProjects.filter((p) => !p.plannedDate && p.status !== 'Published'),
    [filteredProjects]
  );

  const checklistProgress = (proj: YtmPlannerProjectRecord) => {
    const list = proj.productionChecklist || [];
    if (list.length === 0) return '';
    const done = list.filter((c) => c.done).length;
    return `${done}/${list.length} steps`;
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-slate-500 py-10">
        <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
        <span>Loading Smart Content Planner...</span>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {error && (
        <div className="rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/20 p-3.5 text-xs text-rose-700 dark:text-rose-300 flex items-center justify-between gap-2">
          <span className="inline-flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </span>
          <button type="button" onClick={() => setError(null)} className="underline font-semibold">
            Dismiss
          </button>
        </div>
      )}

      {notice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 p-3.5 text-xs text-emerald-700 dark:text-emerald-300 flex items-center justify-between gap-2">
          <span className="inline-flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            {notice}
          </span>
          <button type="button" onClick={() => setNotice(null)} className="underline font-semibold">
            Dismiss
          </button>
        </div>
      )}

      {/* Primary View Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex flex-wrap items-center p-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 gap-0.5">
          {(
            [
              { id: 'calendar', label: 'Calendar', icon: Calendar },
              { id: 'strategy', label: 'AI Strategy Assistant', icon: Sparkles },
              { id: 'daily', label: 'Daily', icon: CalendarDays },
              { id: 'weekly', label: 'Weekly', icon: CalendarDays },
              { id: 'backlog', label: 'Backlog', icon: Inbox },
              { id: 'board', label: 'Pipeline Board', icon: Columns3 },
              { id: 'saved_inspiration', label: 'Saved Inspiration', icon: Bookmark },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id)}
                className={`h-8 px-3 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors ${
                  active
                    ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white shadow-xs'
                    : tab.id === 'strategy'
                      ? 'text-blue-700 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-950/40'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {canWrite && activeTab !== 'saved_inspiration' && activeTab !== 'strategy' && (
          <button
            type="button"
            onClick={() => setShowNewProj((v) => !v)}
            className="h-9 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>{showNewProj ? 'Close Form' : 'New Planned Video'}</span>
          </button>
        )}
      </div>

      {/* Prominent AI Strategy Assistant Tab */}
      {activeTab === 'strategy' ? (
        <YtmStrategyAssistantPanel
          authFetch={authFetch}
          workspace={workspace}
          canWrite={canWrite}
          activeChannelProfile={
            channelProfiles.find((p) => p.id === activeChannelProfileId) ||
            channelProfiles[0] ||
            null
          }
          onCalendarUpdated={async () => {
            await loadPlanner();
          }}
        />
      ) : activeTab === 'saved_inspiration' ? (
        <YtmSavedInspirationPanel
          authFetch={authFetch}
          workspaceKey={workspace.workspaceKey}
          canWrite={canWrite}
          channelProfiles={channelProfiles}
          activeChannelProfileId={activeChannelProfileId}
          onConvertedToPlanner={(proj) => {
            setProjects((prev) => [proj, ...prev]);
            setActiveTab('backlog');
          }}
        />
      ) : (
        <>
          {/* Quick Filters & Search */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3.5 flex flex-wrap items-center gap-2.5 text-xs">
            <div className="inline-flex items-center gap-1 border-r border-slate-200 dark:border-slate-800 pr-2.5">
              {(
                [
                  { id: 'all', label: `All (${projects.length})` },
                  {
                    id: 'scheduled',
                    label: `Scheduled (${projects.filter((p) => p.plannedDate && p.status !== 'Published').length})`,
                  },
                  {
                    id: 'in_progress',
                    label: `In Progress (${
                      projects.filter((p) =>
                        ['Selected', 'Researching', 'Scripting', 'Production', 'Ready to Publish'].includes(p.status)
                      ).length
                    })`,
                  },
                  {
                    id: 'completed',
                    label: `Completed (${projects.filter((p) => p.status === 'Published').length})`,
                  },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setQuickFilter(f.id)}
                  className={`h-8 px-2.5 rounded-lg font-semibold whitespace-nowrap ${
                    quickFilter === f.id
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <div className="relative flex-1 min-w-[180px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search titles, topics, angles..."
                className="w-full h-8 pl-8 pr-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="all">All Pipeline Statuses</option>
              {pipelineStatuses.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>

            {channelProfiles.length > 1 && (
              <select
                value={channelFilter}
                onChange={(e) => setChannelFilter(e.target.value)}
                className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              >
                <option value="all">All Channels</option>
                {channelProfiles.map((p) => (
                  <option key={p.id} value={String(p.id)}>
                    {p.channelName}
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Create Planned Video Form */}
          {showNewProj && canWrite && (
            <form
              onSubmit={(e) => void handleCreateProject(e)}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 text-xs"
            >
              <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                Add Video Idea / Planned Content Item
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Working Video Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    placeholder="e.g., How I Plan 30 Days of Videos in 45 Minutes"
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Core Topic
                  </label>
                  <input
                    type="text"
                    value={newTopic}
                    onChange={(e) => setNewTopic(e.target.value)}
                    placeholder="Channel planning workflow"
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Channel Profile
                  </label>
                  <select
                    value={newChannelProfileId}
                    onChange={(e) =>
                      setNewChannelProfileId(e.target.value ? Number.parseInt(e.target.value, 10) : '')
                    }
                    className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    <option value="">Default Channel</option>
                    {channelProfiles.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.channelName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Status
                  </label>
                  <select
                    value={newStatus}
                    onChange={(e) => setNewStatus(e.target.value)}
                    className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    {pipelineStatuses.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Planned Date
                  </label>
                  <input
                    type="date"
                    value={newPlannedDate}
                    onChange={(e) => setNewPlannedDate(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Priority
                    </label>
                    <select
                      value={newPriority}
                      onChange={(e) => setNewPriority(e.target.value as YtmPriority)}
                      className="w-full h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                      <option value="urgent">Urgent</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Category
                    </label>
                    <input
                      type="text"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                    />
                  </div>
                </div>
                <div className="md:col-span-3">
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Notes / Angle (optional)
                  </label>
                  <input
                    type="text"
                    value={newNotes}
                    onChange={(e) => setNewNotes(e.target.value)}
                    placeholder="Key hook idea, proof points, or production notes..."
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowNewProj(false)}
                  className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingProj}
                  className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                >
                  {savingProj ? 'Saving...' : 'Save to Planner'}
                </button>
              </div>
            </form>
          )}

          {/* VIEW 1: MONTHLY CALENDAR */}
          {activeTab === 'calendar' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      setMonthCursor((c) =>
                        c.month === 0 ? { year: c.year - 1, month: 11 } : { year: c.year, month: c.month - 1 }
                      )
                    }
                    className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-800"
                    aria-label="Previous month"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white min-w-[140px] text-center">
                    {monthLabel}
                  </h3>
                  <button
                    type="button"
                    onClick={() =>
                      setMonthCursor((c) =>
                        c.month === 11 ? { year: c.year + 1, month: 0 } : { year: c.year, month: c.month + 1 }
                      )
                    }
                    className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-800"
                    aria-label="Next month"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const now = new Date();
                      setMonthCursor({ year: now.getUTCFullYear(), month: now.getUTCMonth() });
                      setFocusedCalendarDay(todayKey);
                    }}
                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
                  >
                    Today
                  </button>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-500 dark:text-slate-400 hidden lg:inline">
                    {manageCalendarMode
                      ? 'Select items on the calendar to reschedule, unschedule, or delete.'
                      : 'Click a day number to manage that day, or click any video card to edit.'}
                  </span>
                  {canWrite && (
                    <button
                      type="button"
                      onClick={() => {
                        setManageCalendarMode((prev) => {
                          if (prev) {
                            setSelectedProjectIds([]);
                            setSelectedTaskIds([]);
                            setConfirmAction(null);
                          }
                          return !prev;
                        });
                      }}
                      className={`h-8 px-3 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors ${
                        manageCalendarMode
                          ? 'bg-blue-600 text-white'
                          : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>{manageCalendarMode ? 'Done Managing' : 'Manage Calendar'}</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Calendar Management Toolbar */}
              {manageCalendarMode && canWrite && (
                <div className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 p-3.5 space-y-3 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-semibold text-slate-900 dark:text-white">
                        {selectedProjectIds.length} video(s), {selectedTaskIds.length} task(s) selected
                      </span>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedProjectIds(monthScheduledProjects.map((p) => p.id));
                          setSelectedTaskIds(monthScheduledTasks.map((t) => t.id));
                        }}
                        className="h-7 px-2.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                      >
                        Select Month ({monthScheduledProjects.length + monthScheduledTasks.length})
                      </button>
                      {(selectedProjectIds.length > 0 || selectedTaskIds.length > 0) && (
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedProjectIds([]);
                            setSelectedTaskIds([]);
                          }}
                          className="h-7 px-2.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-500 font-semibold"
                        >
                          Clear Selection
                        </button>
                      )}
                    </div>

                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 text-slate-600 dark:text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={includeMonthTasks}
                          onChange={(e) => setIncludeMonthTasks(e.target.checked)}
                          className="rounded border-slate-300 dark:border-slate-700"
                        />
                        <span>Include tasks</span>
                      </label>
                      <button
                        type="button"
                        disabled={
                          bulkBusy ||
                          (monthScheduledProjects.length === 0 &&
                            (!includeMonthTasks || monthScheduledTasks.length === 0))
                        }
                        onClick={() =>
                          setConfirmAction({
                            type: 'clear_month_unschedule',
                            label: `Unschedule ${monthScheduledProjects.length} video(s)${
                              includeMonthTasks ? ` and ${monthScheduledTasks.length} task(s)` : ''
                            } in ${monthLabel}? Videos will move to Backlog.`,
                          })
                        }
                        className="h-7 px-2.5 rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold inline-flex items-center gap-1 disabled:opacity-50"
                      >
                        <CalendarOff className="w-3.5 h-3.5" />
                        <span>Unschedule Month</span>
                      </button>
                      <button
                        type="button"
                        disabled={
                          bulkBusy ||
                          (monthScheduledProjects.length === 0 &&
                            (!includeMonthTasks || monthScheduledTasks.length === 0))
                        }
                        onClick={() =>
                          setConfirmAction({
                            type: 'clear_month_delete',
                            label: `Permanently delete ${monthScheduledProjects.length} video(s)${
                              includeMonthTasks ? ` and ${monthScheduledTasks.length} task(s)` : ''
                            } scheduled in ${monthLabel}?`,
                          })
                        }
                        className="h-7 px-2.5 rounded-md border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 font-semibold inline-flex items-center gap-1 disabled:opacity-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Clear Month</span>
                      </button>
                    </div>
                  </div>

                  {(selectedProjectIds.length > 0 || selectedTaskIds.length > 0) && (
                    <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                      {selectedProjectIds.length > 0 && (
                        <>
                          <input
                            type="date"
                            value={bulkTargetDate}
                            onChange={(e) => setBulkTargetDate(e.target.value)}
                            aria-label="Target reschedule date"
                            className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-[11px]"
                          />
                          <button
                            type="button"
                            disabled={bulkBusy || !bulkTargetDate}
                            onClick={() =>
                              void runCalendarManage(
                                {
                                  action: 'reschedule_projects',
                                  projectIds: selectedProjectIds,
                                  plannedDate: bulkTargetDate,
                                },
                                (res) =>
                                  `Rescheduled ${res.affectedProjects || 0} video(s) to ${bulkTargetDate}.`
                              )
                            }
                            className="h-8 px-2.5 rounded-lg bg-blue-600 text-white font-semibold inline-flex items-center gap-1 disabled:opacity-50"
                          >
                            <ArrowRightLeft className="w-3.5 h-3.5" />
                            <span>Move to Date</span>
                          </button>
                          <button
                            type="button"
                            disabled={bulkBusy}
                            onClick={() =>
                              void runCalendarManage(
                                {
                                  action: 'reschedule_projects',
                                  projectIds: selectedProjectIds,
                                  shiftDays: -7,
                                },
                                (res) =>
                                  `Shifted ${res.affectedProjects || 0} video(s) earlier by 7 days.`
                              )
                            }
                            className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold disabled:opacity-50"
                          >
                            Shift -7d
                          </button>
                          <button
                            type="button"
                            disabled={bulkBusy}
                            onClick={() =>
                              void runCalendarManage(
                                {
                                  action: 'reschedule_projects',
                                  projectIds: selectedProjectIds,
                                  shiftDays: 7,
                                },
                                (res) =>
                                  `Shifted ${res.affectedProjects || 0} video(s) forward by 7 days.`
                              )
                            }
                            className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold disabled:opacity-50"
                          >
                            Shift +7d
                          </button>
                          <button
                            type="button"
                            disabled={bulkBusy}
                            onClick={() =>
                              void runCalendarManage(
                                {
                                  action: 'unschedule_projects',
                                  projectIds: selectedProjectIds,
                                },
                                (res) =>
                                  `Moved ${res.affectedProjects || 0} video(s) back to Backlog.`
                              )
                            }
                            className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold inline-flex items-center gap-1 disabled:opacity-50"
                          >
                            <CalendarOff className="w-3.5 h-3.5" />
                            <span>Unschedule</span>
                          </button>
                        </>
                      )}
                      <button
                        type="button"
                        disabled={bulkBusy}
                        onClick={() =>
                          setConfirmAction({
                            type: 'delete_selected',
                            label: `Permanently delete ${selectedProjectIds.length} video(s) and ${selectedTaskIds.length} task(s)?`,
                          })
                        }
                        className="h-8 px-3 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold inline-flex items-center gap-1 disabled:opacity-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete Selected</span>
                      </button>
                    </div>
                  )}

                  {confirmAction && confirmAction.type !== 'clear_completed_tasks' && (
                    <div className="rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/40 p-2.5 flex flex-wrap items-center justify-between gap-2">
                      <span className="font-medium text-rose-800 dark:text-rose-200">
                        {confirmAction.label}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          disabled={bulkBusy}
                          onClick={() => setConfirmAction(null)}
                          className="h-7 px-2.5 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          disabled={bulkBusy}
                          onClick={() => void handleConfirmPendingAction()}
                          className="h-7 px-3 rounded bg-rose-600 hover:bg-rose-700 text-white font-semibold inline-flex items-center gap-1 disabled:opacity-60"
                        >
                          {bulkBusy && <Loader2 className="w-3 h-3 animate-spin" />}
                          <span>Confirm</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="grid grid-cols-7 gap-1.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 text-center">
                {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                  <div key={d} className="py-1">
                    {d}
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {monthGrid.map((cell) => {
                  const dayProjects = filteredProjects.filter(
                    (p) => p.plannedDate?.slice(0, 10) === cell.dateKey
                  );
                  const dayTasks = tasks.filter(
                    (t) => t.scheduledAt?.slice(0, 10) === cell.dateKey || t.deadline?.slice(0, 10) === cell.dateKey
                  );
                  const isToday = cell.dateKey === todayKey;
                  const isFocused = focusedCalendarDay === cell.dateKey;
                  const hiddenCount = Math.max(0, dayProjects.length - 3) + Math.max(0, dayTasks.length - 2);
                  return (
                    <div
                      key={cell.dateKey}
                      className={`min-h-[96px] rounded-lg border p-2 flex flex-col gap-1 transition-colors ${
                        isFocused
                          ? 'border-blue-600 ring-1 ring-blue-500/40 bg-blue-50/50 dark:bg-blue-950/30'
                          : isToday
                            ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/20'
                            : cell.inMonth
                              ? 'border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/60'
                              : 'border-slate-100 dark:border-slate-800/50 bg-slate-50/20 dark:bg-slate-950/20 opacity-60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() =>
                            setFocusedCalendarDay((prev) => (prev === cell.dateKey ? null : cell.dateKey))
                          }
                          title={`Manage schedule for ${cell.dateKey}`}
                          className={`text-[11px] font-mono tabular-nums px-1 rounded hover:bg-blue-100 dark:hover:bg-blue-900/40 ${
                            isToday || isFocused
                              ? 'font-bold text-blue-600 dark:text-blue-400'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {cell.dayNum}
                        </button>
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => {
                              setNewPlannedDate(cell.dateKey);
                              setShowNewProj(true);
                            }}
                            title={`Plan video on ${cell.dateKey}`}
                            className="text-slate-400 hover:text-blue-600 p-0.5"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                      <div className="space-y-1 overflow-hidden">
                        {dayProjects.slice(0, 3).map((proj) => {
                          const isChecked = selectedProjectIds.includes(proj.id);
                          return (
                            <button
                              key={proj.id}
                              type="button"
                              onClick={() =>
                                manageCalendarMode && canWrite
                                  ? toggleProjectSelected(proj.id)
                                  : openEditor(proj)
                              }
                              className={`w-full text-left px-1.5 py-1 rounded border text-[11px] font-medium truncate flex items-center gap-1 ${
                                manageCalendarMode && isChecked
                                  ? 'bg-blue-600 border-blue-600 text-white'
                                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-blue-500 text-slate-900 dark:text-white'
                              }`}
                              title={`${proj.title} (${proj.status})`}
                            >
                              {manageCalendarMode && canWrite && (
                                <span
                                  className={`w-3 h-3 rounded-xs border flex items-center justify-center shrink-0 ${
                                    isChecked
                                      ? 'border-white bg-white/20'
                                      : 'border-slate-300 dark:border-slate-600'
                                  }`}
                                >
                                  {isChecked && <Check className="w-2.5 h-2.5" />}
                                </span>
                              )}
                              <span className="truncate">{proj.title}</span>
                            </button>
                          );
                        })}
                        {dayTasks.slice(0, 2).map((t) => {
                          const done = t.status === 'Completed';
                          const isChecked = selectedTaskIds.includes(t.id);
                          return (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => {
                                if (manageCalendarMode && canWrite) {
                                  toggleTaskSelected(t.id);
                                } else if (canWrite) {
                                  void handleUpdateTaskStatus(
                                    t.id,
                                    done ? 'In Progress' : 'Completed'
                                  );
                                }
                              }}
                              className={`w-full text-left text-[10px] truncate px-1 py-0.5 rounded flex items-center gap-1 ${
                                manageCalendarMode && isChecked
                                  ? 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-200 font-semibold'
                                  : done
                                    ? 'text-slate-400 line-through hover:bg-slate-100 dark:hover:bg-slate-800'
                                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                              }`}
                              title={t.taskName}
                            >
                              <span>{manageCalendarMode ? (isChecked ? '☑' : '☐') : done ? '✓' : '○'}</span>
                              <span className="truncate">{t.taskName}</span>
                            </button>
                          );
                        })}
                        {hiddenCount > 0 && (
                          <button
                            type="button"
                            onClick={() => setFocusedCalendarDay(cell.dateKey)}
                            className="text-[10px] font-semibold text-blue-600 dark:text-blue-400 hover:underline px-1"
                          >
                            +{hiddenCount} more
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selected Day Schedule Manager */}
              {focusedCalendarDay && (() => {
                const dayProjects = filteredProjects.filter(
                  (p) => p.plannedDate?.slice(0, 10) === focusedCalendarDay
                );
                const dayTasks = tasks.filter(
                  (t) =>
                    t.scheduledAt?.slice(0, 10) === focusedCalendarDay ||
                    t.deadline?.slice(0, 10) === focusedCalendarDay
                );
                return (
                  <div className="rounded-xl border border-blue-200 dark:border-blue-900 bg-slate-50/80 dark:bg-slate-950 p-4 space-y-3 text-xs">
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-200 dark:border-slate-800">
                      <div>
                        <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                          Day Manager · <span className="font-mono">{focusedCalendarDay}</span>
                        </h4>
                        <p className="text-[11px] text-slate-500">
                          {dayProjects.length} planned video(s) · {dayTasks.length} task(s)
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => {
                              setNewPlannedDate(focusedCalendarDay);
                              setShowNewProj(true);
                            }}
                            className="h-8 px-3 rounded-lg bg-blue-600 text-white font-semibold inline-flex items-center gap-1"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Add Video</span>
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setFocusedCalendarDay(null)}
                          className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 font-semibold"
                        >
                          Close
                        </button>
                      </div>
                    </div>

                    {dayProjects.length > 0 && (
                      <div className="space-y-2">
                        <div className="font-semibold text-slate-700 dark:text-slate-300">
                          Scheduled Videos
                        </div>
                        <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                          {dayProjects.map((proj) => (
                            <div
                              key={proj.id}
                              className="p-2.5 flex flex-wrap items-center justify-between gap-2"
                            >
                              <div className="min-w-0">
                                <div className="font-semibold text-slate-950 dark:text-white truncate">
                                  {proj.title}
                                </div>
                                <div className="text-[11px] text-slate-500">
                                  {proj.status} · {proj.priority} priority
                                </div>
                              </div>
                              <div className="flex flex-wrap items-center gap-1.5">
                                {canWrite && (
                                  <input
                                    type="date"
                                    aria-label={`Reschedule ${proj.title}`}
                                    value={proj.plannedDate?.slice(0, 10) || ''}
                                    onChange={(e) =>
                                      void handleQuickPatchProject(proj.id, {
                                        plannedDate: e.target.value || null,
                                      })
                                    }
                                    className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-[11px]"
                                  />
                                )}
                                <button
                                  type="button"
                                  onClick={() => openEditor(proj)}
                                  className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 font-semibold"
                                >
                                  Edit
                                </button>
                                {canWrite && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        void handleQuickPatchProject(proj.id, { plannedDate: null })
                                      }
                                      title="Move back to Backlog"
                                      className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-blue-600 inline-flex items-center gap-1"
                                    >
                                      <CalendarOff className="w-3 h-3" />
                                      <span>Unschedule</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => void handleDeleteProject(proj.id)}
                                      title="Delete planned video"
                                      className="h-7 px-2 rounded border border-rose-200 dark:border-rose-900 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 inline-flex items-center"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  </>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    <div className="space-y-2">
                      <div className="font-semibold text-slate-700 dark:text-slate-300">
                        Tasks on {focusedCalendarDay}
                      </div>
                      {dayTasks.length > 0 && (
                        <div className="divide-y divide-slate-200 dark:divide-slate-800 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                          {dayTasks.map((t) => {
                            const done = t.status === 'Completed';
                            return (
                              <div
                                key={t.id}
                                className="p-2.5 flex items-center justify-between gap-2"
                              >
                                <button
                                  type="button"
                                  disabled={!canWrite}
                                  onClick={() =>
                                    void handleUpdateTaskStatus(
                                      t.id,
                                      done ? 'In Progress' : 'Completed'
                                    )
                                  }
                                  className="flex items-center gap-2 text-left min-w-0"
                                >
                                  <span
                                    className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                                      done
                                        ? 'bg-emerald-600 border-emerald-600 text-white'
                                        : 'border-slate-300 dark:border-slate-600'
                                    }`}
                                  >
                                    {done && <Check className="w-3 h-3" />}
                                  </span>
                                  <span
                                    className={
                                      done
                                        ? 'line-through text-slate-400 truncate'
                                        : 'text-slate-900 dark:text-white font-medium truncate'
                                    }
                                  >
                                    {t.taskName}
                                  </span>
                                </button>
                                {canWrite && (
                                  <button
                                    type="button"
                                    onClick={() => void handleDeleteTask(t.id)}
                                    aria-label={`Delete task ${t.taskName}`}
                                    className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 inline-flex items-center"
                                  >
                                    <Trash2 className="w-3 h-3" />
                                  </button>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                      {canWrite && (
                        <form
                          onSubmit={(e) => void handleQuickAddDayTask(e, focusedCalendarDay)}
                          className="flex items-center gap-2"
                        >
                          <input
                            type="text"
                            value={dayTaskName}
                            onChange={(e) => setDayTaskName(e.target.value)}
                            placeholder={`Quick-add task for ${focusedCalendarDay}...`}
                            className="flex-1 h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                          />
                          <button
                            type="submit"
                            disabled={savingDayTask || !dayTaskName.trim()}
                            className="h-8 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold disabled:opacity-50"
                          >
                            {savingDayTask ? 'Adding...' : 'Add Task'}
                          </button>
                        </form>
                      )}
                    </div>
                  </div>
                );
              })()}
            </div>
          )}

          {/* VIEW 2: DAILY VIEW */}
          {activeTab === 'daily' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    Daily Production Schedule · <span className="font-mono">{selectedDay}</span>
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Focus strictly on videos and production tasks scheduled for this day.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <input
                    type="date"
                    value={selectedDay}
                    onChange={(e) => setSelectedDay(e.target.value || todayKey)}
                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setSelectedDay(todayKey)}
                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                  >
                    Today
                  </button>
                </div>
              </div>

              {(() => {
                const dayProjects = filteredProjects.filter(
                  (p) => p.plannedDate?.slice(0, 10) === selectedDay || p.deadline?.slice(0, 10) === selectedDay
                );
                const dayTasks = tasks.filter(
                  (t) => t.scheduledAt?.slice(0, 10) === selectedDay || t.deadline?.slice(0, 10) === selectedDay
                );
                if (dayProjects.length === 0 && dayTasks.length === 0) {
                  return (
                    <div className="py-8 text-center text-xs text-slate-500 space-y-2">
                      <p>Nothing scheduled for {selectedDay}.</p>
                      {canWrite && (
                        <button
                          type="button"
                          onClick={() => {
                            setNewPlannedDate(selectedDay);
                            setShowNewProj(true);
                          }}
                          className="h-8 px-3 rounded-lg bg-blue-600 text-white font-semibold"
                        >
                          Schedule Video for {selectedDay}
                        </button>
                      )}
                    </div>
                  );
                }
                return (
                  <div className="space-y-4">
                    {dayProjects.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          Planned Videos ({dayProjects.length})
                        </div>
                        <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                          {dayProjects.map((proj) => (
                            <div
                              key={proj.id}
                              className="p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs"
                            >
                              <div className="min-w-0 space-y-0.5">
                                <div className="font-semibold text-sm text-slate-950 dark:text-white">
                                  {proj.title}
                                </div>
                                <div className="text-slate-500 dark:text-slate-400">
                                  {proj.status} · {proj.priority} priority · {checklistProgress(proj)}
                                  {proj.channelProfileId && channelNameMap.get(proj.channelProfileId)
                                    ? ` · ${channelNameMap.get(proj.channelProfileId)}`
                                    : ''}
                                </div>
                              </div>
                              <div className="flex flex-wrap items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => openEditor(proj)}
                                  className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                                >
                                  Edit
                                </button>
                                {canWrite && (
                                  <>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        void handleQuickPatchProject(proj.id, { plannedDate: null })
                                      }
                                      title="Remove from calendar date (move to Backlog)"
                                      className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-blue-600 inline-flex items-center gap-1"
                                    >
                                      <CalendarOff className="w-3.5 h-3.5" />
                                      <span>Unschedule</span>
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => void handleDeleteProject(proj.id)}
                                      aria-label={`Delete ${proj.title}`}
                                      className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:border-rose-300 dark:hover:border-rose-800 inline-flex items-center"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </>
                                )}
                                <button
                                  type="button"
                                  disabled={openingWfId === proj.id}
                                  onClick={() => void handleLaunchWorkflow(proj)}
                                  className="h-8 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold inline-flex items-center gap-1"
                                >
                                  <Workflow className="w-3.5 h-3.5" />
                                  <span>{proj.workflowProjectId ? 'Open Workflow' : 'Start Production'}</span>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {dayTasks.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          Tasks Due ({dayTasks.length})
                        </div>
                        <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-lg">
                          {dayTasks.map((t) => {
                            const done = t.status === 'Completed';
                            return (
                              <div key={t.id} className="p-3 flex items-center justify-between gap-2 text-xs">
                                <button
                                  type="button"
                                  disabled={!canWrite}
                                  onClick={() =>
                                    void handleUpdateTaskStatus(t.id, done ? 'In Progress' : 'Completed')
                                  }
                                  className="flex items-center gap-2 text-left min-w-0"
                                >
                                  <span
                                    className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                                      done
                                        ? 'bg-emerald-600 border-emerald-600 text-white'
                                        : 'border-slate-300 dark:border-slate-600'
                                    }`}
                                  >
                                    {done && <Check className="w-3 h-3" />}
                                  </span>
                                  <span className={done ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white font-medium'}>
                                    {t.taskName}
                                  </span>
                                </button>
                                <div className="flex items-center gap-2 shrink-0">
                                  <span className="text-slate-500">{t.workspaceSection}</span>
                                  {canWrite && (
                                    <button
                                      type="button"
                                      onClick={() => void handleDeleteTask(t.id)}
                                      aria-label={`Delete task ${t.taskName}`}
                                      className="p-1 text-slate-400 hover:text-rose-600"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>
          )}

          {/* VIEW 3: WEEKLY VIEW */}
          {activeTab === 'weekly' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 sm:p-5 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  7-Day Production Week (from {selectedDay})
                </h3>
                <div className="flex items-center gap-1.5 text-xs">
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date(`${selectedDay}T00:00:00Z`);
                      d.setUTCDate(d.getUTCDate() - 7);
                      setSelectedDay(d.toISOString().slice(0, 10));
                    }}
                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700"
                  >
                    Prev 7d
                  </button>
                  <button
                    type="button"
                    onClick={() => setSelectedDay(todayKey)}
                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                  >
                    Today
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date(`${selectedDay}T00:00:00Z`);
                      d.setUTCDate(d.getUTCDate() + 7);
                      setSelectedDay(d.toISOString().slice(0, 10));
                    }}
                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700"
                  >
                    Next 7d
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-7 gap-2.5">
                {weekDays.map((day) => {
                  const dayProjects = filteredProjects.filter(
                    (p) => p.plannedDate?.slice(0, 10) === day.dateKey
                  );
                  const isToday = day.dateKey === todayKey;
                  return (
                    <div
                      key={day.dateKey}
                      className={`rounded-lg border p-3 min-h-[160px] space-y-2 ${
                        isToday
                          ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/20'
                          : 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-mono font-semibold text-slate-700 dark:text-slate-200">
                          {day.label}
                        </span>
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => {
                              setNewPlannedDate(day.dateKey);
                              setShowNewProj(true);
                            }}
                            className="text-slate-400 hover:text-blue-600"
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                      {dayProjects.length === 0 ? (
                        <p className="text-[11px] text-slate-400 pt-2">Open day</p>
                      ) : (
                        <div className="space-y-1.5">
                          {dayProjects.map((proj) => (
                            <div
                              key={proj.id}
                              className="w-full rounded-md border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2 space-y-1 hover:border-blue-500"
                            >
                              <button
                                type="button"
                                onClick={() => openEditor(proj)}
                                className="w-full text-left"
                              >
                                <div className="text-[11px] font-semibold text-slate-950 dark:text-white line-clamp-2">
                                  {proj.title}
                                </div>
                              </button>
                              <div className="flex items-center justify-between gap-1">
                                <span className="text-[10px] text-slate-500 truncate">{proj.status}</span>
                                {canWrite && (
                                  <div className="flex items-center gap-1 shrink-0">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        void handleQuickPatchProject(proj.id, { plannedDate: null })
                                      }
                                      title="Unschedule to Backlog"
                                      className="p-0.5 text-slate-400 hover:text-blue-600"
                                    >
                                      <CalendarOff className="w-3 h-3" />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => void handleDeleteProject(proj.id)}
                                      title="Delete planned video"
                                      className="p-0.5 text-slate-400 hover:text-rose-600"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* VIEW 4: BACKLOG */}
          {activeTab === 'backlog' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
              <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    Unscheduled Idea &amp; Content Backlog ({backlogProjects.length})
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Assign a planned date to move items onto your Calendar, or start production directly.
                  </p>
                </div>
              </div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {backlogProjects.length === 0 ? (
                  <p className="p-8 text-center text-slate-500">
                    No unscheduled items in your backlog. Convert items from Saved Inspiration or click New Planned Video.
                  </p>
                ) : (
                  backlogProjects.map((proj) => (
                    <div
                      key={proj.id}
                      className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3"
                    >
                      <div className="min-w-0 space-y-1">
                        <div className="font-semibold text-sm text-slate-950 dark:text-white">
                          {proj.title}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 flex flex-wrap items-center gap-x-2">
                          <span>{proj.status}</span>
                          <span>·</span>
                          <span className="capitalize">{proj.priority} priority</span>
                          <span>·</span>
                          <span>{checklistProgress(proj)}</span>
                          {proj.channelProfileId && channelNameMap.get(proj.channelProfileId) && (
                            <>
                              <span>·</span>
                              <span>{channelNameMap.get(proj.channelProfileId)}</span>
                            </>
                          )}
                          {proj.inspirationSourceLabel && (
                            <>
                              <span>·</span>
                              <span className="text-blue-600 dark:text-blue-400">
                                Inspired by {proj.inspirationSourceLabel}
                              </span>
                            </>
                          )}
                        </div>
                        {proj.adaptedAngle && (
                          <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-1">
                            Angle: {proj.adaptedAngle}
                          </p>
                        )}
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        {canWrite && (
                          <input
                            type="date"
                            aria-label="Schedule date"
                            value={proj.plannedDate ? proj.plannedDate.slice(0, 10) : ''}
                            onChange={(e) =>
                              void handleQuickPatchProject(proj.id, {
                                plannedDate: e.target.value || null,
                              })
                            }
                            className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono text-[11px]"
                          />
                        )}
                        <button
                          type="button"
                          onClick={() => openEditor(proj)}
                          className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1"
                        >
                          <Edit3 className="w-3 h-3" />
                          <span>Edit</span>
                        </button>
                        <button
                          type="button"
                          disabled={openingWfId === proj.id}
                          onClick={() => void handleLaunchWorkflow(proj)}
                          className="h-8 px-3 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold inline-flex items-center gap-1"
                        >
                          <Workflow className="w-3.5 h-3.5" />
                          <span>{proj.workflowProjectId ? 'Workflow' : 'Start Production'}</span>
                        </button>
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => void handleDeleteProject(proj.id)}
                            aria-label={`Delete backlog item ${proj.title}`}
                            title="Delete from backlog"
                            className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:border-rose-300 dark:hover:border-rose-800 inline-flex items-center"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* VIEW 5: PIPELINE BOARD */}
          {activeTab === 'board' && (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
              {pipelineStatuses.map((colStatus) => {
                const colItems = filteredProjects.filter((p) => p.status === colStatus);
                return (
                  <div
                    key={colStatus}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3"
                  >
                    <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                      <span className="font-display text-xs font-bold uppercase tracking-wide text-slate-700 dark:text-slate-200">
                        {colStatus}
                      </span>
                      <span className="font-mono text-xs tabular-nums text-slate-500">
                        {colItems.length}
                      </span>
                    </div>

                    {colItems.length === 0 ? (
                      <p className="text-xs text-slate-400 py-4 text-center">Empty</p>
                    ) : (
                      <div className="space-y-2.5">
                        {colItems.map((proj) => (
                          <div
                            key={proj.id}
                            className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 space-y-2"
                          >
                            <div className="flex items-start justify-between gap-2">
                              <button
                                type="button"
                                onClick={() => openEditor(proj)}
                                className="text-left font-semibold text-xs text-slate-950 dark:text-white leading-snug hover:text-blue-600 dark:hover:text-blue-400"
                              >
                                {proj.title}
                              </button>
                              {canWrite && (
                                <button
                                  type="button"
                                  onClick={() => void handleDeleteProject(proj.id)}
                                  aria-label="Delete planned video"
                                  className="text-slate-400 hover:text-rose-600 shrink-0"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400">
                              {proj.priority} · {checklistProgress(proj)}
                              {proj.plannedDate ? ` · ${proj.plannedDate.slice(0, 10)}` : ''}
                            </div>
                            <div className="flex items-center justify-between gap-1.5 pt-1">
                              <select
                                disabled={!canWrite}
                                value={proj.status}
                                onChange={(e) =>
                                  void handleQuickPatchProject(proj.id, { status: e.target.value })
                                }
                                className="h-7 px-1.5 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px] max-w-[120px]"
                              >
                                {pipelineStatuses.map((s) => (
                                  <option key={s} value={s}>
                                    {s}
                                  </option>
                                ))}
                              </select>
                              <button
                                type="button"
                                disabled={openingWfId === proj.id}
                                onClick={() => void handleLaunchWorkflow(proj)}
                                className="h-7 px-2.5 rounded bg-[#0F172A] dark:bg-blue-600 text-white text-[11px] font-semibold inline-flex items-center gap-1 whitespace-nowrap"
                              >
                                <Workflow className="w-3 h-3" />
                                <span>{proj.workflowProjectId ? 'Workflow' : 'Produce'}</span>
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {/* Workspace Production Tasks Queue */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  Production Task Queue ({tasks.length})
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Daily tasks synced with your Dashboard Daily Plan.
                </p>
              </div>
              {canWrite && completedTasksCount > 0 && (
                confirmAction?.type === 'clear_completed_tasks' ? (
                  <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30 text-xs">
                    <span className="text-rose-700 dark:text-rose-300 font-semibold">
                      Delete {completedTasksCount} completed?
                    </span>
                    <button
                      type="button"
                      disabled={bulkBusy}
                      onClick={() => void handleConfirmPendingAction()}
                      className="h-7 px-2.5 rounded bg-rose-600 text-white font-semibold"
                    >
                      Confirm
                    </button>
                    <button
                      type="button"
                      onClick={() => setConfirmAction(null)}
                      className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() =>
                      setConfirmAction({
                        type: 'clear_completed_tasks',
                        label: `Delete ${completedTasksCount} completed task(s)?`,
                      })
                    }
                    className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-rose-600 inline-flex items-center gap-1.5"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Clear Completed ({completedTasksCount})</span>
                  </button>
                )
              )}
            </div>

            {canWrite && (
              <form
                onSubmit={(e) => void handleCreateTask(e)}
                className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 text-xs"
              >
                <input
                  type="text"
                  value={taskName}
                  onChange={(e) => setTaskName(e.target.value)}
                  placeholder="Add production task (e.g., Outline hook & B-roll shot list)..."
                  className="sm:col-span-5 h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
                <select
                  value={taskSection}
                  onChange={(e) => setTaskSection(e.target.value)}
                  className="sm:col-span-2 h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="Workflow">Workflow</option>
                  <option value="Content Planner">Content Planner</option>
                  <option value="Competitors">Competitors</option>
                  <option value="Analytics">Analytics</option>
                  <option value="Community">Community</option>
                </select>
                <input
                  type="date"
                  value={taskDeadline}
                  onChange={(e) => setTaskDeadline(e.target.value)}
                  className="sm:col-span-2 h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                />
                <select
                  value={taskPriority}
                  onChange={(e) => setTaskPriority(e.target.value as YtmPriority)}
                  className="sm:col-span-1 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="low">Low</option>
                  <option value="medium">Med</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
                <button
                  type="submit"
                  disabled={savingTask || !taskName.trim()}
                  className="sm:col-span-2 h-9 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold disabled:opacity-50"
                >
                  {savingTask ? 'Adding...' : 'Add Task'}
                </button>
              </form>
            )}

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {tasks.length === 0 ? (
                <p className="py-5 text-center text-xs text-slate-500">No tasks added yet.</p>
              ) : (
                tasks.map((task) => {
                  const done = task.status === 'Completed';
                  return (
                    <div
                      key={task.id}
                      className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="flex items-start gap-2.5 min-w-0">
                        <button
                          type="button"
                          disabled={!canWrite}
                          onClick={() =>
                            void handleUpdateTaskStatus(task.id, done ? 'In Progress' : 'Completed')
                          }
                          className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                            done
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 dark:border-slate-600'
                          }`}
                        >
                          {done && <Check className="w-3 h-3" />}
                        </button>
                        <div className="min-w-0">
                          <div
                            className={`font-medium ${
                              done ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'
                            }`}
                          >
                            {task.taskName}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400">
                            {task.workspaceSection} · {task.priority} priority
                            {task.deadline ? ` · Due ${task.deadline.slice(0, 10)}` : ''}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <select
                          disabled={!canWrite}
                          value={task.status}
                          onChange={(e) =>
                            void handleUpdateTaskStatus(task.id, e.target.value as YtmTaskStatus)
                          }
                          className="h-8 px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs"
                        >
                          {TASK_STATUSES.map((s) => (
                            <option key={s} value={s}>
                              {s}
                            </option>
                          ))}
                        </select>
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => void handleDeleteTask(task.id)}
                            className="h-8 px-2 rounded border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-rose-600"
                          >
                            Remove
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </>
      )}

      {/* Planner Project Detail & Production Checklist Modal */}
      {editingProj && editDraft && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="w-full max-w-2xl max-h-[90vh] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white truncate">
                Edit Planned Video &amp; Production Checklist
              </h3>
              <button
                type="button"
                onClick={() => {
                  setEditingProj(null);
                  setEditDraft(null);
                }}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form
              onSubmit={(e) => void handleSaveEdit(e)}
              className="flex-1 overflow-y-auto p-5 space-y-4 text-xs"
            >
              {editingProj.inspirationSourceLabel && (
                <div className="rounded-lg border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 p-3 flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="font-semibold text-blue-800 dark:text-blue-300">
                      Inspiration Source:{' '}
                    </span>
                    <span className="text-slate-700 dark:text-slate-300">
                      {editingProj.inspirationSourceLabel}
                    </span>
                  </div>
                  {editingProj.inspirationSourceUrl && (
                    <a
                      href={editingProj.inspirationSourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1 shrink-0"
                    >
                      <span>Source</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Video Title
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={editDraft.title}
                    onChange={(e) => setEditDraft({ ...editDraft, title: e.target.value })}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-semibold"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Pipeline Status
                  </label>
                  <select
                    disabled={!canWrite}
                    value={editDraft.status}
                    onChange={(e) => setEditDraft({ ...editDraft, status: e.target.value })}
                    className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    {pipelineStatuses.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel Profile
                  </label>
                  <select
                    disabled={!canWrite}
                    value={editDraft.channelProfileId}
                    onChange={(e) =>
                      setEditDraft({
                        ...editDraft,
                        channelProfileId: e.target.value ? Number.parseInt(e.target.value, 10) : '',
                      })
                    }
                    className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    <option value="">Default Channel</option>
                    {channelProfiles.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.channelName}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Planned Date (move on Calendar)
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="date"
                      disabled={!canWrite}
                      value={editDraft.plannedDate}
                      onChange={(e) => setEditDraft({ ...editDraft, plannedDate: e.target.value })}
                      className="flex-1 h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                    />
                    {canWrite && editDraft.plannedDate && (
                      <button
                        type="button"
                        onClick={() => setEditDraft({ ...editDraft, plannedDate: '' })}
                        title="Remove from calendar date (move to Backlog)"
                        className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-blue-600 font-semibold whitespace-nowrap"
                      >
                        Unschedule
                      </button>
                    )}
                  </div>
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    disabled={!canWrite}
                    value={editDraft.priority}
                    onChange={(e) =>
                      setEditDraft({ ...editDraft, priority: e.target.value as YtmPriority })
                    }
                    className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Adapted Angle / Core Thesis
                  </label>
                  <textarea
                    rows={2}
                    disabled={!canWrite}
                    value={editDraft.adaptedAngle}
                    onChange={(e) => setEditDraft({ ...editDraft, adaptedAngle: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Production Notes
                  </label>
                  <textarea
                    rows={3}
                    disabled={!canWrite}
                    value={editDraft.notes}
                    onChange={(e) => setEditDraft({ ...editDraft, notes: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
              </div>

              {/* Interactive Production Checklist */}
              <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="font-semibold text-slate-800 dark:text-slate-200">
                  Production Checklist
                </div>
                <div className="space-y-1.5">
                  {editDraft.productionChecklist.map((item) => (
                    <div key={item.id} className="flex items-center justify-between gap-2">
                      <button
                        type="button"
                        disabled={!canWrite}
                        onClick={() =>
                          setEditDraft({
                            ...editDraft,
                            productionChecklist: editDraft.productionChecklist.map((c) =>
                              c.id === item.id ? { ...c, done: !c.done } : c
                            ),
                          })
                        }
                        className="flex items-center gap-2 text-left"
                      >
                        <span
                          className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                            item.done
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 dark:border-slate-600'
                          }`}
                        >
                          {item.done && <Check className="w-3 h-3" />}
                        </span>
                        <span className={item.done ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-200'}>
                          {item.label}
                        </span>
                      </button>
                      {canWrite && (
                        <button
                          type="button"
                          onClick={() =>
                            setEditDraft({
                              ...editDraft,
                              productionChecklist: editDraft.productionChecklist.filter(
                                (c) => c.id !== item.id
                              ),
                            })
                          }
                          className="text-slate-400 hover:text-rose-600 p-0.5"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                {canWrite && (
                  <div className="flex items-center gap-2 pt-1">
                    <input
                      type="text"
                      value={newChecklistStep}
                      onChange={(e) => setNewChecklistStep(e.target.value)}
                      placeholder="Add custom checklist step..."
                      className="flex-1 h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (!newChecklistStep.trim()) return;
                        setEditDraft({
                          ...editDraft,
                          productionChecklist: [
                            ...editDraft.productionChecklist,
                            {
                              id: `chk_${Date.now()}`,
                              label: newChecklistStep.trim(),
                              done: false,
                            },
                          ],
                        });
                        setNewChecklistStep('');
                      }}
                      className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                    >
                      Add
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    disabled={openingWfId === editingProj.id}
                    onClick={() => void handleLaunchWorkflow(editingProj)}
                    className="h-9 px-3.5 rounded-lg bg-[#0F172A] dark:bg-slate-800 text-white font-semibold inline-flex items-center gap-1.5"
                  >
                    <Workflow className="w-3.5 h-3.5" />
                    <span>{editingProj.workflowProjectId ? 'Open in Workflow' : 'Start Production in Workflow'}</span>
                  </button>
                  {canWrite &&
                    (!confirmModalDelete ? (
                      <button
                        type="button"
                        onClick={() => setConfirmModalDelete(true)}
                        className="h-9 px-3 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-semibold inline-flex items-center gap-1.5"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>Delete</span>
                      </button>
                    ) : (
                      <div className="inline-flex items-center gap-1.5 px-2 py-1 rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30">
                        <span className="text-rose-700 dark:text-rose-300 font-semibold">Delete?</span>
                        <button
                          type="button"
                          onClick={() => void handleDeleteProject(editingProj.id)}
                          className="h-7 px-2.5 rounded bg-rose-600 text-white font-semibold"
                        >
                          Confirm
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmModalDelete(false)}
                          className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                        >
                          Cancel
                        </button>
                      </div>
                    ))}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setEditingProj(null);
                      setEditDraft(null);
                      setConfirmModalDelete(false);
                    }}
                    className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                  >
                    Cancel
                  </button>
                  {canWrite && (
                    <button
                      type="submit"
                      disabled={savingEdit}
                      className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                    >
                      {savingEdit ? 'Saving...' : 'Save Changes'}
                    </button>
                  )}
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
