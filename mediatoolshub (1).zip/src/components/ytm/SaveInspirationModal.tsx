import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  BookmarkPlus,
  Check,
  ExternalLink,
  Loader2,
  X,
} from 'lucide-react';
import type {
  YtmChannelProfileWithDna,
  YtmInspirationCategory,
  YtmSavedInspirationRecord,
} from '../../shared/types.ts';
import { YTM_INSPIRATION_CATEGORIES } from '../../shared/ytmHelpers.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

export interface SaveInspirationDraft {
  originalVideoTitle: string;
  originalVideoUrl?: string;
  competitorChannelName?: string;
  competitorChannelId?: string;
  thumbnailUrl?: string | null;
  inspirationCategory?: YtmInspirationCategory;
  inspirationSnippet?: string;
  userNotes?: string;
}

interface Props {
  open: boolean;
  draft: SaveInspirationDraft | null;
  onClose: () => void;
  authFetch: AuthFetchFn;
  workspaceKey?: string;
  channelProfiles?: YtmChannelProfileWithDna[];
  defaultChannelProfileId?: number | null;
  onSaved?: (item: YtmSavedInspirationRecord) => void;
}

export function SaveInspirationModal({
  open,
  draft,
  onClose,
  authFetch,
  workspaceKey,
  channelProfiles = [],
  defaultChannelProfileId = null,
  onSaved,
}: Props) {
  const [profiles, setProfiles] = useState<YtmChannelProfileWithDna[]>(channelProfiles);
  const [title, setTitle] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [channelName, setChannelName] = useState('');
  const [category, setCategory] = useState<YtmInspirationCategory>('video_topic');
  const [snippet, setSnippet] = useState('');
  const [notes, setNotes] = useState('');
  const [channelProfileId, setChannelProfileId] = useState<number | ''>('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    setProfiles(channelProfiles);
  }, [channelProfiles]);

  useEffect(() => {
    if (!open || !draft) return;
    setTitle(draft.originalVideoTitle || '');
    setVideoUrl(draft.originalVideoUrl || '');
    setChannelName(draft.competitorChannelName || '');
    setCategory(draft.inspirationCategory || 'video_topic');
    setSnippet(draft.inspirationSnippet || '');
    setNotes(draft.userNotes || '');
    setError(null);
    setSavedSuccess(false);

    if (defaultChannelProfileId) {
      setChannelProfileId(defaultChannelProfileId);
    } else if (profiles.length > 0) {
      const def = profiles.find((p) => p.isDefault) || profiles[0];
      setChannelProfileId(def.id);
    } else {
      setChannelProfileId('');
    }
  }, [open, draft, defaultChannelProfileId, profiles]);

  // If opened from standalone Competitor Intelligence Studio without preloaded profiles, fetch them once
  useEffect(() => {
    if (!open || profiles.length > 0) return;
    let active = true;
    void (async () => {
      try {
        const res = await ytmRequest<{ profiles: YtmChannelProfileWithDna[] }>(
          authFetch,
          '/channel-profiles',
          { workspaceKey }
        );
        if (!active) return;
        const list = res.profiles || [];
        setProfiles(list);
        if (list.length > 0) {
          const def = list.find((p) => p.isDefault) || list[0];
          setChannelProfileId(def.id);
        }
      } catch {
        // Fallback: server assigns default channel profile
      }
    })();
    return () => {
      active = false;
    };
  }, [open, profiles.length, authFetch, workspaceKey]);

  if (!open || !draft) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setError('Title or observation headline is required.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const res = await ytmRequest<{ inspiration: YtmSavedInspirationRecord }>(
        authFetch,
        '/inspirations',
        {
          workspaceKey,
          method: 'POST',
          body: {
            originalVideoTitle: title.trim(),
            originalVideoUrl: videoUrl.trim(),
            competitorChannelName: channelName.trim(),
            competitorChannelId: draft.competitorChannelId || '',
            thumbnailUrl: draft.thumbnailUrl || null,
            inspirationCategory: category,
            inspirationSnippet: snippet.trim(),
            userNotes: notes.trim(),
            channelProfileId: typeof channelProfileId === 'number' ? channelProfileId : undefined,
          },
        }
      );
      setSavedSuccess(true);
      onSaved?.(res.inspiration);
      setTimeout(() => {
        onClose();
      }, 650);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save inspiration.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
      <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <BookmarkPlus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
              Save Competitor Inspiration to Planner
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close save inspiration modal"
            className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={(e) => void handleSubmit(e)} className="p-5 space-y-4 text-xs">
          {/* Source Preview */}
          {(draft.thumbnailUrl || videoUrl) && (
            <div className="flex items-start gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
              {draft.thumbnailUrl && (
                <img
                  src={draft.thumbnailUrl}
                  alt={title}
                  referrerPolicy="no-referrer"
                  className="w-24 aspect-video rounded object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                />
              )}
              <div className="min-w-0 flex-1 space-y-0.5">
                <div className="font-semibold text-slate-900 dark:text-white line-clamp-2">
                  {title || 'Competitor Reference'}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {channelName || 'Competitor channel'}
                </div>
                {videoUrl && (
                  <a
                    href={videoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline inline-flex items-center gap-1"
                  >
                    <span>Source Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>
          )}

          {error && (
            <div className="rounded-lg border border-amber-200 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/30 p-3 text-amber-800 dark:text-amber-200 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {savedSuccess && (
            <div className="rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 p-3 text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
              <Check className="w-4 h-4 shrink-0" />
              <span>Saved to Content Planner → Saved Inspiration library.</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Inspiration Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as YtmInspirationCategory)}
                className="w-full h-10 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
              >
                {YTM_INSPIRATION_CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Target Channel Profile
              </label>
              <select
                value={channelProfileId}
                onChange={(e) =>
                  setChannelProfileId(e.target.value ? Number.parseInt(e.target.value, 10) : '')
                }
                className="w-full h-10 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
              >
                {profiles.length === 0 ? (
                  <option value="">Default Channel Profile</option>
                ) : (
                  profiles.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.channelName}
                      {p.isDefault ? ' (Default)' : ''}
                    </option>
                  ))
                )}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Reference Video Title / Idea Headline *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
            />
          </div>

          {!draft.originalVideoUrl && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Competitor Channel Name
                </label>
                <input
                  type="text"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  placeholder="Channel name"
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Original Video URL (optional)
                </label>
                <input
                  type="url"
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://www.youtube.com/watch?v=..."
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Captured Detail / Pattern (optional)
            </label>
            <textarea
              rows={2}
              value={snippet}
              onChange={(e) => setSnippet(e.target.value)}
              placeholder="What caught your eye (hook line, title formula, visual contrast, pacing)..."
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Your Personal Notes
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="How you want to twist this for your audience..."
              className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving || savedSuccess}
              className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold inline-flex items-center gap-1.5"
            >
              {saving ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : savedSuccess ? (
                <Check className="w-3.5 h-3.5" />
              ) : (
                <BookmarkPlus className="w-3.5 h-3.5" />
              )}
              <span>{savedSuccess ? 'Saved' : 'Save to Planner'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
