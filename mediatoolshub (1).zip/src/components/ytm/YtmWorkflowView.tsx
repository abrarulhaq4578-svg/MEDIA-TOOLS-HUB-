import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Archive,
  Check,
  CheckCircle2,
  Copy,
  ExternalLink,
  FileText,
  Image as ImageIcon,
  Loader2,
  Lock,
  MessageSquare,
  Plus,
  Sparkles,
  Upload,
  Youtube,
} from 'lucide-react';
import type {
  YtmChannelProfileWithDna,
  YtmConnectedChannelRecord,
  YtmDistributionAssetRecord,
  YtmDistributionPlatform,
  YtmPublishingJobRecord,
  YtmStage4Mode,
  YtmWorkflowProjectRecord,
  YtmWorkflowStageNumber,
} from '../../shared/types.ts';
import {
  YTM_DISTRIBUTION_PLATFORMS,
  YTM_WORKFLOW_STAGES,
} from '../../shared/ytmHelpers.ts';
import { ScriptwritingStudioTool } from '../tools/ScriptwritingStudioTool.tsx';
import { copyToClipboard, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';
import { YtmCommunityPostCreator } from './YtmCommunityPostCreator.tsx';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  canApprove: boolean;
  canPublishYouTube: boolean;
  connectedChannel: YtmConnectedChannelRecord | null;
  activeChannelProfile?: YtmChannelProfileWithDna | null;
  initialWorkflowId?: number | null;
  focusNewVideoSignal?: number;
  onConnectYouTube: () => void;
}

export function YtmWorkflowView({
  authFetch,
  workspaceKey,
  canWrite,
  canApprove,
  canPublishYouTube,
  connectedChannel,
  activeChannelProfile = null,
  initialWorkflowId,
  focusNewVideoSignal = 0,
  onConnectYouTube,
}: Props) {
  const [workflows, setWorkflows] = useState<YtmWorkflowProjectRecord[]>([]);
  const [distAssets, setDistAssets] = useState<YtmDistributionAssetRecord[]>([]);
  const [publishingJobs, setPublishingJobs] = useState<YtmPublishingJobRecord[]>([]);
  const [activeId, setActiveId] = useState<number | null>(initialWorkflowId ?? null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // New Workflow Modal/Bar
  const [newTitle, setNewTitle] = useState('');
  const [creating, setCreating] = useState(false);
  const newTitleInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (focusNewVideoSignal > 0) {
      setTimeout(() => {
        newTitleInputRef.current?.focus();
      }, 60);
    }
  }, [focusNewVideoSignal]);

  // Stage 6 distribution platform tab
  const [activeDistTab, setActiveDistTab] = useState<YtmDistributionPlatform>('instagram');

  const [viewMode, setViewMode] = useState<'pipeline' | 'scripting' | 'posts' | 'history'>('pipeline');
  const [selectedHistoryId, setSelectedHistoryId] = useState<number | null>(null);
  const [lastCompletedProject, setLastCompletedProject] = useState<YtmWorkflowProjectRecord | null>(
    null
  );

  // Video upload form
  const fileInputRef = useRef<HTMLInputElement>(null);
  const thumbInputRef = useRef<HTMLInputElement>(null);
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [uploadPrivacy, setUploadPrivacy] = useState<'private' | 'unlisted' | 'public'>('private');
  const [uploadingVideo, setUploadingVideo] = useState(false);

  const isCompletedRecord = (w: YtmWorkflowProjectRecord) =>
    w.projectStatus === 'COMPLETED' || w.projectStatus === 'PUBLISHED';

  const loadAll = async () => {
    setLoading(true);
    setError(null);
    try {
      const [wfRes, jobsRes] = await Promise.all([
        ytmRequest<{
          workflows: YtmWorkflowProjectRecord[];
          distributionAssets: YtmDistributionAssetRecord[];
        }>(authFetch, '/workflow', { workspaceKey }),
        ytmRequest<{ jobs: YtmPublishingJobRecord[] }>(authFetch, '/youtube/publishing-jobs', {
          workspaceKey,
        }),
      ]);
      const allWfs = wfRes.workflows || [];
      const activeList = allWfs.filter((w) => !isCompletedRecord(w));
      const completedList = allWfs.filter((w) => isCompletedRecord(w));

      setWorkflows(allWfs);
      setDistAssets(wfRes.distributionAssets || []);
      setPublishingJobs(jobsRes.jobs || []);

      if (initialWorkflowId && allWfs.some((w) => w.id === initialWorkflowId)) {
        const target = allWfs.find((w) => w.id === initialWorkflowId)!;
        if (isCompletedRecord(target)) {
          setViewMode('history');
          setSelectedHistoryId(target.id);
        } else {
          setViewMode('pipeline');
          setActiveId(target.id);
        }
      } else if (!activeId || !activeList.some((w) => w.id === activeId)) {
        setActiveId(activeList[0]?.id ?? null);
      }

      if (!selectedHistoryId && completedList.length > 0) {
        setSelectedHistoryId(completedList[0].id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load production workflows.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadAll();
  }, [workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (initialWorkflowId && workflows.some((w) => w.id === initialWorkflowId)) {
      const target = workflows.find((w) => w.id === initialWorkflowId)!;
      if (isCompletedRecord(target)) {
        setViewMode('history');
        setSelectedHistoryId(target.id);
      } else {
        setViewMode('pipeline');
        setActiveId(target.id);
      }
    }
  }, [initialWorkflowId, workflows]);

  const activeWorkflows = workflows.filter((w) => !isCompletedRecord(w));
  const completedWorkflows = workflows.filter((w) => isCompletedRecord(w));

  const activeWf = activeWorkflows.find((w) => w.id === activeId) || activeWorkflows[0] || null;
  const selectedHistoryWf =
    completedWorkflows.find((w) => w.id === selectedHistoryId) || completedWorkflows[0] || null;

  // Strict per-project UI state isolation: reset transient inputs whenever active project switches
  useEffect(() => {
    setVideoFile(null);
    setCopiedId(null);
    setActiveDistTab('instagram');
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (thumbInputRef.current) thumbInputRef.current.value = '';
  }, [activeWf?.id]);

  const replaceWorkflow = (wf: YtmWorkflowProjectRecord) => {
    setWorkflows((prev) => prev.map((item) => (item.id === wf.id ? wf : item)));
  };

  const handleCopy = async (id: string, text: string) => {
    const ok = await copyToClipboard(text);
    if (ok) {
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 1600);
    }
  };

  const handleCreateWorkflow = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !canWrite) return;
    setCreating(true);
    setError(null);
    setNotice(null);
    setLastCompletedProject(null);
    try {
      const res = await ytmRequest<{ workflow: YtmWorkflowProjectRecord }>(
        authFetch,
        '/workflow/projects',
        {
          workspaceKey,
          method: 'POST',
          body: {
            title: newTitle.trim(),
            seedIdea: newTitle.trim(),
            channelProfileId: activeChannelProfile?.id ?? undefined,
          },
        }
      );
      setNewTitle('');
      setWorkflows((prev) => [res.workflow, ...prev]);
      setViewMode('pipeline');
      setActiveId(res.workflow.id);
      setNotice(
        `Started fresh isolated video production "${res.workflow.title}" at Stage 1 (NOT STARTED).`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create workflow project.');
    } finally {
      setCreating(false);
    }
  };

  const patchWorkflow = async (payload: Record<string, unknown>) => {
    if (!activeWf) return;
    setSaving(true);
    setError(null);
    try {
      const res = await ytmRequest<{
        workflow: YtmWorkflowProjectRecord;
        completed?: boolean;
      }>(authFetch, `/workflow/projects/${activeWf.id}`, {
        workspaceKey,
        method: 'PATCH',
        body: payload,
      });
      const updatedWf = res.workflow;
      const nextAll = workflows.map((item) => (item.id === updatedWf.id ? updatedWf : item));
      setWorkflows(nextAll);

      if (res.completed || isCompletedRecord(updatedWf)) {
        // Archive completed project cleanly & reset active workspace to next active project or fresh Stage 1 start
        setLastCompletedProject(updatedWf);
        setSelectedHistoryId(updatedWf.id);
        const remainingActive = nextAll.filter((w) => !isCompletedRecord(w));
        setActiveId(remainingActive[0]?.id ?? null);
        setVideoFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        setNotice(
          `Production "${updatedWf.title}" completed and archived in Completed Project History. Active workspace is ready for your next video.`
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save workflow changes.');
    } finally {
      setSaving(false);
    }
  };

  const runStageAi = async (action: string, extra: Record<string, unknown> = {}) => {
    if (!activeWf || !canWrite) return;
    setBusy(true);
    setError(null);
    try {
      if (action === 'distribution') {
        const res = await ytmRequest<{ distributionAssets: YtmDistributionAssetRecord[] }>(
          authFetch,
          `/workflow/projects/${activeWf.id}/ai`,
          { workspaceKey, method: 'POST', body: { action, ...extra } }
        );
        const others = distAssets.filter((d) => d.workflowProjectId !== activeWf.id);
        setDistAssets([...others, ...(res.distributionAssets || [])]);
        setNotice('Generated multi-platform distribution drafts across all 8 channels.');
      } else {
        const res = await ytmRequest<{ workflow: YtmWorkflowProjectRecord }>(
          authFetch,
          `/workflow/projects/${activeWf.id}/ai`,
          { workspaceKey, method: 'POST', body: { action, ...extra } }
        );
        replaceWorkflow(res.workflow);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'AI generation failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleUploadThumbnail = async (file: File) => {
    if (!activeWf || !canWrite) return;
    setBusy(true);
    setError(null);
    try {
      const fd = new FormData();
      fd.append('thumbnail', file);
      const res = await ytmRequest<{ workflow: YtmWorkflowProjectRecord }>(
        authFetch,
        `/workflow/projects/${activeWf.id}/thumbnail-upload`,
        { workspaceKey, method: 'POST', body: fd, isFormData: true }
      );
      replaceWorkflow(res.workflow);
      setNotice('Thumbnail image uploaded and saved to Workspace Asset Library.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Thumbnail upload failed.');
    } finally {
      setBusy(false);
    }
  };

  const handleUpdateDistributionAsset = async (
    assetId: number,
    patch: Record<string, unknown>
  ) => {
    if (!canWrite) return;
    setSaving(true);
    try {
      const res = await ytmRequest<{ asset: YtmDistributionAssetRecord }>(
        authFetch,
        `/distribution/${assetId}`,
        { workspaceKey, method: 'PATCH', body: patch }
      );
      setDistAssets((prev) => prev.map((a) => (a.id === assetId ? res.asset : a)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update distribution asset.');
    } finally {
      setSaving(false);
    }
  };

  const handleUploadYouTubeVideo = async () => {
    if (!activeWf || !videoFile || !canPublishYouTube) return;
    setUploadingVideo(true);
    setError(null);
    setNotice(null);
    try {
      const fd = new FormData();
      fd.append('video', videoFile);
      fd.append('workflowProjectId', String(activeWf.id));
      fd.append('title', activeWf.stage1Title.selectedTitle || activeWf.title);
      fd.append('description', activeWf.stage5Seo.description || '');
      fd.append('tags', (activeWf.stage5Seo.tags || []).join(','));
      fd.append('privacyStatus', uploadPrivacy);

      const res = await ytmRequest<{ job: YtmPublishingJobRecord }>(authFetch, '/youtube/upload', {
        workspaceKey,
        method: 'POST',
        body: fd,
        isFormData: true,
      });
      setPublishingJobs((prev) => [res.job, ...prev]);
      setVideoFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
      setNotice(`Uploaded to YouTube successfully (${res.job.youtubeVideoUrl}).`);
      await loadAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'YouTube upload failed.');
    } finally {
      setUploadingVideo(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-slate-500 py-10">
        <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
        <span>Loading 6-stage video workflows...</span>
      </div>
    );
  }

  const wfDistAssets = activeWf
    ? distAssets.filter((d) => d.workflowProjectId === activeWf.id)
    : [];
  const activeDistAsset = wfDistAssets.find((d) => d.platform === activeDistTab) || null;
  const activePlatformMeta =
    YTM_DISTRIBUTION_PLATFORMS.find((p) => p.id === activeDistTab) ||
    YTM_DISTRIBUTION_PLATFORMS[0];

  return (
    <div className="space-y-6">
      {/* Workflow 4-Feature Switcher: 1. Video Pipeline | 2. Scripting | 3. Posts | 4. Completed History */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex flex-wrap rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-950 text-xs gap-0.5">
            <button
              type="button"
              onClick={() => setViewMode('pipeline')}
              className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                viewMode === 'pipeline'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Youtube className="w-3.5 h-3.5" />
              <span>1. Video Pipeline ({activeWorkflows.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('scripting')}
              className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                viewMode === 'scripting'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>2. Scripting</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('posts')}
              className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                viewMode === 'posts'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>3. Posts</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('history')}
              className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                viewMode === 'history'
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Archive className="w-3.5 h-3.5" />
              <span>4. Completed History ({completedWorkflows.length})</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {saving && (
              <span className="text-xs text-slate-400 inline-flex items-center gap-1">
                <Loader2 className="w-3 h-3 animate-spin" />
                Saving...
              </span>
            )}
            {canWrite && viewMode === 'pipeline' && (
              <form onSubmit={(e) => void handleCreateWorkflow(e)} className="flex items-center gap-2">
                <input
                  ref={newTitleInputRef}
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="Start fresh video title or idea..."
                  className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs w-56"
                />
                <button
                  type="submit"
                  disabled={creating || !newTitle.trim()}
                  className="h-9 px-3.5 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap disabled:opacity-50"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>New Production</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/20 p-3.5 text-xs text-rose-700 dark:text-rose-300 flex items-center justify-between">
          <span className="inline-flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </span>
          <button type="button" onClick={() => setError(null)} className="underline font-semibold">
            Dismiss
          </button>
        </div>
      )}

      {notice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 p-3.5 text-xs text-emerald-800 dark:text-emerald-200 flex flex-wrap items-center justify-between gap-2">
          <span className="inline-flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            {notice}
          </span>
          <div className="flex items-center gap-3">
            {lastCompletedProject && viewMode === 'pipeline' && (
              <button
                type="button"
                onClick={() => {
                  setSelectedHistoryId(lastCompletedProject.id);
                  setViewMode('history');
                }}
                className="font-semibold underline"
              >
                View in Completed Project History
              </button>
            )}
            <button type="button" onClick={() => setNotice(null)} className="underline font-semibold">
              Dismiss
            </button>
          </div>
        </div>
      )}

      {/* FEATURE 2: SCRIPTING STUDIO DIRECTLY INSIDE WORKFLOW */}
      {viewMode === 'scripting' ? (
        <div className="space-y-4">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-wrap items-center justify-between gap-2 text-xs">
            <div>
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                Scripting Studio
              </h3>
              <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                Draft, approve, and archive full YouTube video scripts directly inside Workflow.
              </p>
            </div>
            {activeWf && (
              <button
                type="button"
                onClick={() => setViewMode('pipeline')}
                className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
              >
                Back to Video Pipeline ({activeWf.title})
              </button>
            )}
          </div>
          <ScriptwritingStudioTool mode="standalone" />
        </div>
      ) : viewMode === 'posts' ? (
        /* FEATURE 3: COMMUNITY POSTS DIRECTLY INSIDE WORKFLOW (4 POST TYPES) */
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-4">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Posts Studio
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Create, save, and approve YouTube Community Posts across all 4 post types: 1. Image Post, 2. Text Post, 3. Text Poll, and 4. Poll.
            </p>
          </div>
          <YtmCommunityPostCreator
            authFetch={authFetch}
            workspaceKey={workspaceKey}
            workflowProjectId={null}
            projectTitle=""
            channelProfileId={activeChannelProfile?.id ?? null}
            canWrite={canWrite}
          />
        </div>
      ) : viewMode === 'history' ? (
        completedWorkflows.length === 0 ? (
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-10 text-center space-y-2 text-xs">
            <Archive className="w-6 h-6 text-slate-400 mx-auto" />
            <div className="font-display text-base font-bold text-slate-950 dark:text-white">
              No Completed Projects Yet
            </div>
            <p className="text-slate-500 max-w-md mx-auto">
              Once a video production completes all 6 stages and receives final approval on Stage 6, it is automatically archived here with its full saved script, thumbnail, SEO package, and timestamps.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 text-xs">
            <div className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
              <div className="px-4 py-3 bg-slate-50 dark:bg-slate-950 font-display text-sm font-bold text-slate-950 dark:text-white">
                Archived Productions ({completedWorkflows.length})
              </div>
              {completedWorkflows.map((w) => {
                const selected = selectedHistoryWf?.id === w.id;
                return (
                  <button
                    key={w.id}
                    type="button"
                    onClick={() => setSelectedHistoryId(w.id)}
                    className={`w-full text-left p-3.5 transition-colors ${
                      selected
                        ? 'bg-blue-50/70 dark:bg-blue-950/30 text-slate-950 dark:text-white'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="font-semibold truncate">{w.title}</div>
                    <div className="font-mono tabular-nums text-[11px] text-slate-500 mt-0.5">
                      #{w.id} · {w.projectStatus} ·{' '}
                      {w.completedAt ? w.completedAt.slice(0, 10) : w.updatedAt.slice(0, 10)}
                    </div>
                  </button>
                );
              })}
            </div>

            {selectedHistoryWf && (
              <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-5">
                <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <div className="font-mono text-[11px] uppercase text-emerald-600 dark:text-emerald-400 font-semibold">
                      Project #{selectedHistoryWf.id} · {selectedHistoryWf.projectStatus}
                      {selectedHistoryWf.completedAt
                        ? ` · Completed ${selectedHistoryWf.completedAt.slice(0, 16).replace('T', ' ')}`
                        : ''}
                    </div>
                    <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white mt-0.5">
                      {selectedHistoryWf.title}
                    </h3>
                    <p className="text-slate-500 mt-1">
                      Topic: {selectedHistoryWf.stage2Topic.centralTopic || 'Not specified'}
                    </p>
                  </div>
                  {selectedHistoryWf.youtubeVideoUrl && (
                    <a
                      href={selectedHistoryWf.youtubeVideoUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="h-8 px-3 rounded-lg bg-[#FF0000] text-white font-semibold inline-flex items-center gap-1.5"
                    >
                      <Youtube className="w-3.5 h-3.5" />
                      <span>Watch on YouTube</span>
                    </a>
                  )}
                </div>

                {/* Stage Approval Timestamps */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {YTM_WORKFLOW_STAGES.map((st) => {
                    const ts = selectedHistoryWf.approvalTimestamps?.[`stage${st.stage}`];
                    return (
                      <div
                        key={st.stage}
                        className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950"
                      >
                        <div className="font-semibold text-slate-800 dark:text-slate-200">{st.label}</div>
                        <div className="font-mono text-[11px] text-emerald-600 dark:text-emerald-400">
                          {ts ? `Approved ${ts.slice(0, 10)}` : 'Approved'}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Saved Final Approved Script */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="font-display text-sm font-bold text-slate-950 dark:text-white inline-flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <span>Final Approved Script</span>
                    </div>
                    {selectedHistoryWf.finalApprovedScript && (
                      <button
                        type="button"
                        onClick={() =>
                          void handleCopy(
                            `hist-script-${selectedHistoryWf.id}`,
                            selectedHistoryWf.finalApprovedScript || ''
                          )
                        }
                        className="h-7 px-2.5 rounded border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1"
                      >
                        <Copy className="w-3 h-3" />
                        <span>
                          {copiedId === `hist-script-${selectedHistoryWf.id}`
                            ? 'Copied'
                            : 'Copy Script'}
                        </span>
                      </button>
                    )}
                  </div>
                  {selectedHistoryWf.finalApprovedScript ? (
                    <pre className="p-4 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 whitespace-pre-wrap font-sans text-xs text-slate-800 dark:text-slate-200 max-h-80 overflow-y-auto leading-relaxed">
                      {selectedHistoryWf.finalApprovedScript}
                    </pre>
                  ) : (
                    <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-500">
                      Script was finalized via linked Script Studio project ({selectedHistoryWf.scriptProjectKey || 'N/A'}).
                    </div>
                  )}
                </div>

                {/* Saved Thumbnail & SEO Summary */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      Stage 4 · Thumbnail / Community Asset
                    </div>
                    {selectedHistoryWf.stage4Thumbnail.uploadedThumbnailUrl ? (
                      <img
                        src={selectedHistoryWf.stage4Thumbnail.uploadedThumbnailUrl}
                        alt={selectedHistoryWf.title}
                        className="w-full aspect-video rounded object-cover border border-slate-200 dark:border-slate-700"
                      />
                    ) : (
                      <div className="text-slate-500">
                        Overlay: {selectedHistoryWf.stage4Thumbnail.selectedTextOverlay || 'None'} · Mode:{' '}
                        {selectedHistoryWf.stage4Mode}
                      </div>
                    )}
                  </div>

                  <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-1.5">
                    <div className="font-semibold text-slate-900 dark:text-white">
                      Stage 5 · Saved YouTube SEO
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 line-clamp-4">
                      {selectedHistoryWf.stage5Seo.description || 'No description saved.'}
                    </p>
                    {selectedHistoryWf.stage5Seo.tags.length > 0 && (
                      <div className="font-mono text-[11px] text-slate-500">
                        Tags: {selectedHistoryWf.stage5Seo.tags.join(', ')}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )
      ) : !activeWf ? (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-10 text-center space-y-3">
          <h3 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Start a New Video Production (Stage 1 · Title)
          </h3>
          <p className="text-xs text-slate-600 dark:text-slate-400 max-w-md mx-auto">
            Enter a fresh video title or idea above to begin an isolated 6-stage pipeline: Title → Topic → AI Script Studio → Thumbnail / Community Post → SEO → Distribution &amp; YouTube Publishing.
          </p>
        </div>
      ) : (
        (() => {
          const maxUnlockedStage: YtmWorkflowStageNumber = (() => {
            for (let s = 1; s <= 5; s++) {
              if (!activeWf.approvals?.[`stage${s}`]) return s as YtmWorkflowStageNumber;
            }
            return 6;
          })();
          const currentWarning = activeWf.stageWarnings?.[`stage${activeWf.currentStage}`];
          const allEarlierStagesApproved = [1, 2, 3, 4, 5].every(
            (s) => Boolean(activeWf.approvals?.[`stage${s}`])
          );

          return (
            <>
              {/* 6-Stage Stepper */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                {YTM_WORKFLOW_STAGES.map((st) => {
                  const isActive = activeWf.currentStage === st.stage;
                  const isApproved = Boolean(activeWf.approvals?.[`stage${st.stage}`]);
                  const isUnlocked = st.stage <= maxUnlockedStage;
                  const hasWarning = Boolean(activeWf.stageWarnings?.[`stage${st.stage}`]);
                  return (
                    <button
                      key={st.stage}
                      type="button"
                      disabled={!isUnlocked || saving || busy}
                      onClick={() => void patchWorkflow({ currentStage: st.stage })}
                      className={`h-11 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 whitespace-nowrap transition-colors ${
                        isActive
                          ? 'border-blue-600 bg-[#0F172A] dark:bg-blue-600 text-white'
                          : !isUnlocked
                            ? 'border-slate-200 dark:border-slate-800 bg-slate-100/70 dark:bg-slate-900/40 text-slate-400 cursor-not-allowed'
                            : hasWarning
                              ? 'border-amber-300 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-200'
                              : isApproved
                                ? 'border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-200'
                                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {!isUnlocked ? (
                        <Lock className="w-3 h-3 shrink-0" />
                      ) : hasWarning ? (
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      ) : isApproved ? (
                        <Check className="w-3.5 h-3.5 shrink-0" />
                      ) : null}
                      <span className="truncate">{st.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Stage Workspace (strictly keyed by activeWf.id for zero state leakage across projects) */}
              <div
                key={activeWf.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 space-y-5"
              >
                {currentWarning && (
                  <div className="rounded-xl border border-amber-200 dark:border-amber-900/60 bg-amber-50 dark:bg-amber-950/25 p-3.5 text-xs text-amber-900 dark:text-amber-200 flex flex-wrap items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 shrink-0" />
                      <span>
                        <strong>Needs Review:</strong> {currentWarning} (Existing work has been preserved.)
                      </span>
                    </span>
                    {canWrite && (
                      <button
                        type="button"
                        onClick={() => void patchWorkflow({ clearStageWarning: activeWf.currentStage })}
                        className="font-semibold underline shrink-0"
                      >
                        Mark Reviewed
                      </button>
                    )}
                  </div>
                )}
            {/* STAGE 1: TITLE */}
            {activeWf.currentStage === 1 && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                      Stage 1 · Title & Packaging Hook
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Generate psychological YouTube title angles or refine your working title.
                    </p>
                  </div>
                  {canWrite && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() =>
                        void runStageAi('titles', { seedIdea: activeWf.stage1Title.seedIdea || activeWf.title })
                      }
                      className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-60"
                    >
                      {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                      <span>Generate 5 Title Angles</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Seed Idea / Core Angle
                    </label>
                    <input
                      type="text"
                      disabled={!canWrite}
                      value={activeWf.stage1Title.seedIdea}
                      onChange={(e) => {
                        const val = e.target.value;
                        replaceWorkflow({
                          ...activeWf,
                          stage1Title: { ...activeWf.stage1Title, seedIdea: val },
                        });
                      }}
                      onBlur={() => void patchWorkflow({ stage1Title: activeWf.stage1Title })}
                      className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Selected Working Title
                    </label>
                    <input
                      type="text"
                      disabled={!canWrite}
                      value={activeWf.stage1Title.selectedTitle}
                      onChange={(e) => {
                        const val = e.target.value;
                        replaceWorkflow({
                          ...activeWf,
                          title: val,
                          stage1Title: { ...activeWf.stage1Title, selectedTitle: val },
                        });
                      }}
                      onBlur={() => void patchWorkflow({ stage1Title: activeWf.stage1Title })}
                      className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-semibold"
                    />
                  </div>
                </div>

                {activeWf.stage1Title.options.length > 0 && (
                  <div className="space-y-2">
                    {activeWf.stage1Title.options.map((opt) => {
                      const selected = activeWf.stage1Title.selectedTitle === opt.title;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          disabled={!canWrite}
                          onClick={() =>
                            void patchWorkflow({
                              stage1Title: {
                                ...activeWf.stage1Title,
                                selectedTitle: opt.title,
                              },
                            })
                          }
                          className={`w-full text-left rounded-lg border p-3.5 text-xs transition-colors ${
                            selected
                              ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/20'
                              : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2 text-slate-500">
                            <span>{opt.angle}</span>
                            {selected && (
                              <span className="font-semibold text-blue-600 dark:text-blue-400">
                                Selected
                              </span>
                            )}
                          </div>
                          <div className="font-display text-sm font-bold text-slate-950 dark:text-white mt-0.5">
                            {opt.title}
                          </div>
                          <div className="mt-1 text-slate-600 dark:text-slate-400">
                            {opt.psychologicalAppeal} · Curiosity Gap: {opt.curiosityGap}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* STAGE 2: TOPIC */}
            {activeWf.currentStage === 2 && (
              <div className="space-y-4 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                      Stage 2 · Topic Clarity & Viewer Transformation
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Clarify target viewer, core tension, and key talking points before scripting.
                    </p>
                  </div>
                  {canWrite && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void runStageAi('topic')}
                      className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                    >
                      {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                      <span>Expand Topic With AI</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(
                    [
                      ['centralTopic', 'Central Topic'],
                      ['targetAudience', 'Target Audience'],
                      ['coreProblem', 'Core Audience Problem'],
                      ['desiredOutcome', 'Desired Outcome / Transformation'],
                    ] as const
                  ).map(([field, label]) => (
                    <div key={field}>
                      <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                        {label}
                      </label>
                      <input
                        type="text"
                        disabled={!canWrite}
                        value={activeWf.stage2Topic[field]}
                        onChange={(e) => {
                          const val = e.target.value;
                          replaceWorkflow({
                            ...activeWf,
                            stage2Topic: { ...activeWf.stage2Topic, [field]: val },
                          });
                        }}
                        onBlur={() => void patchWorkflow({ stage2Topic: activeWf.stage2Topic })}
                        className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                  ))}
                </div>

                <div>
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Supporting Points (one per line)
                  </label>
                  <textarea
                    rows={4}
                    disabled={!canWrite}
                    value={(activeWf.stage2Topic.supportingPoints || []).join('\n')}
                    onChange={(e) => {
                      const arr = e.target.value.split('\n');
                      replaceWorkflow({
                        ...activeWf,
                        stage2Topic: { ...activeWf.stage2Topic, supportingPoints: arr },
                      });
                    }}
                    onBlur={() =>
                      void patchWorkflow({
                        stage2Topic: {
                          ...activeWf.stage2Topic,
                          supportingPoints: activeWf.stage2Topic.supportingPoints.filter((s) =>
                            s.trim()
                          ),
                        },
                      })
                    }
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
              </div>
            )}

            {/* STAGE 3: EMBEDDED AI VIDEO SCRIPTWRITING STUDIO (Keyed by workflow project ID for strict isolation) */}
            {activeWf.currentStage === 3 && (
              <ScriptwritingStudioTool
                key={`wf-script-${activeWf.id}`}
                mode="workflow"
                workflowContext={{
                  workflowProjectId: activeWf.id,
                  workspaceKey,
                  scriptProjectKey: activeWf.scriptProjectKey,
                  approvedTitle: activeWf.stage1Title.selectedTitle || activeWf.title,
                  approvedTopic:
                    activeWf.stage2Topic.centralTopic ||
                    activeWf.stage1Title.seedIdea ||
                    activeWf.title,
                  targetAudience: activeWf.stage2Topic.targetAudience || 'YouTube viewers',
                  coreProblem: activeWf.stage2Topic.coreProblem || '',
                  desiredOutcome: activeWf.stage2Topic.desiredOutcome || '',
                  valueAngle: activeWf.stage2Topic.valueAngle || '',
                  supportingPoints: activeWf.stage2Topic.supportingPoints || [],
                }}
                onScriptProjectLinked={(key) => {
                  if (activeWf.scriptProjectKey !== key) {
                    replaceWorkflow({ ...activeWf, scriptProjectKey: key });
                  }
                }}
                onScriptApproved={async () => {
                  await loadAll();
                  setNotice(
                    'Complete Script approved in Stage 3. Stage 4 (Thumbnail & Community Post) is now unlocked.'
                  );
                }}
              />
            )}

            {/* STAGE 4: DUAL CREATION MODE (1. VIDEO THUMBNAIL | 2. COMMUNITY POST) */}
            {activeWf.currentStage === 4 && (
              <div className="space-y-5 text-xs">
                {/* Explicit Dual Mode Selector */}
                <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                      Stage 4 · Creative Assets (Video Thumbnail &amp; Community Post)
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Switch between designing your Video Thumbnail and creating a YouTube Community Post (1. Image Post, 2. Text Post, 3. Text Poll, or 4. Poll).
                    </p>
                  </div>
                  <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-950">
                    {(
                      [
                        { id: 'thumbnail', label: '1. Video Thumbnail', icon: ImageIcon },
                        { id: 'community_post', label: '2. Community Post', icon: MessageSquare },
                      ] as Array<{
                        id: YtmStage4Mode;
                        label: string;
                        icon: React.ComponentType<{ className?: string }>;
                      }>
                    ).map((m) => {
                      const Icon = m.icon;
                      const isMode = (activeWf.stage4Mode || 'thumbnail') === m.id;
                      return (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => void patchWorkflow({ stage4Mode: m.id })}
                          className={`h-8 px-3 rounded-md font-semibold inline-flex items-center gap-1.5 ${
                            isMode
                              ? 'bg-blue-600 text-white'
                              : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                          }`}
                        >
                          <Icon className="w-3.5 h-3.5" />
                          <span>{m.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {activeWf.stage4Mode === 'community_post' ? (
                  <YtmCommunityPostCreator
                    authFetch={authFetch}
                    workspaceKey={workspaceKey}
                    workflowProjectId={activeWf.id}
                    projectTitle={activeWf.stage1Title.selectedTitle || activeWf.title}
                    projectTopic={activeWf.stage2Topic.centralTopic || activeWf.title}
                    channelProfileId={activeWf.channelProfileId ?? activeChannelProfile?.id ?? null}
                    canWrite={canWrite}
                  />
                ) : (
                  <div className="space-y-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        Video Thumbnail Concepts, Prompt &amp; Asset Upload
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        {canWrite && (
                          <>
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => void runStageAi('thumbnail')}
                              className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
                            >
                              {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                              <span>Generate 3 Concepts</span>
                            </button>
                            <input
                              ref={thumbInputRef}
                              type="file"
                              accept="image/png,image/jpeg,image/webp"
                              className="hidden"
                              onChange={(e) => {
                                const f = e.target.files?.[0];
                                if (f) void handleUploadThumbnail(f);
                              }}
                            />
                            <button
                              type="button"
                              disabled={busy}
                              onClick={() => thumbInputRef.current?.click()}
                              className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
                            >
                              <Upload className="w-3.5 h-3.5" />
                              <span>Upload Thumbnail Image</span>
                            </button>
                          </>
                        )}
                      </div>
                    </div>

                    {!activeWf.stage4Thumbnail.uploadedThumbnailUrl &&
                      activeWf.stage4Thumbnail.concepts.length === 0 &&
                      !activeWf.stage4Thumbnail.selectedTextOverlay && (
                        <div className="rounded-lg border border-dashed border-slate-300 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-950/60 p-4 text-slate-500">
                          <strong>NOT STARTED</strong> — No thumbnail concepts generated or thumbnail image uploaded yet for this project.
                        </div>
                      )}

                    {activeWf.stage4Thumbnail.uploadedThumbnailUrl && (
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-2">
                        <div className="font-semibold text-slate-700 dark:text-slate-200">
                          Uploaded Thumbnail Asset Preview
                        </div>
                        <img
                          src={activeWf.stage4Thumbnail.uploadedThumbnailUrl}
                          alt="Uploaded thumbnail preview"
                          className="max-w-md w-full aspect-video object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                        />
                      </div>
                    )}

                {activeWf.stage4Thumbnail.concepts.length > 0 && (
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                    {activeWf.stage4Thumbnail.concepts.map((c) => {
                      const active = activeWf.stage4Thumbnail.selectedConceptId === c.id;
                      return (
                        <div
                          key={c.id}
                          className={`rounded-xl border p-4 space-y-2 ${
                            active
                              ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/20'
                              : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-display text-sm font-bold text-slate-950 dark:text-white">
                              {c.conceptName}
                            </span>
                            <button
                              type="button"
                              onClick={() =>
                                void patchWorkflow({
                                  stage4Thumbnail: {
                                    ...activeWf.stage4Thumbnail,
                                    selectedConceptId: c.id,
                                    customImagePrompt: c.imagePrompt,
                                    selectedTextOverlay: c.textOverlayOptions?.[0] || '',
                                  },
                                })
                              }
                              className="text-blue-600 dark:text-blue-400 font-semibold"
                            >
                              {active ? 'Selected' : 'Select'}
                            </button>
                          </div>
                          <div><strong>Subject:</strong> {c.mainSubject}</div>
                          <div><strong>Composition:</strong> {c.composition}</div>
                          <div><strong>Contrast:</strong> {c.colorContrast} · {c.emotion}</div>
                          <div>
                            <strong>Text Overlays:</strong> {c.textOverlayOptions.join(' / ')}
                          </div>
                          <div className="pt-1 flex items-center justify-between gap-2">
                            <span className="font-mono text-[11px] text-slate-500 truncate">
                              {c.imagePrompt}
                            </span>
                            <button
                              type="button"
                              onClick={() => void handleCopy(`prompt-${c.id}`, c.imagePrompt)}
                              className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 inline-flex items-center gap-1 shrink-0"
                            >
                              <Copy className="w-3 h-3" />
                              <span>{copiedId === `prompt-${c.id}` ? 'Copied' : 'Prompt'}</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Thumbnail Text Overlay (2–4 words)
                    </label>
                    <input
                      type="text"
                      disabled={!canWrite}
                      value={activeWf.stage4Thumbnail.selectedTextOverlay}
                      onChange={(e) => {
                        const val = e.target.value;
                        replaceWorkflow({
                          ...activeWf,
                          stage4Thumbnail: { ...activeWf.stage4Thumbnail, selectedTextOverlay: val },
                        });
                      }}
                      onBlur={() => void patchWorkflow({ stage4Thumbnail: activeWf.stage4Thumbnail })}
                      className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                      Custom Image Prompt
                    </label>
                    <input
                      type="text"
                      disabled={!canWrite}
                      value={activeWf.stage4Thumbnail.customImagePrompt}
                      onChange={(e) => {
                        const val = e.target.value;
                        replaceWorkflow({
                          ...activeWf,
                          stage4Thumbnail: { ...activeWf.stage4Thumbnail, customImagePrompt: val },
                        });
                      }}
                      onBlur={() => void patchWorkflow({ stage4Thumbnail: activeWf.stage4Thumbnail })}
                      className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                    />
                  </div>
                </div>
                  </div>
                )}
              </div>
            )}

            {/* STAGE 5: SEO */}
            {activeWf.currentStage === 5 && (
              <div className="space-y-4 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                      Stage 5 · YouTube SEO, Metadata & Pre-Publish Checklist
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      Optimize YouTube description, tags, chapters, pinned comment, and quality checks.
                    </p>
                  </div>
                  {canWrite && (
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => void runStageAi('seo')}
                      className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
                    >
                      {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                      <span>Generate SEO Package</span>
                    </button>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-slate-700 dark:text-slate-200">
                          YouTube Description
                        </label>
                        <button
                          type="button"
                          onClick={() => void handleCopy('seo-desc', activeWf.stage5Seo.description)}
                          className="text-blue-600 dark:text-blue-400 font-semibold"
                        >
                          {copiedId === 'seo-desc' ? 'Copied' : 'Copy'}
                        </button>
                      </div>
                      <textarea
                        rows={7}
                        disabled={!canWrite}
                        value={activeWf.stage5Seo.description}
                        onChange={(e) => {
                          const val = e.target.value;
                          replaceWorkflow({
                            ...activeWf,
                            stage5Seo: { ...activeWf.stage5Seo, description: val },
                          });
                        }}
                        onBlur={() => void patchWorkflow({ stage5Seo: activeWf.stage5Seo })}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>

                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-semibold text-slate-700 dark:text-slate-200">
                          Tags (comma-separated)
                        </label>
                        <button
                          type="button"
                          onClick={() =>
                            void handleCopy('seo-tags', (activeWf.stage5Seo.tags || []).join(', '))
                          }
                          className="text-blue-600 dark:text-blue-400 font-semibold"
                        >
                          {copiedId === 'seo-tags' ? 'Copied' : 'Copy Tags'}
                        </button>
                      </div>
                      <input
                        type="text"
                        disabled={!canWrite}
                        value={(activeWf.stage5Seo.tags || []).join(', ')}
                        onChange={(e) => {
                          const tags = e.target.value.split(',').map((t) => t.trim());
                          replaceWorkflow({
                            ...activeWf,
                            stage5Seo: { ...activeWf.stage5Seo, tags },
                          });
                        }}
                        onBlur={() =>
                          void patchWorkflow({
                            stage5Seo: {
                              ...activeWf.stage5Seo,
                              tags: activeWf.stage5Seo.tags.filter(Boolean),
                            },
                          })
                        }
                        className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-200 mb-1">
                        Pinned Comment Draft
                      </label>
                      <textarea
                        rows={3}
                        disabled={!canWrite}
                        value={activeWf.stage5Seo.pinnedComment}
                        onChange={(e) => {
                          const val = e.target.value;
                          replaceWorkflow({
                            ...activeWf,
                            stage5Seo: { ...activeWf.stage5Seo, pinnedComment: val },
                          });
                        }}
                        onBlur={() => void patchWorkflow({ stage5Seo: activeWf.stage5Seo })}
                        className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                      />
                    </div>

                    {activeWf.stage5Seo.chapters.length > 0 && (
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 space-y-1">
                        <div className="font-semibold text-slate-700 dark:text-slate-200">
                          Chapters ({activeWf.stage5Seo.chapters.length})
                        </div>
                        {activeWf.stage5Seo.chapters.map((ch, i) => (
                          <div key={i} className="font-mono text-slate-600 dark:text-slate-300">
                            {ch.timestamp} — {ch.title}
                          </div>
                        ))}
                      </div>
                    )}

                    {activeWf.stage5Seo.uploadChecklist.length > 0 && (
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 space-y-1.5">
                        <div className="font-semibold text-slate-700 dark:text-slate-200">
                          Upload Quality Checklist
                        </div>
                        {activeWf.stage5Seo.uploadChecklist.map((item, idx) => (
                          <button
                            key={idx}
                            type="button"
                            disabled={!canWrite}
                            onClick={() => {
                              const nextList = activeWf.stage5Seo.uploadChecklist.map((c, j) =>
                                j === idx ? { ...c, checked: !c.checked } : c
                              );
                              void patchWorkflow({
                                stage5Seo: { ...activeWf.stage5Seo, uploadChecklist: nextList },
                              });
                            }}
                            className="w-full flex items-center gap-2 text-left text-slate-700 dark:text-slate-200"
                          >
                            <span
                              className={`w-4 h-4 rounded border flex items-center justify-center shrink-0 ${
                                item.checked
                                  ? 'bg-emerald-600 border-emerald-600 text-white'
                                  : 'border-slate-300 dark:border-slate-600'
                              }`}
                            >
                              {item.checked && <Check className="w-3 h-3" />}
                            </span>
                            <span className={item.checked ? 'line-through text-slate-400' : ''}>
                              {item.item}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* STAGE 6: DISTRIBUTION + REAL YOUTUBE API PUBLISHING */}
            {activeWf.currentStage === 6 && (
              <div className="space-y-6 text-xs">
                {/* Real YouTube Video Upload (videos.insert resumable) */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-5 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Youtube className="w-4 h-4 text-[#FF0000]" />
                      <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                        Authorized YouTube Video Upload (Resumable API)
                      </h3>
                    </div>
                    {!connectedChannel && (
                      <button
                        type="button"
                        onClick={onConnectYouTube}
                        className="h-8 px-3 rounded-lg bg-[#FF0000] text-white font-semibold"
                      >
                        Connect YouTube Channel First
                      </button>
                    )}
                  </div>

                  {connectedChannel ? (
                    <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
                      <div className="md:col-span-5">
                        <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                          Select Video File (MP4/MOV/WebM, max 256 MB)
                        </label>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="video/*"
                          disabled={!canPublishYouTube || uploadingVideo}
                          onChange={(e) => setVideoFile(e.target.files?.[0] || null)}
                          className="w-full text-xs file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-[#0F172A] file:text-white file:font-semibold"
                        />
                      </div>
                      <div className="md:col-span-3">
                        <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                          Privacy Visibility
                        </label>
                        <select
                          value={uploadPrivacy}
                          onChange={(e) =>
                            setUploadPrivacy(e.target.value as 'private' | 'unlisted' | 'public')
                          }
                          className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                        >
                          <option value="private">Private (Recommended Draft)</option>
                          <option value="unlisted">Unlisted</option>
                          <option value="public">Public</option>
                        </select>
                      </div>
                      <div className="md:col-span-4">
                        <button
                          type="button"
                          disabled={!videoFile || !canPublishYouTube || uploadingVideo}
                          onClick={() => void handleUploadYouTubeVideo()}
                          className="w-full h-10 px-4 rounded-lg bg-[#FF0000] hover:bg-[#DC2626] disabled:opacity-50 text-white font-semibold inline-flex items-center justify-center gap-2"
                        >
                          {uploadingVideo ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Upload className="w-4 h-4" />
                          )}
                          <span>
                            {uploadingVideo
                              ? 'Uploading to YouTube...'
                              : 'Upload to Connected Channel'}
                          </span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-slate-500 dark:text-slate-400">
                      Connect your channel via Google OAuth to upload finished videos directly with your Stage 1 Title and Stage 5 SEO Description/Tags.
                    </p>
                  )}

                  {publishingJobs.length > 0 && (
                    <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-1.5">
                      <div className="font-semibold text-slate-700 dark:text-slate-300">
                        Recent YouTube Publishing Jobs
                      </div>
                      {publishingJobs.slice(0, 4).map((job) => (
                        <div key={job.id} className="flex items-center justify-between gap-2 text-[11px]">
                          <span className="truncate font-medium text-slate-800 dark:text-slate-200">
                            {job.title} ({job.privacyStatus}) — {job.status} ({job.progressPercent}%)
                          </span>
                          {job.youtubeVideoUrl && (
                            <a
                              href={job.youtubeVideoUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 dark:text-blue-400 inline-flex items-center gap-1 shrink-0"
                            >
                              <span>Watch</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* 8-Platform Distribution Copy & Asset Engine */}
                <div className="space-y-4">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                        8-Platform Multi-Channel Distribution Assets
                      </h3>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Honest publishing: platforms without authorized OAuth integrations provide copy, hashtags, slides, and official post links so you can mark them manually published.
                      </p>
                    </div>
                    {canWrite && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void runStageAi('distribution')}
                        className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
                      >
                        {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                        <span>Generate All 8 Platform Packs</span>
                      </button>
                    )}
                  </div>

                  {/* 8 Platform Tabs */}
                  <div className="flex flex-wrap gap-1.5 p-1 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950">
                    {YTM_DISTRIBUTION_PLATFORMS.map((p) => {
                      const active = activeDistTab === p.id;
                      const asset = wfDistAssets.find((d) => d.platform === p.id);
                      return (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => setActiveDistTab(p.id)}
                          className={`h-8 px-3 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap ${
                            active
                              ? 'bg-white dark:bg-slate-800 text-slate-950 dark:text-white'
                              : 'text-slate-600 dark:text-slate-400'
                          }`}
                        >
                          {asset?.status === 'manually_published' && (
                            <Check className="w-3 h-3 text-emerald-600" />
                          )}
                          <span>{p.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  {!activeDistAsset ? (
                    <div className="rounded-xl border border-dashed border-slate-200 dark:border-slate-700 p-6 text-center space-y-2">
                      <p className="text-slate-500 dark:text-slate-400">
                        No distribution pack generated for <strong>{activePlatformMeta.label}</strong> yet.
                      </p>
                      {canWrite && (
                        <button
                          type="button"
                          disabled={busy}
                          onClick={() =>
                            void runStageAi('distribution', { platforms: [activePlatformMeta.id] })
                          }
                          className="h-9 px-4 rounded-lg bg-[#0F172A] dark:bg-blue-600 text-white font-semibold"
                        >
                          Generate {activePlatformMeta.label} Assets
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-5 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                            {activePlatformMeta.label} · {activeDistAsset.assetType}
                          </div>
                          <p className="text-[11px] text-slate-500">{activePlatformMeta.note}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-[11px] text-slate-600 dark:text-slate-300">
                            Status: {activeDistAsset.status}
                          </span>
                          <a
                            href={activePlatformMeta.officialPublishUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold inline-flex items-center gap-1"
                          >
                            <span>Open {activePlatformMeta.label}</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="font-semibold text-slate-700 dark:text-slate-200">
                          Post Copy
                        </div>
                        <textarea
                          rows={5}
                          disabled={!canWrite}
                          value={activeDistAsset.bodyCopy}
                          onChange={(e) => {
                            const val = e.target.value;
                            setDistAssets((prev) =>
                              prev.map((a) =>
                                a.id === activeDistAsset.id ? { ...a, bodyCopy: val } : a
                              )
                            );
                          }}
                          onBlur={() =>
                            void handleUpdateDistributionAsset(activeDistAsset.id, {
                              bodyCopy: activeDistAsset.bodyCopy,
                            })
                          }
                          className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                      </div>

                      {activeDistAsset.hashtags && (
                        <div className="text-slate-600 dark:text-slate-300 font-mono text-[11px]">
                          {activeDistAsset.hashtags}
                        </div>
                      )}

                      {activeDistAsset.carouselSlides.length > 0 && (
                        <div className="space-y-1">
                          <div className="font-semibold text-slate-700 dark:text-slate-200">
                            Carousel / Thread Slides
                          </div>
                          <ul className="list-disc pl-5 space-y-1 text-slate-600 dark:text-slate-300">
                            {activeDistAsset.carouselSlides.map((s, i) => (
                              <li key={i}>{s}</li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="pt-2 flex flex-wrap items-center justify-between gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            void handleCopy(
                              `dist-${activeDistAsset.id}`,
                              `${activeDistAsset.title}\n\n${activeDistAsset.bodyCopy}\n\n${activeDistAsset.hashtags}`
                            )
                          }
                          className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold inline-flex items-center gap-1.5"
                        >
                          <Copy className="w-3.5 h-3.5" />
                          <span>
                            {copiedId === `dist-${activeDistAsset.id}`
                              ? 'Copied Complete Post'
                              : 'Copy Post & Hashtags'}
                          </span>
                        </button>

                        {canWrite && (
                          <button
                            type="button"
                            onClick={() =>
                              void handleUpdateDistributionAsset(activeDistAsset.id, {
                                status:
                                  activeDistAsset.status === 'manually_published'
                                    ? 'approved'
                                    : 'manually_published',
                              })
                            }
                            className={`h-9 px-4 rounded-lg font-semibold inline-flex items-center gap-1.5 ${
                              activeDistAsset.status === 'manually_published'
                                ? 'bg-emerald-600 text-white'
                                : 'bg-[#0F172A] dark:bg-blue-600 text-white'
                            }`}
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>
                              {activeDistAsset.status === 'manually_published'
                                ? 'Marked Manually Published'
                                : 'Mark as Manually Published'}
                            </span>
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Stage Footer Navigation & Approval */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                {activeWf.currentStage > 1 && (
                  <button
                    type="button"
                    onClick={() =>
                      void patchWorkflow({
                        currentStage: (activeWf.currentStage - 1) as YtmWorkflowStageNumber,
                      })
                    }
                    className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                  >
                    Previous Stage
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2">
                {canApprove && (
                  <button
                    type="button"
                    disabled={saving || (activeWf.currentStage === 6 && !allEarlierStagesApproved)}
                    onClick={() =>
                      void patchWorkflow({
                        approveStage: activeWf.currentStage,
                      })
                    }
                    className="h-9 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-semibold inline-flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>
                      {activeWf.currentStage < 6
                        ? `Approve Stage ${activeWf.currentStage} & Continue`
                        : 'Approve & Complete Production (Archive)'}
                    </span>
                  </button>
                )}
                {activeWf.currentStage < 6 && activeWf.approvals?.[`stage${activeWf.currentStage}`] && (
                  <button
                    type="button"
                    onClick={() =>
                      void patchWorkflow({
                        currentStage: (activeWf.currentStage + 1) as YtmWorkflowStageNumber,
                      })
                    }
                    className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold"
                  >
                    Next Stage
                  </button>
                )}
              </div>
            </div>
          </div>
        </>
          );
        })()
      )}
    </div>
  );
}
