import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock,
  History,
  Loader2,
  Lock,
  Mic,
  MicOff,
  Pause,
  Play,
  Plus,
  RotateCcw,
  Send,
  ShieldCheck,
  Sparkles,
  Square,
  X,
  XCircle,
} from 'lucide-react';
import type {
  YtmAgentChatMessage,
  YtmAgentMode,
  YtmAgentPermissionRecord,
  YtmAgentSessionRecord,
  YtmAgentTaskRecord,
  YtmAgentUiContext,
  YtmChannelProfileWithDna,
  YtmSidebarSection,
  YtmWorkspaceRecord,
} from '../../shared/types.ts';
import { ytmRequest } from './YtmApiClient.ts';

interface Props {
  authFetch: (input: string, init?: RequestInit) => Promise<Response>;
  workspace: YtmWorkspaceRecord;
  activeSection: YtmSidebarSection;
  activeChannelProfile: YtmChannelProfileWithDna | null;
  selectedWorkflowId: number | null;
  onNavigateSection: (section: YtmSidebarSection) => void;
  onOpenWorkflowProject: (workflowId: number) => void;
}

type AgentTab = 'chat' | 'tasks' | 'permissions';

interface BootstrapResponse {
  sessions: YtmAgentSessionRecord[];
  activeSession: YtmAgentSessionRecord;
  tasks: YtmAgentTaskRecord[];
  permissions: YtmAgentPermissionRecord;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  results: ArrayLike<SpeechRecognitionResultLike>;
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

const MODE_OPTIONS: Array<{
  id: YtmAgentMode;
  label: string;
  hint: string;
}> = [
  { id: 'chat', label: 'Chat', hint: 'Read-only Q&A & analysis' },
  { id: 'assist', label: 'Assist', hint: 'Confirms before every change' },
  { id: 'autopilot', label: 'Autopilot', hint: 'Runs multi-step workflows automatically' },
];

const QUICK_PROMPTS: Array<{ label: string; command: string; suggestedMode?: YtmAgentMode }> = [
  {
    label: 'Audit calendar & next priorities',
    command: 'Review my content calendar, dashboard tasks, and Channel DNA, then tell me my top 3 priorities this week.',
    suggestedMode: 'chat',
  },
  {
    label: 'Brainstorm 10 ideas & save top 3',
    command: 'Research my niche and saved competitors, generate 10 video topic ideas matching my Channel DNA, and save the top 3 to Content Planner.',
    suggestedMode: 'assist',
  },
  {
    label: 'Full video workflow (Autopilot)',
    command: 'Create a new workflow project for a high-retention video in my niche: generate titles, expand the topic angle, write a complete 6-minute script, design thumbnail concepts, and generate YouTube SEO.',
    suggestedMode: 'autopilot',
  },
  {
    label: 'Draft a Community Poll',
    command: 'Create an engaging YouTube Community text poll draft based on my Channel DNA to ask my audience what video to make next.',
    suggestedMode: 'assist',
  },
];

function getStatusBadge(status: YtmAgentTaskRecord['status'] | 'idle'): {
  label: string;
  className: string;
} {
  switch (status) {
    case 'pending':
    case 'running':
      return {
        label: 'Running',
        className: 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
      };
    case 'waiting_for_approval':
      return {
        label: 'Approval Needed',
        className: 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
      };
    case 'paused':
      return {
        label: 'Paused',
        className: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700',
      };
    case 'completed':
      return {
        label: 'Completed',
        className: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      };
    case 'failed':
      return {
        label: 'Failed',
        className: 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
      };
    case 'cancelled':
      return {
        label: 'Stopped',
        className: 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-200 dark:border-slate-700',
      };
    default:
      return {
        label: 'Ready',
        className: 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700',
      };
  }
}

export function YtmAiAgentWidget({
  authFetch,
  workspace,
  activeSection,
  activeChannelProfile,
  selectedWorkflowId,
  onNavigateSection,
  onOpenWorkflowProject,
}: Props) {
  const [open, setOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<AgentTab>('chat');
  const [bootstrapped, setBootstrapped] = useState(false);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [actionBusy, setActionBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [session, setSession] = useState<YtmAgentSessionRecord | null>(null);
  const [tasks, setTasks] = useState<YtmAgentTaskRecord[]>([]);
  const [activeTaskKey, setActiveTaskKey] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    return window.sessionStorage.getItem(`mth_agent_task_${workspace.workspaceKey}`) || null;
  });
  const [permissions, setPermissions] = useState<YtmAgentPermissionRecord | null>(null);
  const [mode, setMode] = useState<YtmAgentMode>('assist');
  const [commandInput, setCommandInput] = useState('');
  const [expandedTaskKey, setExpandedTaskKey] = useState<string | null>(null);
  const [savingPerms, setSavingPerms] = useState(false);

  // Voice input via Web Speech API
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const speechSupported = useMemo(() => {
    if (typeof window === 'undefined') return false;
    const w = window as unknown as Record<string, unknown>;
    return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
  }, []);

  const activeTask = useMemo(() => {
    if (activeTaskKey) {
      const match = tasks.find((t) => t.taskKey === activeTaskKey);
      if (match) return match;
    }
    return (
      tasks.find(
        (t) =>
          t.status === 'running' ||
          t.status === 'pending' ||
          t.status === 'waiting_for_approval' ||
          t.status === 'paused'
      ) || null
    );
  }, [tasks, activeTaskKey]);

  const hasLiveTask = Boolean(
    activeTask && (activeTask.status === 'pending' || activeTask.status === 'running')
  );
  const needsApproval = Boolean(activeTask && activeTask.status === 'waiting_for_approval');

  const upsertTask = useCallback((nextTask: YtmAgentTaskRecord) => {
    setTasks((prev) => {
      const idx = prev.findIndex((t) => t.taskKey === nextTask.taskKey);
      if (idx === -1) return [nextTask, ...prev].slice(0, 30);
      const copy = [...prev];
      copy[idx] = nextTask;
      return copy;
    });
  }, []);

  const loadBootstrap = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await ytmRequest<BootstrapResponse>(authFetch, '/agent/sessions', {
        workspaceKey: workspace.workspaceKey,
      });
      setSession(data.activeSession);
      setTasks(data.tasks || []);
      setPermissions(data.permissions);
      setMode(data.activeSession?.mode || data.permissions?.defaultMode || 'assist');
      const live = (data.tasks || []).find(
        (t) =>
          t.status === 'running' ||
          t.status === 'pending' ||
          t.status === 'waiting_for_approval' ||
          t.status === 'paused'
      );
      if (live) {
        setActiveTaskKey(live.taskKey);
      }
      setBootstrapped(true);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to load AI Agent.');
    } finally {
      setLoading(false);
    }
  }, [authFetch, workspace.workspaceKey]);

  // Reset when workspace switches
  useEffect(() => {
    setBootstrapped(false);
    setSession(null);
    setTasks([]);
    const stored =
      typeof window !== 'undefined'
        ? window.sessionStorage.getItem(`mth_agent_task_${workspace.workspaceKey}`)
        : null;
    setActiveTaskKey(stored);
  }, [workspace.workspaceKey]);

  // Persist activeTaskKey across tab/panel navigation
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const key = `mth_agent_task_${workspace.workspaceKey}`;
    if (activeTaskKey) {
      window.sessionStorage.setItem(key, activeTaskKey);
    } else {
      window.sessionStorage.removeItem(key);
    }
  }, [activeTaskKey, workspace.workspaceKey]);

  // Bootstrap on first open OR if there's an existing activeTaskKey to monitor in background
  useEffect(() => {
    if ((open || activeTaskKey) && !bootstrapped && !loading) {
      void loadBootstrap();
    }
  }, [open, activeTaskKey, bootstrapped, loading, loadBootstrap]);

  // Poll active background task every 2 seconds until it stops running (works even when panel is closed!)
  useEffect(() => {
    if (!activeTask || (activeTask.status !== 'pending' && activeTask.status !== 'running')) {
      return;
    }
    const timer = window.setInterval(async () => {
      try {
        const res = await ytmRequest<{
          task: YtmAgentTaskRecord;
          session: YtmAgentSessionRecord | null;
        }>(authFetch, `/agent/tasks/${encodeURIComponent(activeTask.taskKey)}`, {
          workspaceKey: workspace.workspaceKey,
        });
        upsertTask(res.task);
        if (res.session) {
          setSession(res.session);
        }
      } catch {
        // Keep polling gracefully on transient network blips
      }
    }, 2000);
    return () => window.clearInterval(timer);
  }, [activeTask, authFetch, workspace.workspaceKey, upsertTask]);

  // Auto-scroll chat to bottom when messages update
  useEffect(() => {
    if (open && activeTab === 'chat') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [open, activeTab, session?.messages?.length, activeTask?.steps?.length, activeTask?.status]);

  // Cleanup speech recognition on unmount
  useEffect(() => {
    return () => {
      try {
        recognitionRef.current?.stop();
      } catch {
        // ignore
      }
    };
  }, []);

  const toggleVoiceInput = () => {
    if (!speechSupported) return;
    if (listening) {
      try {
        recognitionRef.current?.stop();
      } catch {
        // ignore
      }
      setListening(false);
      return;
    }

    const w = window as unknown as Record<string, new () => SpeechRecognitionLike>;
    const SpeechRec = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!SpeechRec) return;

    try {
      const rec = new SpeechRec();
      rec.continuous = false;
      rec.interimResults = true;
      rec.lang = 'en-US';
      rec.onresult = (event) => {
        let transcript = '';
        for (let i = 0; i < event.results.length; i++) {
          transcript += event.results[i][0]?.transcript || '';
        }
        if (transcript.trim()) {
          setCommandInput(transcript.trim());
        }
      };
      rec.onerror = () => {
        setListening(false);
      };
      rec.onend = () => {
        setListening(false);
      };
      recognitionRef.current = rec;
      setListening(true);
      rec.start();
    } catch {
      setListening(false);
    }
  };

  const handleNewSession = async () => {
    setError(null);
    try {
      const res = await ytmRequest<{ session: YtmAgentSessionRecord }>(authFetch, '/agent/sessions', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: {
          mode,
          channelProfileId: activeChannelProfile?.id ?? null,
        },
      });
      setSession(res.session);
      setActiveTaskKey(null);
      setActiveTab('chat');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to start a new session.');
    }
  };

  const handleSendCommand = async (overrideText?: string, overrideMode?: YtmAgentMode) => {
    const text = (overrideText ?? commandInput).trim();
    if (!text || submitting) return;

    const chosenMode = overrideMode ?? mode;
    if (overrideMode) setMode(overrideMode);
    setSubmitting(true);
    setError(null);

    try {
      const uiContext: YtmAgentUiContext = {
        activeSection,
        channelProfileId: activeChannelProfile?.id ?? null,
        channelProfileName: activeChannelProfile?.channelName ?? null,
        selectedWorkflowId,
      };
      const idempotencyKey = `cmd_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

      const res = await ytmRequest<{
        task: YtmAgentTaskRecord;
        session: YtmAgentSessionRecord;
      }>(authFetch, '/agent/commands', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: {
          sessionKey: session?.sessionKey,
          command: text,
          mode: chosenMode,
          uiContext,
          idempotencyKey,
        },
      });

      setCommandInput('');
      setSession(res.session);
      upsertTask(res.task);
      setActiveTaskKey(res.task.taskKey);
      setActiveTab('chat');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to send command to AI Agent.');
    } finally {
      setSubmitting(false);
    }
  };

  const runTaskControl = async (
    taskKey: string,
    action: 'pause' | 'resume' | 'cancel' | 'retry' | 'approve' | 'reject'
  ) => {
    if (actionBusy) return;
    setActionBusy(true);
    setError(null);
    try {
      const endpoint =
        action === 'approve' || action === 'reject'
          ? `/agent/tasks/${encodeURIComponent(taskKey)}/approve`
          : `/agent/tasks/${encodeURIComponent(taskKey)}/${action}`;
      const body = action === 'approve' || action === 'reject' ? { decision: action } : {};

      const res = await ytmRequest<{ task: YtmAgentTaskRecord }>(authFetch, endpoint, {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body,
      });
      upsertTask(res.task);
      setActiveTaskKey(res.task.taskKey);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : `Unable to ${action} task.`);
    } finally {
      setActionBusy(false);
    }
  };

  const handleToggleToolApproval = async (toolName: string) => {
    if (!permissions || savingPerms) return;
    const isCurrentlyRequired = permissions.approvalRequiredActions.includes(toolName);
    const nextList = isCurrentlyRequired
      ? permissions.approvalRequiredActions.filter((n) => n !== toolName)
      : [...permissions.approvalRequiredActions, toolName];

    setSavingPerms(true);
    try {
      const res = await ytmRequest<{ permissions: YtmAgentPermissionRecord }>(
        authFetch,
        '/agent/permissions',
        {
          workspaceKey: workspace.workspaceKey,
          method: 'PUT',
          body: { approvalRequiredActions: nextList },
        }
      );
      setPermissions(res.permissions);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Unable to update permissions.');
    } finally {
      setSavingPerms(false);
    }
  };

  const handleOpenArtifact = (artifact: NonNullable<YtmAgentChatMessage['artifacts']>[number]) => {
    if (artifact.workflowProjectId) {
      onOpenWorkflowProject(artifact.workflowProjectId);
      return;
    }
    onNavigateSection(artifact.section);
  };

  const statusBadge = getStatusBadge(activeTask?.status ?? 'idle');

  return (
    <>
      {/* Compact Floating AI Agent Trigger Button (bottom-right) */}
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        aria-label={open ? 'Close YouTube OS AI Agent' : 'Open YouTube OS AI Agent'}
        title="YouTube OS AI Agent"
        className={`fixed bottom-5 right-5 z-40 h-12 w-12 rounded-2xl shadow-lg border flex items-center justify-center transition-all ${
          open
            ? 'bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 border-slate-800 dark:border-slate-300'
            : 'bg-blue-600 hover:bg-blue-700 text-white border-blue-500/80'
        }`}
      >
        {open ? (
          <X className="w-5 h-5" />
        ) : (
          <Sparkles className={`w-5 h-5 ${hasLiveTask ? 'animate-pulse' : ''}`} />
        )}
        {!open && needsApproval && (
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-amber-500 border-2 border-white dark:border-slate-950" />
        )}
        {!open && !needsApproval && hasLiveTask && (
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-white dark:border-slate-950 animate-ping" />
        )}
      </button>

      {/* Compact Floating AI Agent Panel */}
      {open && (
        <aside
          aria-label="YouTube OS AI Agent"
          className="fixed bottom-20 right-5 z-40 w-[410px] max-w-[calc(100vw-2rem)] h-[610px] max-h-[calc(100vh-6.5rem)] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl flex flex-col overflow-hidden"
        >
          {/* Header */}
          <div className="px-3.5 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/90 dark:bg-slate-950/70 flex items-center justify-between gap-2 shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                <Sparkles className="w-3.5 h-3.5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-display text-xs font-bold text-slate-950 dark:text-white truncate">
                    YouTube OS Agent
                  </span>
                  <span
                    className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md border ${statusBadge.className}`}
                  >
                    {statusBadge.label}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                  {activeChannelProfile?.channelName || workspace.name} · {activeSection}
                  {selectedWorkflowId ? ` · Project #${selectedWorkflowId}` : ''}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={() => void handleNewSession()}
                title="New chat session"
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800"
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={() => setOpen(false)}
                title="Minimize panel (background tasks keep running)"
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/70 dark:hover:bg-slate-800"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Mode Selector + Panel Tabs */}
          <div className="px-3.5 py-2 border-b border-slate-200 dark:border-slate-800 space-y-2 shrink-0">
            <div className="grid grid-cols-3 gap-1 p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800/90">
              {MODE_OPTIONS.map((opt) => {
                const active = mode === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setMode(opt.id)}
                    title={opt.hint}
                    className={`h-7 rounded-md text-[11px] font-semibold transition-colors ${
                      active
                        ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between gap-2 text-[11px]">
              <span className="text-slate-500 dark:text-slate-400 truncate">
                {MODE_OPTIONS.find((m) => m.id === mode)?.hint}
              </span>
              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => setActiveTab('chat')}
                  className={`px-2 py-0.5 rounded-md font-semibold ${
                    activeTab === 'chat'
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  Chat
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('tasks')}
                  className={`px-2 py-0.5 rounded-md font-semibold inline-flex items-center gap-1 ${
                    activeTab === 'tasks'
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <History className="w-3 h-3" />
                  <span>Tasks</span>
                  {tasks.length > 0 && <span className="text-[10px] opacity-75">({tasks.length})</span>}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('permissions')}
                  className={`px-2 py-0.5 rounded-md font-semibold inline-flex items-center gap-1 ${
                    activeTab === 'permissions'
                      ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300'
                      : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                >
                  <ShieldCheck className="w-3 h-3" />
                  <span>Rules</span>
                </button>
              </div>
            </div>
          </div>

          {error && (
            <div className="mx-3 mt-2 rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/40 px-2.5 py-2 text-[11px] text-rose-700 dark:text-rose-300 flex items-center justify-between gap-2 shrink-0">
              <span className="truncate">{error}</span>
              <button type="button" onClick={() => setError(null)} className="shrink-0">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* TAB 1: CHAT & LIVE EXECUTION */}
          {activeTab === 'chat' && (
            <>
              <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3 text-xs">
                {loading && !bootstrapped ? (
                  <div className="py-12 flex items-center justify-center gap-2 text-slate-500">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Connecting YouTube OS Agent…</span>
                  </div>
                ) : (session?.messages || []).length === 0 ? (
                  <div className="space-y-3">
                    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/50 p-3 space-y-1.5">
                      <div className="font-semibold text-slate-900 dark:text-white">
                        Command your YouTube OS in natural language
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                        I read your Channel DNA, projects, calendar, competitors, and analytics, and run multi-step workflows in the background across your existing YouTube OS tools.
                      </p>
                    </div>
                    <div className="space-y-1.5">
                      <div className="text-[10px] font-semibold uppercase tracking-wide text-slate-400">
                        Try a command
                      </div>
                      {QUICK_PROMPTS.map((q) => (
                        <button
                          key={q.label}
                          type="button"
                          disabled={submitting}
                          onClick={() => void handleSendCommand(q.command, q.suggestedMode)}
                          className="w-full text-left rounded-lg border border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 bg-white dark:bg-slate-950/60 px-2.5 py-2 transition-colors"
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-semibold text-slate-800 dark:text-slate-100 text-[11px]">
                              {q.label}
                            </span>
                            {q.suggestedMode && (
                              <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                                {q.suggestedMode}
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1 mt-0.5">
                            {q.command}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  (session?.messages || []).map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-[92%] rounded-xl px-3 py-2 whitespace-pre-wrap leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 dark:bg-slate-800/90 text-slate-800 dark:text-slate-100 border border-slate-200/80 dark:border-slate-700/80'
                        }`}
                      >
                        {msg.content}
                      </div>
                      {msg.artifacts && msg.artifacts.length > 0 && (
                        <div className="mt-1.5 flex flex-wrap gap-1.5 max-w-[92%]">
                          {msg.artifacts.map((art, i) => (
                            <button
                              key={`${art.type}-${art.id}-${i}`}
                              type="button"
                              onClick={() => handleOpenArtifact(art)}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-semibold border border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/60"
                            >
                              <span className="truncate max-w-[180px]">{art.label}</span>
                              <ArrowUpRight className="w-3 h-3 shrink-0" />
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}

                {/* Active Task Live Progress & Approval Box */}
                {activeTask &&
                  activeTask.status !== 'completed' &&
                  activeTask.status !== 'cancelled' && (
                    <div className="rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950/70 p-3 space-y-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5 min-w-0">
                          {activeTask.status === 'running' || activeTask.status === 'pending' ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600 shrink-0" />
                          ) : activeTask.status === 'waiting_for_approval' ? (
                            <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                          ) : activeTask.status === 'failed' ? (
                            <XCircle className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                          ) : (
                            <Pause className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          )}
                          <span className="font-semibold text-[11px] text-slate-900 dark:text-white truncate">
                            {activeTask.status === 'waiting_for_approval'
                              ? 'Waiting for your approval'
                              : activeTask.status === 'paused'
                                ? 'Task paused'
                                : activeTask.status === 'failed'
                                  ? 'Task paused on error'
                                  : 'Executing in background…'}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          {activeTask.status === 'running' && (
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => void runTaskControl(activeTask.taskKey, 'pause')}
                              title="Pause"
                              className="p-1 rounded border border-slate-300 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                            >
                              <Pause className="w-3 h-3" />
                            </button>
                          )}
                          {activeTask.status === 'paused' && (
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => void runTaskControl(activeTask.taskKey, 'resume')}
                              title="Resume"
                              className="px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-semibold inline-flex items-center gap-1"
                            >
                              <Play className="w-3 h-3" />
                              <span>Resume</span>
                            </button>
                          )}
                          {activeTask.status === 'failed' && (
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => void runTaskControl(activeTask.taskKey, 'retry')}
                              className="px-2 py-0.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-semibold inline-flex items-center gap-1"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>Retry Failed Step</span>
                            </button>
                          )}
                          {(activeTask.status === 'running' ||
                            activeTask.status === 'pending' ||
                            activeTask.status === 'paused' ||
                            activeTask.status === 'waiting_for_approval') && (
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => void runTaskControl(activeTask.taskKey, 'cancel')}
                              title="Stop task"
                              className="p-1 rounded border border-rose-200 dark:border-rose-900 hover:bg-rose-50 dark:hover:bg-rose-950/60 text-rose-600 dark:text-rose-400"
                            >
                              <Square className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      {/* Step Progress List */}
                      {activeTask.steps.length > 0 && (
                        <div className="space-y-1">
                          {activeTask.steps.map((step) => (
                            <div
                              key={step.id}
                              className="flex items-start gap-2 text-[11px] text-slate-700 dark:text-slate-300"
                            >
                              <span className="mt-0.5 shrink-0">
                                {step.status === 'completed' ? (
                                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                                ) : step.status === 'running' ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-500" />
                                ) : step.status === 'waiting_for_approval' ? (
                                  <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                                ) : step.status === 'failed' ? (
                                  <XCircle className="w-3.5 h-3.5 text-rose-500" />
                                ) : (
                                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                                )}
                              </span>
                              <div className="min-w-0 flex-1">
                                <div className="font-medium truncate">
                                  {step.stepOrder}. {step.label}
                                </div>
                                {step.output && typeof step.output.summary === 'string' && (
                                  <div className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-2">
                                    {step.output.summary}
                                  </div>
                                )}
                                {step.errorMessage && (
                                  <div className="text-[10px] text-rose-600 dark:text-rose-400">
                                    {step.errorMessage}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Explicit Approval Request Card */}
                      {activeTask.status === 'waiting_for_approval' && activeTask.pendingApproval && (
                        <div className="rounded-lg border border-amber-300 dark:border-amber-800 bg-amber-50/90 dark:bg-amber-950/40 p-2.5 space-y-2">
                          <div className="text-[11px] font-semibold text-amber-900 dark:text-amber-200">
                            Confirm Action: {activeTask.pendingApproval.label}
                          </div>
                          <div className="text-[11px] text-amber-800 dark:text-amber-300 leading-snug">
                            {activeTask.pendingApproval.summary}
                          </div>
                          <div className="flex items-center gap-2 pt-0.5">
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => void runTaskControl(activeTask.taskKey, 'approve')}
                              className="h-7 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold inline-flex items-center gap-1"
                            >
                              {actionBusy ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <Check className="w-3 h-3" />
                              )}
                              <span>Approve &amp; Run</span>
                            </button>
                            <button
                              type="button"
                              disabled={actionBusy}
                              onClick={() => void runTaskControl(activeTask.taskKey, 'reject')}
                              className="h-7 px-3 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 text-[11px] font-semibold"
                            >
                              Reject
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                <div ref={messagesEndRef} />
              </div>

              {/* Command Input Footer */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void handleSendCommand();
                }}
                className="p-2.5 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shrink-0"
              >
                <div className="flex items-end gap-1.5">
                  <textarea
                    rows={2}
                    value={commandInput}
                    onChange={(e) => setCommandInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        void handleSendCommand();
                      }
                    }}
                    placeholder={
                      mode === 'chat'
                        ? 'Ask about your channel, DNA, or calendar…'
                        : mode === 'assist'
                          ? 'Tell me what to plan or build (I will confirm changes)…'
                          : 'Give a multi-step command to execute in Autopilot…'
                    }
                    className="flex-1 resize-none rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 px-3 py-2 text-xs text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/40"
                  />
                  {speechSupported && (
                    <button
                      type="button"
                      onClick={toggleVoiceInput}
                      title={listening ? 'Stop voice input' : 'Speak command'}
                      className={`h-9 w-9 rounded-xl border flex items-center justify-center shrink-0 transition-colors ${
                        listening
                          ? 'bg-rose-600 border-rose-600 text-white animate-pulse'
                          : 'border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    </button>
                  )}
                  <button
                    type="submit"
                    disabled={submitting || !commandInput.trim()}
                    title="Send command"
                    className="h-9 w-9 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white flex items-center justify-center shrink-0"
                  >
                    {submitting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </form>
            </>
          )}

          {/* TAB 2: EXECUTION HISTORY & BACKGROUND TASKS */}
          {activeTab === 'tasks' && (
            <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-2 text-xs">
              {tasks.length === 0 ? (
                <div className="py-12 text-center text-slate-500 dark:text-slate-400">
                  No agent tasks executed yet. Send a command in Chat to get started.
                </div>
              ) : (
                tasks.map((task) => {
                  const badge = getStatusBadge(task.status);
                  const expanded = expandedTaskKey === task.taskKey;
                  return (
                    <div
                      key={task.taskKey}
                      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-950/50 overflow-hidden"
                    >
                      <button
                        type="button"
                        onClick={() => setExpandedTaskKey(expanded ? null : task.taskKey)}
                        className="w-full px-3 py-2.5 text-left flex items-start justify-between gap-2 hover:bg-slate-100/70 dark:hover:bg-slate-900/70"
                      >
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`text-[10px] font-semibold px-1.5 py-0.5 rounded border ${badge.className}`}
                            >
                              {badge.label}
                            </span>
                            <span className="text-[10px] uppercase font-semibold text-slate-400">
                              {task.mode}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              · {task.steps.length} step{task.steps.length === 1 ? '' : 's'}
                            </span>
                          </div>
                          <div className="font-medium text-slate-900 dark:text-white mt-1 line-clamp-2">
                            {task.command}
                          </div>
                        </div>
                        {expanded ? (
                          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                        ) : (
                          <ChevronRight className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                        )}
                      </button>

                      {expanded && (
                        <div className="px-3 pb-3 pt-1 border-t border-slate-200/80 dark:border-slate-800 space-y-2">
                          {task.steps.length > 0 && (
                            <div className="space-y-1.5">
                              {task.steps.map((s) => (
                                <div key={s.id} className="text-[11px] flex items-start gap-1.5">
                                  <span className="font-semibold text-slate-500 shrink-0">
                                    {s.stepOrder}.
                                  </span>
                                  <div className="min-w-0 flex-1">
                                    <div className="font-medium text-slate-800 dark:text-slate-200">
                                      {s.label}{' '}
                                      <span className="text-[10px] text-slate-400">({s.status})</span>
                                    </div>
                                    {s.output && typeof s.output.summary === 'string' && (
                                      <div className="text-[10px] text-slate-500 dark:text-slate-400">
                                        {s.output.summary}
                                      </div>
                                    )}
                                    {s.errorMessage && (
                                      <div className="text-[10px] text-rose-600 dark:text-rose-400">
                                        {s.errorMessage}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}

                          {task.errorMessage && (
                            <div className="rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 p-2 text-[11px] text-rose-700 dark:text-rose-300">
                              {task.errorMessage}
                            </div>
                          )}

                          <div className="flex flex-wrap items-center gap-1.5 pt-1">
                            {task.status === 'failed' && (
                              <button
                                type="button"
                                disabled={actionBusy}
                                onClick={() => void runTaskControl(task.taskKey, 'retry')}
                                className="h-7 px-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold inline-flex items-center gap-1"
                              >
                                <RotateCcw className="w-3 h-3" />
                                <span>Retry Failed Step</span>
                              </button>
                            )}
                            {task.status === 'paused' && (
                              <button
                                type="button"
                                disabled={actionBusy}
                                onClick={() => void runTaskControl(task.taskKey, 'resume')}
                                className="h-7 px-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-semibold inline-flex items-center gap-1"
                              >
                                <Play className="w-3 h-3" />
                                <span>Resume</span>
                              </button>
                            )}
                            {task.status === 'waiting_for_approval' && (
                              <button
                                type="button"
                                onClick={() => {
                                  setActiveTaskKey(task.taskKey);
                                  setActiveTab('chat');
                                }}
                                className="h-7 px-2.5 rounded-lg bg-amber-500 hover:bg-amber-600 text-white text-[11px] font-semibold"
                              >
                                Review Approval
                              </button>
                            )}
                            {task.workflowProjectId && (
                              <button
                                type="button"
                                onClick={() => onOpenWorkflowProject(task.workflowProjectId!)}
                                className="h-7 px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 text-[11px] font-semibold inline-flex items-center gap-1"
                              >
                                <span>Open Project #{task.workflowProjectId}</span>
                                <ArrowUpRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })
              )}
            </div>
          )}

          {/* TAB 3: PERMISSIONS & SAFETY RULES */}
          {activeTab === 'permissions' && (
            <div className="flex-1 overflow-y-auto px-3.5 py-3 space-y-3 text-xs">
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/50 p-2.5 text-[11px] text-slate-600 dark:text-slate-400 leading-relaxed">
                Control which write actions require explicit confirmation in <strong>Autopilot</strong> mode. Destructive actions always require confirmation.
              </div>

              {permissions ? (
                <div className="space-y-1.5">
                  {permissions.tools
                    .filter((t) => t.actionCategory !== 'read')
                    .map((tool) => {
                      const locked = tool.alwaysRequiresApproval;
                      const requiresConfirm =
                        locked || permissions.approvalRequiredActions.includes(tool.name);
                      return (
                        <div
                          key={tool.name}
                          className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950/60 px-2.5 py-2 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="font-semibold text-[11px] text-slate-900 dark:text-white flex items-center gap-1.5">
                              <span className="truncate">{tool.label}</span>
                              {locked && <Lock className="w-3 h-3 text-amber-500 shrink-0" />}
                            </div>
                            <div className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-1">
                              {tool.description}
                            </div>
                          </div>
                          <button
                            type="button"
                            disabled={locked || savingPerms}
                            onClick={() => void handleToggleToolApproval(tool.name)}
                            className={`px-2 py-1 rounded-md text-[10px] font-semibold shrink-0 border ${
                              requiresConfirm
                                ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800'
                                : 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800'
                            } ${locked ? 'opacity-80 cursor-not-allowed' : ''}`}
                          >
                            {locked ? 'Always Confirm' : requiresConfirm ? 'Ask First' : 'Auto-run'}
                          </button>
                        </div>
                      );
                    })}
                </div>
              ) : (
                <div className="py-8 text-center text-slate-500">Loading permissions…</div>
              )}
            </div>
          )}
        </aside>
      )}
    </>
  );
}
