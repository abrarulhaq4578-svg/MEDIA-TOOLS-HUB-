import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  Bell,
  Check,
  Copy,
  Dna,
  Download,
  FolderOpen,
  KeyRound,
  Loader2,
  Plus,
  Settings,
  Trash2,
  Youtube,
} from 'lucide-react';
import type {
  YtmAssetRecord,
  YtmChannelProfileWithDna,
  YtmWorkspaceRecord,
} from '../../shared/types.ts';
import { YTM_DEFAULT_PIPELINE_STATUSES } from '../../shared/ytmHelpers.ts';
import {
  copyToClipboard,
  triggerAuthenticatedDownload,
  ytmRequest,
  type AuthFetchFn,
  type YtmAuthStatusData,
} from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspace: YtmWorkspaceRecord;
  canManageWorkspace: boolean;
  canManageOAuth: boolean;
  canWriteWorkflow: boolean;
  authStatus: YtmAuthStatusData | null;
  activeChannelProfile?: YtmChannelProfileWithDna | null;
  channelProfiles?: YtmChannelProfileWithDna[];
  onSelectChannelProfile?: (id: number) => void;
  onOpenChannelDna?: () => void;
  onWorkspaceUpdated: () => Promise<void>;
  onConnectYouTube: () => void;
  onDisconnectYouTube: () => Promise<void>;
}

interface OthersResponse {
  assets: YtmAssetRecord[];
  notifications: Array<{
    id: number;
    title: string;
    message: string;
    linkSection: string;
    isRead: boolean;
    createdAt: string;
  }>;
  activity: Array<{
    id: number;
    actorEmail: string;
    action: string;
    resourceType: string;
    resourceId: string | null;
    createdAt: string;
  }>;
}

type OthersTab = 'assets' | 'exports' | 'notifications' | 'settings' | 'connections' | 'activity';

export function YtmOthersView({
  authFetch,
  workspace,
  canManageWorkspace,
  canManageOAuth,
  canWriteWorkflow,
  authStatus,
  activeChannelProfile,
  channelProfiles = [],
  onSelectChannelProfile,
  onOpenChannelDna,
  onWorkspaceUpdated,
  onConnectYouTube,
  onDisconnectYouTube,
}: Props) {
  const [tab, setTab] = useState<OthersTab>('assets');
  const [data, setData] = useState<OthersResponse>({ assets: [], notifications: [], activity: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Asset / prompt creation
  const [assetTitle, setAssetTitle] = useState('');
  const [assetType, setAssetType] = useState<'prompt' | 'template'>('prompt');
  const [promptText, setPromptText] = useState('');
  const [savingAsset, setSavingAsset] = useState(false);

  // Workspace settings
  const [wsName, setWsName] = useState(workspace.name);
  const [wsDesc, setWsDesc] = useState(workspace.description);
  const [wsGoal, setWsGoal] = useState(workspace.channelGoal);
  const [statusesInput, setStatusesInput] = useState(
    (workspace.customStatuses?.length ? workspace.customStatuses : YTM_DEFAULT_PIPELINE_STATUSES).join(', ')
  );
  const [savingSettings, setSavingSettings] = useState(false);
  const [downloading, setDownloading] = useState<'csv' | 'json' | null>(null);

  useEffect(() => {
    setWsName(workspace.name);
    setWsDesc(workspace.description);
    setWsGoal(workspace.channelGoal);
    setStatusesInput(
      (workspace.customStatuses?.length ? workspace.customStatuses : YTM_DEFAULT_PIPELINE_STATUSES).join(', ')
    );
  }, [workspace]);

  const loadOthers = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await ytmRequest<OthersResponse>(authFetch, '/others', {
        workspaceKey: workspace.workspaceKey,
      });
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load workspace tools.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadOthers();
  }, [workspace.workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSaveAsset = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assetTitle.trim() || !canWriteWorkflow) return;
    setSavingAsset(true);
    setError(null);
    try {
      await ytmRequest(authFetch, '/others/assets', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: {
          title: assetTitle.trim(),
          assetType,
          promptText,
          tags: [],
        },
      });
      setAssetTitle('');
      setPromptText('');
      await loadOthers();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save prompt/template.');
    } finally {
      setSavingAsset(false);
    }
  };

  const handleDeleteAsset = async (id: number) => {
    if (!canWriteWorkflow) return;
    await ytmRequest(authFetch, `/others/assets/${id}`, {
      workspaceKey: workspace.workspaceKey,
      method: 'DELETE',
    });
    await loadOthers();
  };

  const handleMarkAllRead = async () => {
    await ytmRequest(authFetch, '/others/notifications/read-all', {
      workspaceKey: workspace.workspaceKey,
      method: 'POST',
      body: {},
    });
    await loadOthers();
    await onWorkspaceUpdated();
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canManageWorkspace) return;
    setSavingSettings(true);
    setError(null);
    setNotice(null);
    try {
      const customStatuses = statusesInput
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      await ytmRequest(authFetch, `/workspaces/${encodeURIComponent(workspace.workspaceKey)}`, {
        workspaceKey: workspace.workspaceKey,
        method: 'PATCH',
        body: {
          name: wsName.trim(),
          description: wsDesc.trim(),
          channelGoal: wsGoal.trim(),
          customStatuses: customStatuses.length > 0 ? customStatuses : YTM_DEFAULT_PIPELINE_STATUSES,
        },
      });
      setNotice('Workspace settings and pipeline statuses saved.');
      await onWorkspaceUpdated();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save workspace settings.');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleExport = async (format: 'csv' | 'json') => {
    setDownloading(format);
    setError(null);
    try {
      const url = `/api/v1/ytm/others/export?format=${format}&workspaceKey=${encodeURIComponent(
        workspace.workspaceKey
      )}`;
      await triggerAuthenticatedDownload(
        authFetch,
        url,
        `ytm-${workspace.workspaceKey}-export.${format}`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Export download failed.');
    } finally {
      setDownloading(null);
    }
  };

  const handleCopy = async (id: string, val: string) => {
    if (await copyToClipboard(val)) {
      setCopiedId(id);
      setTimeout(() => setCopiedId((prev) => (prev === id ? null : prev)), 1500);
    }
  };

  const unreadCount = data.notifications.filter((n) => !n.isRead).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Others · Library, Exports, Connections &amp; Settings
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Manage saved prompts, uploaded assets, CSV/JSON backups, pipeline statuses, OAuth setup, and audit history.
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 text-xs">
        {[
          { id: 'assets', label: 'Assets & Prompts', icon: FolderOpen },
          { id: 'exports', label: 'Export Centre', icon: Download },
          { id: 'notifications', label: `Notifications (${unreadCount})`, icon: Bell },
          { id: 'settings', label: 'Workspace Settings', icon: Settings },
          { id: 'connections', label: 'Connected Accounts', icon: KeyRound },
          { id: 'activity', label: 'Activity History', icon: Activity },
        ].map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.id}
              type="button"
              onClick={() => setTab(t.id as OthersTab)}
              className={`h-9 px-3.5 rounded-lg font-semibold inline-flex items-center gap-1.5 ${
                tab === t.id
                  ? 'bg-blue-600 text-white'
                  : 'border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {error && (
        <div className="p-3.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* TAB 1: ASSETS & PROMPTS */}
      {tab === 'assets' && (
        <div className="space-y-4">
          {canWriteWorkflow && (
            <form
              onSubmit={handleSaveAsset}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-3 text-xs"
            >
              <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                Save Reusable Prompt or Content Template
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <input
                  type="text"
                  required
                  value={assetTitle}
                  onChange={(e) => setAssetTitle(e.target.value)}
                  placeholder="Title (e.g. Documentary Hook Prompt)"
                  className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
                <select
                  value={assetType}
                  onChange={(e) => setAssetType(e.target.value as 'prompt' | 'template')}
                  className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                >
                  <option value="prompt">AI Image / Script Prompt</option>
                  <option value="template">Reusable Checklist / Template</option>
                </select>
                <button
                  type="submit"
                  disabled={savingAsset}
                  className="h-10 px-4 rounded-lg bg-blue-600 text-white font-semibold inline-flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  <span>{savingAsset ? 'Saving…' : 'Save to Library'}</span>
                </button>
              </div>
              <textarea
                rows={2}
                value={promptText}
                onChange={(e) => setPromptText(e.target.value)}
                placeholder="Prompt or template text…"
                className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
              />
            </form>
          )}

          {loading ? (
            <div className="p-8 text-center text-xs text-slate-500">Loading library…</div>
          ) : data.assets.length === 0 ? (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-xs text-slate-500">
              No saved assets or prompts yet. Thumbnail uploads from Workflow Stage 4 and saved prompts appear here.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {data.assets.map((asset) => (
                <div
                  key={asset.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2.5 text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                        {asset.title}
                      </div>
                      <div className="font-mono text-[11px] uppercase text-slate-500">
                        {asset.assetType} · {asset.createdAt.slice(0, 10)}
                      </div>
                    </div>
                    {canWriteWorkflow && (
                      <button
                        type="button"
                        onClick={() => void handleDeleteAsset(asset.id)}
                        className="p-1 text-slate-400 hover:text-red-600"
                        aria-label="Delete asset"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  {asset.assetType === 'thumbnail' && asset.dataUrlOrPath && (
                    <img
                      src={asset.dataUrlOrPath}
                      alt={asset.title}
                      className="w-full aspect-video object-cover rounded-lg border border-slate-200 dark:border-slate-700"
                    />
                  )}
                  {asset.promptText && (
                    <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-[11px] text-slate-600 dark:text-slate-300 line-clamp-4">
                      {asset.promptText}
                    </div>
                  )}
                  {asset.promptText && (
                    <button
                      type="button"
                      onClick={() => void handleCopy(`asset-${asset.id}`, asset.promptText)}
                      className="h-7 px-2.5 rounded border border-slate-200 dark:border-slate-700 inline-flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copiedId === `asset-${asset.id}` ? 'Copied' : 'Copy Text'}</span>
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: EXPORT CENTRE */}
      {tab === 'exports' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4">
          <div className="space-y-1">
            <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Authenticated Workspace Export Centre
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Download your planner videos, tasks, workflows, brand deals, and revenue ledger securely using your authenticated workspace session.
            </p>
          </div>
          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              disabled={downloading !== null}
              onClick={() => void handleExport('csv')}
              className="h-10 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-2"
            >
              {downloading === 'csv' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>Export CSV Summary</span>
            </button>
            <button
              type="button"
              disabled={downloading !== null}
              onClick={() => void handleExport('json')}
              className="h-10 px-4 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold inline-flex items-center gap-2"
            >
              {downloading === 'json' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              <span>Export Full JSON Backup</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: NOTIFICATIONS */}
      {tab === 'notifications' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
              Notifications ({data.notifications.length})
            </h3>
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={() => void handleMarkAllRead()}
                className="text-xs font-semibold text-blue-600 dark:text-blue-400"
              >
                Mark all read
              </button>
            )}
          </div>
          {data.notifications.length === 0 ? (
            <div className="text-xs text-slate-500 py-4">No notifications right now.</div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {data.notifications.map((n) => (
                <div key={n.id} className="py-3 flex items-start justify-between gap-2">
                  <div>
                    <div className={`font-semibold ${n.isRead ? 'text-slate-700 dark:text-slate-300' : 'text-blue-600 dark:text-blue-400'}`}>
                      {n.title}
                    </div>
                    <div className="text-slate-500 mt-0.5">{n.message}</div>
                  </div>
                  <span className="font-mono text-[11px] text-slate-400 shrink-0">
                    {n.createdAt.slice(0, 10)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: CREATOR WORKSPACE DETAILS & SETTINGS */}
      {tab === 'settings' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-6 text-xs">
          <form onSubmit={handleSaveSettings} className="space-y-4">
            <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Creator Workspace Details &amp; Settings
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Workspace Name
                </label>
                <input
                  type="text"
                  disabled={!canManageWorkspace}
                  value={wsName}
                  onChange={(e) => setWsName(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Channel Goal (Used by AI Daily Planner)
                </label>
                <input
                  type="text"
                  disabled={!canManageWorkspace}
                  value={wsGoal}
                  onChange={(e) => setWsGoal(e.target.value)}
                  placeholder="e.g. Publish 2 deep-dive tutorials weekly to reach 100k subscribers"
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                  Description
                </label>
                <input
                  type="text"
                  disabled={!canManageWorkspace}
                  value={wsDesc}
                  onChange={(e) => setWsDesc(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
              </div>
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-600 dark:text-slate-300">
                    Custom Content Pipeline Statuses (comma-separated)
                  </label>
                  {canManageWorkspace && (
                    <button
                      type="button"
                      onClick={() => setStatusesInput(YTM_DEFAULT_PIPELINE_STATUSES.join(', '))}
                      className="text-blue-600 dark:text-blue-400 font-semibold"
                    >
                      Reset Defaults
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  disabled={!canManageWorkspace}
                  value={statusesInput}
                  onChange={(e) => setStatusesInput(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                />
              </div>
            </div>
            {canManageWorkspace && (
              <button
                type="submit"
                disabled={savingSettings}
                className="h-10 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold"
              >
                {savingSettings ? 'Saving…' : 'Save Workspace Details'}
              </button>
            )}
          </form>

          {/* Channel DNA Inside Creator Workspace Details */}
          {onOpenChannelDna && (
            <div className="pt-5 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
                    <Dna className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                      Channel DNA
                    </h4>
                    <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                      {activeChannelProfile
                        ? `Active profile: ${activeChannelProfile.channelName}${activeChannelProfile.niche ? ` · ${activeChannelProfile.niche}` : ''} · ${activeChannelProfile.dna.preferredLanguage || 'English'}. Automatically guides Content Planner, Workflow, Community Posts, and Performance Coach.`
                        : 'Configure your niche, target audience, audience problems, content pillars, formats, brand voice, and publishing rules.'}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onOpenChannelDna}
                  className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold shrink-0"
                >
                  {activeChannelProfile ? 'Edit Channel DNA' : 'Configure Channel DNA'}
                </button>
              </div>

              {channelProfiles.length > 0 && onSelectChannelProfile && (
                <div className="max-w-md">
                  <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                    Active Channel DNA Profile
                  </label>
                  <select
                    aria-label="Active Channel DNA profile"
                    value={activeChannelProfile?.id ?? ''}
                    onChange={(e) => onSelectChannelProfile(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-semibold text-slate-900 dark:text-white"
                  >
                    {channelProfiles.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.channelName}
                        {p.niche ? ` · ${p.niche}` : ''}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: CONNECTED ACCOUNTS & OAUTH SETUP */}
      {tab === 'connections' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              {authStatus?.connectedChannel?.thumbnailUrl ? (
                <img
                  src={authStatus.connectedChannel.thumbnailUrl}
                  alt={authStatus.connectedChannel.channelTitle}
                  referrerPolicy="no-referrer"
                  className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 object-cover"
                />
              ) : (
                <div className="w-10 h-10 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-center justify-center text-red-600 dark:text-red-400">
                  <Youtube className="w-5 h-5" />
                </div>
              )}
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                    YouTube Channel OAuth 2.0 Connection
                  </h3>
                  <span
                    className={`px-2 py-0.5 rounded-md font-semibold text-[11px] ${
                      authStatus?.connectionState === 'connected'
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300'
                        : authStatus?.connectionState === 'expired' ||
                            authStatus?.connectionState === 'permission_required'
                          ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/50 dark:text-amber-300'
                          : authStatus?.connectionState === 'error'
                            ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/50 dark:text-rose-300'
                            : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    }`}
                  >
                    {authStatus?.statusLabel || 'Not Connected'}
                  </span>
                </div>
                <p className="text-slate-500 mt-0.5">
                  {authStatus?.connectedChannel
                    ? `${authStatus.connectedChannel.channelTitle} (${authStatus.connectedChannel.channelId}) · ${authStatus.statusMessage}`
                    : authStatus?.statusMessage || 'No channel connected to this workspace.'}
                </p>
              </div>
            </div>

            {canManageOAuth && (
              <div className="flex flex-wrap items-center gap-2">
                {authStatus?.connectedChannel && authStatus.connectionState !== 'not_connected' && (
                  <button
                    type="button"
                    onClick={() => void onDisconnectYouTube()}
                    className="h-9 px-3.5 rounded-lg border border-red-300 dark:border-red-900 text-red-600 font-semibold"
                  >
                    Disconnect Channel
                  </button>
                )}
                {authStatus?.connectionState !== 'connected' && (
                  <button
                    type="button"
                    onClick={onConnectYouTube}
                    className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                  >
                    {authStatus?.connectionState === 'expired' ||
                    authStatus?.connectionState === 'permission_required' ||
                    authStatus?.connectionState === 'error'
                      ? 'Reconnect YouTube Channel'
                      : 'Connect YouTube Channel'}
                  </button>
                )}
              </div>
            )}
          </div>

          {authStatus?.missingScopes?.length ? (
            <div className="p-3.5 rounded-xl border border-amber-200 dark:border-amber-900 bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-200 space-y-1">
              <div className="font-semibold">Missing Required YouTube OAuth Scopes:</div>
              <div className="font-mono text-[11px] break-all">{authStatus.missingScopes.join(', ')}</div>
            </div>
          ) : null}

          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2">
            <div className="font-semibold text-slate-900 dark:text-white">
              Server Google OAuth Environment Status:{' '}
              {authStatus?.oauthConfigured ? (
                <span className="text-emerald-600 dark:text-emerald-400">Configured</span>
              ) : (
                <span className="text-amber-600 dark:text-amber-400">Configuration Incomplete</span>
              )}
            </div>
            {!authStatus?.oauthConfigured && authStatus?.configValidation?.details ? (
              <div className="text-slate-600 dark:text-slate-300">
                {authStatus.configValidation.details}
              </div>
            ) : null}
            {!authStatus?.oauthConfigured && authStatus?.missingVars?.length ? (
              <div className="text-slate-600 dark:text-slate-300">
                Missing server environment variables:{' '}
                <span className="font-mono font-semibold">{authStatus.missingVars.join(', ')}</span>
              </div>
            ) : null}
            {authStatus?.redirectUri && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-slate-500">Authorized Redirect URI:</span>
                <code className="px-2 py-1 rounded bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 font-mono text-[11px]">
                  {authStatus.redirectUri}
                </code>
                <button
                  type="button"
                  onClick={() => void handleCopy('redir', authStatus.redirectUri)}
                  className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 inline-flex items-center gap-1"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copiedId === 'redir' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            )}
            {authStatus?.configValidation?.diagnostics && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px] font-mono text-slate-600 dark:text-slate-400 space-y-0.5">
                <div>
                  Source: {authStatus.configValidation.diagnostics.source} · dotenv:{' '}
                  {String(authStatus.configValidation.diagnostics.dotenvFilePresent)} · Frontend Override:{' '}
                  {String(authStatus.configValidation.diagnostics.frontendEnvOverridePresent)}
                </div>
                <div>
                  GOOGLE_CLIENT_ID: {authStatus.configValidation.diagnostics.clientIdPresent ? 'Present' : 'Unconfigured'} ·{' '}
                  rawLen={authStatus.configValidation.diagnostics.rawClientIdLength ?? 0} ·{' '}
                  endsWithApps={String(authStatus.configValidation.diagnostics.clientIdEndsWithAppsDomain)} ·{' '}
                  placeholder={String(authStatus.configValidation.diagnostics.clientIdIsPlaceholderLiteral)} ·{' '}
                  status={authStatus.configValidation.diagnostics.clientIdFormatValid ? 'Valid Web Client ID' : authStatus.configValidation.diagnostics.clientIdIssueCode}
                </div>
                <div>
                  GOOGLE_CLIENT_SECRET: {authStatus.configValidation.diagnostics.clientSecretPresent ? 'Present' : 'Unconfigured'} ·{' '}
                  rawLen={authStatus.configValidation.diagnostics.rawClientSecretLength ?? 0} ·{' '}
                  placeholder={String(authStatus.configValidation.diagnostics.clientSecretIsPlaceholderLiteral)} ·{' '}
                  status={authStatus.configValidation.diagnostics.clientSecretFormatValid ? 'Valid' : authStatus.configValidation.diagnostics.clientSecretIssueCode}
                </div>
                <div>
                  OAuth2Client Ready: {String(Boolean(authStatus.configValidation.oauthClientInitialized))} ·{' '}
                  Auth URL Ready: {String(Boolean(authStatus.configValidation.authorizationUrlReady))} ·{' '}
                  Redirect Source: {authStatus.configValidation.diagnostics.redirectUriSource || 'request_derived'}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 6: ACTIVITY HISTORY */}
      {tab === 'activity' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Workspace Activity Audit Log ({data.activity.length})
          </h3>
          {data.activity.length === 0 ? (
            <div className="text-xs text-slate-500 py-4">No activity recorded yet.</div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              {data.activity.map((a) => (
                <div key={a.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                  <div>
                    <span className="font-mono font-semibold text-slate-900 dark:text-white">
                      {a.action}
                    </span>{' '}
                    <span className="text-slate-500">
                      on {a.resourceType} {a.resourceId ? `#${a.resourceId}` : ''} by {a.actorEmail || 'system'}
                    </span>
                  </div>
                  <span className="font-mono text-[11px] text-slate-400">
                    {a.createdAt.slice(0, 16).replace('T', ' ')}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
