import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  BookOpen,
  CalendarPlus,
  Check,
  CheckCircle2,
  Compass,
  GraduationCap,
  Lightbulb,
  ListChecks,
  Loader2,
  RefreshCw,
  TrendingUp,
  Workflow,
  Youtube,
} from 'lucide-react';
import type {
  YtmCoachActionRecord,
  YtmCoachSnapshotRecord,
  YtmConnectedChannelRecord,
} from '../../shared/types.ts';
import { formatCompactNumber, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  connectedChannel: YtmConnectedChannelRecord | null;
  activeChannelProfileId: number | null;
  onConnectYouTube: () => void;
  onOpenPlanner: () => void;
  onOpenWorkflow: (workflowProjectId: number) => void;
}

type CoachTab =
  | 'diagnosis'
  | 'improve'
  | 'opportunities'
  | 'actions'
  | 'learning'
  | 'progress';

interface CoachLoadResponse {
  connectedChannel: YtmConnectedChannelRecord | null;
  latestSnapshot: YtmCoachSnapshotRecord | null;
  snapshotHistory: YtmCoachSnapshotRecord[];
  actions: YtmCoachActionRecord[];
}

function formatDuration(sec: number | null): string {
  if (sec === null || !Number.isFinite(sec)) return 'N/A';
  const m = Math.floor(sec / 60);
  const s = Math.round(sec % 60);
  return `${m}m ${String(s).padStart(2, '0')}s`;
}

function formatDelta(current: number | null, previous: number | null): string | null {
  if (current === null || previous === null || previous === 0) return null;
  const pct = ((current - previous) / Math.abs(previous)) * 100;
  return `${pct >= 0 ? '+' : ''}${pct.toFixed(1)}% vs prev`;
}

export function YtmPerformanceCoachView({
  authFetch,
  workspaceKey,
  canWrite,
  connectedChannel,
  activeChannelProfileId,
  onConnectYouTube,
  onOpenPlanner,
  onOpenWorkflow,
}: Props) {
  const [tab, setTab] = useState<CoachTab>('diagnosis');
  const [days, setDays] = useState<7 | 28 | 90>(28);
  const [loading, setLoading] = useState(true);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [snapshot, setSnapshot] = useState<YtmCoachSnapshotRecord | null>(null);
  const [history, setHistory] = useState<YtmCoachSnapshotRecord[]>([]);
  const [actions, setActions] = useState<YtmCoachActionRecord[]>([]);
  const [busyActionId, setBusyActionId] = useState<number | null>(null);
  const [outcomeDrafts, setOutcomeDrafts] = useState<Record<number, string>>({});

  const loadCoach = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await ytmRequest<CoachLoadResponse>(authFetch, '/coach', {
        workspaceKey,
      });
      setSnapshot(res.latestSnapshot || null);
      setHistory(res.snapshotHistory || []);
      setActions(res.actions || []);
      const notesMap: Record<number, string> = {};
      for (const a of res.actions || []) {
        notesMap[a.id] = a.outcomeNotes || '';
      }
      setOutcomeDrafts(notesMap);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load Creator Performance Coach.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadCoach();
  }, [workspaceKey, connectedChannel?.channelId]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleRunAnalysis = async () => {
    if (!connectedChannel) return;
    setAnalyzing(true);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{
        snapshot: YtmCoachSnapshotRecord;
        newActions: YtmCoachActionRecord[];
      }>(authFetch, '/coach/analyze', {
        workspaceKey,
        method: 'POST',
        body: { days, channelProfileId: activeChannelProfileId },
      });
      setSnapshot(res.snapshot);
      setHistory((prev) => [res.snapshot, ...prev]);
      setActions((prev) => [...res.newActions, ...prev]);
      setNotice(
        `Coach analysis completed using authorized YouTube Analytics (${res.snapshot.periodStart} to ${res.snapshot.periodEnd}).`
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Creator Performance Coach analysis failed.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleUpdateAction = async (
    actionId: number,
    patch: { status?: YtmCoachActionRecord['status']; outcomeNotes?: string }
  ) => {
    if (!canWrite) return;
    setBusyActionId(actionId);
    setError(null);
    try {
      const res = await ytmRequest<{ action: YtmCoachActionRecord }>(
        authFetch,
        `/coach/actions/${actionId}`,
        {
          workspaceKey,
          method: 'PATCH',
          body: patch,
        }
      );
      setActions((prev) => prev.map((a) => (a.id === actionId ? res.action : a)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update action.');
    } finally {
      setBusyActionId(null);
    }
  };

  const handleSendToPlanner = async (actionId: number) => {
    if (!canWrite) return;
    setBusyActionId(actionId);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{ action: YtmCoachActionRecord; plannerTaskId: number }>(
        authFetch,
        `/coach/actions/${actionId}/send-to-planner`,
        { workspaceKey, method: 'POST', body: {} }
      );
      setActions((prev) => prev.map((a) => (a.id === actionId ? res.action : a)));
      setNotice('Approved Coach action added to Content Planner.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to send action to Content Planner.');
    } finally {
      setBusyActionId(null);
    }
  };

  const handleSendToWorkflow = async (actionId: number) => {
    if (!canWrite) return;
    setBusyActionId(actionId);
    setError(null);
    try {
      const res = await ytmRequest<{ action: YtmCoachActionRecord; workflowProjectId: number }>(
        authFetch,
        `/coach/actions/${actionId}/send-to-workflow`,
        { workspaceKey, method: 'POST', body: {} }
      );
      setActions((prev) => prev.map((a) => (a.id === actionId ? res.action : a)));
      onOpenWorkflow(res.workflowProjectId);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to launch Workflow from Coach action.');
    } finally {
      setBusyActionId(null);
    }
  };

  // Honest authorization gate when no YouTube channel is connected
  if (!connectedChannel) {
    return (
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 max-w-2xl mx-auto text-center space-y-4">
        <div className="w-12 h-12 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 mx-auto">
          <GraduationCap className="w-6 h-6" />
        </div>
        <div className="space-y-1.5">
          <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">
            Creator Performance Coach Requires YouTube Authorization
          </h2>
          <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
            Creator Performance Coach interprets your real YouTube Analytics API v2 and YouTube Data API v3 data (views, watch time, average view duration, net subscribers, likes, comments, and video performance) to teach you what happened, why it matters, and what to improve next.
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Because Coach never fabricates metrics or guesses performance without authorized data, connect your YouTube channel first.
          </p>
        </div>
        <button
          type="button"
          onClick={onConnectYouTube}
          className="h-10 px-5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-2"
        >
          <Youtube className="w-4 h-4" />
          <span>Connect YouTube Channel</span>
        </button>
      </div>
    );
  }

  const m = snapshot?.metricsSummary;

  return (
    <div className="space-y-5">
      {/* Header & Controls */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="font-display text-lg font-bold text-slate-950 dark:text-white">
                Creator Performance Coach
              </h2>
            </div>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              Evidence-based coaching for <strong>{connectedChannel.channelTitle}</strong> using authorized YouTube Analytics &amp; Data APIs. Explains what happened, teaches you how to improve, and hands off approved actions to Content Planner or Workflow.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs shrink-0">
            <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-950 font-mono tabular-nums">
              {([7, 28, 90] as const).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDays(d)}
                  className={`h-8 px-2.5 rounded-md font-semibold ${
                    days === d
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-600 dark:text-slate-300'
                  }`}
                >
                  {d}d
                </button>
              ))}
            </div>
            <button
              type="button"
              disabled={analyzing}
              onClick={() => void handleRunAnalysis()}
              className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold inline-flex items-center gap-1.5"
            >
              {analyzing ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <RefreshCw className="w-3.5 h-3.5" />
              )}
              <span>{analyzing ? 'Analyzing Channel...' : 'Run Performance Coach'}</span>
            </button>
          </div>
        </div>

        {/* 6 Required Internal Tabs */}
        <div className="flex flex-wrap gap-2 border-t border-slate-100 dark:border-slate-800 pt-3 text-xs">
          {[
            { id: 'diagnosis', label: '1. Performance Diagnosis', icon: Activity },
            { id: 'improve', label: '2. What to Improve', icon: Compass },
            { id: 'opportunities', label: '3. Growth Opportunities', icon: Lightbulb },
            { id: 'actions', label: `4. Recommended Actions (${actions.filter((a) => a.status !== 'dismissed').length})`, icon: ListChecks },
            { id: 'learning', label: '5. Learning Center', icon: BookOpen },
            { id: 'progress', label: `6. Progress Tracking (${history.length})`, icon: TrendingUp },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id as CoachTab)}
                className={`h-9 px-3 rounded-lg font-semibold inline-flex items-center gap-1.5 ${
                  tab === t.id
                    ? 'bg-blue-600 text-white'
                    : 'border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/20 p-3.5 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 p-3.5 text-xs text-emerald-700 dark:text-emerald-300 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{notice}</span>
          </div>
          <div className="flex items-center gap-3">
            <button type="button" onClick={onOpenPlanner} className="font-semibold underline">
              Open Planner
            </button>
            <button type="button" onClick={() => setNotice(null)} className="font-semibold underline">
              Dismiss
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="py-12 flex items-center justify-center gap-2 text-xs text-slate-500">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
          <span>Loading Creator Performance Coach...</span>
        </div>
      ) : !snapshot ? (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center space-y-3 text-xs">
          <p className="text-slate-600 dark:text-slate-300 max-w-lg mx-auto">
            No coaching snapshot saved yet for <strong>{connectedChannel.channelTitle}</strong>. Click <strong>Run Performance Coach</strong> above to pull your latest YouTube Analytics &amp; Data API metrics and generate your personalized diagnosis and action plan.
          </p>
        </div>
      ) : (
        <>
          {/* Honest Metric Availability Disclosure */}
          {m?.unavailableMetricsDisclosure && (
            <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-4 py-2.5 text-[11px] text-slate-600 dark:text-slate-400">
              <strong>Data Scope Transparency ({snapshot.periodStart} → {snapshot.periodEnd}):</strong>{' '}
              {m.unavailableMetricsDisclosure}
            </div>
          )}

          {/* TAB 1: PERFORMANCE DIAGNOSIS */}
          {tab === 'diagnosis' && (
            <div className="space-y-5 text-xs">
              {/* Headline + KPI Strip */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="font-mono text-[11px] uppercase tracking-wider text-blue-600 dark:text-blue-400 font-semibold">
                      Channel Health · {snapshot.diagnosis.overallStatus.replace(/_/g, ' ')}
                    </div>
                    <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                      {snapshot.diagnosis.headline}
                    </h3>
                    <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                      {snapshot.diagnosis.periodComparisonSummary}
                    </p>
                  </div>
                </div>

                {m && (
                  <div className="grid grid-cols-2 md:grid-cols-5 gap-3 pt-2 border-t border-slate-100 dark:border-slate-800">
                    {[
                      {
                        label: 'Views',
                        val: m.views !== null ? formatCompactNumber(m.views) : 'N/A',
                        delta: formatDelta(m.views, m.previousViews),
                      },
                      {
                        label: 'Watch Time (min)',
                        val:
                          m.watchTimeMinutes !== null
                            ? formatCompactNumber(m.watchTimeMinutes)
                            : 'N/A',
                        delta: formatDelta(m.watchTimeMinutes, m.previousWatchTimeMinutes),
                      },
                      {
                        label: 'Avg View Duration',
                        val: formatDuration(m.avgViewDurationSec),
                        delta: formatDelta(m.avgViewDurationSec, m.previousAvgViewDurationSec),
                      },
                      {
                        label: 'Net Subscribers',
                        val:
                          m.subscribersNet !== null
                            ? `${m.subscribersNet >= 0 ? '+' : ''}${formatCompactNumber(m.subscribersNet)}`
                            : 'N/A',
                        delta: formatDelta(m.subscribersNet, m.previousSubscribersNet),
                      },
                      {
                        label: 'Uploads in Period',
                        val: String(m.uploadsInPeriod),
                        delta: 'CTR / Impressions: Not in API',
                      },
                    ].map((kpi) => (
                      <div
                        key={kpi.label}
                        className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800"
                      >
                        <div className="text-[11px] text-slate-500">{kpi.label}</div>
                        <div className="font-mono tabular-nums text-base font-bold text-slate-950 dark:text-white mt-0.5">
                          {kpi.val}
                        </div>
                        {kpi.delta && (
                          <div className="font-mono tabular-nums text-[11px] text-slate-500 mt-0.5">
                            {kpi.delta}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2.5">
                  <h4 className="font-display text-sm font-bold text-emerald-700 dark:text-emerald-400">
                    What Is Working (Verified Evidence)
                  </h4>
                  <ul className="space-y-2 text-slate-700 dark:text-slate-300">
                    {snapshot.diagnosis.whatsWorking.map((item, idx) => (
                      <li key={idx}>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          • {item.point}
                        </span>
                        {item.evidence && (
                          <div className="pl-3 text-slate-500 dark:text-slate-400">
                            {item.evidence}
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2.5">
                  <h4 className="font-display text-sm font-bold text-amber-700 dark:text-amber-400">
                    What Needs Attention / Not Improving
                  </h4>
                  <ul className="space-y-2 text-slate-700 dark:text-slate-300">
                    {snapshot.diagnosis.notImproving.map((item, idx) => (
                      <li key={idx}>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          • {item.point}
                        </span>
                        {item.evidence && (
                          <div className="pl-3 text-slate-500 dark:text-slate-400">
                            {item.evidence}
                          </div>
                        )}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2">
                  <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    Strongest Topics
                  </h4>
                  <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
                    {snapshot.diagnosis.strongestTopics.map((t, i) => (
                      <li key={i}>• {t}</li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2">
                  <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    Underperforming Videos &amp; Declining Topics
                  </h4>
                  <ul className="space-y-1.5 text-slate-600 dark:text-slate-300">
                    {snapshot.diagnosis.underperformingVideos.map((v, i) => (
                      <li key={`uv_${i}`}>
                        <span className="font-semibold text-slate-900 dark:text-white">
                          • {v.videoTitle}
                        </span>
                        <div className="pl-3 text-slate-500 dark:text-slate-400">
                          {v.observation} ({v.likelyReason})
                        </div>
                      </li>
                    ))}
                    {snapshot.diagnosis.decliningTopics.map((t, i) => (
                      <li key={`dt_${i}`}>• Declining topic: {t}</li>
                    ))}
                  </ul>
                </div>
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2">
                  <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    Publishing Habit Assessment
                  </h4>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {snapshot.diagnosis.publishingHabitAssessment}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: WHAT TO IMPROVE (8-PART BEGINNER-FRIENDLY TEACHING FRAMEWORK) */}
          {tab === 'improve' && (
            <div className="space-y-4 text-xs">
              {snapshot.improvements.map((imp) => (
                <div
                  key={imp.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                      {imp.area}
                    </h4>
                    <span className="font-mono text-[11px] uppercase text-slate-500">
                      8-Step Coaching Guide
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {[
                      { label: '1. What Happened', text: imp.whatHappened },
                      { label: '2. Why It Matters', text: imp.whyItMatters },
                      { label: '3. Evidence From Your Channel', text: imp.evidenceFromChannel },
                      { label: '4. Possible Cause', text: imp.possibleCause },
                      { label: '5. What to Improve', text: imp.whatToImprove },
                      { label: '6. How to Improve (Step-by-Step)', text: imp.howToImprove },
                      { label: '7. Next Concrete Action', text: imp.nextAction },
                      { label: '8. How to Measure Progress', text: imp.howToMeasure },
                    ].map((block) => (
                      <div
                        key={block.label}
                        className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1"
                      >
                        <div className="font-semibold text-slate-900 dark:text-white">
                          {block.label}
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                          {block.text}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 3: GROWTH OPPORTUNITIES (OWN CHANNEL vs EXTERNAL COMPETITOR DATA SEPARATED) */}
          {tab === 'opportunities' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              {snapshot.opportunities.map((opp) => (
                <div
                  key={opp.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-2.5"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="font-mono text-[11px] uppercase text-blue-600 dark:text-blue-400 font-semibold">
                      {opp.category.replace(/_/g, ' ')}
                    </span>
                    <span className="font-mono text-[11px] text-slate-500">
                      Source:{' '}
                      {opp.evidenceSource === 'own_channel_data'
                        ? 'Own Channel Data'
                        : opp.evidenceSource === 'external_competitor_intelligence'
                          ? 'External Competitor Intelligence'
                          : 'Combined (Own + External)'}
                    </span>
                  </div>
                  <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    {opp.title}
                  </h4>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    <strong>Opportunity Context:</strong> {opp.explanation}
                  </p>
                  <p className="text-slate-500 dark:text-slate-400">
                    <strong>Expected Impact:</strong> {opp.expectedImpact}
                  </p>
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-slate-800 dark:text-slate-200">
                    <strong>Suggested Video Angle:</strong> {opp.suggestedVideoAngle}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: RECOMMENDED ACTIONS (DAILY / WEEKLY / MONTHLY / EXPERIMENTS WITH APPROVAL HANDOFF) */}
          {tab === 'actions' && (
            <div className="space-y-4 text-xs">
              {(['daily', 'weekly', 'monthly', 'experiment'] as const).map((horizon) => {
                const list = actions.filter(
                  (a) => a.horizon === horizon && a.status !== 'dismissed'
                );
                if (list.length === 0) return null;
                const heading =
                  horizon === 'daily'
                    ? 'Daily Priorities'
                    : horizon === 'weekly'
                      ? 'Weekly Action Plan'
                      : horizon === 'monthly'
                        ? 'Monthly Strategic Focus'
                        : 'Guided Growth Experiments';
                return (
                  <div
                    key={horizon}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
                  >
                    <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 font-display font-bold text-slate-900 dark:text-white">
                      {heading} ({list.length})
                    </div>
                    <div className="divide-y divide-slate-100 dark:divide-slate-800">
                      {list.map((act) => (
                        <div key={act.id} className="p-4 space-y-2.5">
                          <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-3">
                            <div className="space-y-1 flex-1">
                              <div className="font-semibold text-sm text-slate-950 dark:text-white">
                                {act.title}
                              </div>
                              <div className="font-mono text-[11px] text-slate-500">
                                Priority: {act.priority} · Status: {act.status.replace(/_/g, ' ')} · Measure: {act.metricToMeasure}
                              </div>
                              <p className="text-slate-600 dark:text-slate-300">
                                <strong>Why:</strong> {act.rationale}
                              </p>
                              <p className="text-slate-600 dark:text-slate-300">
                                <strong>Steps:</strong> {act.actionSteps}
                              </p>
                            </div>

                            {canWrite && (
                              <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                                {act.status === 'pending' && (
                                  <button
                                    type="button"
                                    disabled={busyActionId === act.id}
                                    onClick={() =>
                                      void handleUpdateAction(act.id, { status: 'approved' })
                                    }
                                    className="h-8 px-2.5 rounded-lg border border-emerald-600 text-emerald-700 dark:text-emerald-400 font-semibold inline-flex items-center gap-1"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                    <span>Approve</span>
                                  </button>
                                )}
                                <button
                                  type="button"
                                  disabled={busyActionId === act.id || Boolean(act.linkedPlannerTaskId)}
                                  onClick={() => void handleSendToPlanner(act.id)}
                                  className="h-8 px-2.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold inline-flex items-center gap-1"
                                >
                                  <CalendarPlus className="w-3.5 h-3.5" />
                                  <span>
                                    {act.linkedPlannerTaskId ? 'In Planner' : 'Send to Planner'}
                                  </span>
                                </button>
                                <button
                                  type="button"
                                  disabled={busyActionId === act.id}
                                  onClick={() =>
                                    act.linkedWorkflowProjectId
                                      ? onOpenWorkflow(act.linkedWorkflowProjectId)
                                      : void handleSendToWorkflow(act.id)
                                  }
                                  className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1"
                                >
                                  <Workflow className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                                  <span>
                                    {act.linkedWorkflowProjectId
                                      ? 'Open Workflow'
                                      : 'Start Workflow'}
                                  </span>
                                </button>
                                {act.status !== 'completed' && (
                                  <button
                                    type="button"
                                    disabled={busyActionId === act.id}
                                    onClick={() =>
                                      void handleUpdateAction(act.id, { status: 'completed' })
                                    }
                                    className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                                  >
                                    Mark Done
                                  </button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* TAB 5: LEARNING CENTER */}
          {tab === 'learning' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
              {snapshot.learningLessons.map((lesson) => (
                <div
                  key={lesson.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3"
                >
                  <div className="font-mono text-[11px] uppercase text-blue-600 dark:text-blue-400 font-semibold">
                    Creator Lesson
                  </div>
                  <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    {lesson.topic}
                  </h4>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {lesson.plainEnglishExplanation}
                  </p>
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                    <strong>How This Shows Up on Your Channel:</strong> {lesson.howItShowsUpOnYourChannel}
                  </div>
                  {lesson.beginnerChecklist?.length > 0 && (
                    <div className="space-y-1">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">
                        Actionable Checklist
                      </div>
                      <ul className="space-y-1 text-slate-600 dark:text-slate-400">
                        {lesson.beginnerChecklist.map((step, i) => (
                          <li key={i}>• {step}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* TAB 6: PROGRESS TRACKING */}
          {tab === 'progress' && (
            <div className="space-y-5 text-xs">
              {/* Saved Coaching Snapshots Over Time */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
                <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  Coaching Snapshot History ({history.length})
                </h4>
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {history.map((snap) => (
                    <div
                      key={snap.id}
                      className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                    >
                      <div className="space-y-0.5">
                        <div className="font-semibold text-slate-950 dark:text-white">
                          {snap.diagnosis.headline || `Coaching Check-In (${snap.periodStart} → ${snap.periodEnd})`}
                        </div>
                        <div className="font-mono tabular-nums text-[11px] text-slate-500">
                          {snap.periodStart} → {snap.periodEnd} · Views:{' '}
                          {snap.metricsSummary.views !== null
                            ? formatCompactNumber(snap.metricsSummary.views)
                            : 'N/A'}{' '}
                          · Avg Duration: {formatDuration(snap.metricsSummary.avgViewDurationSec)} · Net Subs:{' '}
                          {snap.metricsSummary.subscribersNet ?? 'N/A'}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          setSnapshot(snap);
                          setTab('diagnosis');
                        }}
                        className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold shrink-0"
                      >
                        Inspect Snapshot
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action & Experiment Outcome Log */}
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
                <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  Tracked Actions &amp; Experiment Outcomes
                </h4>
                {actions.length === 0 ? (
                  <p className="text-slate-500">No tracked actions yet.</p>
                ) : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800">
                    {actions.map((act) => (
                      <div key={act.id} className="py-3 space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div>
                            <span className="font-semibold text-slate-950 dark:text-white">
                              {act.title}
                            </span>
                            <span className="font-mono text-[11px] text-slate-500 ml-2">
                              {act.horizon} · {act.status.replace(/_/g, ' ')}
                            </span>
                          </div>
                          {canWrite && (
                            <select
                              value={act.status}
                              onChange={(e) =>
                                void handleUpdateAction(act.id, {
                                  status: e.target.value as YtmCoachActionRecord['status'],
                                })
                              }
                              className="h-8 px-2 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                            >
                              <option value="pending">pending</option>
                              <option value="approved">approved</option>
                              <option value="in_progress">in progress</option>
                              <option value="completed">completed</option>
                              <option value="dismissed">dismissed</option>
                            </select>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            disabled={!canWrite}
                            value={outcomeDrafts[act.id] ?? ''}
                            onChange={(e) =>
                              setOutcomeDrafts((prev) => ({
                                ...prev,
                                [act.id]: e.target.value,
                              }))
                            }
                            placeholder="Record observed outcome (e.g., retention held +8% after tightening 0–30s hook)..."
                            className="flex-1 h-8 px-2.5 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                          />
                          {canWrite && (
                            <button
                              type="button"
                              disabled={busyActionId === act.id}
                              onClick={() =>
                                void handleUpdateAction(act.id, {
                                  outcomeNotes: outcomeDrafts[act.id] || '',
                                })
                              }
                              className="h-8 px-3 rounded border border-slate-200 dark:border-slate-700 font-semibold"
                            >
                              Save Note
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
