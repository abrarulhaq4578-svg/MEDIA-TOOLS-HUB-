import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Briefcase,
  DollarSign,
  Info,
  Loader2,
  Plus,
  RefreshCw,
  Trash2,
} from 'lucide-react';
import type {
  YtmBrandDealRecord,
  YtmConnectedChannelRecord,
  YtmRevenueCategory,
  YtmRevenueEntryRecord,
} from '../../shared/types.ts';
import { YTM_REVENUE_CATEGORIES } from '../../shared/ytmHelpers.ts';
import { formatMoneyCents, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  connectedChannel: YtmConnectedChannelRecord | null;
}

interface EarnOverviewResponse {
  entries: YtmRevenueEntryRecord[];
  deals: YtmBrandDealRecord[];
  categoryTotals: Array<{
    category: YtmRevenueCategory;
    label: string;
    receivedCents: number;
    pendingCents: number;
    projectedCents: number;
    targetCents: number | null;
  }>;
  apiMonetary: {
    available: boolean;
    estimatedRevenue: number | null;
    currency: string;
    note: string;
  } | null;
}

export function YtmEarnView({
  authFetch,
  workspaceKey,
  canWrite,
  connectedChannel,
}: Props) {
  const [data, setData] = useState<EarnOverviewResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [syncingApi, setSyncingApi] = useState(false);

  // New revenue entry state
  const [showEntryForm, setShowEntryForm] = useState(false);
  const [category, setCategory] = useState<YtmRevenueCategory>('ads');
  const [sourceLabel, setSourceLabel] = useState('');
  const [entryType, setEntryType] = useState<'api' | 'manual' | 'estimate'>('manual');
  const [amountUsd, setAmountUsd] = useState('');
  const [monthKey, setMonthKey] = useState(() => new Date().toISOString().slice(0, 7));
  const [paymentStatus, setPaymentStatus] = useState<'received' | 'pending' | 'projected'>('received');
  const [targetUsd, setTargetUsd] = useState('');
  const [notes, setNotes] = useState('');
  const [savingEntry, setSavingEntry] = useState(false);

  // New brand deal state
  const [showDealForm, setShowDealForm] = useState(false);
  const [brandName, setBrandName] = useState('');
  const [contactDetails, setContactDetails] = useState('');
  const [campaign, setCampaign] = useState('');
  const [dealUsd, setDealUsd] = useState('');
  const [deliverables, setDeliverables] = useState('');
  const [deadline, setDeadline] = useState('');
  const [followUpDate, setFollowUpDate] = useState('');
  const [contractStatus, setContractStatus] = useState<YtmBrandDealRecord['contractStatus']>('negotiating');
  const [dealPaymentStatus, setDealPaymentStatus] = useState<YtmBrandDealRecord['paymentStatus']>('unpaid');
  const [savingDeal, setSavingDeal] = useState(false);

  const loadOverview = async (includeApi = false) => {
    if (includeApi) setSyncingApi(true);
    else setLoading(true);
    setError(null);
    try {
      const res = await ytmRequest<EarnOverviewResponse>(
        authFetch,
        `/earn/overview${includeApi ? '?includeApiMonetary=1' : ''}`,
        { workspaceKey }
      );
      setData(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load monetization overview.');
    } finally {
      setLoading(false);
      setSyncingApi(false);
    }
  };

  useEffect(() => {
    void loadOverview(Boolean(connectedChannel));
  }, [workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleAddEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!sourceLabel.trim() || !canWrite) return;
    setSavingEntry(true);
    try {
      const amountCents = Math.round((Number.parseFloat(amountUsd) || 0) * 100);
      const targetCents = targetUsd.trim() ? Math.round((Number.parseFloat(targetUsd) || 0) * 100) : null;
      await ytmRequest(authFetch, '/earn/entries', {
        workspaceKey,
        method: 'POST',
        body: {
          category,
          sourceLabel: sourceLabel.trim(),
          entryType,
          amountCents,
          currency: 'USD',
          monthKey,
          paymentStatus,
          targetCents,
          notes,
        },
      });
      setSourceLabel('');
      setAmountUsd('');
      setTargetUsd('');
      setNotes('');
      setShowEntryForm(false);
      await loadOverview(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save revenue entry.');
    } finally {
      setSavingEntry(false);
    }
  };

  const handleDeleteEntry = async (id: number) => {
    if (!canWrite) return;
    await ytmRequest(authFetch, `/earn/entries/${id}`, { workspaceKey, method: 'DELETE' });
    await loadOverview(false);
  };

  const handleAddDeal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!brandName.trim() || !canWrite) return;
    setSavingDeal(true);
    try {
      const dealAmountCents = Math.round((Number.parseFloat(dealUsd) || 0) * 100);
      await ytmRequest(authFetch, '/earn/deals', {
        workspaceKey,
        method: 'POST',
        body: {
          brandName: brandName.trim(),
          contactDetails,
          campaign,
          dealAmountCents,
          currency: 'USD',
          deliverables,
          deadline: deadline || null,
          followUpDate: followUpDate || null,
          contractStatus,
          paymentStatus: dealPaymentStatus,
        },
      });
      setBrandName('');
      setContactDetails('');
      setCampaign('');
      setDealUsd('');
      setDeliverables('');
      setDeadline('');
      setFollowUpDate('');
      setShowDealForm(false);
      await loadOverview(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create brand deal.');
    } finally {
      setSavingDeal(false);
    }
  };

  const handleUpdateDeal = async (
    id: number,
    patch: Partial<Pick<YtmBrandDealRecord, 'contractStatus' | 'paymentStatus'>>
  ) => {
    if (!canWrite) return;
    await ytmRequest(authFetch, `/earn/deals/${id}`, {
      workspaceKey,
      method: 'PATCH',
      body: patch,
    });
    await loadOverview(false);
  };

  const handleDeleteDeal = async (id: number) => {
    if (!canWrite) return;
    await ytmRequest(authFetch, `/earn/deals/${id}`, { workspaceKey, method: 'DELETE' });
    await loadOverview(false);
  };

  if (loading && !data) {
    return (
      <div className="p-10 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Loading Earn &amp; Brand Deals…</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Earn · Creator Revenue &amp; Brand Deal CRM
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Track official YouTube monetary figures separately from manual income entries and sponsorship deals.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {connectedChannel && (
            <button
              type="button"
              disabled={syncingApi}
              onClick={() => void loadOverview(true)}
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold inline-flex items-center gap-1.5"
            >
              {syncingApi ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              <span>Check YouTube Monetary API</span>
            </button>
          )}
          {canWrite && (
            <>
              <button
                type="button"
                onClick={() => setShowEntryForm((v) => !v)}
                className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Log Revenue</span>
              </button>
              <button
                type="button"
                onClick={() => setShowDealForm((v) => !v)}
                className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>New Brand Deal</span>
              </button>
            </>
          )}
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Official Monetary API Status Banner */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-2.5 text-xs">
          <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
          <div>
            <div className="font-semibold text-slate-900 dark:text-white">
              YouTube Monetary Analytics API Status
            </div>
            <p className="text-slate-600 dark:text-slate-400 mt-0.5">
              {data?.apiMonetary
                ? data.apiMonetary.available
                  ? `Official 30-day API estimatedRevenue: ${data.apiMonetary.estimatedRevenue} ${data.apiMonetary.currency}`
                  : data.apiMonetary.note
                : connectedChannel
                ? 'Click "Check YouTube Monetary API" to query yt-analytics-monetary.readonly if granted on your Partner channel.'
                : 'No YouTube channel connected yet. Manual and estimated entries below remain isolated from API earnings.'}
            </p>
          </div>
        </div>
      </div>

      {/* 6 Category Breakdown Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {YTM_REVENUE_CATEGORIES.map((cat) => {
          const totals = data?.categoryTotals.find((c) => c.category === cat.id);
          return (
            <div
              key={cat.id}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-2.5"
            >
              <div>
                <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  {cat.label}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  {cat.description}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-1 text-xs">
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-400">Received</div>
                  <div className="font-mono font-bold tabular-nums text-emerald-700 dark:text-emerald-300">
                    {formatMoneyCents(totals?.receivedCents || 0)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-400">Pending</div>
                  <div className="font-mono font-bold tabular-nums text-amber-700 dark:text-amber-300">
                    {formatMoneyCents(totals?.pendingCents || 0)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-wider text-slate-400">Projected</div>
                  <div className="font-mono font-bold tabular-nums text-slate-700 dark:text-slate-300">
                    {formatMoneyCents(totals?.projectedCents || 0)}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Log Revenue Form */}
      {showEntryForm && canWrite && (
        <form
          onSubmit={handleAddEntry}
          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3 text-xs"
        >
          <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Log Revenue Entry
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as YtmRevenueCategory)}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              {YTM_REVENUE_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.label}
                </option>
              ))}
            </select>
            <input
              type="text"
              required
              value={sourceLabel}
              onChange={(e) => setSourceLabel(e.target.value)}
              placeholder="Source label (e.g. AdSense Nov, Notion Integration)"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            />
            <select
              value={entryType}
              onChange={(e) => setEntryType(e.target.value as 'api' | 'manual' | 'estimate')}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="manual">Manual Confirmed</option>
              <option value="estimate">Estimate / Projection</option>
              <option value="api">API Verified</option>
            </select>
            <input
              type="number"
              step="0.01"
              min="0"
              required
              value={amountUsd}
              onChange={(e) => setAmountUsd(e.target.value)}
              placeholder="Amount ($ USD)"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <input
              type="month"
              value={monthKey}
              onChange={(e) => setMonthKey(e.target.value)}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <select
              value={paymentStatus}
              onChange={(e) => setPaymentStatus(e.target.value as 'received' | 'pending' | 'projected')}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="received">Received</option>
              <option value="pending">Pending</option>
              <option value="projected">Projected</option>
            </select>
            <input
              type="number"
              step="0.01"
              min="0"
              value={targetUsd}
              onChange={(e) => setTargetUsd(e.target.value)}
              placeholder="Optional Monthly Goal ($)"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Notes"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            />
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowEntryForm(false)}
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={savingEntry}
              className="h-9 px-4 rounded-lg bg-blue-600 text-white font-semibold"
            >
              {savingEntry ? 'Saving…' : 'Save Entry'}
            </button>
          </div>
        </form>
      )}

      {/* New Brand Deal Form */}
      {showDealForm && canWrite && (
        <form
          onSubmit={handleAddDeal}
          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3 text-xs"
        >
          <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
            Add Brand Deal
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <input
              type="text"
              required
              value={brandName}
              onChange={(e) => setBrandName(e.target.value)}
              placeholder="Brand name"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            />
            <input
              type="text"
              value={campaign}
              onChange={(e) => setCampaign(e.target.value)}
              placeholder="Campaign / Video integration"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            />
            <input
              type="text"
              value={contactDetails}
              onChange={(e) => setContactDetails(e.target.value)}
              placeholder="Sponsor contact email / manager"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            />
            <input
              type="number"
              step="0.01"
              min="0"
              value={dealUsd}
              onChange={(e) => setDealUsd(e.target.value)}
              placeholder="Deal value ($ USD)"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <input
              type="text"
              value={deliverables}
              onChange={(e) => setDeliverables(e.target.value)}
              placeholder="Deliverables (e.g. 60s mid-roll + pinned link)"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 sm:col-span-2"
            />
            <input
              type="date"
              value={deadline}
              onChange={(e) => setDeadline(e.target.value)}
              title="Delivery deadline"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <input
              type="date"
              value={followUpDate}
              onChange={(e) => setFollowUpDate(e.target.value)}
              title="Follow-up reminder"
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
            />
            <select
              value={contractStatus}
              onChange={(e) => setContractStatus(e.target.value as YtmBrandDealRecord['contractStatus'])}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="lead">Lead</option>
              <option value="negotiating">Negotiating</option>
              <option value="signed">Signed</option>
              <option value="delivered">Delivered</option>
              <option value="cancelled">Cancelled</option>
            </select>
            <select
              value={dealPaymentStatus}
              onChange={(e) => setDealPaymentStatus(e.target.value as YtmBrandDealRecord['paymentStatus'])}
              className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              <option value="unpaid">Unpaid</option>
              <option value="invoiced">Invoiced</option>
              <option value="partial">Partial</option>
              <option value="paid">Paid</option>
            </select>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowDealForm(false)}
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={savingDeal}
              className="h-9 px-4 rounded-lg bg-blue-600 text-white font-semibold"
            >
              {savingDeal ? 'Saving…' : 'Create Brand Deal'}
            </button>
          </div>
        </form>
      )}

      {/* Revenue Ledger + Brand Deal CRM */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Revenue Ledger */}
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            <span>Revenue Ledger ({data?.entries.length || 0})</span>
          </h3>
          {!data?.entries.length ? (
            <div className="text-xs text-slate-500 py-4">
              No revenue entries logged yet.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                    <th className="pb-2 font-semibold">Source</th>
                    <th className="pb-2 font-semibold">Type</th>
                    <th className="pb-2 font-semibold">Month</th>
                    <th className="pb-2 font-semibold">Status</th>
                    <th className="pb-2 font-semibold text-right">Amount</th>
                    <th className="pb-2"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {data.entries.map((entry) => (
                    <tr key={entry.id}>
                      <td className="py-2 pr-2 font-semibold text-slate-900 dark:text-white">
                        {entry.sourceLabel}
                        <div className="text-[11px] font-normal text-slate-500">{entry.category}</div>
                      </td>
                      <td className="py-2 pr-2 font-mono uppercase text-[11px] text-slate-500">
                        {entry.entryType}
                      </td>
                      <td className="py-2 pr-2 font-mono text-slate-500">{entry.monthKey}</td>
                      <td className="py-2 pr-2 capitalize text-slate-600 dark:text-slate-300">
                        {entry.paymentStatus}
                      </td>
                      <td className="py-2 text-right font-mono font-bold tabular-nums">
                        {formatMoneyCents(entry.amountCents, entry.currency)}
                      </td>
                      <td className="py-2 pl-2 text-right">
                        {canWrite && (
                          <button
                            type="button"
                            onClick={() => void handleDeleteEntry(entry.id)}
                            aria-label="Delete revenue entry"
                            className="p-1 text-slate-400 hover:text-red-600"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Brand Deal CRM */}
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
          <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-blue-600" />
            <span>Brand Deal &amp; Collaboration CRM ({data?.deals.length || 0})</span>
          </h3>
          {!data?.deals.length ? (
            <div className="text-xs text-slate-500 py-4">
              No sponsorship or brand deals tracked yet.
            </div>
          ) : (
            <div className="space-y-3">
              {data.deals.map((deal) => (
                <div
                  key={deal.id}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-2 text-xs"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                        {deal.brandName}
                      </div>
                      {deal.campaign && (
                        <div className="text-slate-600 dark:text-slate-300">{deal.campaign}</div>
                      )}
                      {deal.deliverables && (
                        <div className="text-[11px] text-slate-500 mt-0.5">{deal.deliverables}</div>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <div className="font-mono font-bold text-sm tabular-nums text-slate-950 dark:text-white">
                        {formatMoneyCents(deal.dealAmountCents, deal.currency)}
                      </div>
                      {deal.deadline && (
                        <div className="font-mono text-[11px] text-slate-500">Due {deal.deadline}</div>
                      )}
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <select
                        disabled={!canWrite}
                        value={deal.contractStatus}
                        onChange={(e) =>
                          void handleUpdateDeal(deal.id, {
                            contractStatus: e.target.value as YtmBrandDealRecord['contractStatus'],
                          })
                        }
                        className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px]"
                      >
                        <option value="lead">Lead</option>
                        <option value="negotiating">Negotiating</option>
                        <option value="signed">Signed</option>
                        <option value="delivered">Delivered</option>
                        <option value="cancelled">Cancelled</option>
                      </select>
                      <select
                        disabled={!canWrite}
                        value={deal.paymentStatus}
                        onChange={(e) =>
                          void handleUpdateDeal(deal.id, {
                            paymentStatus: e.target.value as YtmBrandDealRecord['paymentStatus'],
                          })
                        }
                        className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-[11px]"
                      >
                        <option value="unpaid">Unpaid</option>
                        <option value="invoiced">Invoiced</option>
                        <option value="partial">Partial</option>
                        <option value="paid">Paid</option>
                      </select>
                    </div>
                    {canWrite && (
                      <button
                        type="button"
                        onClick={() => void handleDeleteDeal(deal.id)}
                        className="text-slate-400 hover:text-red-600 p-1"
                        aria-label="Delete deal"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
