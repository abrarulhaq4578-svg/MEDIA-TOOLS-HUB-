import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  BarChart3,
  CalendarDays,
  Check,
  Lightbulb,
  Loader2,
  Plus,
  RefreshCw,
  Youtube,
} from 'lucide-react';
import type {
  YtmDashboardOverview,
  YtmDashboardUpcomingItem,
  YtmPlannerProjectRecord,
  YtmPriority,
} from '../../shared/types.ts';
import { formatCompactNumber, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';
import type { YtmPlannerTab } from './YtmPlannerView.tsx';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWritePlanner: boolean;
  canManageOAuth: boolean;
  checkingOAuth: boolean;
  onConnectYouTube: () => void;
  onSyncChannel: () => void;
  onCreateNewVideo: () => void;
  onAddContentIdea: () => void;
  onOpenContentPlanner: (tab?: YtmPlannerTab) => void;
  onViewAnalytics: () => void;
  onOpenProjectInWorkflow: (project: YtmPlannerProjectRecord) => Promise<void>;
}

interface TodayPlanRow {
  id: string;
  itemType: 'project' | 'task';
  taskId?: number;
  title: string;
  platform: string;
  scheduledTime: string | null;
  status: string;
  priority: YtmPriority;
  isCompleted: boolean;
  project?: YtmPlannerProjectRecord;
}

function inferPlatform(titleText: string, hintText?: string | null): string {
  const combined = `${titleText} ${hintText || ''}`.toLowerCase();
  if (/\binstagram\b|\breel\b|\bcarousel\b/.test(combined)) return 'Instagram';
  if (/\btiktok\b/.test(combined)) return 'TikTok';
  if (/\byoutube shorts\b|\bshorts\b/.test(combined)) return 'YouTube Shorts';
  if (/\blinkedin\b/.test(combined)) return 'LinkedIn';
  if (/\bfacebook\b/.test(combined)) return 'Facebook';
  if (/\bpinterest\b/.test(combined)) return 'Pinterest';
  if (/\btwitter\b|\bx thread\b/.test(combined)) return 'X / Twitter';
  if (/\bebook\b|\be-book\b/.test(combined)) return 'Ebook';
  if (/\bnewsletter\b/.test(combined)) return 'Newsletter';
  if (/\bpodcast\b/.test(combined)) return 'Podcast';
  if (/\bblog\b|\barticle\b/.test(combined)) return 'Blog';
  return 'YouTube';
}

function formatScheduledTime(iso: string | null | undefined): string | null {
  if (!iso) return null;
  const match = iso.match(/T(\d{2}):(\d{2})/);
  if (!match) return null;
  const hours = Number.parseInt(match[1], 10);
  const minutes = match[2];
  if (hours === 0 && minutes === '00') return null;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  const hour12 = hours % 12 === 0 ? 12 : hours % 12;
  return `${hour12}:${minutes} ${suffix}`;
}

function formatDisplayDate(dateKey: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return dateKey;
  const d = new Date(`${dateKey}T00:00:00Z`);
  return d.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: 'UTC',
  });
}

function formatPriorityLabel(priority: YtmPriority | undefined): string | null {
  if (!priority) return null;
  return `${priority.charAt(0).toUpperCase()}${priority.slice(1)} priority`;
}

function parseViewCount(raw: string | null | undefined): number | null {
  if (!raw) return null;
  const n = Number.parseInt(raw, 10);
  return Number.isFinite(n) ? n : null;
}

export function YtmDashboardView({
  authFetch,
  workspaceKey,
  canWritePlanner,
  canManageOAuth,
  checkingOAuth,
  onConnectYouTube,
  onSyncChannel,
  onCreateNewVideo,
  onAddContentIdea,
  onOpenContentPlanner,
  onViewAnalytics,
  onOpenProjectInWorkflow,
}: Props) {
  const [overview, setOverview] = useState<YtmDashboardOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [togglingTaskId, setTogglingTaskId] = useState<number | null>(null);
  const [openingProjectId, setOpeningProjectId] = useState<number | null>(null);

  const loadDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await ytmRequest<YtmDashboardOverview>(authFetch, '/dashboard', {
        workspaceKey,
      });
      setOverview(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load dashboard.');
    } finally {
      setLoading(false);
    }
  }, [authFetch, workspaceKey]);

  useEffect(() => {
    void loadDashboard();
  }, [loadDashboard]);

  const handleToggleTaskDone = async (taskId: number, currentStatus: string) => {
    if (!canWritePlanner) return;
    setTogglingTaskId(taskId);
    try {
      await ytmRequest(authFetch, `/planner/tasks/${taskId}`, {
        workspaceKey,
        method: 'PATCH',
        body: { status: currentStatus === 'Completed' ? 'In Progress' : 'Completed' },
      });
      await loadDashboard();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to update task status.');
    } finally {
      setTogglingTaskId(null);
    }
  };

  const handleOpenProject = async (project: YtmPlannerProjectRecord) => {
    setOpeningProjectId(project.id);
    try {
      await onOpenProjectInWorkflow(project);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to open video workflow.');
    } finally {
      setOpeningProjectId(null);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6" aria-busy="true" aria-label="Loading dashboard">
        <div className="h-[72px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className="h-[92px] rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse"
            />
          ))}
        </div>
        <div className="h-56 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse" />
        <div className="h-44 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse" />
      </div>
    );
  }

  if (error || !overview) {
    return (
      <div className="rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50 dark:bg-rose-950/20 p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2.5 text-sm text-rose-700 dark:text-rose-300">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error || 'Dashboard is currently unavailable.'}</span>
        </div>
        <button
          type="button"
          onClick={() => void loadDashboard()}
          className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold whitespace-nowrap transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  const ch = overview.connectedChannel;
  const isConnected = Boolean(ch && ch.connectionStatus === 'connected');
  const workflowStages = overview.workflowStagesById || {};
  const videosInProduction =
    overview.videosInProductionCount ?? overview.videosInProgressCount ?? 0;

  // Build unified Today's Plan rows directly from Content Planner records
  const knownProjectsMap = new Map<number, YtmPlannerProjectRecord>();
  for (const p of overview.todaysScheduledProjects || []) knownProjectsMap.set(p.id, p);
  for (const p of overview.inProgressVideos || []) knownProjectsMap.set(p.id, p);
  for (const item of overview.upcomingContent || []) {
    if (item.project) knownProjectsMap.set(item.project.id, item.project);
  }

  const todayRows: TodayPlanRow[] = [
    ...(overview.todaysScheduledProjects || []).map((proj) => {
      const wfStage = proj.workflowProjectId ? workflowStages[proj.workflowProjectId] : undefined;
      return {
        id: `project-${proj.id}`,
        itemType: 'project' as const,
        title: proj.title,
        platform: inferPlatform(proj.title, proj.category),
        scheduledTime: formatScheduledTime(proj.plannedDate || proj.deadline),
        status: wfStage ? wfStage.stageLabel : proj.status,
        priority: proj.priority,
        isCompleted: proj.status === 'Published',
        project: proj,
      };
    }),
    ...(overview.todaysPlan || []).map((task) => {
      const linkedProject = task.plannerProjectId
        ? knownProjectsMap.get(task.plannerProjectId)
        : undefined;
      return {
        id: `task-${task.id}`,
        itemType: 'task' as const,
        taskId: task.id,
        title: task.taskName,
        platform: inferPlatform(task.taskName, linkedProject?.category || task.workspaceSection),
        scheduledTime: formatScheduledTime(task.scheduledAt || task.deadline),
        status: task.status,
        priority: task.priority,
        isCompleted: task.status === 'Completed',
        project: linkedProject,
      };
    }),
  ];

  // Next 5 upcoming scheduled items from Content Planner
  const upcomingItems: YtmDashboardUpcomingItem[] = (overview.upcomingContent || []).slice(0, 5);

  const channelConnectionLabel = !ch
    ? 'Not connected'
    : ch.connectionStatus === 'connected'
      ? 'Connected'
      : ch.connectionStatus === 'reconnect_required'
        ? 'Reconnect required'
        : 'Disconnected';

  const channelConnectionColor = !ch
    ? 'text-slate-500 dark:text-slate-400'
    : ch.connectionStatus === 'connected'
      ? 'text-emerald-700 dark:text-emerald-400'
      : 'text-amber-700 dark:text-amber-400';

  return (
    <div className="space-y-6">
      {/* SECTION A — CHANNEL HEADER */}
      <section
        aria-label="Channel header"
        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-5 py-4 flex flex-wrap items-center justify-between gap-4"
      >
        <div className="flex items-center gap-3.5 min-w-0">
          {ch?.thumbnailUrl ? (
            <img
              src={ch.thumbnailUrl}
              alt={ch.channelTitle}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 object-cover shrink-0"
            />
          ) : (
            <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
              <Youtube className="w-5 h-5" />
            </div>
          )}

          <div className="min-w-0">
            <h1 className="font-display text-base font-bold text-slate-950 dark:text-white truncate">
              {ch ? ch.channelTitle : 'No YouTube channel connected'}
            </h1>
            <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 dark:text-slate-400">
              <span className={`font-medium ${channelConnectionColor}`}>
                {channelConnectionLabel}
              </span>
              <span aria-hidden="true">·</span>
              <span className="truncate">Workspace: {overview.workspace.name}</span>
              {ch?.channelHandle && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono text-slate-500 dark:text-slate-400">
                    {ch.channelHandle}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {isConnected ? (
            <button
              type="button"
              onClick={() => {
                onSyncChannel();
                void loadDashboard();
              }}
              className="h-9 px-3.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh</span>
            </button>
          ) : (
            canManageOAuth && (
              <button
                type="button"
                disabled={checkingOAuth}
                onClick={onConnectYouTube}
                className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white text-xs font-semibold inline-flex items-center gap-2 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
              >
                {checkingOAuth ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Youtube className="w-3.5 h-3.5" />
                )}
                <span>Connect YouTube Channel</span>
              </button>
            )
          )}
        </div>
      </section>

      {/* SECTION B — SIMPLE CHANNEL OVERVIEW */}
      <section aria-label="Channel overview" className="space-y-3">
        <div className="flex items-baseline justify-between gap-2">
          <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-white">
            Channel Overview
          </h2>
          {!isConnected && (
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Connect your YouTube channel above to view live statistics.
            </span>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            label="Subscribers"
            value={isConnected && ch ? formatCompactNumber(ch.subscriberCount) : '—'}
            note={isConnected ? 'Authorized channel count' : 'Connect channel to view'}
          />
          <MetricCard
            label="Total Views"
            value={isConnected && ch ? formatCompactNumber(parseViewCount(ch.viewCount)) : '—'}
            note={isConnected ? 'Lifetime channel views' : 'Connect channel to view'}
          />
          <MetricCard
            label="Videos Published"
            value={isConnected && ch ? formatCompactNumber(ch.videoCount) : '—'}
            note={isConnected ? 'Public uploads on YouTube' : 'Connect channel to view'}
          />
          <MetricCard
            label="Videos in Production"
            value={String(videosInProduction)}
            note="Active in Planner & Workflow"
          />
        </div>
      </section>

      {/* SECTION C — TODAY'S PLAN */}
      <section
        aria-label="Today's plan"
        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
      >
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-baseline gap-2.5">
            <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Today’s Plan
            </h2>
            <span className="font-mono text-xs tabular-nums text-slate-500 dark:text-slate-400">
              {formatDisplayDate(overview.todayDateKey)}
            </span>
          </div>

          {todayRows.length > 0 && (
            <button
              type="button"
              onClick={() => onOpenContentPlanner('daily')}
              className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 rounded"
            >
              Open Content Planner
            </button>
          )}
        </div>

        {todayRows.length === 0 ? (
          <div className="px-5 py-10 text-center space-y-3">
            <p className="text-sm text-slate-600 dark:text-slate-400">
              No content or tasks scheduled for today.
            </p>
            <button
              type="button"
              onClick={() => onOpenContentPlanner('calendar')}
              className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
            >
              <CalendarDays className="w-3.5 h-3.5" />
              <span>Open Content Planner</span>
            </button>
          </div>
        ) : (
          <ul className="divide-y divide-slate-100 dark:divide-slate-800">
            {todayRows.map((row) => {
              const priorityLabel = formatPriorityLabel(row.priority);
              const isOpening = row.project && openingProjectId === row.project.id;
              const isToggling = row.taskId && togglingTaskId === row.taskId;

              return (
                <li
                  key={row.id}
                  className="px-5 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                >
                  <div className="flex items-start gap-3 min-w-0">
                    {row.itemType === 'task' && row.taskId !== undefined && (
                      <button
                        type="button"
                        aria-label={
                          row.isCompleted
                            ? `Mark ${row.title} incomplete`
                            : `Mark ${row.title} completed`
                        }
                        disabled={!canWritePlanner || Boolean(isToggling)}
                        onClick={() => void handleToggleTaskDone(row.taskId!, row.status)}
                        className={`mt-0.5 w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors ${
                          row.isCompleted
                            ? 'bg-emerald-600 border-emerald-600 text-white'
                            : 'border-slate-300 dark:border-slate-600 hover:border-blue-600'
                        }`}
                      >
                        {isToggling ? (
                          <Loader2 className="w-2.5 h-2.5 animate-spin" />
                        ) : (
                          row.isCompleted && <Check className="w-3 h-3" />
                        )}
                      </button>
                    )}

                    <div className="min-w-0">
                      <div
                        className={`text-sm font-medium truncate ${
                          row.isCompleted
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-white'
                        }`}
                      >
                        {row.title}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-slate-500 dark:text-slate-400">
                        <span>{row.platform}</span>
                        {row.scheduledTime && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono tabular-nums">{row.scheduledTime}</span>
                          </>
                        )}
                        <span aria-hidden="true">·</span>
                        <span className="text-slate-700 dark:text-slate-300">{row.status}</span>
                        {priorityLabel && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span
                              className={
                                row.priority === 'high'
                                  ? 'text-amber-700 dark:text-amber-400 font-medium'
                                  : undefined
                              }
                            >
                              {priorityLabel}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0 sm:pl-3">
                    {row.project ? (
                      <button
                        type="button"
                        disabled={Boolean(isOpening)}
                        onClick={() => void handleOpenProject(row.project!)}
                        className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-blue-600 hover:text-blue-600 dark:hover:text-blue-400 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap transition-colors"
                      >
                        {isOpening ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <>
                            <span>Open Workflow</span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </>
                        )}
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onOpenContentPlanner('daily')}
                        className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-blue-600 hover:text-blue-600 dark:hover:text-blue-400 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5 whitespace-nowrap transition-colors"
                      >
                        <span>Open in Planner</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>

      {/* SECTION D — UPCOMING CONTENT */}
      <section
        aria-label="Upcoming content"
        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
      >
        <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <h2 className="font-display text-sm font-semibold text-slate-950 dark:text-white">
            Upcoming Content
          </h2>
          <button
            type="button"
            onClick={() => onOpenContentPlanner('calendar')}
            className="text-xs font-semibold text-blue-600 dark:text-blue-400 hover:underline whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 rounded"
          >
            View Full Calendar
          </button>
        </div>

        {upcomingItems.length === 0 ? (
          <div className="px-5 py-7 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400">
            <span>No upcoming content scheduled yet.</span>
            <button
              type="button"
              onClick={() => onOpenContentPlanner('calendar')}
              className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 font-semibold text-slate-700 dark:text-slate-200 whitespace-nowrap transition-colors"
            >
              View Full Calendar
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-xs font-medium text-slate-500 dark:text-slate-400">
                  <th className="py-2.5 pl-5 pr-3">Content</th>
                  <th className="py-2.5 px-3 whitespace-nowrap">Platform</th>
                  <th className="py-2.5 px-3 whitespace-nowrap">Scheduled Date</th>
                  <th className="py-2.5 pl-3 pr-5 text-right whitespace-nowrap">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {upcomingItems.map((item) => (
                  <tr
                    key={item.id}
                    className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors"
                  >
                    <td className="py-3 pl-5 pr-3 max-w-[320px]">
                      <button
                        type="button"
                        onClick={() => {
                          if (item.project) {
                            void handleOpenProject(item.project);
                          } else {
                            onOpenContentPlanner('calendar');
                          }
                        }}
                        className="font-medium text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 text-left truncate block w-full"
                      >
                        {item.title}
                      </button>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {item.platform}
                    </td>
                    <td className="py-3 px-3 font-mono tabular-nums text-slate-600 dark:text-slate-400 whitespace-nowrap">
                      {formatDisplayDate(item.scheduledDate)}
                    </td>
                    <td className="py-3 pl-3 pr-5 text-right text-slate-700 dark:text-slate-300 whitespace-nowrap">
                      {item.status}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* SECTION E — QUICK ACTIONS */}
      <section aria-label="Quick actions" className="space-y-3">
        <h2 className="font-display text-sm font-semibold text-slate-900 dark:text-white">
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <button
            type="button"
            onClick={onCreateNewVideo}
            className="h-11 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold flex items-center justify-between gap-2 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <span className="inline-flex items-center gap-2">
              <Plus className="w-4 h-4 shrink-0" />
              <span>Create New Video</span>
            </span>
            <ArrowRight className="w-3.5 h-3.5 shrink-0" />
          </button>

          <button
            type="button"
            onClick={onAddContentIdea}
            className="h-11 px-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-600 text-slate-900 dark:text-white text-xs font-semibold flex items-center justify-between gap-2 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <span className="inline-flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
              <span>Add Content Idea</span>
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </button>

          <button
            type="button"
            onClick={() => onOpenContentPlanner('calendar')}
            className="h-11 px-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-600 text-slate-900 dark:text-white text-xs font-semibold flex items-center justify-between gap-2 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <span className="inline-flex items-center gap-2">
              <CalendarDays className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
              <span>Open Content Planner</span>
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </button>

          <button
            type="button"
            onClick={onViewAnalytics}
            className="h-11 px-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-600 text-slate-900 dark:text-white text-xs font-semibold flex items-center justify-between gap-2 whitespace-nowrap transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600"
          >
            <span className="inline-flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-slate-500 dark:text-slate-400 shrink-0" />
              <span>View Analytics</span>
            </span>
            <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
          </button>
        </div>
      </section>
    </div>
  );
}

function MetricCard({
  label,
  value,
  note,
}: {
  label: string;
  value: string;
  note: string;
}) {
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
      <div className="text-xs font-medium text-slate-500 dark:text-slate-400">{label}</div>
      <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-slate-950 dark:text-white">
        {value}
      </div>
      <div className="mt-1 text-xs text-slate-500 dark:text-slate-400">{note}</div>
    </div>
  );
}
