import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Check,
  Dna,
  Loader2,
  Plus,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import type { YtmChannelProfileWithDna } from '../../shared/types.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  open: boolean;
  onClose: () => void;
  authFetch: AuthFetchFn;
  workspaceKey: string;
  canWrite: boolean;
  profiles: YtmChannelProfileWithDna[];
  activeProfileId: number | null;
  onSelectProfile: (profileId: number) => void;
  onProfilesChanged: (profiles: YtmChannelProfileWithDna[], selectedId?: number) => void;
}

interface FormState {
  channelName: string;
  channelHandle: string;
  description: string;
  niche: string;
  subNiche: string;
  isDefault: boolean;
  targetAudience: string;
  audienceProblems: string;
  preferredLanguage: string;
  contentCategories: string;
  preferredFormats: string;
  contentFormat: string;
  videoStyle: string;
  toneOfVoice: string;
  brandVoice: string;
  storytellingApproach: string;
  scriptStructure: string;
  preferredVideoDuration: string;
  publishingPreferences: string;
  contentRules: string;
  creativeGuidelines: string;
  titlePreferences: string;
  thumbnailDesignPreferences: string;
  colorPalette: string;
  typography: string;
  wordsToUse: string;
  wordsToAvoid: string;
  uniquePositioning: string;
}

function profileToForm(p: YtmChannelProfileWithDna): FormState {
  return {
    channelName: p.channelName || '',
    channelHandle: p.channelHandle || '',
    description: p.description || '',
    niche: p.niche || '',
    subNiche: p.subNiche || '',
    isDefault: p.isDefault,
    targetAudience: p.dna.targetAudience || '',
    audienceProblems: (p.dna.audienceProblems || []).join(', '),
    preferredLanguage: p.dna.preferredLanguage || 'English',
    contentCategories: (p.dna.contentCategories || []).join(', '),
    preferredFormats: (p.dna.preferredFormats || []).join(', '),
    contentFormat: p.dna.contentFormat || 'Long-form YouTube',
    videoStyle: p.dna.videoStyle || '',
    toneOfVoice: p.dna.toneOfVoice || '',
    brandVoice: p.dna.brandVoice || '',
    storytellingApproach: p.dna.storytellingApproach || '',
    scriptStructure: p.dna.scriptStructure || '',
    preferredVideoDuration: p.dna.preferredVideoDuration || '8–12 minutes',
    publishingPreferences: p.dna.publishingPreferences || '',
    contentRules: p.dna.contentRules || '',
    creativeGuidelines: p.dna.creativeGuidelines || '',
    titlePreferences: p.dna.titlePreferences || '',
    thumbnailDesignPreferences: p.dna.thumbnailDesignPreferences || '',
    colorPalette: (p.dna.colorPalette || []).join(', '),
    typography: p.dna.typography || '',
    wordsToUse: (p.dna.wordsToUse || []).join(', '),
    wordsToAvoid: (p.dna.wordsToAvoid || []).join(', '),
    uniquePositioning: p.dna.uniquePositioning || '',
  };
}

function emptyForm(): FormState {
  return {
    channelName: '',
    channelHandle: '',
    description: '',
    niche: '',
    subNiche: '',
    isDefault: false,
    targetAudience: '',
    audienceProblems: '',
    preferredLanguage: 'English',
    contentCategories: '',
    preferredFormats: '',
    contentFormat: 'Long-form YouTube',
    videoStyle: '',
    toneOfVoice: '',
    brandVoice: '',
    storytellingApproach: '',
    scriptStructure: '',
    preferredVideoDuration: '8–12 minutes',
    publishingPreferences: '',
    contentRules: '',
    creativeGuidelines: '',
    titlePreferences: '',
    thumbnailDesignPreferences: '',
    colorPalette: '',
    typography: '',
    wordsToUse: '',
    wordsToAvoid: '',
    uniquePositioning: '',
  };
}

function splitCsv(value: string): string[] {
  return value
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

export function YtmChannelDnaModal({
  open,
  onClose,
  authFetch,
  workspaceKey,
  canWrite,
  profiles,
  activeProfileId,
  onSelectProfile,
  onProfilesChanged,
}: Props) {
  const [creatingNew, setCreatingNew] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(activeProfileId);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setError(null);
    setSavedNotice(null);
    if (creatingNew) return;
    const chosen =
      profiles.find((p) => p.id === (editingId ?? activeProfileId)) ||
      profiles.find((p) => p.isDefault) ||
      profiles[0];
    if (chosen) {
      setEditingId(chosen.id);
      setForm(profileToForm(chosen));
    }
  }, [open, profiles, activeProfileId, editingId, creatingNew]);

  if (!open) return null;

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
    setSavedNotice(null);
  };

  const handleChooseProfile = (p: YtmChannelProfileWithDna) => {
    setCreatingNew(false);
    setEditingId(p.id);
    setForm(profileToForm(p));
    setError(null);
    setSavedNotice(null);
    onSelectProfile(p.id);
  };

  const handleStartNew = () => {
    setCreatingNew(true);
    setEditingId(null);
    setForm(emptyForm());
    setError(null);
    setSavedNotice(null);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWrite) return;
    if (!form.channelName.trim()) {
      setError('Channel name is required.');
      return;
    }
    setSaving(true);
    setError(null);
    setSavedNotice(null);
    try {
      const payload = {
        channelName: form.channelName.trim(),
        channelHandle: form.channelHandle.trim(),
        description: form.description.trim(),
        niche: form.niche.trim(),
        subNiche: form.subNiche.trim(),
        isDefault: form.isDefault,
        dna: {
          targetAudience: form.targetAudience.trim(),
          audienceProblems: splitCsv(form.audienceProblems),
          preferredLanguage: form.preferredLanguage.trim() || 'English',
          contentCategories: splitCsv(form.contentCategories),
          preferredFormats: splitCsv(form.preferredFormats),
          contentFormat: form.contentFormat.trim() || 'Long-form YouTube',
          videoStyle: form.videoStyle.trim(),
          toneOfVoice: form.toneOfVoice.trim(),
          brandVoice: form.brandVoice.trim(),
          storytellingApproach: form.storytellingApproach.trim(),
          scriptStructure: form.scriptStructure.trim(),
          preferredVideoDuration: form.preferredVideoDuration.trim() || '8–12 minutes',
          publishingPreferences: form.publishingPreferences.trim(),
          contentRules: form.contentRules.trim(),
          creativeGuidelines: form.creativeGuidelines.trim(),
          titlePreferences: form.titlePreferences.trim(),
          thumbnailDesignPreferences: form.thumbnailDesignPreferences.trim(),
          colorPalette: splitCsv(form.colorPalette),
          typography: form.typography.trim(),
          wordsToUse: splitCsv(form.wordsToUse),
          wordsToAvoid: splitCsv(form.wordsToAvoid),
          uniquePositioning: form.uniquePositioning.trim(),
        },
      };

      let savedProfile: YtmChannelProfileWithDna;
      if (creatingNew || !editingId) {
        const res = await ytmRequest<{ profile: YtmChannelProfileWithDna }>(
          authFetch,
          '/channel-profiles',
          { workspaceKey, method: 'POST', body: payload }
        );
        savedProfile = res.profile;
      } else {
        const res = await ytmRequest<{ profile: YtmChannelProfileWithDna }>(
          authFetch,
          `/channel-profiles/${editingId}`,
          { workspaceKey, method: 'PATCH', body: payload }
        );
        savedProfile = res.profile;
      }

      const listRes = await ytmRequest<{ profiles: YtmChannelProfileWithDna[] }>(
        authFetch,
        '/channel-profiles',
        { workspaceKey }
      );
      setCreatingNew(false);
      setEditingId(savedProfile.id);
      setForm(profileToForm(savedProfile));
      onProfilesChanged(listRes.profiles || [], savedProfile.id);
      onSelectProfile(savedProfile.id);
      setSavedNotice('Channel DNA saved. AI generation will now use this profile.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save Channel DNA profile.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!canWrite || !editingId || profiles.length <= 1) return;
    setDeleting(true);
    setError(null);
    try {
      await ytmRequest(authFetch, `/channel-profiles/${editingId}`, {
        workspaceKey,
        method: 'DELETE',
      });
      const listRes = await ytmRequest<{ profiles: YtmChannelProfileWithDna[] }>(
        authFetch,
        '/channel-profiles',
        { workspaceKey }
      );
      const next = listRes.profiles?.[0];
      onProfilesChanged(listRes.profiles || [], next?.id);
      if (next) {
        setEditingId(next.id);
        setForm(profileToForm(next));
        onSelectProfile(next.id);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete channel profile.');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl max-h-[90vh] rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 flex items-center justify-center text-blue-600 dark:text-blue-400 shrink-0">
              <Dna className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h2 className="font-display text-base font-bold text-slate-950 dark:text-white truncate">
                Channel DNA & Multi-Channel Profiles
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Persistent identity and voice rules automatically retrieved by AI before generating titles, adaptations, scripts, and daily plans.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close Channel DNA modal"
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto grid grid-cols-1 lg:grid-cols-12">
          {/* Left Channel Profile Switcher */}
          <div className="lg:col-span-3 border-b lg:border-b-0 lg:border-r border-slate-200 dark:border-slate-800 p-4 space-y-3 bg-slate-50/70 dark:bg-slate-950/50">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Channels ({profiles.length})
              </span>
              {canWrite && (
                <button
                  type="button"
                  onClick={handleStartNew}
                  className="text-xs font-semibold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1 hover:underline"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Channel</span>
                </button>
              )}
            </div>

            <div className="space-y-1.5">
              {profiles.map((p) => {
                const selected = !creatingNew && p.id === editingId;
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleChooseProfile(p)}
                    className={`w-full text-left px-3 py-2.5 rounded-lg border transition-colors ${
                      selected
                        ? 'border-blue-600 bg-blue-50/70 dark:bg-blue-950/30 text-slate-950 dark:text-white'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100/70 dark:hover:bg-slate-800/70'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-xs font-semibold truncate">{p.channelName}</span>
                      {p.isDefault && (
                        <Star className="w-3 h-3 text-amber-500 fill-amber-500 shrink-0" />
                      )}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                      {[p.niche, p.dna.preferredLanguage].filter(Boolean).join(' · ') || 'DNA setup pending'}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right DNA Editor Form */}
          <form onSubmit={(e) => void handleSave(e)} className="lg:col-span-9 p-5 sm:p-6 space-y-6 text-xs">
            {error && (
              <div className="rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30 p-3 text-rose-700 dark:text-rose-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}
            {savedNotice && (
              <div className="rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 p-3 text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4 shrink-0" />
                <span>{savedNotice}</span>
              </div>
            )}

            {/* Section 1: Channel Identity */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  {creatingNew ? 'New Channel Profile' : '1. Channel Identity & Positioning'}
                </h3>
                <label className="inline-flex items-center gap-2 text-xs text-slate-600 dark:text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    disabled={!canWrite}
                    checked={form.isDefault}
                    onChange={(e) => setField('isDefault', e.target.checked)}
                    className="rounded border-slate-300 dark:border-slate-700"
                  />
                  <span>Default active channel</span>
                </label>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel Name *
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={form.channelName}
                    onChange={(e) => setField('channelName', e.target.value)}
                    placeholder="e.g., Practical AI Builders"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel Handle (optional)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.channelHandle}
                    onChange={(e) => setField('channelHandle', e.target.value)}
                    placeholder="@practicalaibuilders"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Primary Niche
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.niche}
                    onChange={(e) => setField('niche', e.target.value)}
                    placeholder="e.g., Creator Productivity & Tech"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Sub-Niche
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.subNiche}
                    onChange={(e) => setField('subNiche', e.target.value)}
                    placeholder="e.g., Solo YouTube automation & script systems"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel Description
                  </label>
                  <textarea
                    rows={2}
                    disabled={!canWrite}
                    value={form.description}
                    onChange={(e) => setField('description', e.target.value)}
                    placeholder="What your channel exists to help viewers achieve..."
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Target Audience
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.targetAudience}
                    onChange={(e) => setField('targetAudience', e.target.value)}
                    placeholder="e.g., Ambitious part-time creators (1k–50k subs)"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Language
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.preferredLanguage}
                    onChange={(e) => setField('preferredLanguage', e.target.value)}
                    placeholder="English, Urdu, Hindi, Spanish..."
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Audience Problems &amp; Pain Points (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.audienceProblems}
                    onChange={(e) => setField('audienceProblems', e.target.value)}
                    placeholder="e.g., Low retention after 30s, inconsistent upload schedule, weak thumbnails"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Unique Channel Positioning
                  </label>
                  <textarea
                    rows={2}
                    disabled={!canWrite}
                    value={form.uniquePositioning}
                    onChange={(e) => setField('uniquePositioning', e.target.value)}
                    placeholder="What differentiates this channel from competitors in the same niche..."
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>

            {/* Section 2: Content Format & Storytelling */}
            <div className="space-y-3">
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                2. Format, Voice & Storytelling System
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Content Categories (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.contentCategories}
                    onChange={(e) => setField('contentCategories', e.target.value)}
                    placeholder="Tutorials, Case Studies, Teardowns, Experiments"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Content Format
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.contentFormat}
                    onChange={(e) => setField('contentFormat', e.target.value)}
                    placeholder="Long-form talking head + screen walkthroughs"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Video Style
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.videoStyle}
                    onChange={(e) => setField('videoStyle', e.target.value)}
                    placeholder="Fast-paced documentary / clean whiteboard / practical studio"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Video Duration
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.preferredVideoDuration}
                    onChange={(e) => setField('preferredVideoDuration', e.target.value)}
                    placeholder="10–14 minutes"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tone of Voice
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.toneOfVoice}
                    onChange={(e) => setField('toneOfVoice', e.target.value)}
                    placeholder="Direct, analytical, encouraging, zero hype"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Storytelling Approach
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.storytellingApproach}
                    onChange={(e) => setField('storytellingApproach', e.target.value)}
                    placeholder="Real-world problem → experiment → evidence → repeatable system"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Video Formats (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.preferredFormats}
                    onChange={(e) => setField('preferredFormats', e.target.value)}
                    placeholder="Long-form tutorials, Shorts, Live Q&A, Community Polls"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Brand Voice
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.brandVoice}
                    onChange={(e) => setField('brandVoice', e.target.value)}
                    placeholder="Trusted mentor, calm builder, evidence-first teacher"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Publishing Preferences
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.publishingPreferences}
                    onChange={(e) => setField('publishingPreferences', e.target.value)}
                    placeholder="e.g., 1 long-form every Tuesday 4 PM + 2 Shorts + 1 Community Poll"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Script Structure
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.scriptStructure}
                    onChange={(e) => setField('scriptStructure', e.target.value)}
                    placeholder="0-20s curiosity hook → stakes → 3 numbered steps with proof → clear next action"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Packaging, Visual Identity & Guardrails */}
            <div className="space-y-3">
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2">
                3. Titles, Thumbnails & Vocabulary Guardrails
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Title Preferences
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.titlePreferences}
                    onChange={(e) => setField('titlePreferences', e.target.value)}
                    placeholder="Under 60 chars, specific outcomes, curiosity without clickbait"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Thumbnail Design Preferences
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.thumbnailDesignPreferences}
                    onChange={(e) => setField('thumbnailDesignPreferences', e.target.value)}
                    placeholder="Clean 1-subject composition, 2–3 bold words max, high contrast"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Color Palette (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.colorPalette}
                    onChange={(e) => setField('colorPalette', e.target.value)}
                    placeholder="#0F172A, #2563EB, #FACC15, #FFFFFF"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Typography
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.typography}
                    onChange={(e) => setField('typography', e.target.value)}
                    placeholder="Heavy geometric sans (Montserrat / Inter ExtraBold)"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Words & Phrases to Use (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.wordsToUse}
                    onChange={(e) => setField('wordsToUse', e.target.value)}
                    placeholder="workflow, repeatable system, tested, practical breakdown"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Words &amp; Styles to Avoid (comma-separated)
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={form.wordsToAvoid}
                    onChange={(e) => setField('wordsToAvoid', e.target.value)}
                    placeholder="INSANE, MIND-BLOWING, overnight hack, clickbait arrows"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Content Rules &amp; Guardrails
                  </label>
                  <textarea
                    rows={2}
                    disabled={!canWrite}
                    value={form.contentRules}
                    onChange={(e) => setField('contentRules', e.target.value)}
                    placeholder="e.g., Always back claims with screenshots or tests; never promise overnight viral results"
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Creative Guidelines
                  </label>
                  <textarea
                    rows={2}
                    disabled={!canWrite}
                    value={form.creativeGuidelines}
                    onChange={(e) => setField('creativeGuidelines', e.target.value)}
                    placeholder="e.g., Clean visual pacing, pattern interrupt every 45s, clear on-screen summaries"
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
              </div>
            </div>

            {/* Actions Footer */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div>
                {!creatingNew && editingId && canWrite && profiles.length > 1 && (
                  <button
                    type="button"
                    disabled={deleting}
                    onClick={() => void handleDelete()}
                    className="h-9 px-3 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-semibold inline-flex items-center gap-1.5"
                  >
                    {deleting ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Trash2 className="w-3.5 h-3.5" />
                    )}
                    <span>Delete Channel Profile</span>
                  </button>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="h-9 px-4 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold"
                >
                  Close
                </button>
                {canWrite && (
                  <button
                    type="submit"
                    disabled={saving}
                    className="h-9 px-5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold inline-flex items-center gap-1.5"
                  >
                    {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                    <span>{creatingNew ? 'Create Channel DNA' : 'Save Channel DNA'}</span>
                  </button>
                )}
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
