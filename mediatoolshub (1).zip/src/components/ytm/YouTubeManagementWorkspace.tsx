import React, { useCallback, useEffect, useState } from 'react';
import {
  AlertCircle,
  BarChart3,
  CalendarDays,
  Check,
  ChevronDown,
  Copy,
  Dna,
  DollarSign,
  ExternalLink,
  GraduationCap,
  KeyRound,
  LayoutDashboard,
  Loader2,
  LogIn,
  Menu,
  MessageSquare,
  Plus,
  Radar,
  RefreshCw,
  Settings2,
  Users,
  Workflow,
  X,
  Youtube,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';
import type {
  YtmChannelProfileWithDna,
  YtmOAuthCredentialDiagnostics,
  YtmPlannerProjectRecord,
  YtmSidebarSection,
  YtmWorkspaceRecord,
} from '../../shared/types.ts';
import {
  hasYtmPermission,
  validateGoogleOAuthAuthorizationUrl,
  YTM_ROLE_LABELS,
  YTM_SIDEBAR_SECTIONS,
} from '../../shared/ytmHelpers.ts';
import { copyToClipboard, ytmRequest, type YtmAuthStatusData } from './YtmApiClient.ts';
import { YtmAnalyticsView } from './YtmAnalyticsView.tsx';
import { YtmChannelDnaModal } from './YtmChannelDnaModal.tsx';
import { YtmCommunityView } from './YtmCommunityView.tsx';
import { YtmCompetitorsView } from './YtmCompetitorsView.tsx';
import { YtmDashboardView } from './YtmDashboardView.tsx';
import { YtmEarnView } from './YtmEarnView.tsx';
import { YtmOthersView } from './YtmOthersView.tsx';
import { YtmPerformanceCoachView } from './YtmPerformanceCoachView.tsx';
import { YtmPlannerView, type YtmPlannerTab } from './YtmPlannerView.tsx';
import { YtmTeamView } from './YtmTeamView.tsx';
import { YtmWorkflowView } from './YtmWorkflowView.tsx';
import { YtmAiAgentWidget } from './YtmAiAgentWidget.tsx';

const SECTION_ICONS: Record<YtmSidebarSection, React.ComponentType<{ className?: string }>> = {
  dashboard: LayoutDashboard,
  competitors: Radar,
  planner: CalendarDays,
  workflow: Workflow,
  analytics: BarChart3,
  coach: GraduationCap,
  earn: DollarSign,
  community: MessageSquare,
  team: Users,
  others: Settings2,
};

interface WorkspacesResponse {
  workspaces: YtmWorkspaceRecord[];
  pendingInvites: Array<{
    token: string;
    role: string;
    workspaceName: string;
    expiresAt: string;
  }>;
}

function parseSectionFromPath(currentPath: string): YtmSidebarSection {
  const clean = currentPath.split('?')[0].replace(/\/+$/, '');
  const prefix = '/youtube-management';
  if (!clean.startsWith(prefix)) return 'dashboard';
  const rest = clean.slice(prefix.length).replace(/^\/+/, '');
  const valid = YTM_SIDEBAR_SECTIONS.map((s) => s.id);
  return valid.includes(rest as YtmSidebarSection) ? (rest as YtmSidebarSection) : 'dashboard';
}

export function YouTubeManagementWorkspace() {
  const { authFetch, firebaseUser, authLoading, signInWithGoogle, currentPath, navigate } = useApp();
  const activeSection = parseSectionFromPath(currentPath);

  const [workspaces, setWorkspaces] = useState<YtmWorkspaceRecord[]>([]);
  const [pendingInvites, setPendingInvites] = useState<WorkspacesResponse['pendingInvites']>([]);
  const [activeKey, setActiveKey] = useState<string>(() => {
    if (typeof window === 'undefined') return '';
    return window.localStorage.getItem('mth_ytm_workspace_key') || '';
  });
  const [authStatus, setAuthStatus] = useState<YtmAuthStatusData | null>(null);
  const [loadingWs, setLoadingWs] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [showNewWs, setShowNewWs] = useState(false);
  const [newWsName, setNewWsName] = useState('');
  const [newWsGoal, setNewWsGoal] = useState('');
  const [creatingWs, setCreatingWs] = useState(false);

  const [selectedWorkflowId, setSelectedWorkflowId] = useState<number | null>(() => {
    if (typeof window === 'undefined') return null;
    const w = new URLSearchParams(window.location.search).get('workflowId');
    return w ? Number.parseInt(w, 10) || null : null;
  });

  // Channel DNA profiles state (multi-channel support)
  const [channelProfiles, setChannelProfiles] = useState<YtmChannelProfileWithDna[]>([]);
  const [activeChannelProfileId, setActiveChannelProfileId] = useState<number | null>(() => {
    if (typeof window === 'undefined') return null;
    const raw = window.localStorage.getItem('mth_ytm_channel_profile_id');
    const parsed = raw ? Number.parseInt(raw, 10) : NaN;
    return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
  });
  const [showChannelDnaModal, setShowChannelDnaModal] = useState(false);
  const [showWorkspaceDetailsModal, setShowWorkspaceDetailsModal] = useState(false);
  const [editWsName, setEditWsName] = useState('');
  const [editWsDesc, setEditWsDesc] = useState('');
  const [editWsGoal, setEditWsGoal] = useState('');
  const [savingWsDetails, setSavingWsDetails] = useState(false);
  const [wsDetailsNotice, setWsDetailsNotice] = useState<string | null>(null);
  const [plannerInitialTab, setPlannerInitialTab] = useState<YtmPlannerTab>('calendar');
  const [openNewIdeaSignal, setOpenNewIdeaSignal] = useState(0);
  const [focusNewVideoSignal, setFocusNewVideoSignal] = useState(0);

  // OAuth Modal state
  const [oauthModal, setOauthModal] = useState<{
    mode: 'ready' | 'setup_required' | 'config_error';
    authUrl?: string;
    redirectUri?: string;
    missingVars?: string[];
    errorTitle?: string;
    errorMessage?: string;
    diagnostics?: YtmOAuthCredentialDiagnostics;
  } | null>(null);
  const [checkingOAuth, setCheckingOAuth] = useState(false);
  const [copiedRedirectUri, setCopiedRedirectUri] = useState(false);
  const [copyError, setCopyError] = useState<string | null>(null);

  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  const handleCopyRedirectUri = async (uri: string) => {
    setCopyError(null);
    const ok = await copyToClipboard(uri);
    if (ok) {
      setCopiedRedirectUri(true);
      setTimeout(() => setCopiedRedirectUri(false), 2500);
    } else {
      setCopiedRedirectUri(false);
      setCopyError('Clipboard access was blocked by the browser. Select and copy the URL manually.');
    }
  };

  const activeWorkspace = workspaces.find((w) => w.workspaceKey === activeKey) || workspaces[0] || null;
  const activeChannelProfile =
    channelProfiles.find((p) => p.id === activeChannelProfileId) ||
    channelProfiles.find((p) => p.isDefault) ||
    channelProfiles[0] ||
    null;

  const loadWorkspaces = useCallback(async () => {
    if (!firebaseUser) {
      setLoadingWs(false);
      return;
    }
    setLoadingWs(true);
    setError(null);
    try {
      const res = await ytmRequest<WorkspacesResponse>(authFetch, '/workspaces');
      setWorkspaces(res.workspaces || []);
      setPendingInvites(res.pendingInvites || []);
      if (res.workspaces?.length) {
        setActiveKey((prev) => {
          const valid = res.workspaces.some((w) => w.workspaceKey === prev);
          const chosen = valid ? prev : res.workspaces[0].workspaceKey;
          window.localStorage.setItem('mth_ytm_workspace_key', chosen);
          return chosen;
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load YouTube Management workspaces.');
    } finally {
      setLoadingWs(false);
    }
  }, [authFetch, firebaseUser]);

  const loadAuthStatus = useCallback(async () => {
    if (!firebaseUser || !activeWorkspace) return;
    try {
      const status = await ytmRequest<YtmAuthStatusData>(authFetch, '/auth/status', {
        workspaceKey: activeWorkspace.workspaceKey,
      });
      setAuthStatus(status);
    } catch {
      // Non-blocking status check
    }
  }, [authFetch, firebaseUser, activeWorkspace]);

  const loadChannelProfiles = useCallback(async () => {
    if (!firebaseUser || !activeWorkspace) return;
    try {
      const res = await ytmRequest<{ profiles: YtmChannelProfileWithDna[] }>(
        authFetch,
        '/channel-profiles',
        { workspaceKey: activeWorkspace.workspaceKey }
      );
      const list = res.profiles || [];
      setChannelProfiles(list);
      if (list.length > 0) {
        setActiveChannelProfileId((prev) => {
          const valid = prev && list.some((p) => p.id === prev);
          const chosen = valid ? prev : (list.find((p) => p.isDefault) || list[0]).id;
          window.localStorage.setItem('mth_ytm_channel_profile_id', String(chosen));
          return chosen;
        });
      } else {
        setActiveChannelProfileId(null);
      }
    } catch {
      // Non-blocking profile refresh
    }
  }, [authFetch, firebaseUser, activeWorkspace]);

  useEffect(() => {
    void loadWorkspaces();
  }, [loadWorkspaces]);

  useEffect(() => {
    void loadAuthStatus();
  }, [loadAuthStatus]);

  useEffect(() => {
    void loadChannelProfiles();
  }, [loadChannelProfiles]);

  // Listen for OAuth completion postMessage, window focus return, and same-tab callback params
  useEffect(() => {
    const onMessage = (ev: MessageEvent) => {
      if (!ev.data || typeof ev.data !== 'object') return;
      if (ev.data.type === 'YTM_OAUTH_SUCCESS') {
        setOauthModal(null);
        setError(null);
        void loadAuthStatus();
      } else if (ev.data.type === 'YTM_OAUTH_ERROR') {
        setOauthModal(null);
        setError(
          typeof ev.data.message === 'string' && ev.data.message
            ? ev.data.message
            : 'Google OAuth authorization failed or was cancelled.'
        );
      }
    };
    const onFocus = () => {
      if (oauthModal?.mode === 'ready') {
        void loadAuthStatus();
      }
    };
    window.addEventListener('message', onMessage);
    window.addEventListener('focus', onFocus);
    return () => {
      window.removeEventListener('message', onMessage);
      window.removeEventListener('focus', onFocus);
    };
  }, [loadAuthStatus, oauthModal]);

  useEffect(() => {
    if (typeof window === 'undefined' || !activeWorkspace) return;
    const params = new URLSearchParams(window.location.search);
    const oauthState = params.get('oauth');
    if (oauthState === 'connected' || oauthState === 'error') {
      if (oauthState === 'connected') {
        setOauthModal(null);
        void loadAuthStatus();
      } else {
        setError('Google OAuth authorization was cancelled or returned an error.');
      }
      params.delete('oauth');
      const nextSearch = params.toString();
      const nextUrl = `${window.location.pathname}${nextSearch ? `?${nextSearch}` : ''}`;
      window.history.replaceState({}, '', nextUrl);
    }
  }, [activeWorkspace, loadAuthStatus]);

  const handleSelectSection = (section: YtmSidebarSection) => {
    setMobileNavOpen(false);
    navigate(`/youtube-management/${section}`);
  };

  const handleSelectChannelProfile = (profileId: number) => {
    setActiveChannelProfileId(profileId);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('mth_ytm_channel_profile_id', String(profileId));
    }
  };

  const handleOpenContentPlanner = (tab: YtmPlannerTab = 'calendar') => {
    setPlannerInitialTab(tab);
    handleSelectSection('planner');
  };

  const handleOpenAddContentIdea = () => {
    setPlannerInitialTab('calendar');
    setOpenNewIdeaSignal((n) => n + 1);
    handleSelectSection('planner');
  };

  const handleCreateNewVideo = () => {
    setFocusNewVideoSignal((n) => n + 1);
    handleSelectSection('workflow');
  };

  const handleSwitchWorkspace = (key: string) => {
    setActiveKey(key);
    window.localStorage.setItem('mth_ytm_workspace_key', key);
  };

  const handleCreateWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWsName.trim()) return;
    setCreatingWs(true);
    setError(null);
    try {
      const res = await ytmRequest<{ workspace: YtmWorkspaceRecord }>(authFetch, '/workspaces', {
        method: 'POST',
        body: { name: newWsName.trim(), channelGoal: newWsGoal.trim() },
      });
      setNewWsName('');
      setNewWsGoal('');
      setShowNewWs(false);
      setActiveKey(res.workspace.workspaceKey);
      window.localStorage.setItem('mth_ytm_workspace_key', res.workspace.workspaceKey);
      await loadWorkspaces();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to create workspace.');
    } finally {
      setCreatingWs(false);
    }
  };

  const handleAcceptInvite = async (token: string) => {
    try {
      await ytmRequest(authFetch, `/workspaces/invitations/${encodeURIComponent(token)}/accept`, {
        method: 'POST',
        body: {},
      });
      await loadWorkspaces();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to accept workspace invitation.');
    }
  };

  const handleConnectYouTube = async () => {
    if (!activeWorkspace) return;
    setCheckingOAuth(true);
    setError(null);
    try {
      const endpoint = `/api/v1/ytm/auth/google?workspaceKey=${encodeURIComponent(activeWorkspace.workspaceKey)}`;
      const fetchInit: RequestInit = {
        cache: 'no-store',
        headers: { Accept: 'application/json' },
      };

      let res = await authFetch(endpoint, fetchInit);
      let contentType = res.headers.get('content-type') || '';
      let rawText = await res.text();

      // If the hosting proxy returned a transient warmup page while the backend restarted, retry once.
      if (!contentType.includes('application/json') && /warmup|starting|loading/i.test(rawText)) {
        await new Promise((resolve) => setTimeout(resolve, 900));
        res = await authFetch(endpoint, fetchInit);
        contentType = res.headers.get('content-type') || '';
        rawText = await res.text();
      }

      if (!contentType.includes('application/json')) {
        if (res.redirected || /__cookie_check|cookie check/i.test(rawText)) {
          throw new Error(
            'Your preview session needs to refresh before starting Google OAuth. Reload the page and click Connect YouTube Channel again.'
          );
        }
        throw new Error(
          `OAuth initiation endpoint returned non-JSON response (${res.status}). Reload the page or check backend API routing.`
        );
      }

      let raw: {
        ok?: boolean;
        code?: string;
        message?: string;
        redirectUri?: string;
        missingVars?: string[];
        diagnostics?: YtmOAuthCredentialDiagnostics;
        data?: {
          authorizationUrl?: string;
          url?: string;
          redirectUri?: string;
        };
        error?: {
          code?: string;
          message?: string;
          setupRequired?: boolean;
          redirectUri?: string;
          missingVars?: string[];
          diagnostics?: YtmOAuthCredentialDiagnostics;
          credentialDiagnostics?: YtmOAuthCredentialDiagnostics;
        };
      } | null = null;

      try {
        raw = JSON.parse(rawText);
      } catch {
        throw new Error('OAuth initiation endpoint returned invalid JSON.');
      }

      const errorCode = raw?.error?.code || raw?.code;
      const errorMessage = raw?.error?.message || raw?.message;
      const diagnostics =
        raw?.error?.credentialDiagnostics || raw?.error?.diagnostics || raw?.diagnostics;
      const redirectUri = raw?.error?.redirectUri || raw?.redirectUri || authStatus?.redirectUri;
      const missingVars = raw?.error?.missingVars || raw?.missingVars;

      const isSetupMissing =
        res.status === 422 ||
        res.status === 503 ||
        raw?.error?.setupRequired ||
        errorCode === 'OAUTH_NOT_CONFIGURED' ||
        Boolean(missingVars?.length) ||
        Boolean(diagnostics?.clientIdIsPlaceholderLiteral) ||
        Boolean(diagnostics?.clientSecretIsPlaceholderLiteral);

      const isConfigIssue =
        errorCode === 'GOOGLE_OAUTH_CONFIGURATION_INVALID' ||
        errorCode === 'OAUTH_INVALID_CLIENT' ||
        errorCode === 'OAUTH_CONFIGURATION_ERROR';

      if (isSetupMissing) {
        setCopiedRedirectUri(false);
        setCopyError(null);
        setOauthModal({
          mode: 'setup_required',
          errorMessage,
          redirectUri,
          missingVars:
            missingVars && missingVars.length > 0
              ? missingVars
              : ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET'],
          diagnostics,
        });
        return;
      }

      if (isConfigIssue) {
        setCopiedRedirectUri(false);
        setCopyError(null);
        setOauthModal({
          mode: 'config_error',
          errorTitle:
            errorCode === 'OAUTH_INVALID_CLIENT'
              ? 'Google OAuth Rejected Client ID (401 invalid_client)'
              : 'Google OAuth Configuration Error',
          errorMessage: errorMessage || 'Configured Google OAuth client could not be validated.',
          redirectUri,
          missingVars,
          diagnostics,
        });
        return;
      }

      if (!res.ok || raw?.ok === false) {
        throw new Error(errorMessage || 'Unable to start YouTube OAuth connection.');
      }

      const rawAuthUrl = raw?.data?.authorizationUrl || raw?.data?.url;
      const validatedAuthUrl = validateGoogleOAuthAuthorizationUrl(rawAuthUrl);

      setCopiedRedirectUri(false);
      setCopyError(null);
      setOauthModal({
        mode: 'ready',
        authUrl: validatedAuthUrl,
        redirectUri: raw?.data?.redirectUri,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to prepare YouTube OAuth.');
    } finally {
      setCheckingOAuth(false);
    }
  };

  const handleProceedToGoogleOAuth = (e?: React.MouseEvent<HTMLElement>) => {
    if (!oauthModal?.authUrl) return;
    try {
      const validatedUrl = validateGoogleOAuthAuthorizationUrl(oauthModal.authUrl);
      const isInIframe = typeof window !== 'undefined' && window.self !== window.top;
      if (!isInIframe) {
        if (e) e.preventDefault();
        window.location.assign(validatedUrl);
      }
    } catch (err) {
      if (e) e.preventDefault();
      setError(err instanceof Error ? err.message : 'Invalid Google OAuth authorization URL.');
    }
  };

  const handleDisconnectYouTube = async () => {
    if (!activeWorkspace) return;
    await ytmRequest(authFetch, '/auth/disconnect', {
      workspaceKey: activeWorkspace.workspaceKey,
      method: 'POST',
      body: {},
    });
    await loadAuthStatus();
  };

  const handleOpenPlannerInWorkflow = async (project: YtmPlannerProjectRecord) => {
    if (!activeWorkspace) return;
    if (project.workflowProjectId) {
      setSelectedWorkflowId(project.workflowProjectId);
      handleSelectSection('workflow');
      return;
    }
    const res = await ytmRequest<{ workflow: { id: number } }>(authFetch, '/workflow/projects', {
      workspaceKey: activeWorkspace.workspaceKey,
      method: 'POST',
      body: {
        title: project.title,
        plannerProjectId: project.id,
        channelProfileId: project.channelProfileId ?? activeChannelProfile?.id ?? undefined,
        savedInspirationId: project.savedInspirationId ?? undefined,
        adaptedIdeaId: project.adaptedIdeaId ?? undefined,
        topic: project.topic,
        targetAudience: project.targetAudience,
        adaptedAngle: project.adaptedAngle,
        notes: project.notes,
      },
    });
    setSelectedWorkflowId(res.workflow.id);
    handleSelectSection('workflow');
  };

  const handleCreateWorkflowFromSeed = async (seed: {
    title: string;
    topic?: string;
    notes?: string;
    targetAudience?: string;
    adaptedAngle?: string;
  }) => {
    if (!activeWorkspace) return;
    const res = await ytmRequest<{ workflow: { id: number } }>(authFetch, '/workflow/projects', {
      workspaceKey: activeWorkspace.workspaceKey,
      method: 'POST',
      body: {
        title: seed.title,
        seedIdea: seed.topic || seed.title,
        topic: seed.topic || seed.title,
        targetAudience: seed.targetAudience,
        adaptedAngle: seed.adaptedAngle,
        notes: seed.notes,
        channelProfileId: activeChannelProfile?.id ?? undefined,
      },
    });
    setSelectedWorkflowId(res.workflow.id);
    handleSelectSection('workflow');
  };

  if (authLoading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Initializing YouTube Creator Operating System…</span>
      </div>
    );
  }

  if (!firebaseUser) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-16">
        <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 sm:p-10 text-center space-y-5">
          <div className="w-14 h-14 rounded-2xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-center justify-center mx-auto text-red-600 dark:text-red-400">
            <Youtube className="w-7 h-7" />
          </div>
          <div className="space-y-2">
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-950 dark:text-white">
              YouTube Management · Creator Operating System
            </h1>
            <p className="text-sm text-slate-600 dark:text-slate-400 max-w-xl mx-auto leading-relaxed">
              Sign in with your Google account to unlock your private creator workspace: Daily Plan, Content Planner, 6-Stage Video Workflow, Own-Channel Analytics, Brand Deal CRM, Comment Manager, and 8-Role Team Delegation.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void signInWithGoogle()}
            className="h-11 px-6 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold inline-flex items-center gap-2"
          >
            <LogIn className="w-4 h-4" />
            <span>Sign in with Google to Open Workspace</span>
          </button>
        </div>
      </div>
    );
  }

  if (loadingWs && !activeWorkspace) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Loading creator workspace…</span>
      </div>
    );
  }

  const role = activeWorkspace?.myRole || 'viewer';
  const canWritePlanner = hasYtmPermission(role, 'planner:write');
  const canWriteWorkflow = hasYtmPermission(role, 'workflow:write');
  const canApproveWorkflow = hasYtmPermission(role, 'workflow:approve');
  const canPublishYouTube = hasYtmPermission(role, 'publish:youtube');
  const canReadAnalytics = hasYtmPermission(role, 'analytics:read');
  const canReadEarn = hasYtmPermission(role, 'earn:read');
  const canWriteEarn = hasYtmPermission(role, 'earn:write');
  const canWriteCommunity = hasYtmPermission(role, 'community:write');
  const canManageTeam = hasYtmPermission(role, 'team:manage');
  const canManageWorkspace = hasYtmPermission(role, 'workspace:manage');
  const canManageOAuth = hasYtmPermission(role, 'oauth:manage');
  const connectedChannel = authStatus?.connectedChannel || null;

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Pending Invitations Banner */}
      {pendingInvites.length > 0 && (
        <div className="mb-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/70 dark:bg-blue-950/30 p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
          {pendingInvites.map((inv) => (
            <div key={inv.token} className="flex flex-wrap items-center justify-between gap-3 w-full">
              <div>
                <strong>Team Invitation:</strong> Join <strong>{inv.workspaceName}</strong> as{' '}
                <strong>{inv.role}</strong>.
              </div>
              <button
                type="button"
                onClick={() => void handleAcceptInvite(inv.token)}
                className="h-8 px-3.5 rounded-lg bg-blue-600 text-white font-semibold"
              >
                Accept Invitation
              </button>
            </div>
          ))}
        </div>
      )}

      {error && (
        <div className="mb-4 p-3.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-6 items-start">
        {/* Mobile Header */}
        <div className="lg:hidden w-full flex items-center justify-between gap-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3">
          <button
            type="button"
            onClick={() => setMobileNavOpen((v) => !v)}
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold inline-flex items-center gap-1.5"
          >
            <Menu className="w-4 h-4" />
            <span>
              {YTM_SIDEBAR_SECTIONS.find((s) => s.id === activeSection)?.label || 'Menu'}
            </span>
          </button>
          <span className="text-xs font-semibold truncate">{activeWorkspace?.name}</span>
        </div>

        {/* Left 256px Navigation Sidebar */}
        <aside
          className={`${
            mobileNavOpen ? 'block' : 'hidden'
          } lg:block w-full lg:w-64 shrink-0 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 space-y-4`}
        >
          {/* Workspace Selector */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              <span>Creator Workspace</span>
              <div className="inline-flex items-center gap-2 normal-case">
                <button
                  type="button"
                  onClick={() => {
                    if (activeWorkspace) {
                      setEditWsName(activeWorkspace.name);
                      setEditWsDesc(activeWorkspace.description || '');
                      setEditWsGoal(activeWorkspace.channelGoal || '');
                    }
                    setWsDetailsNotice(null);
                    setShowWorkspaceDetailsModal(true);
                  }}
                  className="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 inline-flex items-center gap-0.5 font-semibold"
                >
                  <Settings2 className="w-3 h-3" />
                  <span>Details</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowNewWs((v) => !v)}
                  className="text-blue-600 dark:text-blue-400 inline-flex items-center gap-0.5 font-semibold"
                >
                  <Plus className="w-3 h-3" />
                  <span>New</span>
                </button>
              </div>
            </div>
            <div className="relative">
              <select
                value={activeWorkspace?.workspaceKey || ''}
                onChange={(e) => handleSwitchWorkspace(e.target.value)}
                className="w-full h-10 pl-3 pr-8 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-semibold text-slate-900 dark:text-white appearance-none"
              >
                {workspaces.map((w) => (
                  <option key={w.workspaceKey} value={w.workspaceKey}>
                    {w.name} ({YTM_ROLE_LABELS[w.myRole]})
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
            </div>

            {showNewWs && (
              <form onSubmit={handleCreateWorkspace} className="pt-1 space-y-2 text-xs">
                <input
                  type="text"
                  required
                  value={newWsName}
                  onChange={(e) => setNewWsName(e.target.value)}
                  placeholder="Channel / Brand workspace name"
                  className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
                <input
                  type="text"
                  value={newWsGoal}
                  onChange={(e) => setNewWsGoal(e.target.value)}
                  placeholder="Optional channel goal"
                  className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                />
                <div className="flex justify-end gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowNewWs(false)}
                    className="h-8 px-2.5 rounded border border-slate-200 dark:border-slate-700"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={creatingWs}
                    className="h-8 px-3 rounded bg-blue-600 text-white font-semibold"
                  >
                    Create
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Exact 10 Ordered Sidebar Sections */}
          <nav className="space-y-1 pt-2 border-t border-slate-200 dark:border-slate-800" aria-label="YouTube Management sections">
            {YTM_SIDEBAR_SECTIONS.map((sec) => {
              const Icon = SECTION_ICONS[sec.id];
              const isActive = activeSection === sec.id;
              return (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => handleSelectSection(sec.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg flex items-start gap-2.5 transition-colors ${
                    isActive
                      ? 'bg-blue-600 text-white'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 mt-0.5 ${
                      isActive ? 'text-white' : 'text-slate-500 dark:text-slate-400'
                    }`}
                  />
                  <div className="min-w-0">
                    <div className="text-xs font-semibold truncate">
                      {sec.order}. {sec.label}
                    </div>
                    <div
                      className={`text-[11px] truncate ${
                        isActive ? 'text-blue-100' : 'text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      {sec.shortDesc}
                    </div>
                  </div>
                </button>
              );
            })}
          </nav>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 min-w-0 space-y-5 w-full">
          {/* Top Workspace Status Bar (hidden on Dashboard because Dashboard Section A owns the single compact Channel Header) */}
          {activeSection !== 'dashboard' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                {connectedChannel?.thumbnailUrl ? (
                  <img
                    src={connectedChannel.thumbnailUrl}
                    alt={connectedChannel.channelTitle}
                    referrerPolicy="no-referrer"
                    className="w-8 h-8 rounded-full border border-slate-200 dark:border-slate-700 object-cover"
                  />
                ) : (
                  <div className="w-8 h-8 rounded-lg bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-center justify-center text-red-600 dark:text-red-400 shrink-0">
                    <Youtube className="w-4 h-4" />
                  </div>
                )}
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-950 dark:text-white truncate">
                    {connectedChannel
                      ? `${connectedChannel.channelTitle} (Connected)`
                      : 'No YouTube Channel Connected'}
                  </div>
                  <div className="text-[11px] text-slate-500 truncate">
                    Workspace: {activeWorkspace?.name} · Role: {YTM_ROLE_LABELS[role]}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    if (activeWorkspace) {
                      setEditWsName(activeWorkspace.name);
                      setEditWsDesc(activeWorkspace.description || '');
                      setEditWsGoal(activeWorkspace.channelGoal || '');
                    }
                    setWsDetailsNotice(null);
                    setShowWorkspaceDetailsModal(true);
                  }}
                  className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 hover:border-blue-500 font-semibold text-slate-800 dark:text-slate-100 inline-flex items-center gap-1.5"
                >
                  <Settings2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Workspace Details</span>
                </button>
                {connectedChannel ? (
                  <button
                    type="button"
                    onClick={() => void loadAuthStatus()}
                    className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Sync Channel</span>
                  </button>
                ) : (
                  canManageOAuth && (
                    <button
                      type="button"
                      disabled={checkingOAuth}
                      onClick={() => void handleConnectYouTube()}
                      className="h-8 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
                    >
                      {checkingOAuth ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Youtube className="w-3.5 h-3.5" />
                      )}
                      <span>Connect YouTube Channel</span>
                    </button>
                  )
                )}
              </div>
            </div>
          )}

          {/* Active Section Body */}
          {activeWorkspace && (
            <>
              {activeSection === 'dashboard' && (
                <YtmDashboardView
                  authFetch={authFetch}
                  workspaceKey={activeWorkspace.workspaceKey}
                  canWritePlanner={canWritePlanner}
                  canManageOAuth={canManageOAuth}
                  checkingOAuth={checkingOAuth}
                  onConnectYouTube={() => void handleConnectYouTube()}
                  onSyncChannel={() => void loadAuthStatus()}
                  onCreateNewVideo={handleCreateNewVideo}
                  onAddContentIdea={handleOpenAddContentIdea}
                  onOpenContentPlanner={handleOpenContentPlanner}
                  onViewAnalytics={() => handleSelectSection('analytics')}
                  onOpenProjectInWorkflow={handleOpenPlannerInWorkflow}
                />
              )}

              {activeSection === 'planner' && (
                <YtmPlannerView
                  authFetch={authFetch}
                  workspace={activeWorkspace}
                  canWrite={canWritePlanner}
                  channelProfiles={channelProfiles}
                  activeChannelProfileId={activeChannelProfile?.id ?? null}
                  initialTab={plannerInitialTab}
                  openNewIdeaSignal={openNewIdeaSignal}
                  onOpenInWorkflow={handleOpenPlannerInWorkflow}
                />
              )}

              {activeSection === 'competitors' && (
                <YtmCompetitorsView
                  authFetch={authFetch}
                  workspaceKey={activeWorkspace.workspaceKey}
                  canWrite={canWritePlanner}
                  channelProfiles={channelProfiles}
                  activeChannelProfileId={activeChannelProfile?.id ?? null}
                  onOpenPlanner={() => {
                    setPlannerInitialTab('saved_inspiration');
                    handleSelectSection('planner');
                  }}
                  onSendToWorkflow={handleCreateWorkflowFromSeed}
                />
              )}

              {activeSection === 'workflow' && (
                <YtmWorkflowView
                  authFetch={authFetch}
                  workspaceKey={activeWorkspace.workspaceKey}
                  canWrite={canWriteWorkflow}
                  canApprove={canApproveWorkflow}
                  canPublishYouTube={canPublishYouTube}
                  connectedChannel={connectedChannel}
                  activeChannelProfile={activeChannelProfile}
                  initialWorkflowId={selectedWorkflowId}
                  focusNewVideoSignal={focusNewVideoSignal}
                  onConnectYouTube={() => void handleConnectYouTube()}
                />
              )}

              {activeSection === 'analytics' &&
                (canReadAnalytics ? (
                  <YtmAnalyticsView
                    authFetch={authFetch}
                    workspaceKey={activeWorkspace.workspaceKey}
                    connectedChannel={connectedChannel}
                    onConnectYouTube={() => void handleConnectYouTube()}
                  />
                ) : (
                  <PermissionNotice role={role} area="Analytics & Growth" />
                ))}

              {activeSection === 'coach' &&
                (canReadAnalytics ? (
                  <YtmPerformanceCoachView
                    authFetch={authFetch}
                    workspaceKey={activeWorkspace.workspaceKey}
                    canWrite={canWritePlanner}
                    connectedChannel={connectedChannel}
                    activeChannelProfileId={activeChannelProfile?.id ?? null}
                    onConnectYouTube={() => void handleConnectYouTube()}
                    onOpenPlanner={() => {
                      setPlannerInitialTab('calendar');
                      handleSelectSection('planner');
                    }}
                    onOpenWorkflow={(wfId) => {
                      setSelectedWorkflowId(wfId);
                      handleSelectSection('workflow');
                    }}
                  />
                ) : (
                  <PermissionNotice role={role} area="Creator Performance Coach" />
                ))}

              {activeSection === 'earn' &&
                (canReadEarn ? (
                  <YtmEarnView
                    authFetch={authFetch}
                    workspaceKey={activeWorkspace.workspaceKey}
                    canWrite={canWriteEarn}
                    connectedChannel={connectedChannel}
                  />
                ) : (
                  <PermissionNotice role={role} area="Earn & Brand Deal CRM" />
                ))}

              {activeSection === 'community' && (
                <YtmCommunityView
                  authFetch={authFetch}
                  workspaceKey={activeWorkspace.workspaceKey}
                  canWrite={canWriteCommunity}
                  connectedChannel={connectedChannel}
                  onConnectYouTube={() => void handleConnectYouTube()}
                />
              )}

              {activeSection === 'team' && (
                <YtmTeamView
                  authFetch={authFetch}
                  workspace={activeWorkspace}
                  canManageTeam={canManageTeam}
                  canApprove={canApproveWorkflow}
                />
              )}

              {activeSection === 'others' && (
                <YtmOthersView
                  authFetch={authFetch}
                  workspace={activeWorkspace}
                  canManageWorkspace={canManageWorkspace}
                  canManageOAuth={canManageOAuth}
                  canWriteWorkflow={canWriteWorkflow}
                  authStatus={authStatus}
                  activeChannelProfile={activeChannelProfile}
                  channelProfiles={channelProfiles}
                  onSelectChannelProfile={handleSelectChannelProfile}
                  onOpenChannelDna={() => setShowChannelDnaModal(true)}
                  onWorkspaceUpdated={async () => {
                    await loadWorkspaces();
                    await loadAuthStatus();
                  }}
                  onConnectYouTube={() => void handleConnectYouTube()}
                  onDisconnectYouTube={handleDisconnectYouTube}
                />
              )}
            </>
          )}
        </main>
      </div>

      {/* Google OAuth Ready / Setup / Diagnostic Modal (no window.open needed) */}
      {oauthModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="max-w-xl w-full max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4 text-xs">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-blue-600 shrink-0" />
                <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                  {oauthModal.mode === 'ready'
                    ? 'Authorize Your YouTube Channel'
                    : oauthModal.mode === 'config_error'
                      ? oauthModal.errorTitle || 'Google OAuth Configuration Error'
                      : 'Google OAuth Setup Required'}
                </h3>
              </div>
              <button
                type="button"
                aria-label="Close Google OAuth modal"
                onClick={() => {
                  setOauthModal(null);
                  setCopiedRedirectUri(false);
                  setCopyError(null);
                }}
                className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isInIframe && (
              <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-blue-900 dark:text-blue-200 space-y-2">
                <p className="leading-relaxed">
                  Google OAuth may not work inside an embedded preview. Open MediaToolsHub in a new tab before connecting your channel.
                </p>
                <div className="flex flex-wrap items-center gap-2">
                  <a
                    href={typeof window !== 'undefined' ? window.location.href : '/youtube-management'}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="h-8 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
                  >
                    <span>Open App in New Tab</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <span className="text-[11px] text-blue-700 dark:text-blue-300">
                    If your browser blocks new tabs, copy this page URL into a standalone browser tab.
                  </span>
                </div>
              </div>
            )}

            {oauthModal.mode === 'ready' && oauthModal.authUrl ? (
              <div className="space-y-3">
                <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                  Click below to open Google’s official OAuth consent screen in a new tab and grant read, analytics, upload, and comment permissions for your YouTube channel.
                </p>
                <div className="flex flex-wrap gap-2">
                  <a
                    href={oauthModal.authUrl}
                    target="_blank"
                    rel="opener"
                    onClick={handleProceedToGoogleOAuth}
                    className="h-10 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-2"
                  >
                    <span>Continue to Google OAuth</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <button
                    type="button"
                    onClick={() => {
                      setOauthModal(null);
                      void loadAuthStatus();
                    }}
                    className="h-10 px-4 rounded-xl border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Refresh Connection</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {oauthModal.mode === 'config_error' ? (
                  <div className="p-3 rounded-lg bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 leading-relaxed">
                    {oauthModal.errorMessage || 'Configured Google OAuth client could not be validated.'}
                  </div>
                ) : (
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {oauthModal.diagnostics?.clientIdIsPlaceholderLiteral ||
                    oauthModal.diagnostics?.clientSecretIsPlaceholderLiteral
                      ? 'The running server currently receives 4-character placeholder sentinel values for Google OAuth environment variables instead of real Google Cloud OAuth credentials. Configure the real values in your active runtime environment (or deploy to your Google Cloud Run service with Secret Manager) and restart/redeploy.'
                      : 'Your MediaToolsHub server does not yet have valid Google OAuth client credentials configured in its runtime environment. No fake connection was created.'}
                  </p>
                )}

                {oauthModal.missingVars?.length ? (
                  <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900">
                    <div className="font-semibold text-amber-800 dark:text-amber-300">
                      Unconfigured Server Environment Variables:
                    </div>
                    <div className="font-mono mt-1 text-amber-700 dark:text-amber-200">
                      {oauthModal.missingVars.join(', ')}
                    </div>
                  </div>
                ) : null}

                {oauthModal.diagnostics && (
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1 font-mono text-[11px] text-slate-700 dark:text-slate-300">
                    <div>
                      source: {oauthModal.diagnostics.source || 'server_env'} | dotenv=
                      {String(Boolean(oauthModal.diagnostics.dotenvFilePresent))} | frontendOverride=
                      {String(Boolean(oauthModal.diagnostics.frontendEnvOverridePresent))}
                    </div>
                    {oauthModal.diagnostics.cloudRunService && (
                      <div>
                        service: {oauthModal.diagnostics.cloudRunService}
                        {oauthModal.diagnostics.cloudRunRevision
                          ? ` (${oauthModal.diagnostics.cloudRunRevision})`
                          : ''}
                      </div>
                    )}
                    <div>
                      GOOGLE_CLIENT_ID: present={String(Boolean(oauthModal.diagnostics.clientIdPresent))},
                      rawLen={oauthModal.diagnostics.rawClientIdLength ?? oauthModal.diagnostics.clientIdLength ?? 0},
                      cleanLen={oauthModal.diagnostics.clientIdLength ?? 0}, endsWithApps=
                      {String(Boolean(oauthModal.diagnostics.clientIdEndsWithAppsDomain))}, formatValid=
                      {String(Boolean(oauthModal.diagnostics.clientIdFormatValid))}, placeholder=
                      {String(Boolean(oauthModal.diagnostics.clientIdIsPlaceholderLiteral))} (
                      {oauthModal.diagnostics.clientIdIssueCode || 'none'})
                    </div>
                    <div>
                      GOOGLE_CLIENT_SECRET: present=
                      {String(Boolean(oauthModal.diagnostics.clientSecretPresent))}, rawLen=
                      {oauthModal.diagnostics.rawClientSecretLength ?? oauthModal.diagnostics.clientSecretLength ?? 0},
                      cleanLen={oauthModal.diagnostics.clientSecretLength ?? 0}, formatValid=
                      {String(Boolean(oauthModal.diagnostics.clientSecretFormatValid))}, placeholder=
                      {String(Boolean(oauthModal.diagnostics.clientSecretIsPlaceholderLiteral))} (
                      {oauthModal.diagnostics.clientSecretIssueCode || 'none'})
                    </div>
                    <div>
                      redirectUriValid={String(Boolean(oauthModal.diagnostics.redirectUriValid ?? true))} |
                      redirectSource={oauthModal.diagnostics.redirectUriSource || 'confirmed_default'} |
                      oauthClientInitialized={String(Boolean(oauthModal.diagnostics.oauthClientInitialized))} |
                      authorizationUrlReady={String(Boolean(oauthModal.diagnostics.authorizationUrlReady))}
                    </div>
                    {oauthModal.diagnostics.issues?.length ? (
                      <div className="text-rose-700 dark:text-rose-300">
                        issues: {oauthModal.diagnostics.issues.join(', ')}
                      </div>
                    ) : null}
                    {oauthModal.diagnostics.googleEndpointCheck && (
                      <div>googleCheck: {oauthModal.diagnostics.googleEndpointCheck}</div>
                    )}
                  </div>
                )}

                {oauthModal.redirectUri && (
                  <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-semibold text-slate-700 dark:text-slate-300">
                        Authorized Redirect URI (Google Cloud Console):
                      </div>
                      <button
                        type="button"
                        onClick={() => void handleCopyRedirectUri(oauthModal.redirectUri!)}
                        className="h-7 px-2.5 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 hover:border-blue-500 text-[11px] font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1 shrink-0"
                      >
                        {copiedRedirectUri ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span className="text-emerald-700 dark:text-emerald-400">Copied</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            <span>Copy Redirect URI</span>
                          </>
                        )}
                      </button>
                    </div>
                    <div className="font-mono break-all text-slate-600 dark:text-slate-400 select-all">
                      {oauthModal.redirectUri}
                    </div>
                    {copyError && (
                      <div className="text-[11px] text-amber-700 dark:text-amber-300">{copyError}</div>
                    )}
                  </div>
                )}

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1.5">
                  <div className="font-semibold text-slate-800 dark:text-slate-200">
                    Setup Checklist (Project: mediatoolshub)
                  </div>
                  <ol className="list-decimal list-inside space-y-1 text-slate-600 dark:text-slate-300 leading-relaxed">
                    <li>
                      Open Google Cloud Console for project <span className="font-mono">mediatoolshub</span> → APIs &amp; Services → Credentials → Web application OAuth client (<span className="font-mono">400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com</span>).
                    </li>
                    <li>
                      Generate/rotate a fresh Client Secret (never reuse an exposed secret) and verify YouTube Data API v3 and YouTube Analytics API are enabled.
                    </li>
                    <li>
                      Verify the Authorized Redirect URI above matches Google Cloud Console character-for-character.
                    </li>
                    <li>
                      Configure <span className="font-mono">GOOGLE_CLIENT_ID</span>, <span className="font-mono">GOOGLE_CLIENT_SECRET</span>, <span className="font-mono">GOOGLE_REDIRECT_URI</span>, and a 64-char hex <span className="font-mono">OAUTH_TOKEN_ENCRYPTION_KEY</span> in your server runtime environment or Cloud Run Secret Manager.
                    </li>
                    <li>
                      Paste raw single-line values without wrapping quotation marks, line breaks, or extra spaces.
                    </li>
                    <li>
                      Restart or redeploy the backend service so the new environment variables replace the 4-character placeholders.
                    </li>
                    <li>
                      Verify <span className="font-mono">/api/v1/health?checkOAuth=1</span> reports <span className="font-mono">valid: true</span>, then click <strong>Connect YouTube Channel</strong> again.
                    </li>
                  </ol>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
      {/* Creator Workspace Details Modal (with Channel DNA inside) */}
      {showWorkspaceDetailsModal && activeWorkspace && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="max-w-2xl w-full max-h-[90vh] overflow-y-auto rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5 text-xs">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                  Creator Workspace Details
                </h3>
                <p className="text-slate-500 dark:text-slate-400 mt-0.5">
                  Workspace identity, goals, connected YouTube channel, and Channel DNA profile.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setShowWorkspaceDetailsModal(false)}
                aria-label="Close Creator Workspace Details"
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {wsDetailsNotice && (
              <div className="rounded-lg border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 px-3 py-2 text-emerald-700 dark:text-emerald-300 font-medium">
                {wsDetailsNotice}
              </div>
            )}

            {/* Workspace Info Form */}
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                if (!canManageWorkspace) return;
                setSavingWsDetails(true);
                setWsDetailsNotice(null);
                try {
                  await ytmRequest(
                    authFetch,
                    `/workspaces/${encodeURIComponent(activeWorkspace.workspaceKey)}`,
                    {
                      workspaceKey: activeWorkspace.workspaceKey,
                      method: 'PATCH',
                      body: {
                        name: editWsName.trim() || activeWorkspace.name,
                        description: editWsDesc.trim(),
                        channelGoal: editWsGoal.trim(),
                      },
                    }
                  );
                  await loadWorkspaces();
                  setWsDetailsNotice('Creator Workspace details saved.');
                } catch (err) {
                  setError(
                    err instanceof Error ? err.message : 'Unable to update workspace details.'
                  );
                } finally {
                  setSavingWsDetails(false);
                }
              }}
              className="space-y-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Workspace Name
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canManageWorkspace}
                    value={editWsName}
                    onChange={(e) => setEditWsName(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Role &amp; Workspace Key
                  </label>
                  <div className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center justify-between text-slate-600 dark:text-slate-300">
                    <span className="font-semibold">{YTM_ROLE_LABELS[role]}</span>
                    <span className="font-mono text-[11px] text-slate-400 truncate max-w-[140px]">
                      {activeWorkspace.workspaceKey}
                    </span>
                  </div>
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel Goal
                  </label>
                  <input
                    type="text"
                    disabled={!canManageWorkspace}
                    value={editWsGoal}
                    onChange={(e) => setEditWsGoal(e.target.value)}
                    placeholder="e.g. Publish 2 deep-dive tutorials weekly to reach 100k subscribers"
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Description
                  </label>
                  <input
                    type="text"
                    disabled={!canManageWorkspace}
                    value={editWsDesc}
                    onChange={(e) => setEditWsDesc(e.target.value)}
                    placeholder="Short description of this creator workspace"
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
              </div>

              {canManageWorkspace && (
                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={savingWsDetails}
                    className="h-8 px-3.5 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-semibold inline-flex items-center gap-1.5"
                  >
                    {savingWsDetails && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                    <span>Save Workspace Details</span>
                  </button>
                </div>
              )}
            </form>

            {/* Channel DNA Inside Creator Workspace Details */}
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-950/60 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Dna className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                  <div>
                    <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                      Channel DNA
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      Guides Content Planner, AI Strategy, Workflow, Community Posts, and Performance Coach.
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setShowWorkspaceDetailsModal(false);
                    setShowChannelDnaModal(true);
                  }}
                  className="h-8 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                >
                  {activeChannelProfile ? 'Edit Channel DNA' : 'Configure Channel DNA'}
                </button>
              </div>

              {channelProfiles.length > 0 ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Active Channel DNA Profile ({channelProfiles.length})
                    </label>
                    <div className="relative">
                      <select
                        aria-label="Active Channel DNA profile"
                        value={activeChannelProfile?.id ?? ''}
                        onChange={(e) => handleSelectChannelProfile(Number(e.target.value))}
                        className="w-full h-9 pl-3 pr-8 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-xs font-semibold text-slate-900 dark:text-white appearance-none"
                      >
                        {channelProfiles.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.channelName}
                            {p.niche ? ` · ${p.niche}` : ''}
                          </option>
                        ))}
                      </select>
                      <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2.5 top-2.5 pointer-events-none" />
                    </div>
                  </div>

                  {activeChannelProfile && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5">
                        <div className="text-slate-400 uppercase font-semibold text-[10px]">
                          Niche &amp; Language
                        </div>
                        <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
                          {[
                            activeChannelProfile.niche || 'Not set',
                            activeChannelProfile.subNiche,
                            activeChannelProfile.dna.preferredLanguage,
                          ]
                            .filter(Boolean)
                            .join(' · ')}
                        </div>
                      </div>
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5">
                        <div className="text-slate-400 uppercase font-semibold text-[10px]">
                          Target Audience
                        </div>
                        <div className="font-semibold text-slate-900 dark:text-white mt-0.5 line-clamp-2">
                          {activeChannelProfile.dna.targetAudience || 'Not configured yet'}
                        </div>
                      </div>
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5">
                        <div className="text-slate-400 uppercase font-semibold text-[10px]">
                          Brand Voice &amp; Tone
                        </div>
                        <div className="font-semibold text-slate-900 dark:text-white mt-0.5 line-clamp-2">
                          {activeChannelProfile.dna.brandVoice ||
                            activeChannelProfile.dna.toneOfVoice ||
                            'Not configured yet'}
                        </div>
                      </div>
                      <div className="rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-2.5">
                        <div className="text-slate-400 uppercase font-semibold text-[10px]">
                          Publishing Preferences
                        </div>
                        <div className="font-semibold text-slate-900 dark:text-white mt-0.5 line-clamp-2">
                          {activeChannelProfile.dna.publishingPreferences ||
                            activeChannelProfile.dna.contentFormat ||
                            'Not configured yet'}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="rounded-lg border border-dashed border-slate-300 dark:border-slate-700 p-3 text-slate-500">
                  No Channel DNA profile configured yet. Click <strong>Configure Channel DNA</strong> to set your niche, audience, content pillars, brand voice, and creative rules.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Channel DNA Multi-Channel Identity Modal */}
      {activeWorkspace && (
        <YtmChannelDnaModal
          open={showChannelDnaModal}
          onClose={() => setShowChannelDnaModal(false)}
          authFetch={authFetch}
          workspaceKey={activeWorkspace.workspaceKey}
          canWrite={canWritePlanner || canManageWorkspace}
          profiles={channelProfiles}
          activeProfileId={activeChannelProfile?.id ?? null}
          onSelectProfile={handleSelectChannelProfile}
          onProfilesChanged={(nextProfiles, selectedId) => {
            setChannelProfiles(nextProfiles);
            if (selectedId) {
              handleSelectChannelProfile(selectedId);
            } else if (nextProfiles.length > 0 && !nextProfiles.some((p) => p.id === activeChannelProfileId)) {
              const fallback = nextProfiles.find((p) => p.isDefault) || nextProfiles[0];
              handleSelectChannelProfile(fallback.id);
            }
          }}
        />
      )}

      {/* Floating YouTube OS Central AI Agent (bottom-right, visible across all YouTube OS sections) */}
      {activeWorkspace && (
        <YtmAiAgentWidget
          authFetch={authFetch}
          workspace={activeWorkspace}
          activeSection={activeSection}
          activeChannelProfile={activeChannelProfile}
          selectedWorkflowId={selectedWorkflowId}
          onNavigateSection={handleSelectSection}
          onOpenWorkflowProject={(workflowId) => {
            setSelectedWorkflowId(workflowId);
            handleSelectSection('workflow');
          }}
        />
      )}
    </div>
  );
}

function PermissionNotice({ role, area }: { role: string; area: string }) {
  return (
    <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-xs text-slate-500">
      Your current workspace role (<strong className="capitalize">{role.replace('_', ' ')}</strong>) does not include access to <strong>{area}</strong>. Ask a workspace Owner or Admin to update your permissions in Team &amp; Delegation.
    </div>
  );
}
