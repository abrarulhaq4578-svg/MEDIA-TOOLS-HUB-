import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  Check,
  CheckCircle2,
  Loader2,
  MailPlus,
  Shield,
  UserCheck,
  Users,
} from 'lucide-react';
import type {
  YtmInvitationRecord,
  YtmPlannerProjectRecord,
  YtmWorkflowProjectRecord,
  YtmWorkspaceMemberRecord,
  YtmWorkspaceRecord,
  YtmWorkspaceRole,
} from '../../shared/types.ts';
import { YTM_ROLE_LABELS } from '../../shared/ytmHelpers.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspace: YtmWorkspaceRecord;
  canManageTeam: boolean;
  canApprove: boolean;
}

const ASSIGNABLE_ROLES: YtmWorkspaceRole[] = [
  'admin',
  'manager',
  'editor',
  'thumbnail_designer',
  'script_writer',
  'analyst',
  'viewer',
];

export function YtmTeamView({ authFetch, workspace, canManageTeam, canApprove }: Props) {
  const [members, setMembers] = useState<YtmWorkspaceMemberRecord[]>([]);
  const [invitations, setInvitations] = useState<YtmInvitationRecord[]>([]);
  const [workflows, setWorkflows] = useState<YtmWorkflowProjectRecord[]>([]);
  const [plannerProjects, setPlannerProjects] = useState<YtmPlannerProjectRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<YtmWorkspaceRole>('editor');
  const [inviting, setInviting] = useState(false);

  const [reviewNotesMap, setReviewNotesMap] = useState<Record<number, string>>({});

  const loadAll = async () => {
    setLoading(true);
    setError(null);
    try {
      const [teamRes, wfRes, plRes] = await Promise.all([
        ytmRequest<{ members: YtmWorkspaceMemberRecord[]; invitations: YtmInvitationRecord[] }>(
          authFetch,
          '/team',
          { workspaceKey: workspace.workspaceKey }
        ),
        ytmRequest<{ workflows: YtmWorkflowProjectRecord[] }>(authFetch, '/workflow', {
          workspaceKey: workspace.workspaceKey,
        }),
        ytmRequest<{ projects: YtmPlannerProjectRecord[] }>(authFetch, '/planner', {
          workspaceKey: workspace.workspaceKey,
        }),
      ]);
      setMembers(teamRes.members || []);
      setInvitations(teamRes.invitations || []);
      setWorkflows(wfRes.workflows || []);
      setPlannerProjects(plRes.projects || []);
      const notes: Record<number, string> = {};
      for (const w of wfRes.workflows || []) {
        notes[w.id] = w.reviewNotes || '';
      }
      setReviewNotesMap(notes);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load team workspace.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadAll();
  }, [workspace.workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail.trim() || !canManageTeam) return;
    setInviting(true);
    setError(null);
    setNotice(null);
    try {
      await ytmRequest(authFetch, '/team/invite', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: { email: inviteEmail.trim(), role: inviteRole },
      });
      setNotice(
        `Invitation issued for ${inviteEmail.trim()} as ${YTM_ROLE_LABELS[inviteRole]}. When they sign into MediaToolsHub with that Google email, they can accept from their workspace bar.`
      );
      setInviteEmail('');
      await loadAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to invite teammate.');
    } finally {
      setInviting(false);
    }
  };

  const handleUpdateMember = async (
    memberId: number,
    patch: { role?: YtmWorkspaceRole; status?: 'active' | 'revoked' }
  ) => {
    if (!canManageTeam) return;
    setError(null);
    try {
      await ytmRequest(authFetch, `/team/members/${memberId}`, {
        workspaceKey: workspace.workspaceKey,
        method: 'PATCH',
        body: patch,
      });
      await loadAll();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update member permissions.');
    }
  };

  const handleAssignWorkflow = async (wfId: number, assigneeUserId: number | null) => {
    await ytmRequest(authFetch, `/workflow/projects/${wfId}`, {
      workspaceKey: workspace.workspaceKey,
      method: 'PATCH',
      body: { assigneeUserId },
    });
    await loadAll();
  };

  const handleReviewWorkflow = async (
    wfId: number,
    reviewStatus: 'approved' | 'changes_requested'
  ) => {
    if (!canApprove) return;
    await ytmRequest(authFetch, `/workflow/projects/${wfId}`, {
      workspaceKey: workspace.workspaceKey,
      method: 'PATCH',
      body: {
        reviewStatus,
        reviewNotes: reviewNotesMap[wfId] || '',
      },
    });
    setNotice(`Workflow updated to ${reviewStatus.replace('_', ' ')}.`);
    await loadAll();
  };

  const handleAssignPlannerProject = async (projId: number, assigneeUserId: number | null) => {
    await ytmRequest(authFetch, `/planner/projects/${projId}`, {
      workspaceKey: workspace.workspaceKey,
      method: 'PATCH',
      body: { assigneeUserId },
    });
    await loadAll();
  };

  const activeMembers = members.filter((m) => m.status === 'active');

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Team &amp; Delegation · {workspace.name}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Your Role: <strong className="text-slate-900 dark:text-white">{YTM_ROLE_LABELS[workspace.myRole]}</strong> · Invite teammates, configure 8-role RBAC permissions, and assign production reviews.
          </p>
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/30 text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
          <Check className="w-4 h-4 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Invite Form */}
      {canManageTeam ? (
        <form
          onSubmit={handleInvite}
          className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-wrap items-end gap-3 text-xs"
        >
          <div className="flex-1 min-w-[220px]">
            <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Invite Teammate by Google Email
            </label>
            <input
              type="email"
              required
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              placeholder="editor@channelteam.com"
              className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            />
          </div>
          <div className="w-52">
            <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
              Workspace Role
            </label>
            <select
              value={inviteRole}
              onChange={(e) => setInviteRole(e.target.value as YtmWorkspaceRole)}
              className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
            >
              {ASSIGNABLE_ROLES.map((r) => (
                <option key={r} value={r}>
                  {YTM_ROLE_LABELS[r]}
                </option>
              ))}
            </select>
          </div>
          <button
            type="submit"
            disabled={inviting}
            className="h-10 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-semibold inline-flex items-center gap-1.5"
          >
            {inviting ? <Loader2 className="w-4 h-4 animate-spin" /> : <MailPlus className="w-4 h-4" />}
            <span>Send Invite</span>
          </button>
        </form>
      ) : (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-xs text-slate-500">
          Only Owner, Admin, or Manager roles can invite members or modify workspace permissions.
        </div>
      )}

      {loading ? (
        <div className="p-8 text-center text-xs text-slate-500 flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span>Loading team &amp; delegation queues…</span>
        </div>
      ) : (
        <>
          {/* Members & Invitations */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span>Workspace Members ({members.length})</span>
              </h3>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                {members.map((m) => (
                  <div key={m.id} className="py-3 flex flex-wrap items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="font-semibold text-slate-900 dark:text-white truncate">
                        {m.displayName || m.email}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono truncate">{m.email}</div>
                    </div>
                    <div className="flex items-center gap-2">
                      {m.role === 'owner' ? (
                        <span className="font-semibold text-blue-600 dark:text-blue-400 inline-flex items-center gap-1">
                          <Shield className="w-3.5 h-3.5" />
                          Owner
                        </span>
                      ) : (
                        <>
                          <select
                            disabled={!canManageTeam}
                            value={m.role}
                            onChange={(e) =>
                              void handleUpdateMember(m.id, {
                                role: e.target.value as YtmWorkspaceRole,
                              })
                            }
                            className="h-8 px-2 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                          >
                            {ASSIGNABLE_ROLES.map((r) => (
                              <option key={r} value={r}>
                                {YTM_ROLE_LABELS[r]}
                              </option>
                            ))}
                          </select>
                          {canManageTeam && (
                            <button
                              type="button"
                              onClick={() =>
                                void handleUpdateMember(m.id, {
                                  status: m.status === 'active' ? 'revoked' : 'active',
                                })
                              }
                              className={`h-8 px-2.5 rounded border font-semibold ${
                                m.status === 'active'
                                  ? 'border-red-200 dark:border-red-900 text-red-600'
                                  : 'border-emerald-200 dark:border-emerald-900 text-emerald-600'
                              }`}
                            >
                              {m.status === 'active' ? 'Revoke' : 'Restore'}
                            </button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-emerald-600" />
                <span>Invitations ({invitations.length})</span>
              </h3>
              {invitations.length === 0 ? (
                <div className="text-xs text-slate-500 py-4">No invitations sent yet.</div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                  {invitations.map((inv) => (
                    <div key={inv.id} className="py-2.5 flex items-center justify-between gap-2">
                      <div>
                        <div className="font-semibold text-slate-900 dark:text-white">{inv.email}</div>
                        <div className="text-[11px] text-slate-500">
                          Role: {YTM_ROLE_LABELS[inv.role]} · Expires {inv.expiresAt.slice(0, 10)}
                        </div>
                      </div>
                      <span className="font-mono text-[11px] uppercase text-slate-500">
                        {inv.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Workflow Delegation & Review Approval Queue */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
            <div>
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-600" />
                <span>Production Delegation &amp; Review Queue ({workflows.length})</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Assign video workflows to team specialists and approve or request revisions cleanly.
              </p>
            </div>

            {workflows.length === 0 ? (
              <div className="text-xs text-slate-500">No active workflows in this workspace yet.</div>
            ) : (
              <div className="space-y-3">
                {workflows.map((wf) => (
                  <div
                    key={wf.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 space-y-3 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="font-display text-sm font-bold text-slate-950 dark:text-white">
                          {wf.title}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          Stage {wf.currentStage}/6 · Review Status:{' '}
                          <strong className="capitalize">{wf.reviewStatus.replace('_', ' ')}</strong>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-500">Assignee:</span>
                        <select
                          disabled={!canManageTeam && !canApprove}
                          value={wf.assigneeUserId ?? ''}
                          onChange={(e) =>
                            void handleAssignWorkflow(
                              wf.id,
                              e.target.value ? Number.parseInt(e.target.value, 10) : null
                            )
                          }
                          className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                        >
                          <option value="">Unassigned</option>
                          {activeMembers.map((m) => (
                            <option key={m.userId} value={m.userId}>
                              {m.displayName || m.email} ({YTM_ROLE_LABELS[m.role]})
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {canApprove && (
                      <div className="flex flex-wrap items-center gap-2">
                        <input
                          type="text"
                          value={reviewNotesMap[wf.id] ?? ''}
                          onChange={(e) =>
                            setReviewNotesMap((prev) => ({ ...prev, [wf.id]: e.target.value }))
                          }
                          placeholder="Review feedback or revision notes…"
                          className="flex-1 min-w-[200px] h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900"
                        />
                        <button
                          type="button"
                          onClick={() => void handleReviewWorkflow(wf.id, 'approved')}
                          className="h-8 px-3 rounded-lg bg-emerald-600 text-white font-semibold"
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          onClick={() => void handleReviewWorkflow(wf.id, 'changes_requested')}
                          className="h-8 px-3 rounded-lg border border-amber-300 dark:border-amber-800 text-amber-700 dark:text-amber-300 font-semibold"
                        >
                          Request Changes
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {plannerProjects.length > 0 && (
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                  Planner Video Assignments
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                  {plannerProjects.slice(0, 8).map((p) => (
                    <div
                      key={p.id}
                      className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 text-xs"
                    >
                      <span className="truncate font-semibold text-slate-800 dark:text-slate-200">
                        {p.title}
                      </span>
                      <select
                        disabled={!canManageTeam && !canApprove}
                        value={p.assigneeUserId ?? ''}
                        onChange={(e) =>
                          void handleAssignPlannerProject(
                            p.id,
                            e.target.value ? Number.parseInt(e.target.value, 10) : null
                          )
                        }
                        className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-[11px]"
                      >
                        <option value="">Unassigned</option>
                        {activeMembers.map((m) => (
                          <option key={m.userId} value={m.userId}>
                            {m.displayName || m.email}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
