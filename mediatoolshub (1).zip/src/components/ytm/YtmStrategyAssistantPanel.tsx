import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Calendar,
  CalendarClock,
  Check,
  CheckCircle2,
  Loader2,
  MessageSquare,
  RefreshCw,
  Sliders,
  Sparkles,
  Trash2,
  X,
} from 'lucide-react';
import type {
  YtmCalendarAuditReport,
  YtmChannelProfileWithDna,
  YtmContentStrategyRecord,
  YtmPriority,
  YtmStrategyCalendarItem,
  YtmStrategyIntake,
  YtmWorkspaceRecord,
} from '../../shared/types.ts';
import { ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspace: YtmWorkspaceRecord;
  canWrite: boolean;
  activeChannelProfile: YtmChannelProfileWithDna | null;
  onCalendarUpdated: () => Promise<void>;
}

type StrategySubTab = 'setup' | 'strategy' | 'calendar' | 'audit';

interface StrategyLoadResponse {
  strategy: YtmContentStrategyRecord | null;
  strategies: YtmContentStrategyRecord[];
  liveAudit: YtmCalendarAuditReport;
}

const CONTENT_TYPE_LABELS: Record<YtmStrategyCalendarItem['contentType'], string> = {
  long_form_video: 'Long-Form Video',
  youtube_short: 'YouTube Short',
  community_post: 'Community Post',
  poll: 'Community Poll',
  quiz: 'Community Quiz',
  engagement_session: 'Comment / Engagement',
  promo_post: 'Launch / Promo',
  behind_the_scenes: 'Behind the Scenes',
};

function defaultIntakeFromContext(
  workspace: YtmWorkspaceRecord,
  profile: YtmChannelProfileWithDna | null
): YtmStrategyIntake {
  const formats =
    profile?.dna.preferredFormats?.length
      ? profile.dna.preferredFormats
      : [profile?.dna.contentFormat || 'Long-form YouTube', 'YouTube Shorts', 'Community Posts'];
  return {
    mainPlatform: 'YouTube',
    niche: profile?.niche || workspace.name || '',
    targetAudience: profile?.dna.targetAudience || '',
    contentFormats: formats,
    publishingGoals: workspace.channelGoal || 'Sustainable weekly publishing and subscriber growth',
    availableHoursPerWeek: 8,
    preferredFrequency: profile?.dna.publishingPreferences || '1 long-form video + 2 Shorts per week',
    monthlyContentTarget: '4 long-form videos, 8 Shorts, 4 Community Posts',
    audienceEngagementGoals: 'Weekly polls, comment reply sessions, and audience topic requests',
    additionalConstraints: profile?.dna.contentRules || '',
  };
}

export function YtmStrategyAssistantPanel({
  authFetch,
  workspace,
  canWrite,
  activeChannelProfile,
  onCalendarUpdated,
}: Props) {
  const [subTab, setSubTab] = useState<StrategySubTab>('setup');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);

  const [strategy, setStrategy] = useState<YtmContentStrategyRecord | null>(null);
  const [strategies, setStrategies] = useState<YtmContentStrategyRecord[]>([]);
  const [liveAudit, setLiveAudit] = useState<YtmCalendarAuditReport | null>(null);

  const [intake, setIntake] = useState<YtmStrategyIntake>(() =>
    defaultIntakeFromContext(workspace, activeChannelProfile)
  );
  const [formatsInput, setFormatsInput] = useState(() =>
    defaultIntakeFromContext(workspace, activeChannelProfile).contentFormats.join(', ')
  );
  const [generating, setGenerating] = useState(false);
  const [savingDraft, setSavingDraft] = useState(false);
  const [applying, setApplying] = useState(false);
  const [regeneratingDates, setRegeneratingDates] = useState(false);
  const [applyingAuditId, setApplyingAuditId] = useState<string | null>(null);
  const [deletingStrategy, setDeletingStrategy] = useState(false);
  const [confirmDeleteStrategy, setConfirmDeleteStrategy] = useState(false);
  const [confirmClearDraftItems, setConfirmClearDraftItems] = useState(false);

  // Calendar preview controls
  const [calendarGrouping, setCalendarGrouping] = useState<'weekly' | 'monthly'>('weekly');
  const [selectedDateKeys, setSelectedDateKeys] = useState<string[]>([]);
  const [regenNote, setRegenNote] = useState('');
  const [editingItemId, setEditingItemId] = useState<string | null>(null);

  const loadStrategy = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await ytmRequest<StrategyLoadResponse>(authFetch, '/strategy', {
        workspaceKey: workspace.workspaceKey,
      });
      setStrategy(res.strategy);
      setStrategies(res.strategies || []);
      setLiveAudit(res.liveAudit || null);
      if (res.strategy) {
        setIntake(res.strategy.intake);
        setFormatsInput((res.strategy.intake.contentFormats || []).join(', '));
      } else {
        const def = defaultIntakeFromContext(workspace, activeChannelProfile);
        setIntake(def);
        setFormatsInput(def.contentFormats.join(', '));
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load AI Strategy Assistant.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadStrategy();
  }, [workspace.workspaceKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const handleGenerateStrategy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canWrite) return;
    setGenerating(true);
    setError(null);
    setNotice(null);
    try {
      const parsedFormats = formatsInput
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const payloadIntake: YtmStrategyIntake = {
        ...intake,
        contentFormats:
          parsedFormats.length > 0 ? parsedFormats : ['Long-form YouTube', 'YouTube Shorts'],
      };
      const res = await ytmRequest<{ strategy: YtmContentStrategyRecord }>(
        authFetch,
        '/strategy/generate',
        {
          workspaceKey: workspace.workspaceKey,
          method: 'POST',
          body: {
            channelProfileId: activeChannelProfile?.id ?? null,
            intake: payloadIntake,
          },
        }
      );
      setStrategy(res.strategy);
      setStrategies((prev) => [res.strategy, ...prev.filter((s) => s.id !== res.strategy.id)]);
      setSubTab('calendar');
      setNotice(
        'Draft strategy & calendar generated. Review, edit, or approve items below before saving anything to your live Content Planner.'
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Strategy generation failed.');
    } finally {
      setGenerating(false);
    }
  };

  const persistCalendarItems = async (nextItems: YtmStrategyCalendarItem[]) => {
    if (!strategy || !canWrite) return;
    setStrategy({ ...strategy, calendarItems: nextItems });
    setSavingDraft(true);
    setError(null);
    try {
      const res = await ytmRequest<{ strategy: YtmContentStrategyRecord }>(
        authFetch,
        `/strategy/${strategy.id}`,
        {
          workspaceKey: workspace.workspaceKey,
          method: 'PATCH',
          body: { calendarItems: nextItems },
        }
      );
      setStrategy(res.strategy);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save draft edit.');
    } finally {
      setSavingDraft(false);
    }
  };

  const updateCalendarItem = (
    itemId: string,
    patch: Partial<YtmStrategyCalendarItem>
  ) => {
    if (!strategy) return;
    const next = strategy.calendarItems.map((it) =>
      it.id === itemId ? { ...it, ...patch } : it
    );
    void persistCalendarItems(next);
  };

  const deleteCalendarItem = (itemId: string) => {
    if (!strategy || !canWrite) return;
    const next = strategy.calendarItems.filter((it) => it.id !== itemId);
    if (editingItemId === itemId) setEditingItemId(null);
    void persistCalendarItems(next);
  };

  const removeRejectedDraftItems = () => {
    if (!strategy || !canWrite) return;
    const next = strategy.calendarItems.filter((it) => it.status !== 'rejected');
    void persistCalendarItems(next);
    setNotice('Removed rejected items from this strategy draft.');
  };

  const clearUnsavedDraftItems = () => {
    if (!strategy || !canWrite) return;
    const next = strategy.calendarItems.filter((it) => it.status === 'saved_to_calendar');
    setConfirmClearDraftItems(false);
    setSelectedDateKeys([]);
    setEditingItemId(null);
    void persistCalendarItems(next);
    setNotice('Cleared all unsaved draft items from this strategy plan.');
  };

  const handleDeleteStrategy = async () => {
    if (!strategy || !canWrite) return;
    const target = strategy;
    setDeletingStrategy(true);
    setError(null);
    setNotice(null);
    try {
      await ytmRequest<{ deleted: boolean; deletedId: number }>(
        authFetch,
        `/strategy/${target.id}`,
        {
          workspaceKey: workspace.workspaceKey,
          method: 'DELETE',
        }
      );
      const remaining = strategies.filter((s) => s.id !== target.id);
      setStrategies(remaining);
      const nextActive = remaining[0] || null;
      setStrategy(nextActive);
      setConfirmDeleteStrategy(false);
      setConfirmClearDraftItems(false);
      setSelectedDateKeys([]);
      setEditingItemId(null);
      if (nextActive) {
        setIntake(nextActive.intake);
        setFormatsInput((nextActive.intake.contentFormats || []).join(', '));
      } else {
        const def = defaultIntakeFromContext(workspace, activeChannelProfile);
        setIntake(def);
        setFormatsInput(def.contentFormats.join(', '));
        setSubTab('setup');
      }
      setNotice(`Deleted strategy plan "${target.title}".`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to delete strategy plan.');
    } finally {
      setDeletingStrategy(false);
    }
  };

  const toggleDateSelection = (dateKey: string) => {
    setSelectedDateKeys((prev) =>
      prev.includes(dateKey) ? prev.filter((d) => d !== dateKey) : [...prev, dateKey]
    );
  };

  const handleRegenerateSelectedDates = async () => {
    if (!strategy || !canWrite || selectedDateKeys.length === 0) return;
    setRegeneratingDates(true);
    setError(null);
    setNotice(null);
    try {
      const res = await ytmRequest<{ strategy: YtmContentStrategyRecord }>(
        authFetch,
        `/strategy/${strategy.id}/regenerate-dates`,
        {
          workspaceKey: workspace.workspaceKey,
          method: 'POST',
          body: { dates: selectedDateKeys, note: regenNote.trim() || undefined },
        }
      );
      setStrategy(res.strategy);
      setSelectedDateKeys([]);
      setRegenNote('');
      setNotice('Regenerated draft items for the selected dates.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to regenerate selected dates.');
    } finally {
      setRegeneratingDates(false);
    }
  };

  const handleApplyToCalendar = async (approveAll: boolean) => {
    if (!strategy || !canWrite) return;
    setApplying(true);
    setError(null);
    setNotice(null);
    try {
      const approvedIds = strategy.calendarItems
        .filter((it) => it.status === 'approved')
        .map((it) => it.id);
      const res = await ytmRequest<{
        strategy: YtmContentStrategyRecord;
        createdProjectsCount: number;
        createdTasksCount: number;
      }>(authFetch, `/strategy/${strategy.id}/apply`, {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: approveAll ? { approveAll: true } : { itemIds: approvedIds },
      });
      setStrategy(res.strategy);
      setNotice(
        `Saved ${res.createdProjectsCount} video project(s) and ${res.createdTasksCount} task(s) to Content Planner without overwriting existing entries.`
      );
      await onCalendarUpdated();
      await loadStrategy();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to save approved items to calendar.');
    } finally {
      setApplying(false);
    }
  };

  const handleApplyAuditSuggestion = async (
    itemId: string,
    targetType: 'project' | 'task' | 'gap',
    targetId: number | null,
    targetTitle: string,
    suggestedDate: string | null
  ) => {
    if (!canWrite || !suggestedDate) return;
    setApplyingAuditId(itemId);
    setError(null);
    setNotice(null);
    try {
      await ytmRequest(authFetch, '/strategy/calendar-audit/apply', {
        workspaceKey: workspace.workspaceKey,
        method: 'POST',
        body: { targetType, targetId, targetTitle, suggestedDate },
      });
      setNotice(`Applied approved calendar adjustment for "${targetTitle}" → ${suggestedDate}.`);
      await onCalendarUpdated();
      await loadStrategy();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to apply calendar adjustment.');
    } finally {
      setApplyingAuditId(null);
    }
  };

  const groupedItems = useMemo(() => {
    if (!strategy) return [] as Array<{ label: string; items: YtmStrategyCalendarItem[] }>;
    const sorted = [...strategy.calendarItems].sort((a, b) => a.date.localeCompare(b.date));
    const firstMs = sorted[0]?.date ? Date.parse(`${sorted[0].date}T00:00:00Z`) : Date.now();
    const map = new Map<string, YtmStrategyCalendarItem[]>();
    for (const item of sorted) {
      const itemMs = Date.parse(`${item.date}T00:00:00Z`);
      const weekNum =
        Number.isFinite(itemMs) && Number.isFinite(firstMs)
          ? Math.max(1, Math.floor((itemMs - firstMs) / (7 * 86400000)) + 1)
          : 1;
      const key =
        calendarGrouping === 'weekly'
          ? `Week ${weekNum}`
          : item.date.slice(0, 7) || 'Month';
      const arr = map.get(key) || [];
      arr.push(item);
      map.set(key, arr);
    }
    return Array.from(map.entries()).map(([label, items]) => ({ label, items }));
  }, [strategy, calendarGrouping]);

  const approvedPendingCount = useMemo(
    () => (strategy?.calendarItems || []).filter((i) => i.status === 'approved').length,
    [strategy]
  );
  const totalUnsavedPending = useMemo(
    () =>
      (strategy?.calendarItems || []).filter(
        (i) => i.status === 'pending_review' || i.status === 'approved'
      ).length,
    [strategy]
  );

  const auditCount = liveAudit?.suggestions?.length || 0;

  return (
    <div className="space-y-5">
      {/* Header & Sub-Navigation */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
                AI Strategy Assistant
              </h3>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Builds a realistic publishing schedule, audience communication routine, and approval-gated calendar draft from your active Channel DNA ({activeChannelProfile?.channelName || 'Workspace Default'}). Existing calendar entries are never auto-overwritten.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {strategies.length > 1 && (
              <select
                aria-label="Select saved strategy draft"
                value={strategy?.id ?? ''}
                onChange={(e) => {
                  const chosen = strategies.find((s) => s.id === Number(e.target.value));
                  if (chosen) {
                    setStrategy(chosen);
                    setIntake(chosen.intake);
                    setFormatsInput((chosen.intake.contentFormats || []).join(', '));
                    setConfirmDeleteStrategy(false);
                    setConfirmClearDraftItems(false);
                  }
                }}
                className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-xs font-medium"
              >
                {strategies.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.title} ({s.createdAt.slice(0, 10)})
                  </option>
                ))}
              </select>
            )}
            {strategy && canWrite && !confirmDeleteStrategy && (
              <button
                type="button"
                onClick={() => setConfirmDeleteStrategy(true)}
                className="h-9 px-3 rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50/70 dark:bg-rose-950/30 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-950/60 text-xs font-semibold inline-flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Plan</span>
              </button>
            )}
          </div>
        </div>

        {strategy && canWrite && confirmDeleteStrategy && (
          <div className="rounded-lg border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/30 p-3 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="text-rose-800 dark:text-rose-200 font-medium">
              Delete strategy plan <strong>"{strategy.title}"</strong>? Items already saved to your live Calendar will stay intact.
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={deletingStrategy}
                onClick={() => setConfirmDeleteStrategy(false)}
                className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold text-slate-700 dark:text-slate-200"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={deletingStrategy}
                onClick={() => void handleDeleteStrategy()}
                className="h-8 px-3 rounded-lg bg-rose-600 hover:bg-rose-700 text-white font-semibold inline-flex items-center gap-1.5 disabled:opacity-60"
              >
                {deletingStrategy ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <Trash2 className="w-3.5 h-3.5" />
                )}
                <span>{deletingStrategy ? 'Deleting...' : 'Confirm Delete Plan'}</span>
              </button>
            </div>
          </div>
        )}

        <div className="flex flex-wrap gap-2 border-t border-slate-100 dark:border-slate-800 pt-3 text-xs">
          {[
            { id: 'setup', label: '1. Strategy Setup', icon: Sliders },
            { id: 'strategy', label: '2. Publishing & Communication', icon: MessageSquare },
            {
              id: 'calendar',
              label: `3. Calendar Draft (${strategy?.calendarItems.length || 0})`,
              icon: Calendar,
            },
            {
              id: 'audit',
              label: `4. Calendar Health & Rescheduling (${auditCount})`,
              icon: CalendarClock,
            },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setSubTab(t.id as StrategySubTab)}
                className={`h-9 px-3.5 rounded-lg font-semibold inline-flex items-center gap-1.5 ${
                  subTab === t.id
                    ? 'bg-blue-600 text-white'
                    : 'border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {error && (
        <div className="rounded-xl border border-rose-200 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/20 p-3.5 text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {notice && (
        <div className="rounded-xl border border-emerald-200 dark:border-emerald-900 bg-emerald-50 dark:bg-emerald-950/20 p-3.5 text-xs text-emerald-700 dark:text-emerald-300 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{notice}</span>
          </div>
          <button type="button" onClick={() => setNotice(null)} className="font-semibold underline">
            Dismiss
          </button>
        </div>
      )}

      {loading ? (
        <div className="py-10 flex items-center justify-center gap-2 text-xs text-slate-500">
          <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
          <span>Loading Strategy Assistant...</span>
        </div>
      ) : (
        <>
          {/* SUB-TAB 1: STRATEGY CREATION INTAKE */}
          {subTab === 'setup' && (
            <form
              onSubmit={(e) => void handleGenerateStrategy(e)}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-5 text-xs"
            >
              <div>
                <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  Creator Capacity &amp; Publishing Goals Intake
                </h4>
                <p className="text-slate-500 mt-0.5">
                  Pre-filled from your active Channel DNA. The assistant tailors weekly volume strictly to your available hours — never suggesting arbitrary or unsustainable posting frequencies.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Main Platform
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={intake.mainPlatform}
                    onChange={(e) => setIntake({ ...intake, mainPlatform: e.target.value })}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Channel Niche
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={intake.niche}
                    onChange={(e) => setIntake({ ...intake, niche: e.target.value })}
                    placeholder="e.g., Personal Finance for Freelancers"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Target Audience
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={intake.targetAudience}
                    onChange={(e) => setIntake({ ...intake, targetAudience: e.target.value })}
                    placeholder="Who watches your videos and what problem do they want solved?"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Content Formats (comma-separated)
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={formatsInput}
                    onChange={(e) => setFormatsInput(e.target.value)}
                    placeholder="Long-form Tutorials, YouTube Shorts, Community Polls"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Available Creator Hours / Week
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={80}
                    required
                    disabled={!canWrite}
                    value={intake.availableHoursPerWeek}
                    onChange={(e) =>
                      setIntake({
                        ...intake,
                        availableHoursPerWeek: Math.max(1, Number(e.target.value) || 1),
                      })
                    }
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono tabular-nums"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Preferred Publishing Frequency
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={intake.preferredFrequency}
                    onChange={(e) => setIntake({ ...intake, preferredFrequency: e.target.value })}
                    placeholder="e.g., 1 long-form video every Tuesday + 1 Short Friday"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Monthly Content Target
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={intake.monthlyContentTarget}
                    onChange={(e) => setIntake({ ...intake, monthlyContentTarget: e.target.value })}
                    placeholder="e.g., 4 long-form videos, 4 Shorts, 4 Community Posts"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Publishing Goals
                  </label>
                  <input
                    type="text"
                    required
                    disabled={!canWrite}
                    value={intake.publishingGoals}
                    onChange={(e) => setIntake({ ...intake, publishingGoals: e.target.value })}
                    placeholder="e.g., Consistent weekly rhythm and stronger return viewership"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Audience Engagement Goals
                  </label>
                  <input
                    type="text"
                    disabled={!canWrite}
                    value={intake.audienceEngagementGoals}
                    onChange={(e) =>
                      setIntake({ ...intake, audienceEngagementGoals: e.target.value })
                    }
                    placeholder="e.g., Grow comment conversations, run polls to pick next topics, post launch announcements"
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Additional Schedule Constraints or Rules (optional)
                  </label>
                  <textarea
                    rows={2}
                    disabled={!canWrite}
                    value={intake.additionalConstraints || ''}
                    onChange={(e) =>
                      setIntake({ ...intake, additionalConstraints: e.target.value })
                    }
                    placeholder="e.g., Can only film on Saturdays; avoid posting on Sundays..."
                    className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                  />
                </div>
              </div>

              {canWrite && (
                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">
                    Output is created as a reviewable draft first — nothing is written to your live calendar until approved.
                  </span>
                  <button
                    type="submit"
                    disabled={generating}
                    className="h-10 px-5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold inline-flex items-center gap-2"
                  >
                    {generating ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Sparkles className="w-4 h-4" />
                    )}
                    <span>{generating ? 'Building Strategy & 4-Week Calendar...' : 'Generate Strategy & Draft Calendar'}</span>
                  </button>
                </div>
              )}
            </form>
          )}

          {/* SUB-TAB 2: PUBLISHING & AUDIENCE COMMUNICATION STRATEGY */}
          {subTab === 'strategy' && (
            !strategy ? (
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-xs text-slate-500 space-y-3">
                <p>No strategy draft generated yet. Complete Step 1 to generate a realistic publishing and audience communication plan.</p>
                <button
                  type="button"
                  onClick={() => setSubTab('setup')}
                  className="h-9 px-4 rounded-lg bg-blue-600 text-white font-semibold"
                >
                  Open Strategy Setup
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 text-xs">
                {/* Publishing Strategy Card */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
                  <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                      Publishing Strategy · {strategy.title}
                    </h4>
                    <p className="text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      {strategy.publishingStrategy.summary}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider font-semibold text-slate-500">Long-Form Target</div>
                      <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
                        {strategy.publishingStrategy.longFormMonthlyTarget || 'Tailored to hours'}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider font-semibold text-slate-500">Shorts Cadence</div>
                      <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
                        {strategy.publishingStrategy.shortsWeeklyTarget || 'Optional support'}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider font-semibold text-slate-500">Community Posts</div>
                      <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
                        {strategy.publishingStrategy.communityPostsCadence || 'Weekly'}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                      <div className="text-[11px] uppercase tracking-wider font-semibold text-slate-500">Polls &amp; Quizzes</div>
                      <div className="font-semibold text-slate-900 dark:text-white mt-0.5">
                        {strategy.publishingStrategy.pollsAndQuizzesCadence || 'Bi-weekly'}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">Behind-the-Scenes &amp; Promo Mix: </span>
                      <span className="text-slate-600 dark:text-slate-400">
                        {strategy.publishingStrategy.behindTheScenesAndPromoMix}
                      </span>
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">Comment Engagement Routine: </span>
                      <span className="text-slate-600 dark:text-slate-400">
                        {strategy.publishingStrategy.commentEngagementRoutine}
                      </span>
                    </div>
                    <div className="p-3 rounded-lg border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/20 text-slate-700 dark:text-slate-300">
                      <span className="font-semibold text-blue-700 dark:text-blue-400">Capacity Realism Check ({strategy.intake.availableHoursPerWeek} hrs/wk): </span>
                      {strategy.publishingStrategy.capacityRealismNote}
                    </div>
                  </div>

                  {strategy.publishingStrategy.contentPillarsMix?.length > 0 && (
                    <div className="space-y-2 pt-1">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">Content Pillar Balance</div>
                      <div className="divide-y divide-slate-100 dark:divide-slate-800">
                        {strategy.publishingStrategy.contentPillarsMix.map((p, idx) => (
                          <div key={idx} className="py-2 flex items-start justify-between gap-3">
                            <div>
                              <div className="font-semibold text-slate-900 dark:text-white">{p.pillar}</div>
                              <div className="text-slate-500">{p.objective}</div>
                            </div>
                            <span className="font-mono tabular-nums font-semibold text-blue-600 dark:text-blue-400 shrink-0">
                              {p.sharePercent}%
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Audience Communication Strategy Card */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4">
                  <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
                    <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                      Audience Communication &amp; Community Strategy
                    </h4>
                    <p className="text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                      {strategy.communicationStrategy.overview}
                    </p>
                  </div>

                  {strategy.communicationStrategy.weeklyEngagementSchedule?.length > 0 && (
                    <div className="space-y-1.5">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">Weekly Engagement Routine</div>
                      <ul className="space-y-1 text-slate-600 dark:text-slate-300">
                        {strategy.communicationStrategy.weeklyEngagementSchedule.map((item, i) => (
                          <li key={i}>
                            • <strong>{item.dayOfWeek}:</strong> {item.activity}{' '}
                            <span className="font-mono text-[11px] text-slate-400">
                              ({item.timeMinutes} min)
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">Subscriber Questions</div>
                      {strategy.communicationStrategy.subscriberQuestionPrompts.map((q, i) => (
                        <div key={i} className="text-slate-600 dark:text-slate-400">• {q}</div>
                      ))}
                    </div>
                    <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
                      <div className="font-semibold text-slate-800 dark:text-slate-200">Poll &amp; Quiz Ideas</div>
                      {[
                        ...strategy.communicationStrategy.pollIdeas.map((x) => `Poll: ${x}`),
                        ...strategy.communicationStrategy.quizIdeas.map((x) => `Quiz: ${x}`),
                      ].map((q, i) => (
                        <div key={i} className="text-slate-600 dark:text-slate-400">• {q}</div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2 text-slate-600 dark:text-slate-300">
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">Feedback Collection Routine: </span>
                      {strategy.communicationStrategy.feedbackCollectionRoutine}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">Comment Response Sessions: </span>
                      {strategy.communicationStrategy.commentResponseSessions}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">Launch Announcement Flow: </span>
                      {strategy.communicationStrategy.launchAnnouncementFlow}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">Post-Publication Plan: </span>
                      {strategy.communicationStrategy.postPublicationEngagementPlan}
                    </div>
                  </div>
                </div>
              </div>
            )
          )}

          {/* SUB-TAB 3: WEEKLY & MONTHLY CALENDAR PREVIEW + APPROVAL GATE */}
          {subTab === 'calendar' && (
            !strategy ? (
              <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center text-xs text-slate-500 space-y-3">
                <p>Generate a strategy in Step 1 to preview and approve your weekly &amp; monthly content calendar draft.</p>
                <button
                  type="button"
                  onClick={() => setSubTab('setup')}
                  className="h-9 px-4 rounded-lg bg-blue-600 text-white font-semibold"
                >
                  Open Strategy Setup
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {/* Action Bar */}
                <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 p-0.5 bg-slate-50 dark:bg-slate-950">
                      <button
                        type="button"
                        onClick={() => setCalendarGrouping('weekly')}
                        className={`h-7 px-3 rounded font-semibold ${
                          calendarGrouping === 'weekly'
                            ? 'bg-blue-600 text-white'
                            : 'text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        Weekly View
                      </button>
                      <button
                        type="button"
                        onClick={() => setCalendarGrouping('monthly')}
                        className={`h-7 px-3 rounded font-semibold ${
                          calendarGrouping === 'monthly'
                            ? 'bg-blue-600 text-white'
                            : 'text-slate-600 dark:text-slate-300'
                        }`}
                      >
                        Monthly View
                      </button>
                    </div>
                    {savingDraft && (
                      <span className="text-slate-500 inline-flex items-center gap-1">
                        <Loader2 className="w-3 h-3 animate-spin" /> Saving draft...
                      </span>
                    )}
                  </div>

                  {canWrite && (
                    <div className="flex flex-wrap items-center gap-2">
                      {strategy.calendarItems.some((it) => it.status === 'rejected') && (
                        <button
                          type="button"
                          onClick={removeRejectedDraftItems}
                          className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-rose-600 font-semibold inline-flex items-center gap-1.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove Rejected</span>
                        </button>
                      )}
                      {strategy.calendarItems.some((it) => it.status !== 'saved_to_calendar') &&
                        (!confirmClearDraftItems ? (
                          <button
                            type="button"
                            onClick={() => setConfirmClearDraftItems(true)}
                            className="h-9 px-3 rounded-lg border border-rose-200 dark:border-rose-900 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 font-semibold inline-flex items-center gap-1.5"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>Clear Draft</span>
                          </button>
                        ) : (
                          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg border border-rose-300 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40">
                            <span className="text-rose-700 dark:text-rose-300 font-semibold">
                              Clear unsaved items?
                            </span>
                            <button
                              type="button"
                              onClick={clearUnsavedDraftItems}
                              className="h-7 px-2.5 rounded bg-rose-600 text-white font-semibold"
                            >
                              Confirm
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmClearDraftItems(false)}
                              className="h-7 px-2 rounded border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold"
                            >
                              Cancel
                            </button>
                          </div>
                        ))}
                      <button
                        type="button"
                        disabled={applying || approvedPendingCount === 0}
                        onClick={() => void handleApplyToCalendar(false)}
                        className="h-9 px-3.5 rounded-lg border border-blue-600 text-blue-600 dark:text-blue-400 font-semibold disabled:opacity-50 inline-flex items-center gap-1.5"
                      >
                        {applying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />}
                        <span>Save Approved ({approvedPendingCount}) to Calendar</span>
                      </button>
                      <button
                        type="button"
                        disabled={applying || totalUnsavedPending === 0}
                        onClick={() => void handleApplyToCalendar(true)}
                        className="h-9 px-4 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold inline-flex items-center gap-1.5"
                      >
                        {applying ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle2 className="w-3.5 h-3.5" />}
                        <span>Approve Entire Draft ({totalUnsavedPending})</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Regenerate Selected Dates Bar */}
                {canWrite && selectedDateKeys.length > 0 && (
                  <div className="rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/60 dark:bg-blue-950/20 p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs">
                    <div className="font-semibold text-blue-800 dark:text-blue-200">
                      {selectedDateKeys.length} date(s) selected for regeneration ({selectedDateKeys.join(', ')})
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <input
                        type="text"
                        value={regenNote}
                        onChange={(e) => setRegenNote(e.target.value)}
                        placeholder="Optional instruction (e.g., lighter topic, Shorts only)..."
                        className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 w-60"
                      />
                      <button
                        type="button"
                        disabled={regeneratingDates}
                        onClick={() => void handleRegenerateSelectedDates()}
                        className="h-8 px-3 rounded-lg bg-blue-600 text-white font-semibold inline-flex items-center gap-1.5"
                      >
                        {regeneratingDates ? (
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        ) : (
                          <RefreshCw className="w-3.5 h-3.5" />
                        )}
                        <span>Regenerate Selected Dates</span>
                      </button>
                    </div>
                  </div>
                )}

                {/* Grouped Draft Items */}
                <div className="space-y-4">
                  {groupedItems.map((group) => (
                    <div
                      key={group.label}
                      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
                    >
                      <div className="px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                        <span className="font-display font-bold text-slate-900 dark:text-white">
                          {group.label}
                        </span>
                        <span className="font-mono tabular-nums text-slate-500">
                          {group.items.length} planned item(s)
                        </span>
                      </div>

                      <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                        {group.items.map((item) => {
                          const isEditing = editingItemId === item.id;
                          const isSaved = item.status === 'saved_to_calendar';
                          const isRejected = item.status === 'rejected';
                          const isApproved = item.status === 'approved';
                          const isDateChecked = selectedDateKeys.includes(item.date);

                          return (
                            <div
                              key={item.id}
                              className={`p-4 flex flex-col lg:flex-row lg:items-start justify-between gap-3 ${
                                isRejected ? 'opacity-55' : ''
                              }`}
                            >
                              <div className="flex items-start gap-3 min-w-0 flex-1">
                                {!isSaved && canWrite && (
                                  <input
                                    type="checkbox"
                                    aria-label={`Select date ${item.date} for regeneration`}
                                    checked={isDateChecked}
                                    onChange={() => toggleDateSelection(item.date)}
                                    className="mt-1 rounded border-slate-300 dark:border-slate-700"
                                  />
                                )}
                                <div className="min-w-0 flex-1 space-y-1">
                                  {isEditing ? (
                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                      <input
                                        type="text"
                                        value={item.title}
                                        onChange={(e) =>
                                          updateCalendarItem(item.id, { title: e.target.value })
                                        }
                                        className="sm:col-span-3 h-9 px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-semibold"
                                      />
                                      <input
                                        type="date"
                                        value={item.date}
                                        onChange={(e) =>
                                          updateCalendarItem(item.id, {
                                            date: e.target.value,
                                            publishingDeadline: e.target.value,
                                          })
                                        }
                                        className="h-9 px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                                      />
                                      <input
                                        type="text"
                                        value={item.time || ''}
                                        onChange={(e) =>
                                          updateCalendarItem(item.id, { time: e.target.value || null })
                                        }
                                        placeholder="16:00"
                                        className="h-9 px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                                      />
                                      <select
                                        value={item.priority}
                                        onChange={(e) =>
                                          updateCalendarItem(item.id, {
                                            priority: e.target.value as YtmPriority,
                                          })
                                        }
                                        className="h-9 px-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                                      >
                                        <option value="low">low</option>
                                        <option value="medium">medium</option>
                                        <option value="high">high</option>
                                        <option value="urgent">urgent</option>
                                      </select>
                                    </div>
                                  ) : (
                                    <>
                                      <div className="font-semibold text-sm text-slate-950 dark:text-white">
                                        {item.title}
                                      </div>
                                      <div className="font-mono tabular-nums text-[11px] text-slate-500">
                                        {item.date} {item.time || ''} · {item.platform} ·{' '}
                                        {CONTENT_TYPE_LABELS[item.contentType] || item.contentType} ·{' '}
                                        Priority: {item.priority} · Prod Due: {item.productionDeadline}
                                      </div>
                                      <p className="text-slate-600 dark:text-slate-400">
                                        {item.objective}
                                      </p>
                                    </>
                                  )}
                                </div>
                              </div>

                              <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                                {isSaved ? (
                                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold inline-flex items-center gap-1">
                                    <CheckCircle2 className="w-3.5 h-3.5" />
                                    Saved to Calendar
                                  </span>
                                ) : (
                                  canWrite && (
                                    <>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setEditingItemId(isEditing ? null : item.id)
                                        }
                                        className="h-8 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                                      >
                                        {isEditing ? 'Done' : 'Edit / Reschedule'}
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          updateCalendarItem(item.id, {
                                            status: isApproved ? 'pending_review' : 'approved',
                                          })
                                        }
                                        className={`h-8 px-2.5 rounded-lg font-semibold inline-flex items-center gap-1 ${
                                          isApproved
                                            ? 'bg-emerald-600 text-white'
                                            : 'border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200'
                                        }`}
                                      >
                                        <Check className="w-3.5 h-3.5" />
                                        <span>{isApproved ? 'Approved' : 'Approve'}</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          updateCalendarItem(item.id, {
                                            status: isRejected ? 'pending_review' : 'rejected',
                                          })
                                        }
                                        className={`h-8 px-2.5 rounded-lg font-semibold inline-flex items-center gap-1 ${
                                          isRejected
                                            ? 'bg-rose-600 text-white'
                                            : 'border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-rose-600'
                                        }`}
                                      >
                                        <X className="w-3.5 h-3.5" />
                                        <span>{isRejected ? 'Rejected' : 'Reject'}</span>
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => deleteCalendarItem(item.id)}
                                        aria-label={`Delete draft item ${item.title}`}
                                        title="Delete from draft"
                                        className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-400 hover:text-rose-600 hover:border-rose-300 dark:hover:border-rose-800 inline-flex items-center"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" />
                                      </button>
                                    </>
                                  )
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )
          )}

          {/* SUB-TAB 4: CONTINUOUS CALENDAR HEALTH & RESCHEDULING ASSISTANCE */}
          {subTab === 'audit' && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div>
                  <h4 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                    Continuous Calendar Health &amp; Rescheduling Audit
                  </h4>
                  <p className="text-slate-500 mt-0.5">
                    {liveAudit?.healthSummary ||
                      'Monitors your live Content Planner for missed deadlines, overloaded weeks, publishing gaps, and overlapping dates. No schedule changes are applied without your explicit approval.'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => void loadStrategy()}
                  className="h-8 px-3 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold inline-flex items-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Re-Scan Calendar</span>
                </button>
              </div>

              {!liveAudit || liveAudit.suggestions.length === 0 ? (
                <div className="py-6 text-center text-emerald-700 dark:text-emerald-400 font-semibold flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Your Content Planner schedule is healthy — no missed deadlines, overlaps, or overload warnings detected.</span>
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {liveAudit.suggestions.map((item) => (
                    <div
                      key={item.id}
                      className="py-3.5 flex flex-col md:flex-row md:items-center justify-between gap-3"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <AlertTriangle
                            className={`w-4 h-4 shrink-0 ${
                              item.severity === 'high'
                                ? 'text-rose-600'
                                : item.severity === 'medium'
                                  ? 'text-amber-600'
                                  : 'text-blue-600'
                            }`}
                          />
                          <span className="font-semibold text-slate-950 dark:text-white">
                            {item.targetTitle}
                          </span>
                          <span className="font-mono text-[11px] uppercase text-slate-500">
                            · {item.issueType.replace(/_/g, ' ')}
                            {item.currentDate ? ` · Current: ${item.currentDate}` : ''}
                            {item.suggestedDate ? ` → Proposed: ${item.suggestedDate}` : ''}
                          </span>
                        </div>
                        <p className="text-slate-600 dark:text-slate-400 pl-6">
                          {item.summary} {item.rationale}
                        </p>
                      </div>

                      {canWrite && item.suggestedDate && (
                        <button
                          type="button"
                          disabled={applyingAuditId === item.id}
                          onClick={() =>
                            void handleApplyAuditSuggestion(
                              item.id,
                              item.targetType,
                              item.targetId,
                              item.targetTitle,
                              item.suggestedDate!
                            )
                          }
                          className="h-8 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-60 text-white font-semibold shrink-0 inline-flex items-center gap-1.5 self-start md:self-center"
                        >
                          {applyingAuditId === item.id ? (
                            <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <Check className="w-3.5 h-3.5" />
                          )}
                          <span>Approve &amp; Apply ({item.suggestedDate})</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
