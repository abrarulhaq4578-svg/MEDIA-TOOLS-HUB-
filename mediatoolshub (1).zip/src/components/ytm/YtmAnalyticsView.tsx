import React, { useEffect, useState } from 'react';
import {
  AlertCircle,
  BarChart3,
  ExternalLink,
  Info,
  Loader2,
  RefreshCw,
  Sparkles,
  Youtube,
} from 'lucide-react';
import type {
  YtmChannelAnalyticsReport,
  YtmConnectedChannelRecord,
} from '../../shared/types.ts';
import { formatCompactNumber, ytmRequest, type AuthFetchFn } from './YtmApiClient.ts';

interface Props {
  authFetch: AuthFetchFn;
  workspaceKey: string;
  connectedChannel: YtmConnectedChannelRecord | null;
  onConnectYouTube: () => void;
}

interface AnalyticsInsightsResult {
  executiveSummary: string;
  wins: string[];
  bottlenecks: string[];
  experiments: string[];
  limitationsNotice: string;
}

interface ChannelVideoSummary {
  videoId: string;
  title: string;
  publishedAt?: string;
  thumbnailUrl?: string;
  viewCount?: number;
}

function isoDaysAgo(days: number): string {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
}

function formatDuration(sec: number | null | undefined): string {
  if (sec === null || sec === undefined || !Number.isFinite(sec)) return 'Unavailable';
  const total = Math.max(0, Math.round(sec));
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function YtmAnalyticsView({
  authFetch,
  workspaceKey,
  connectedChannel,
  onConnectYouTube,
}: Props) {
  const [startDate, setStartDate] = useState<string>(() => isoDaysAgo(28));
  const [endDate, setEndDate] = useState<string>(() => isoDaysAgo(0));
  const [report, setReport] = useState<YtmChannelAnalyticsReport | null>(null);
  const [recentVideos, setRecentVideos] = useState<ChannelVideoSummary[]>([]);
  const [insights, setInsights] = useState<AnalyticsInsightsResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const loadAnalytics = async (rangeStart = startDate, rangeEnd = endDate) => {
    if (!connectedChannel) {
      setReport(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const [analyticsRes, videosRes] = await Promise.all([
        ytmRequest<{ report: YtmChannelAnalyticsReport }>(
          authFetch,
          `/analytics?startDate=${encodeURIComponent(rangeStart)}&endDate=${encodeURIComponent(rangeEnd)}`,
          { workspaceKey }
        ),
        ytmRequest<{ videos: ChannelVideoSummary[] }>(authFetch, '/youtube/videos', {
          workspaceKey,
        }).catch(() => ({ videos: [] })),
      ]);
      setReport(analyticsRes.report);
      setRecentVideos(videosRes.videos || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to load channel analytics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (connectedChannel) {
      void loadAnalytics();
    } else {
      setReport(null);
      setRecentVideos([]);
      setInsights(null);
    }
  }, [workspaceKey, connectedChannel?.channelId]); // eslint-disable-line react-hooks/exhaustive-deps

  const applyPreset = (days: number) => {
    const nextStart = isoDaysAgo(days);
    const nextEnd = isoDaysAgo(0);
    setStartDate(nextStart);
    setEndDate(nextEnd);
    void loadAnalytics(nextStart, nextEnd);
  };

  const handleGenerateInsights = async () => {
    if (!report) return;
    setLoadingInsights(true);
    setError(null);
    try {
      const res = await ytmRequest<{ insights: AnalyticsInsightsResult }>(
        authFetch,
        '/analytics/insights',
        { workspaceKey, method: 'POST', body: { report } }
      );
      setInsights(res.insights);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate AI analytics summary.');
    } finally {
      setLoadingInsights(false);
    }
  };

  if (!connectedChannel) {
    return (
      <div className="space-y-5">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Analytics &amp; Growth
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Official YouTube Analytics API v2 performance metrics for your connected channel only.
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-8 text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 flex items-center justify-center mx-auto text-red-600 dark:text-red-400">
            <Youtube className="w-6 h-6" />
          </div>
          <div className="max-w-lg mx-auto space-y-1.5">
            <h3 className="font-display text-base font-bold text-slate-950 dark:text-white">
              Connect Your Own YouTube Channel to View Private Analytics
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              This section displays authorized views, watch time, average view duration, subscriber changes, traffic sources, and top videos for your channel only. Public competitor analysis remains strictly separated in Competitor &amp; Analytics.
            </p>
          </div>
          <button
            type="button"
            onClick={onConnectYouTube}
            className="h-10 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold inline-flex items-center gap-2"
          >
            <Youtube className="w-4 h-4" />
            <span>Connect YouTube Channel</span>
          </button>
        </div>
      </div>
    );
  }

  const maxDailyViews = Math.max(1, ...(report?.dailySeries || []).map((d) => d.views || 0));

  return (
    <div className="space-y-6">
      {/* Header + Date Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold text-slate-950 dark:text-white">
            Analytics &amp; Growth · {connectedChannel.channelTitle}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Source: {report?.source === 'youtube_analytics_api_v2' ? 'YouTube Analytics API v2' : 'YouTube Data API Fallback'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 p-0.5">
            {[7, 28, 90].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => applyPreset(d)}
                className="px-2.5 py-1.5 rounded-md font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                {d}d
              </button>
            ))}
          </div>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
          />
          <span className="text-slate-400">→</span>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-xs"
          />
          <button
            type="button"
            disabled={loading}
            onClick={() => void loadAnalytics(startDate, endDate)}
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 font-semibold inline-flex items-center gap-1.5"
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
            <span>Refresh</span>
          </button>
          <button
            type="button"
            disabled={loadingInsights || !report}
            onClick={() => void handleGenerateInsights()}
            className="h-9 px-3.5 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-semibold inline-flex items-center gap-1.5"
          >
            {loadingInsights ? (
              <Loader2 className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5" />
            )}
            <span>AI Performance Insights</span>
          </button>
        </div>
      </div>

      {error && (
        <div className="p-3.5 rounded-xl border border-red-200 dark:border-red-900 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {loading && !report ? (
        <div className="p-12 text-center text-slate-500 text-xs flex items-center justify-center gap-2">
          <Loader2 className="w-4 h-4 animate-spin" />
          <span>Loading official YouTube Analytics v2 metrics…</span>
        </div>
      ) : report ? (
        <>
          {/* KPI Strip */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-3">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Views
              </div>
              <div className="mt-1 font-display text-2xl font-bold tabular-nums text-slate-950 dark:text-white">
                {report.totals.views !== null ? formatCompactNumber(report.totals.views) : 'Unavailable'}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Watch Time (hrs)
              </div>
              <div className="mt-1 font-display text-2xl font-bold tabular-nums text-slate-950 dark:text-white">
                {report.totals.estimatedMinutesWatched !== null
                  ? (report.totals.estimatedMinutesWatched / 60).toFixed(1)
                  : 'Unavailable'}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Avg Duration
              </div>
              <div className="mt-1 font-display text-2xl font-bold tabular-nums text-slate-950 dark:text-white">
                {formatDuration(report.totals.averageViewDurationSec)}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Net Subs
              </div>
              <div className="mt-1 font-display text-2xl font-bold tabular-nums text-slate-950 dark:text-white">
                {report.totals.subscribersGained !== null
                  ? `${report.totals.subscribersGained - (report.totals.subscribersLost || 0) >= 0 ? '+' : ''}${
                      report.totals.subscribersGained - (report.totals.subscribersLost || 0)
                    }`
                  : 'Unavailable'}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Impressions
              </div>
              <div className="mt-1 font-display text-lg font-bold tabular-nums text-slate-500 dark:text-slate-400">
                {report.totals.impressions !== null
                  ? formatCompactNumber(report.totals.impressions)
                  : 'Unavailable'}
              </div>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500">
                Impressions CTR
              </div>
              <div className="mt-1 font-display text-lg font-bold tabular-nums text-slate-500 dark:text-slate-400">
                {report.totals.impressionsCtr !== null
                  ? `${report.totals.impressionsCtr.toFixed(2)}%`
                  : 'Unavailable'}
              </div>
            </div>
          </div>

          {report.unavailableMetricsNote && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 px-4 py-3 text-xs text-slate-600 dark:text-slate-400 flex items-start gap-2">
              <Info className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <span>{report.unavailableMetricsNote}</span>
            </div>
          )}

          {/* AI Insights Card */}
          {insights && (
            <div className="rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/40 dark:bg-blue-950/20 p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                  AI Growth Insights
                </h3>
              </div>
              <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed">
                {insights.executiveSummary}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div>
                  <div className="font-semibold text-emerald-700 dark:text-emerald-300 mb-1.5">
                    Wins
                  </div>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {insights.wins.map((w, idx) => (
                      <li key={idx}>{w}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <div className="font-semibold text-amber-700 dark:text-amber-300 mb-1.5">
                    Bottlenecks
                  </div>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {insights.bottlenecks.map((b, idx) => (
                      <li key={idx}>{b}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <div className="font-semibold text-blue-700 dark:text-blue-300 mb-1.5">
                    Next Experiments
                  </div>
                  <ul className="space-y-1 text-slate-600 dark:text-slate-300 list-disc pl-4">
                    {insights.experiments.map((ex, idx) => (
                      <li key={idx}>{ex}</li>
                    ))}
                  </ul>
                </div>
              </div>
              {insights.limitationsNotice && (
                <div className="text-[11px] text-slate-500 dark:text-slate-400">
                  {insights.limitationsNotice}
                </div>
              )}
            </div>
          )}

          {/* Daily Trend + Traffic Sources */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-blue-600" />
                  <span>Daily Views Trend</span>
                </h3>
                <span className="text-[11px] font-mono text-slate-500">
                  {report.dailySeries.length} days
                </span>
              </div>
              {report.dailySeries.length === 0 ? (
                <div className="text-xs text-slate-500 py-4">
                  No daily series available for the selected date range.
                </div>
              ) : (
                <div className="space-y-1.5 max-h-72 overflow-y-auto pr-1">
                  {report.dailySeries.slice(-14).map((day) => {
                    const pct = Math.max(4, Math.round((day.views / maxDailyViews) * 100));
                    return (
                      <div key={day.date} className="flex items-center gap-3 text-xs">
                        <span className="font-mono text-[11px] text-slate-500 w-24 shrink-0">
                          {day.date}
                        </span>
                        <div className="flex-1 h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                          <div className="h-full bg-blue-600 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                        <span className="font-mono tabular-nums text-slate-700 dark:text-slate-300 w-16 text-right shrink-0">
                          {day.views.toLocaleString()}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
              <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
                Traffic Sources
              </h3>
              {report.trafficSources.length === 0 ? (
                <div className="text-xs text-slate-500 py-4">
                  No traffic source breakdown returned for this window.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                        <th className="pb-2 font-semibold">Source</th>
                        <th className="pb-2 font-semibold text-right">Views</th>
                        <th className="pb-2 font-semibold text-right">Watch Mins</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {report.trafficSources.map((ts) => (
                        <tr key={ts.sourceType}>
                          <td className="py-2 font-medium text-slate-800 dark:text-slate-200">
                            {ts.sourceType.replace(/_/g, ' ')}
                          </td>
                          <td className="py-2 text-right font-mono tabular-nums">
                            {ts.views.toLocaleString()}
                          </td>
                          <td className="py-2 text-right font-mono tabular-nums text-slate-500">
                            {Math.round(ts.estimatedMinutesWatched).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Top Videos Table */}
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
            <h3 className="font-display text-sm font-bold text-slate-950 dark:text-white">
              Top Videos in Selected Period
            </h3>
            {report.topVideos.length === 0 ? (
              <div className="text-xs text-slate-500">
                No top-video Analytics rows returned. Recent uploads are listed below if available.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500">
                      <th className="pb-2 font-semibold">Video</th>
                      <th className="pb-2 font-semibold text-right">Views</th>
                      <th className="pb-2 font-semibold text-right">Watch Time (min)</th>
                      <th className="pb-2 font-semibold text-right">Avg Duration</th>
                      <th className="pb-2 font-semibold text-right">Link</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {report.topVideos.map((v) => (
                      <tr key={v.videoId}>
                        <td className="py-2.5 pr-4 font-semibold text-slate-900 dark:text-white">
                          {v.title}
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums">
                          {v.views.toLocaleString()}
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          {Math.round(v.estimatedMinutesWatched).toLocaleString()}
                        </td>
                        <td className="py-2.5 text-right font-mono tabular-nums text-slate-600 dark:text-slate-300">
                          {formatDuration(v.averageViewDurationSec)}
                        </td>
                        <td className="py-2.5 text-right">
                          <a
                            href={`https://www.youtube.com/watch?v=${v.videoId}`}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-blue-600 dark:text-blue-400 font-semibold"
                          >
                            <span>Open</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {recentVideos.length > 0 && (
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Latest Channel Uploads ({recentVideos.length})
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {recentVideos.slice(0, 6).map((vid) => (
                    <a
                      key={vid.videoId}
                      href={`https://www.youtube.com/watch?v=${vid.videoId}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-3 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-blue-400 transition-colors"
                    >
                      {vid.thumbnailUrl && (
                        <img
                          src={vid.thumbnailUrl}
                          alt={vid.title}
                          referrerPolicy="no-referrer"
                          className="w-20 aspect-video rounded object-cover shrink-0"
                        />
                      )}
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-slate-900 dark:text-white truncate">
                          {vid.title}
                        </div>
                        {vid.viewCount !== undefined && (
                          <div className="text-[11px] font-mono text-slate-500">
                            {formatCompactNumber(vid.viewCount)} views
                          </div>
                        )}
                      </div>
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>
        </>
      ) : null}
    </div>
  );
}
