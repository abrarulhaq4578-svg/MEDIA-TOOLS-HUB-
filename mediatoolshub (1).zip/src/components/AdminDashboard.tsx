import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  BarChart3,
  CheckCircle2,
  FileText,
  Film,
  KeyRound,
  Megaphone,
  Settings,
  Shield,
  Trash2,
  Users,
  Wrench,
} from 'lucide-react';
import { useApp } from '../context/AppContext.tsx';
import { parseSafeJsonResponse } from '../lib/apiClient.ts';
import type {
  AdPlacement,
  AdminMediaStats,
  BlogPostRecord,
  IntegrationStatus,
  ToolDefinition,
  UserProfile,
  YouTubeApiQuotaStats,
} from '../shared/types.ts';

type AdminTab =
  | 'overview'
  | 'media'
  | 'integrations'
  | 'tools'
  | 'ads'
  | 'blog'
  | 'users'
  | 'reports'
  | 'logs'
  | 'settings';

export function AdminDashboard() {
  const { firebaseUser, dbUser, signInWithGoogle, authFetch, tools, refreshCatalog } = useApp();
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [overview, setOverview] = useState<{
    summary: {
      totalVisitors: number;
      dailyVisitors: number;
      monthlyVisitors: number;
      totalToolUsage: number;
      failedRequests: number;
      apiUsageCount: number;
      activeUsers: number;
      openAbuseReports: number;
      unreadContacts: number;
    };
    topTools: Array<{ slug: string; name: string; platformSlug: string; usageCount: number; isEnabled: boolean }>;
    platformBreakdown: Array<{ platformSlug: string; runs: number }>;
    recentAudit: Array<{ id: number; actorEmail: string; action: string; resourceType: string; createdAt: string }>;
    integrations?: IntegrationStatus[];
    youtubeQuota?: YouTubeApiQuotaStats;
  } | null>(null);

  const [integrationList, setIntegrationList] = useState<IntegrationStatus[]>([]);
  const [youtubeQuota, setYoutubeQuota] = useState<YouTubeApiQuotaStats | null>(null);
  const [ads, setAds] = useState<AdPlacement[]>([]);
  const [posts, setPosts] = useState<BlogPostRecord[]>([]);
  const [userList, setUserList] = useState<UserProfile[]>([]);
  const [reports, setReports] = useState<{
    abuseReports: Array<{ id: number; targetUrl: string; reportType: string; reporterEmail: string; details: string; status: string; createdAt: string }>;
    contactMessages: Array<{ id: number; name: string; email: string; subject: string; message: string; status: string; createdAt: string }>;
  }>({ abuseReports: [], contactMessages: [] });
  const [logs, setLogs] = useState<{
    processingJobs: Array<{ id: number; toolSlug: string; platformSlug: string; status: string; durationMs: number; errorMessage: string | null; createdAt: string }>;
    auditLogs: Array<{ id: number; actorEmail: string; action: string; resourceType: string; resourceId: string | null; createdAt: string }>;
  }>({ processingJobs: [], auditLogs: [] });
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [mediaStats, setMediaStats] = useState<AdminMediaStats | null>(null);
  const [mediaLimitInput, setMediaLimitInput] = useState('100');
  const [mediaTtlInput, setMediaTtlInput] = useState('30');
  const [mediaDomainsInput, setMediaDomainsInput] = useState('');
  const [cleanupNotice, setCleanupNotice] = useState<string | null>(null);

  // New Blog Post Form
  const [newPost, setNewPost] = useState({
    title: '',
    slug: '',
    excerpt: '',
    category: 'Guides',
    contentMarkdown: '',
  });
  const [savingMsg, setSavingMsg] = useState<string | null>(null);

  const loadTabData = async (tab: AdminTab) => {
    setLoading(true);
    setError(null);
    try {
      if (tab === 'overview') {
        const res = await authFetch('/api/v1/admin/overview');
        const data = await parseSafeJsonResponse<NonNullable<typeof overview>>(res);
        setOverview(data);
        if (data.integrations) setIntegrationList(data.integrations);
        if (data.youtubeQuota) setYoutubeQuota(data.youtubeQuota);
      } else if (tab === 'media') {
        const res = await authFetch('/api/v1/admin/media');
        const data = await parseSafeJsonResponse<AdminMediaStats>(res);
        setMediaStats(data);
        setMediaLimitInput(String(data.maxUploadMb));
        setMediaTtlInput(String(data.jobTtlMinutes));
        setMediaDomainsInput(data.allowedDomains || '');
      } else if (tab === 'integrations') {
        const res = await authFetch('/api/v1/admin/integrations');
        const data = await parseSafeJsonResponse<{
          integrations?: IntegrationStatus[];
          youtubeQuota?: YouTubeApiQuotaStats | null;
        }>(res);
        setIntegrationList(data.integrations || []);
        setYoutubeQuota(data.youtubeQuota || null);
      } else if (tab === 'ads') {
        const res = await authFetch('/api/v1/admin/ads');
        const data = await parseSafeJsonResponse<{ placements?: AdPlacement[] }>(res);
        setAds(data.placements || []);
      } else if (tab === 'blog') {
        const res = await authFetch('/api/v1/admin/blog');
        const data = await parseSafeJsonResponse<{ posts?: BlogPostRecord[] }>(res);
        setPosts(data.posts || []);
      } else if (tab === 'users') {
        const res = await authFetch('/api/v1/admin/users');
        const data = await parseSafeJsonResponse<{ users?: UserProfile[] }>(res);
        setUserList(data.users || []);
      } else if (tab === 'reports') {
        const res = await authFetch('/api/v1/admin/reports');
        setReports(await parseSafeJsonResponse<typeof reports>(res));
      } else if (tab === 'logs') {
        const res = await authFetch('/api/v1/admin/logs');
        setLogs(await parseSafeJsonResponse<typeof logs>(res));
      } else if (tab === 'settings') {
        const res = await authFetch('/api/v1/admin/settings');
        const data = await parseSafeJsonResponse<{ settings?: Record<string, string> }>(res);
        setSettings(data.settings || {});
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Admin request failed.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (dbUser?.role === 'admin') {
      void loadTabData(activeTab);
    } else {
      setLoading(false);
    }
  }, [dbUser, activeTab]);

  if (!firebaseUser) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center space-y-4">
        <Shield className="w-10 h-10 text-blue-600 mx-auto" />
        <h1 className="font-display text-2xl font-bold text-slate-950 dark:text-white">
          Administrator Sign-In Required
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Public admin registration is disabled. Sign in with an authorized administrator Google account.
        </p>
        <button
          type="button"
          onClick={() => void signInWithGoogle()}
          className="px-6 py-2.5 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-sm font-semibold"
        >
          Sign in with Google
        </button>
      </div>
    );
  }

  if (dbUser?.role !== 'admin') {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center space-y-3">
        <AlertTriangle className="w-10 h-10 text-amber-500 mx-auto" />
        <h1 className="font-display text-2xl font-bold text-slate-950 dark:text-white">
          Access Restricted
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">
          Signed in as <span className="font-mono">{firebaseUser.email}</span>, which does not hold administrator privileges.
        </p>
      </div>
    );
  }

  const toggleTool = async (tool: ToolDefinition) => {
    const res = await authFetch(`/api/v1/admin/tools/${tool.slug}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isEnabled: tool.isEnabled === false }),
    });
    if (res.ok) await refreshCatalog();
  };

  const updateAd = async (placementKey: string, patch: Partial<AdPlacement>) => {
    const res = await authFetch(`/api/v1/admin/ads/${placementKey}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    if (res.ok) {
      await loadTabData('ads');
      await refreshCatalog();
    }
  };

  const createBlogPost = async (e: React.FormEvent) => {
    e.preventDefault();
    const res = await authFetch('/api/v1/admin/blog', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPost),
    });
    if (res.ok) {
      setNewPost({ title: '', slug: '', excerpt: '', category: 'Guides', contentMarkdown: '' });
      await loadTabData('blog');
    }
  };

  const saveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingMsg(null);
    const res = await authFetch('/api/v1/admin/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ settings }),
    });
    if (res.ok) {
      setSavingMsg('Settings saved to PostgreSQL.');
      await refreshCatalog();
    }
  };

  const toggleOptionalIntegration = async (item: IntegrationStatus) => {
    if (!item.toggleSettingKey) return;
    const nextEnabled = item.status === 'Disabled';
    const res = await authFetch('/api/v1/admin/settings', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        settings: { [item.toggleSettingKey]: nextEnabled ? 'true' : 'false' },
      }),
    });
    if (res.ok) {
      await loadTabData('integrations');
      await refreshCatalog();
    }
  };

  const navItems: Array<{ id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'overview', label: 'Overview', icon: BarChart3 },
    { id: 'media', label: 'Media Processing', icon: Film },
    { id: 'integrations', label: 'Integrations & Env', icon: KeyRound },
    { id: 'tools', label: 'Tools & SEO', icon: Wrench },
    { id: 'ads', label: 'Ad Placements', icon: Megaphone },
    { id: 'blog', label: 'Blog Manager', icon: FileText },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'reports', label: 'Reports & Inbox', icon: AlertTriangle },
    { id: 'logs', label: 'System Logs', icon: Activity },
    { id: 'settings', label: 'Settings & Limits', icon: Settings },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Sidebar */}
        <aside className="w-full lg:w-64 shrink-0 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-3 space-y-1">
          <div className="px-3 py-2 text-xs font-semibold text-slate-400">
            MediaToolsHub Admin
          </div>
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${
                  active
                    ? 'bg-[#0F172A] dark:bg-blue-600 text-white'
                    : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </aside>

        {/* Main Admin Content */}
        <div className="flex-1 min-w-0 w-full space-y-6">
          {error && (
            <div className="rounded-xl border border-rose-200 bg-rose-50 dark:bg-rose-950/30 p-4 text-sm text-rose-800 dark:text-rose-200">
              {error}
            </div>
          )}

          {loading ? (
            <div className="h-64 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 animate-pulse" />
          ) : (
            <>
              {/* OVERVIEW */}
              {activeTab === 'overview' && overview && (
                <div className="space-y-6">
                  {integrationList.some((i) => i.status !== 'Connected') && (
                    <div className="rounded-2xl border border-amber-200 dark:border-amber-900/60 bg-amber-50/80 dark:bg-amber-950/25 p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="font-display text-sm font-bold text-amber-950 dark:text-amber-200">
                          Integration Configuration Status
                        </div>
                        <p className="text-xs text-amber-900 dark:text-amber-300 leading-relaxed">
                          Unconfigured or disabled integrations do not block core features:{' '}
                          <span className="font-mono">
                            {integrationList
                              .filter((i) => i.status !== 'Connected')
                              .map((i) => `${i.envVar} (${i.status})`)
                              .join(', ')}
                          </span>
                          .
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTab('integrations')}
                        className="px-4 py-2 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white text-xs font-semibold whitespace-nowrap shrink-0"
                      >
                        Review Integrations
                      </button>
                    </div>
                  )}

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    {[
                      { label: 'Daily Visitors', val: overview.summary.dailyVisitors },
                      { label: 'Monthly Visitors', val: overview.summary.monthlyVisitors },
                      { label: 'Total Tool Runs', val: overview.summary.totalToolUsage },
                      { label: 'Failed Requests', val: overview.summary.failedRequests },
                      { label: 'API Key Requests', val: overview.summary.apiUsageCount },
                      { label: 'Registered Users', val: overview.summary.activeUsers },
                      { label: 'Open DMCA/Abuse', val: overview.summary.openAbuseReports },
                      {
                        label: 'YT API Units Today',
                        val: youtubeQuota ? `${youtubeQuota.estimatedUnitsUsed}/${youtubeQuota.dailyBudgetLimit}` : '0',
                      },
                    ].map((kpi) => (
                      <div
                        key={kpi.label}
                        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4"
                      >
                        <div className="text-xs text-slate-500 dark:text-slate-400">{kpi.label}</div>
                        <div className="mt-1.5 font-display text-2xl font-bold font-mono tabular-nums text-slate-950 dark:text-white">
                          {typeof kpi.val === 'number' ? kpi.val.toLocaleString() : kpi.val}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                      <h2 className="font-display text-base font-bold mb-4">Most Popular Tools</h2>
                      <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                        {overview.topTools.map((t) => (
                          <div key={t.slug} className="py-2.5 flex items-center justify-between">
                            <span className="font-medium text-slate-900 dark:text-white">{t.name}</span>
                            <span className="font-mono tabular-nums text-slate-500">
                              {t.usageCount.toLocaleString()} runs
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                      <h2 className="font-display text-base font-bold mb-4">Platform Distribution</h2>
                      {overview.platformBreakdown.length === 0 ? (
                        <p className="text-xs text-slate-500">No tool executions logged yet.</p>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                          {overview.platformBreakdown.map((p) => (
                            <div key={p.platformSlug} className="py-2.5 flex items-center justify-between">
                              <span className="capitalize font-medium text-slate-900 dark:text-white">
                                {p.platformSlug}
                              </span>
                              <span className="font-mono tabular-nums text-slate-500">
                                {p.runs} jobs
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* MEDIA PROCESSING */}
              {activeTab === 'media' && mediaStats && (
                <div className="space-y-6">
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                    {[
                      { label: 'Total Conversions', val: mediaStats.totalJobs },
                      { label: 'Successful', val: mediaStats.successfulConversions },
                      { label: 'Failed', val: mediaStats.failedConversions },
                      { label: 'Active Jobs', val: mediaStats.activeJobsCount },
                      { label: 'Expired Jobs', val: mediaStats.expiredJobsCount },
                      {
                        label: 'Temp Storage',
                        val: `${(mediaStats.storageUsedBytes / (1024 * 1024)).toFixed(2)} MB (${mediaStats.tempFileCount})`,
                      },
                    ].map((kpi) => (
                      <div
                        key={kpi.label}
                        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-4"
                      >
                        <div className="text-xs text-slate-500 dark:text-slate-400">{kpi.label}</div>
                        <div className="mt-1.5 font-display text-lg font-bold font-mono tabular-nums text-slate-950 dark:text-white">
                          {typeof kpi.val === 'number' ? kpi.val.toLocaleString() : kpi.val}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Configurable Limits & Temporary Storage Cleanup */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        setCleanupNotice(null);
                        const res = await authFetch('/api/v1/admin/settings', {
                          method: 'PATCH',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({
                            settings: {
                              media_max_upload_mb: mediaLimitInput,
                              media_job_ttl_minutes: mediaTtlInput,
                              media_allowed_domains: mediaDomainsInput,
                            },
                          }),
                        });
                        if (res.ok) {
                          setCleanupNotice('Media limits and domain rules saved.');
                          await loadTabData('media');
                        }
                      }}
                      className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 text-xs"
                    >
                      <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
                        Media Limits & URL Allowlist
                      </h2>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                            Max File Size (MB, 1-500)
                          </label>
                          <input
                            type="number"
                            min={1}
                            max={500}
                            value={mediaLimitInput}
                            onChange={(e) => setMediaLimitInput(e.target.value)}
                            className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                          />
                        </div>
                        <div>
                          <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                            Temp Retention TTL (minutes)
                          </label>
                          <input
                            type="number"
                            min={1}
                            max={240}
                            value={mediaTtlInput}
                            onChange={(e) => setMediaTtlInput(e.target.value)}
                            className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1">
                          Allowed Remote Media Domains (comma-separated, blank = any safe public host)
                        </label>
                        <input
                          type="text"
                          value={mediaDomainsInput}
                          onChange={(e) => setMediaDomainsInput(e.target.value)}
                          placeholder="cdn.example.com, media.myorg.org"
                          className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                        />
                      </div>
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                      >
                        Save Media Limits
                      </button>
                    </form>

                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4 text-xs">
                      <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
                        Temporary Storage Cleanup Status
                      </h2>
                      <div className="space-y-1.5 text-slate-600 dark:text-slate-300">
                        <div>
                          <strong>Last Cleanup Run:</strong>{' '}
                          <span className="font-mono">
                            {mediaStats.lastCleanupAt
                              ? new Date(mediaStats.lastCleanupAt).toLocaleString()
                              : 'Pending / on interval'}
                          </span>
                        </div>
                        <div>
                          <strong>Last Sweep Removed:</strong>{' '}
                          <span className="font-mono">
                            {mediaStats.lastCleanupRemoved} jobs ·{' '}
                            {(mediaStats.lastCleanupFreedBytes / 1024).toFixed(1)} KB freed
                          </span>
                        </div>
                      </div>
                      {cleanupNotice && (
                        <p className="text-emerald-600 dark:text-emerald-400 font-semibold">{cleanupNotice}</p>
                      )}
                      <div className="flex flex-wrap gap-2.5 pt-1">
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await authFetch('/api/v1/media/cleanup', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ forceAll: false }),
                              });
                              const d = await parseSafeJsonResponse<{
                                removedJobs: number;
                                freedBytes: number;
                              }>(res);
                              setCleanupNotice(
                                `Swept ${d.removedJobs} expired jobs (${(d.freedBytes / 1024).toFixed(1)} KB freed).`
                              );
                              await loadTabData('media');
                            } catch (err) {
                              setCleanupNotice(
                                err instanceof Error ? err.message : 'Cleanup failed.'
                              );
                            }
                          }}
                          className="px-4 py-2 rounded-xl bg-[#0F172A] dark:bg-blue-600 text-white font-semibold inline-flex items-center gap-1.5"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Clean Expired Files</span>
                        </button>
                        <button
                          type="button"
                          onClick={async () => {
                            try {
                              const res = await authFetch('/api/v1/media/cleanup', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ forceAll: true }),
                              });
                              const d = await parseSafeJsonResponse<{
                                removedJobs: number;
                                freedBytes: number;
                              }>(res);
                              setCleanupNotice(
                                `Purged ${d.removedJobs} idle temp jobs (${(d.freedBytes / 1024).toFixed(1)} KB freed).`
                              );
                              await loadTabData('media');
                            } catch (err) {
                              setCleanupNotice(err instanceof Error ? err.message : 'Purge failed.');
                            }
                          }}
                          className="px-4 py-2 rounded-xl border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 font-semibold"
                        >
                          Purge All Idle Temp Storage
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Active Jobs, Recent Downloads, Processing Errors */}
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-xs">
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                      <h3 className="font-display text-sm font-bold mb-3">Active & Recent Jobs</h3>
                      {mediaStats.activeAndRecentJobs.length === 0 ? (
                        <p className="text-slate-500">No conversion jobs recorded in current worker.</p>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800">
                          {mediaStats.activeAndRecentJobs.slice(0, 12).map((j) => (
                            <div key={j.jobId} className="py-2 space-y-0.5">
                              <div className="flex items-center justify-between gap-2">
                                <span className="font-mono font-semibold truncate">{j.sourceLabel}</span>
                                <span className="font-mono text-blue-600 dark:text-blue-400 shrink-0">
                                  {j.status} ({j.progressPct}%)
                                </span>
                              </div>
                              <div className="text-slate-500 font-mono">
                                {j.sourceFormat || '?'} → {j.targetFormat || 'inspect'}
                                {j.outputSizeBytes ? ` · ${(j.outputSizeBytes / 1024).toFixed(1)} KB` : ''}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                      <h3 className="font-display text-sm font-bold mb-3">Recent Downloads</h3>
                      {mediaStats.recentDownloads.length === 0 ? (
                        <p className="text-slate-500">No downloads logged yet.</p>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800">
                          {mediaStats.recentDownloads.slice(0, 12).map((dl) => (
                            <div key={dl.id} className="py-2 flex items-center justify-between gap-2">
                              <span className="font-mono truncate">
                                {dl.format.toUpperCase()} · {dl.resolution || dl.assetType}
                              </span>
                              <span className="font-mono text-slate-500 shrink-0">
                                {dl.fileSizeBytes ? `${(dl.fileSizeBytes / 1024).toFixed(1)} KB` : '—'}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                      <h3 className="font-display text-sm font-bold mb-3">Processing Errors</h3>
                      {mediaStats.recentErrors.length === 0 ? (
                        <p className="text-slate-500">No recent processing errors.</p>
                      ) : (
                        <div className="divide-y divide-slate-100 dark:divide-slate-800">
                          {mediaStats.recentErrors.slice(0, 12).map((errItem) => (
                            <div key={String(errItem.id)} className="py-2 space-y-0.5">
                              <div className="font-mono text-rose-600 dark:text-rose-400 font-semibold truncate">
                                {errItem.errorCode || 'ERROR'} · {errItem.source}
                              </div>
                              <div className="text-slate-600 dark:text-slate-400 line-clamp-2">
                                {errItem.errorMessage}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* INTEGRATIONS & ENV */}
              {activeTab === 'integrations' && (
                <div className="space-y-6">
                  {youtubeQuota && (
                    <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-4">
                        <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
                          YouTube Data API v3 Quota & Cache Monitor ({youtubeQuota.dateKey})
                        </h2>
                        <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
                          {youtubeQuota.estimatedUnitsUsed} / {youtubeQuota.dailyBudgetLimit} daily units
                        </span>
                      </div>
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                        {[
                          { label: 'videos.list Calls', val: youtubeQuota.videosListCalls },
                          { label: 'channels.list Calls', val: youtubeQuota.channelsListCalls },
                          { label: 'Cache Hits Saved', val: youtubeQuota.cacheHits },
                          { label: 'Cached Videos', val: youtubeQuota.cacheEntries },
                          { label: 'API Errors Today', val: youtubeQuota.errorCount },
                        ].map((m) => (
                          <div
                            key={m.label}
                            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3"
                          >
                            <div className="text-slate-500 dark:text-slate-400">{m.label}</div>
                            <div className="mt-1 font-mono text-lg font-bold text-slate-950 dark:text-white">
                              {m.val}
                            </div>
                          </div>
                        ))}
                      </div>
                      {youtubeQuota.lastError && (
                        <p className="mt-3 text-xs text-rose-600 dark:text-rose-400 font-mono">
                          Last API note: {youtubeQuota.lastError}
                        </p>
                      )}
                    </div>
                  )}

                  {(['Required Configuration', 'Optional Integrations'] as const).map((groupLabel) => {
                    const isRequiredGroup = groupLabel === 'Required Configuration';
                    const items = integrationList.filter((i) => i.required === isRequiredGroup);
                    return (
                      <div
                        key={groupLabel}
                        className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden"
                      >
                        <div className="p-5 border-b border-slate-200 dark:border-slate-800">
                          <h2 className="font-display text-base font-bold text-slate-950 dark:text-white">
                            {groupLabel}
                          </h2>
                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                            {isRequiredGroup
                              ? 'YOUTUBE_API_KEY powers extended YouTube Data API functionality; ADMIN_EMAIL designates administrator access.'
                              : 'Optional integrations can be configured anytime without blocking development or core utilities.'}
                          </p>
                        </div>
                        <div className="divide-y divide-slate-200 dark:divide-slate-800">
                          {items.map((item) => {
                            const badgeStyle =
                              item.status === 'Connected'
                                ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                                : item.status === 'Not Configured'
                                  ? 'bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300'
                                  : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300';

                            return (
                              <div key={item.envVar} className="p-5 space-y-2.5">
                                <div className="flex flex-wrap items-center justify-between gap-3">
                                  <div className="flex items-center gap-2.5">
                                    {item.status === 'Connected' ? (
                                      <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                                    ) : (
                                      <AlertTriangle
                                        className={`w-4 h-4 shrink-0 ${
                                          item.status === 'Not Configured'
                                            ? 'text-amber-500'
                                            : 'text-slate-400'
                                        }`}
                                      />
                                    )}
                                    <span className="font-display text-sm font-bold text-slate-950 dark:text-white">
                                      {item.label}
                                    </span>
                                    <span className="font-mono text-xs text-slate-500 dark:text-slate-400">
                                      {item.envVar}
                                    </span>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <span className={`px-2.5 py-1 rounded-lg text-xs font-semibold ${badgeStyle}`}>
                                      {item.status}
                                    </span>
                                    {item.toggleSettingKey && (
                                      <button
                                        type="button"
                                        onClick={() => void toggleOptionalIntegration(item)}
                                        className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
                                      >
                                        {item.status === 'Disabled' ? 'Enable' : 'Disable'}
                                      </button>
                                    )}
                                  </div>
                                </div>
                                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                                  {item.statusMessage}
                                </p>
                                {item.status !== 'Connected' && (
                                  <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-3 text-xs space-y-1 text-slate-600 dark:text-slate-400">
                                    <div>
                                      <strong className="text-slate-800 dark:text-slate-200">
                                        Fallback Behavior:
                                      </strong>{' '}
                                      {item.disabledBehavior}
                                    </div>
                                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                                      <span>
                                        <strong className="text-slate-800 dark:text-slate-200">
                                          Configure Later:
                                        </strong>{' '}
                                        {item.activationHint}
                                      </span>
                                      {item.canConfigureInAdmin && (
                                        <button
                                          type="button"
                                          onClick={() => setActiveTab('settings')}
                                          className="px-3 py-1 rounded-lg bg-blue-600 text-white text-xs font-semibold whitespace-nowrap"
                                        >
                                          Configure in Settings
                                        </button>
                                      )}
                                    </div>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

              {/* TOOLS */}
              {activeTab === 'tools' && (
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
                  <div className="p-5 border-b border-slate-200 dark:border-slate-800">
                    <h2 className="font-display text-lg font-bold">Manage Tools & Availability</h2>
                  </div>
                  <div className="divide-y divide-slate-200 dark:divide-slate-800">
                    {tools.map((t) => (
                      <div key={t.slug} className="p-4 flex items-center justify-between gap-4 text-xs">
                        <div className="min-w-0">
                          <div className="font-semibold text-sm text-slate-950 dark:text-white">
                            {t.name}
                          </div>
                          <div className="text-slate-500 font-mono truncate">
                            {t.routePath} · {t.category} · {t.usageCount ?? 0} runs
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => void toggleTool(t)}
                          className={`px-3.5 py-1.5 rounded-lg font-semibold shrink-0 ${
                            t.isEnabled !== false
                              ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                              : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {t.isEnabled !== false ? 'Enabled' : 'Disabled'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ADS */}
              {activeTab === 'ads' && (
                <div className="space-y-4">
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 text-xs text-slate-600 dark:text-slate-300">
                    All 8 advertisement placements are disabled by default. Configure your approved provider and Ad Unit IDs before enabling placements.
                  </div>
                  {ads.map((ad) => (
                    <div
                      key={ad.placementKey}
                      className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-4"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div>
                          <div className="font-display text-base font-bold text-slate-950 dark:text-white">
                            {ad.label}
                          </div>
                          <div className="text-xs text-slate-500">{ad.notes}</div>
                        </div>
                        <button
                          type="button"
                          onClick={() => void updateAd(ad.placementKey, { isEnabled: !ad.isEnabled })}
                          className={`px-4 py-1.5 rounded-lg text-xs font-semibold ${
                            ad.isEnabled
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {ad.isEnabled ? 'Active' : 'Disabled'}
                        </button>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                        <select
                          value={ad.provider}
                          onChange={(e) => void updateAd(ad.placementKey, { provider: e.target.value })}
                          className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                        >
                          <option value="google_adsense">Google AdSense</option>
                          <option value="google_ad_manager">Google Ad Manager</option>
                          <option value="direct_sponsorship">Direct Sponsorship</option>
                        </select>
                        <input
                          type="text"
                          defaultValue={ad.adUnitId}
                          placeholder="Ad Unit ID (e.g., ca-pub-slot)"
                          onBlur={(e) => {
                            if (e.target.value !== ad.adUnitId) {
                              void updateAd(ad.placementKey, { adUnitId: e.target.value });
                            }
                          }}
                          className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                        />
                        <div className="flex items-center gap-4">
                          <label className="flex items-center gap-1.5">
                            <input
                              type="checkbox"
                              checked={ad.desktopEnabled}
                              onChange={(e) =>
                                void updateAd(ad.placementKey, { desktopEnabled: e.target.checked })
                              }
                            />
                            <span>Desktop</span>
                          </label>
                          <label className="flex items-center gap-1.5">
                            <input
                              type="checkbox"
                              checked={ad.mobileEnabled}
                              onChange={(e) =>
                                void updateAd(ad.placementKey, { mobileEnabled: e.target.checked })
                              }
                            />
                            <span>Mobile</span>
                          </label>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* BLOG */}
              {activeTab === 'blog' && (
                <div className="space-y-6">
                  <form
                    onSubmit={createBlogPost}
                    className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3"
                  >
                    <h2 className="font-display text-base font-bold">Publish New Blog Article</h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <input
                        type="text"
                        required
                        placeholder="Article Title"
                        value={newPost.title}
                        onChange={(e) => setNewPost({ ...newPost, title: e.target.value })}
                        className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                      />
                      <input
                        type="text"
                        required
                        placeholder="URL Slug (e.g., youtube-seo-guide)"
                        value={newPost.slug}
                        onChange={(e) => setNewPost({ ...newPost, slug: e.target.value })}
                        className="h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                      />
                    </div>
                    <input
                      type="text"
                      required
                      placeholder="Short excerpt..."
                      value={newPost.excerpt}
                      onChange={(e) => setNewPost({ ...newPost, excerpt: e.target.value })}
                      className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm"
                    />
                    <textarea
                      rows={5}
                      required
                      placeholder="Markdown content..."
                      value={newPost.contentMarkdown}
                      onChange={(e) => setNewPost({ ...newPost, contentMarkdown: e.target.value })}
                      className="w-full p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-sm font-mono"
                    />
                    <button
                      type="submit"
                      className="px-5 py-2 rounded-lg bg-blue-600 text-white text-xs font-semibold"
                    >
                      Publish Article
                    </button>
                  </form>

                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 divide-y divide-slate-200 dark:divide-slate-800">
                    {posts.map((p) => (
                      <div key={p.id} className="p-4 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-semibold text-sm">{p.title}</div>
                          <div className="text-slate-500 font-mono">/blog/{p.slug}</div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await authFetch(`/api/v1/admin/blog/${p.id}`, {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ isPublished: !p.isPublished }),
                            });
                            await loadTabData('blog');
                          }}
                          className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 font-semibold"
                        >
                          {p.isPublished ? 'Published' : 'Draft'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* USERS */}
              {activeTab === 'users' && (
                <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden">
                  <div className="p-5 border-b border-slate-200 dark:border-slate-800">
                    <h2 className="font-display text-lg font-bold">Registered Users</h2>
                  </div>
                  <div className="divide-y divide-slate-200 dark:divide-slate-800">
                    {userList.map((u) => (
                      <div key={u.id} className="p-4 flex flex-wrap items-center justify-between gap-4 text-xs">
                        <div>
                          <div className="font-semibold text-sm text-slate-950 dark:text-white">
                            {u.email}
                          </div>
                          <div className="text-slate-500 font-mono">
                            Role: {u.role} · Plan: {u.plan}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={async () => {
                            await authFetch(`/api/v1/admin/users/${u.id}`, {
                              method: 'PATCH',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ isActive: !u.isActive }),
                            });
                            await loadTabData('users');
                          }}
                          className={`px-3 py-1.5 rounded-lg font-semibold ${
                            u.isActive ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {u.isActive ? 'Active' : 'Suspended'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* REPORTS & CONTACT */}
              {activeTab === 'reports' && (
                <div className="space-y-6">
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
                    <h2 className="font-display text-base font-bold">DMCA & Abuse Reports</h2>
                    {reports.abuseReports.length === 0 ? (
                      <p className="text-xs text-slate-500">No abuse or DMCA reports filed.</p>
                    ) : (
                      reports.abuseReports.map((r) => (
                        <div key={r.id} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                          <div className="flex justify-between">
                            <span className="font-semibold uppercase">{r.reportType} · {r.reporterEmail}</span>
                            <select
                              value={r.status}
                              onChange={async (e) => {
                                await authFetch(`/api/v1/admin/reports/${r.id}`, {
                                  method: 'PATCH',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ status: e.target.value }),
                                });
                                await loadTabData('reports');
                              }}
                              className="px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950"
                            >
                              <option value="open">Open</option>
                              <option value="reviewing">Reviewing</option>
                              <option value="resolved">Resolved</option>
                            </select>
                          </div>
                          <div className="font-mono text-blue-600 break-all">{r.targetUrl}</div>
                          <p className="text-slate-600 dark:text-slate-400">{r.details}</p>
                        </div>
                      ))
                    )}
                  </div>

                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 space-y-3">
                    <h2 className="font-display text-base font-bold">Contact Messages</h2>
                    {reports.contactMessages.length === 0 ? (
                      <p className="text-xs text-slate-500">No contact inquiries yet.</p>
                    ) : (
                      reports.contactMessages.map((m) => (
                        <div key={m.id} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 text-xs space-y-1">
                          <div className="font-semibold">{m.subject} — {m.name} ({m.email})</div>
                          <p className="text-slate-600 dark:text-slate-400">{m.message}</p>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* LOGS */}
              {activeTab === 'logs' && (
                <div className="space-y-6">
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                    <h2 className="font-display text-base font-bold mb-3">Recent Processing Jobs</h2>
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                      {logs.processingJobs.map((j) => (
                        <div key={j.id} className="py-2 flex items-center justify-between gap-3">
                          <span className="font-mono truncate">{j.toolSlug} · {j.platformSlug}</span>
                          <span className="font-mono tabular-nums text-slate-500 shrink-0">
                            {j.status} · {j.durationMs}ms
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5">
                    <h2 className="font-display text-base font-bold mb-3">Admin Audit Log</h2>
                    <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
                      {logs.auditLogs.map((a) => (
                        <div key={a.id} className="py-2 flex items-center justify-between gap-3">
                          <span>{a.actorEmail} · <strong>{a.action}</strong> ({a.resourceType})</span>
                          <span className="font-mono text-slate-500">
                            {new Date(a.createdAt).toLocaleString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* SETTINGS */}
              {activeTab === 'settings' && (
                <form
                  onSubmit={saveSettings}
                  className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-6 space-y-4"
                >
                  <h2 className="font-display text-lg font-bold">Website, Rate Limits & SEO Config</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    {[
                      { key: 'rate_limit_per_min', label: 'Public API Rate Limit (requests / min)' },
                      { key: 'adsense_publisher_id', label: 'Google AdSense Publisher ID (ca-pub-...)' },
                      { key: 'ga_measurement_id', label: 'Google Analytics 4 Measurement ID (G-...)' },
                      { key: 'gsc_verification_token', label: 'Google Search Console Verification Token' },
                    ].map((field) => (
                      <div key={field.key}>
                        <label className="block font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
                          {field.label}
                        </label>
                        <input
                          type="text"
                          value={settings[field.key] || ''}
                          onChange={(e) =>
                            setSettings({ ...settings, [field.key]: e.target.value })
                          }
                          className="w-full h-10 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 font-mono"
                        />
                      </div>
                    ))}
                  </div>
                  {savingMsg && <p className="text-xs text-emerald-600 font-semibold">{savingMsg}</p>}
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl bg-blue-600 text-white text-xs font-semibold"
                  >
                    Save Configuration
                  </button>
                </form>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
