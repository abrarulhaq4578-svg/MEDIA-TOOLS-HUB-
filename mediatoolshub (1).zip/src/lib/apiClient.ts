export interface StructuredApiError {
  code?: string;
  message?: string;
}

export class ApiClientError extends Error {
  code?: string;
  status?: number;
  preview?: string;

  constructor(
    message: string,
    options?: { code?: string; status?: number; preview?: string }
  ) {
    super(message);
    this.name = 'ApiClientError';
    this.code = options?.code;
    this.status = options?.status;
    this.preview = options?.preview;
  }
}

export function isWarmupHtmlPreview(raw: string): boolean {
  const lower = raw.replace(/\s+/g, ' ').trim().toLowerCase();
  return (
    lower.includes('starting server') ||
    lower.includes('warmup') ||
    lower.includes('waking up')
  );
}

/**
 * Wraps fetch() to transparently retry when the reverse proxy (nginx) intercepts a
 * cold-starting or restarting backend with 502/503/504 or a 200 text/html warmup page.
 * Because warmup responses never reach Node.js, retrying them is safe even for POST/PATCH/DELETE.
 */
export async function fetchWithWarmupRetry(
  input: string,
  init?: RequestInit,
  options?: { maxRetries?: number; retryDelaysMs?: number[]; fetchImpl?: typeof fetch }
): Promise<Response> {
  const maxRetries = options?.maxRetries ?? 3;
  const retryDelaysMs = options?.retryDelaysMs ?? [1400, 2400, 3800];
  const fetchFn = options?.fetchImpl ?? fetch;

  let lastResponse: Response | null = null;
  let lastError: unknown = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetchFn(input, init);
      lastResponse = response;

      const contentType = (response.headers.get('content-type') || '').toLowerCase();
      if (contentType.includes('application/json')) {
        return response;
      }

      let isTransientProxyWarmup =
        response.status === 502 || response.status === 503 || response.status === 504;

      if (!isTransientProxyWarmup && contentType.includes('text/html')) {
        try {
          const preview = await response.clone().text();
          isTransientProxyWarmup = isWarmupHtmlPreview(preview);
        } catch {
          isTransientProxyWarmup = false;
        }
      }

      if (!isTransientProxyWarmup || attempt >= maxRetries) {
        return response;
      }
    } catch (err) {
      lastError = err;
      const isAbort = err instanceof DOMException && err.name === 'AbortError';
      if (isAbort || attempt >= maxRetries) {
        throw err;
      }
    }

    const delay = retryDelaysMs[Math.min(attempt, retryDelaysMs.length - 1)] ?? 2000;
    await new Promise((resolve) => setTimeout(resolve, delay));
  }

  if (lastResponse) return lastResponse;
  throw lastError instanceof Error ? lastError : new Error('Network request failed.');
}

export async function parseSafeJsonResponse<T = Record<string, unknown>>(
  response: Response,
  endpointLabel?: string
): Promise<T> {
  const contentType = response.headers.get('content-type') || '';
  const raw = await response.text();
  const isDev =
    typeof import.meta !== 'undefined' &&
    Boolean((import.meta as { env?: { DEV?: boolean } }).env?.DEV);

  if (!contentType.includes('application/json')) {
    const sanitizedPreview = raw.replace(/\s+/g, ' ').trim().slice(0, 180);
    if (isDev) {
      console.warn('[MediaToolsHub API] Non-JSON response received', {
        endpoint: endpointLabel || response.url || 'unknown',
        status: response.status,
        contentType: contentType || 'missing',
        preview: sanitizedPreview,
      });
    }

    if (response.status === 404) {
      throw new ApiClientError(
        'API endpoint not found (404). Check API routing and backend deployment.',
        { code: 'NOT_FOUND', status: 404, preview: sanitizedPreview }
      );
    }
    if (response.status === 401) {
      throw new ApiClientError(
        'User authentication required (401). Please sign in again.',
        { code: 'AUTH_REQUIRED', status: 401, preview: sanitizedPreview }
      );
    }
    if (response.status === 403) {
      throw new ApiClientError(
        'Permission denied (403). You do not have access to this endpoint.',
        { code: 'FORBIDDEN', status: 403, preview: sanitizedPreview }
      );
    }
    if (response.status === 502 || response.status === 503 || response.status === 504) {
      throw new ApiClientError(
        `Backend unavailable (${response.status}). Check server health and deployment.`,
        { code: 'BACKEND_UNAVAILABLE', status: response.status, preview: sanitizedPreview }
      );
    }
    if (isWarmupHtmlPreview(sanitizedPreview)) {
      throw new ApiClientError(
        'The backend server is warming up or an upstream AI request was interrupted. Please click Retry in a moment.',
        { code: 'BACKEND_WARMING_UP', status: response.status, preview: sanitizedPreview }
      );
    }
    throw new ApiClientError(
      `API returned non-JSON response (${response.status}). Check API routing and backend deployment.`,
      { code: 'NON_JSON_RESPONSE', status: response.status, preview: sanitizedPreview }
    );
  }

  let data: T & {
    ok?: boolean;
    error?: string | StructuredApiError;
    message?: string;
  };

  try {
    data = JSON.parse(raw);
  } catch {
    if (isDev) {
      console.warn('[MediaToolsHub API] Malformed JSON response', {
        endpoint: endpointLabel || response.url || 'unknown',
        status: response.status,
      });
    }
    throw new ApiClientError('The API returned invalid JSON.', {
      code: 'INVALID_JSON_RESPONSE',
      status: response.status,
    });
  }

  if (!response.ok || data.ok === false) {
    const errorMessage =
      typeof data.error === 'string'
        ? data.error
        : data.error?.message || data.message || `API request failed: ${response.status}`;
    const errorCode =
      typeof data.error === 'object' && data.error?.code ? data.error.code : undefined;

    throw new ApiClientError(errorMessage, {
      code: errorCode,
      status: response.status,
    });
  }

  return data;
}
