import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';
import { fetchWithWarmupRetry, parseSafeJsonResponse } from '../lib/apiClient.ts';
import { getToolByRoutePath, TOOLS_CATALOG } from '../shared/toolsCatalog.ts';
import type {
  AdPlacement,
  PublicIntegrationFlags,
  ScriptStudioSeed,
  ToolDefinition,
  UserProfile,
} from '../shared/types.ts';

type Theme = 'light' | 'dark';

const DEFAULT_INTEGRATIONS: PublicIntegrationFlags = {
  youtubeApiConfigured: false,
  metaApiConfigured: false,
  pinterestApiConfigured: false,
  adsenseEnabled: false,
  gaEnabled: false,
  gscEnabled: false,
};

interface AppContextValue {
  theme: Theme;
  toggleTheme: () => void;
  currentPath: string;
  navigate: (path: string, prefillUrl?: string) => void;
  prefillUrl: string;
  setPrefillUrl: (url: string) => void;
  scriptSeed: ScriptStudioSeed | null;
  setScriptSeed: (seed: ScriptStudioSeed | null) => void;
  openScriptStudioWithSeed: (seed: ScriptStudioSeed) => void;
  tools: ToolDefinition[];
  adPlacements: AdPlacement[];
  adsensePublisherId: string;
  integrations: PublicIntegrationFlags;
  refreshCatalog: () => Promise<void>;
  firebaseUser: User | null;
  dbUser: UserProfile | null;
  authLoading: boolean;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  authFetch: (input: string, init?: RequestInit) => Promise<Response>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      const saved = window.localStorage.getItem('mth_theme');
      if (saved === 'dark' || saved === 'light') return saved;
    }
    return 'light';
  });

  const [currentPath, setCurrentPath] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      return window.location.pathname || '/';
    }
    return '/';
  });

  const [prefillUrl, setPrefillUrl] = useState<string>('');
  const [scriptSeed, setScriptSeed] = useState<ScriptStudioSeed | null>(null);
  const [tools, setTools] = useState<ToolDefinition[]>(TOOLS_CATALOG);
  const [adPlacements, setAdPlacements] = useState<AdPlacement[]>([]);
  const [adsensePublisherId, setAdsensePublisherId] = useState<string>('');
  const [integrations, setIntegrations] = useState<PublicIntegrationFlags>(DEFAULT_INTEGRATIONS);

  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [dbUser, setDbUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);

  // Sync theme to <html>
  useEffect(() => {
    const root = document.documentElement;
    root.classList.toggle('dark', theme === 'dark');
    window.localStorage.setItem('mth_theme', theme);
  }, [theme]);

  const toggleTheme = useCallback(() => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  }, []);

  // Auth listener
  const syncDbUser = useCallback(async (user: User | null) => {
    if (!user) {
      setDbUser(null);
      return;
    }
    try {
      const token = await user.getIdToken();
      const res = await fetchWithWarmupRetry('/api/v1/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await parseSafeJsonResponse<{ user: UserProfile }>(res);
      setDbUser(data.user);
    } catch {
      // Non-blocking sync failure
    }
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      await syncDbUser(user);
      setAuthLoading(false);
    });
    return () => unsub();
  }, [syncDbUser]);

  const signInWithGoogle = useCallback(async () => {
    const cred = await signInWithPopup(auth, googleAuthProvider);
    await syncDbUser(cred.user);
  }, [syncDbUser]);

  const signOutUser = useCallback(async () => {
    await signOut(auth);
    setDbUser(null);
  }, []);

  const authFetch = useCallback(
    async (input: string, init: RequestInit = {}) => {
      const headers = new Headers(init.headers || {});
      if (firebaseUser) {
        const token = await firebaseUser.getIdToken();
        headers.set('Authorization', `Bearer ${token}`);
      }
      return fetchWithWarmupRetry(input, { ...init, headers });
    },
    [firebaseUser]
  );

  // Load tools & ad placements + record visit once per session
  const refreshCatalog = useCallback(async () => {
    try {
      const [toolsRes, adsRes] = await Promise.all([
        fetchWithWarmupRetry('/api/v1/tools'),
        fetchWithWarmupRetry('/api/v1/ads/active'),
      ]);
      if (toolsRes.ok) {
        const data = await parseSafeJsonResponse<{ tools: ToolDefinition[] }>(toolsRes);
        if (Array.isArray(data.tools) && data.tools.length > 0) {
          setTools(data.tools);
        }
      }
      if (adsRes.ok) {
        const adData = await parseSafeJsonResponse<{
          placements: AdPlacement[];
          adsensePublisherId?: string;
          integrations?: PublicIntegrationFlags;
        }>(adsRes);
        setAdPlacements(adData.placements || []);
        setAdsensePublisherId(adData.adsensePublisherId || '');
        if (adData.integrations) {
          setIntegrations(adData.integrations);
        }
      }
    } catch {
      // Keep built-in catalog fallback on transient error
    }
  }, []);

  useEffect(() => {
    void refreshCatalog();
    if (!window.sessionStorage.getItem('mth_visited')) {
      window.sessionStorage.setItem('mth_visited', '1');
      fetch('/api/v1/analytics/visit', { method: 'POST' }).catch(() => {});
    }
  }, [refreshCatalog]);

  // History listener & SEO head sync
  useEffect(() => {
    const onPopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  useEffect(() => {
    const clean = currentPath.split('?')[0].replace(/\/+$/, '') || '/';
    const matchedTool = tools.find((t) => t.routePath === clean) || getToolByRoutePath(clean);
    if (matchedTool) {
      document.title = matchedTool.seoTitle;
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) metaDesc.setAttribute('content', matchedTool.seoDescription);
    } else if (clean === '/youtube-management' || clean.startsWith('/youtube-management/')) {
      document.title = 'YouTube Management – MediaToolsHub Creator Operating System';
      const metaDesc = document.querySelector('meta[name="description"]');
      if (metaDesc) {
        metaDesc.setAttribute(
          'content',
          'Plan, script, optimize, schedule, publish, monetize, and grow your YouTube channel from one creator operating system.'
        );
      }
    } else if (clean === '/') {
      document.title = 'MediaToolsHub – All Your Social Media Tools in One Place';
    }
  }, [currentPath, tools]);

  const navigate = useCallback((path: string, nextPrefill?: string) => {
    if (typeof nextPrefill === 'string') {
      setPrefillUrl(nextPrefill);
    }
    const target = path.startsWith('/') ? path : `/${path}`;
    const targetPathOnly = target.split('?')[0] || '/';
    const currentFull = `${window.location.pathname}${window.location.search}`;
    if (target !== currentFull) {
      window.history.pushState({}, '', target);
      setCurrentPath(targetPathOnly);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const openScriptStudioWithSeed = useCallback(
    (seed: ScriptStudioSeed) => {
      setScriptSeed(seed);
      navigate('/ai-scriptwriting-studio');
    },
    [navigate]
  );

  return (
    <AppContext.Provider
      value={{
        theme,
        toggleTheme,
        currentPath,
        navigate,
        prefillUrl,
        setPrefillUrl,
        scriptSeed,
        setScriptSeed,
        openScriptStudioWithSeed,
        tools,
        adPlacements,
        adsensePublisherId,
        integrations,
        refreshCatalog,
        firebaseUser,
        dbUser,
        authLoading,
        signInWithGoogle,
        signOutUser,
        authFetch,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return ctx;
}
