import type { NextFunction, Request, Response } from 'express';
import type { DecodedIdToken } from 'firebase-admin/auth';
import { adminAuth } from '../../lib/firebase-admin.ts';
import { getOrCreateUser, getUserByUid } from '../../db/users.ts';

export interface AuthUserRecord {
  id: number;
  uid: string;
  email: string;
  displayName: string | null;
  photoUrl: string | null;
  role: string;
  plan: string;
  isActive: boolean;
}

export interface AuthRequest extends Request {
  firebaseUser?: DecodedIdToken;
  dbUser?: AuthUserRecord;
}

export const optionalAuth = async (
  req: AuthRequest,
  _res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }

  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    return next();
  }

  try {
    const decoded = await adminAuth.verifyIdToken(token);
    req.firebaseUser = decoded;
    const dbUser = await getOrCreateUser(
      decoded.uid,
      decoded.email || `${decoded.uid}@firebase.local`,
      decoded.name ?? null,
      decoded.picture ?? null
    );
    if (dbUser) {
      req.dbUser = dbUser;
    }
  } catch {
    // Public endpoints proceed anonymously if token is expired/invalid
  }

  return next();
};

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Authentication required. Please sign in with Google.',
      code: 'AUTH_REQUIRED',
    });
  }

  const token = authHeader.slice('Bearer '.length).trim();
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    req.firebaseUser = decoded;
    const dbUser = await getOrCreateUser(
      decoded.uid,
      decoded.email || `${decoded.uid}@firebase.local`,
      decoded.name ?? null,
      decoded.picture ?? null
    );
    if (!dbUser || !dbUser.isActive) {
      return res.status(403).json({
        error: 'This account has been deactivated.',
        code: 'ACCOUNT_DISABLED',
      });
    }
    req.dbUser = dbUser;
    return next();
  } catch (error) {
    console.error('Firebase token verification error:', error);
    return res.status(401).json({
      error: 'Invalid or expired authentication token.',
      code: 'INVALID_TOKEN',
    });
  }
};

export const requireAdmin = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  if (!req.firebaseUser) {
    return res.status(401).json({ error: 'Authentication required.', code: 'AUTH_REQUIRED' });
  }
  const dbUser = req.dbUser ?? (await getUserByUid(req.firebaseUser.uid));
  if (!dbUser || dbUser.role !== 'admin') {
    return res.status(403).json({
      error: 'Administrator privileges required.',
      code: 'ADMIN_FORBIDDEN',
    });
  }
  req.dbUser = dbUser;
  return next();
};
