import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { apiKeys, apiUsage, websiteSettings } from '../../db/schema.ts';

interface WindowEntry {
  count: number;
  resetAt: number;
}

const ipBuckets = new Map<string, WindowEntry>();
let cachedDefaultLimit = 60;
let lastLimitFetchAt = 0;

async function getConfiguredRateLimit(): Promise<number> {
  const now = Date.now();
  if (now - lastLimitFetchAt < 30_000) {
    return cachedDefaultLimit;
  }
  lastLimitFetchAt = now;
  try {
    const rows = await db
      .select()
      .from(websiteSettings)
      .where(eq(websiteSettings.key, 'rate_limit_per_min'))
      .limit(1);
    if (rows[0]?.value) {
      const parsed = Number.parseInt(rows[0].value, 10);
      if (Number.isFinite(parsed) && parsed >= 5 && parsed <= 10000) {
        cachedDefaultLimit = parsed;
      }
    }
  } catch {
    // Keep last known limit on transient DB unavailability
  }
  return cachedDefaultLimit;
}

export function clearRateLimiterCache() {
  lastLimitFetchAt = 0;
}

export function hashApiKey(rawKey: string): string {
  return crypto.createHash('sha256').update(rawKey).digest('hex');
}

export const apiRateLimiter = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  const start = Date.now();
  const apiKeyHeader = req.header('x-api-key')?.trim();
  let limit = await getConfiguredRateLimit();
  let bucketKey = `ip:${req.ip || req.socket.remoteAddress || 'unknown'}`;
  let matchedKeyId: number | null = null;

  if (apiKeyHeader) {
    try {
      const hashed = hashApiKey(apiKeyHeader);
      const found = await db
        .select()
        .from(apiKeys)
        .where(eq(apiKeys.keyHash, hashed))
        .limit(1);
      if (!found[0] || !found[0].isActive) {
        return res.status(401).json({
          ok: false,
          error: {
            code: 'INVALID_API_KEY',
            message: 'Invalid or revoked API key.',
          },
        });
      }
      matchedKeyId = found[0].id;
      limit = found[0].rateLimitPerMin;
      bucketKey = `key:${found[0].id}`;
      db.update(apiKeys)
        .set({ lastUsedAt: new Date() })
        .where(eq(apiKeys.id, found[0].id))
        .catch(() => {});
    } catch {
      return res.status(503).json({
        ok: false,
        error: {
          code: 'API_KEY_CHECK_FAILED',
          message: 'Unable to verify API key right now.',
        },
      });
    }
  }

  const now = Date.now();
  const windowMs = 60_000;
  let entry = ipBuckets.get(bucketKey);

  if (!entry || entry.resetAt <= now) {
    entry = { count: 0, resetAt: now + windowMs };
    ipBuckets.set(bucketKey, entry);
  }

  entry.count += 1;
  const remaining = Math.max(0, limit - entry.count);

  res.setHeader('X-RateLimit-Limit', String(limit));
  res.setHeader('X-RateLimit-Remaining', String(remaining));
  res.setHeader('X-RateLimit-Reset', String(Math.ceil(entry.resetAt / 1000)));

  if (matchedKeyId !== null) {
    res.on('finish', () => {
      db.insert(apiUsage)
        .values({
          apiKeyId: matchedKeyId,
          endpoint: req.path,
          statusCode: res.statusCode,
          latencyMs: Date.now() - start,
        })
        .catch(() => {});
    });
  }

  if (entry.count > limit) {
    const retryAfterSec = Math.max(1, Math.ceil((entry.resetAt - now) / 1000));
    res.setHeader('Retry-After', String(retryAfterSec));
    return res.status(429).json({
      ok: false,
      error: {
        code: 'RATE_LIMIT_EXCEEDED',
        message: `Rate limit exceeded. Try again in ${retryAfterSec} seconds.`,
      },
      retryAfterSec,
    });
  }

  if (ipBuckets.size > 5000) {
    for (const [k, v] of ipBuckets.entries()) {
      if (v.resetAt <= now) ipBuckets.delete(k);
    }
  }

  return next();
};
