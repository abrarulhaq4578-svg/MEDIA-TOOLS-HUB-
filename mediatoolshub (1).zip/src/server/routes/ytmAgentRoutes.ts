import crypto from 'node:crypto';
import express from 'express';
import { and, asc, desc, eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  ytmAgentSessions,
  ytmAgentTasks,
  ytmAgentTaskSteps,
} from '../../db/schema.ts';
import type { YtmAgentMode, YtmAgentUiContext } from '../../shared/types.ts';
import type { AuthRequest } from '../middleware/auth.ts';
import {
  cancelAgentTask,
  getOrCreateAgentPermissions,
  handleAgentApprovalDecision,
  hydrateAgentSession,
  hydrateAgentTask,
  launchAgentTask,
  listWorkspaceAgentTasks,
  pauseAgentTask,
  resumeAgentTask,
  retryFailedAgentTask,
  updateAgentPermissions,
} from '../services/ytmAgentEngine.ts';
import {
  resolveAuthorizedWorkspace,
  YtmAccessError,
} from '../services/ytmWorkspaceService.ts';

const router = express.Router();

function okJson(res: express.Response, data: unknown, status = 200) {
  return res.status(status).json({ ok: true, data });
}

function failJson(res: express.Response, status: number, code: string, message: string) {
  return res.status(status).json({ ok: false, error: { code, message } });
}

function getWorkspaceKeyFromReq(req: AuthRequest): string | undefined {
  const headerKey = req.header('x-ytm-workspace');
  const queryKey = typeof req.query.workspaceKey === 'string' ? req.query.workspaceKey : undefined;
  const bodyKey = typeof req.body?.workspaceKey === 'string' ? req.body.workspaceKey : undefined;
  return (headerKey || queryKey || bodyKey || '').trim() || undefined;
}

function handleAgentRouteError(res: express.Response, err: unknown, fallback: string) {
  if (err instanceof YtmAccessError) {
    return failJson(res, err.statusCode, err.code, err.message);
  }
  const msg = err instanceof Error ? err.message : fallback;
  return failJson(res, 500, 'AGENT_ERROR', msg || fallback);
}

function normalizeMode(raw: unknown, fallback: YtmAgentMode = 'assist'): YtmAgentMode {
  if (raw === 'chat' || raw === 'assist' || raw === 'autopilot') return raw;
  return fallback;
}

async function ensureDefaultSession(params: {
  workspaceId: number;
  userId: number;
  defaultMode: YtmAgentMode;
  channelProfileId?: number | null;
}) {
  const existing = await db
    .select()
    .from(ytmAgentSessions)
    .where(
      and(
        eq(ytmAgentSessions.workspaceId, params.workspaceId),
        eq(ytmAgentSessions.userId, params.userId)
      )
    )
    .orderBy(desc(ytmAgentSessions.updatedAt))
    .limit(15);

  if (existing.length > 0) {
    return existing;
  }

  const inserted = await db
    .insert(ytmAgentSessions)
    .values({
      sessionKey: `ags_${crypto.randomBytes(8).toString('hex')}`,
      workspaceId: params.workspaceId,
      userId: params.userId,
      channelProfileId: params.channelProfileId ?? null,
      title: 'New Agent Session',
      mode: params.defaultMode,
      messagesJson: '[]',
    })
    .returning();

  return inserted;
}

// ==============================================================================
// SESSIONS & BOOTSTRAP
// ==============================================================================

router.get('/agent/sessions', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const permissions = await getOrCreateAgentPermissions(workspace.id, user.id);
    const sessionRows = await ensureDefaultSession({
      workspaceId: workspace.id,
      userId: user.id,
      defaultMode: permissions.defaultMode,
    });
    const tasks = await listWorkspaceAgentTasks(workspace.id, user.id, 20);

    return okJson(res, {
      sessions: sessionRows.map(hydrateAgentSession),
      activeSession: hydrateAgentSession(sessionRows[0]),
      tasks,
      permissions,
    });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to load AI Agent sessions.');
  }
});

router.post('/agent/sessions', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const permissions = await getOrCreateAgentPermissions(workspace.id, user.id);
    const mode = normalizeMode(req.body?.mode, permissions.defaultMode);
    const channelProfileId =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;

    const inserted = await db
      .insert(ytmAgentSessions)
      .values({
        sessionKey: `ags_${crypto.randomBytes(8).toString('hex')}`,
        workspaceId: workspace.id,
        userId: user.id,
        channelProfileId,
        title: typeof req.body?.title === 'string' && req.body.title.trim() ? req.body.title.trim().slice(0, 80) : 'New Agent Session',
        mode,
        messagesJson: '[]',
      })
      .returning();

    return okJson(res, { session: hydrateAgentSession(inserted[0]) }, 201);
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to create AI Agent session.');
  }
});

router.delete('/agent/sessions/:sessionKey', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const sessionKey = String(req.params.sessionKey || '').trim();
    if (!sessionKey) return failJson(res, 400, 'INVALID_SESSION_KEY', 'Session key is required.');

    await db
      .delete(ytmAgentSessions)
      .where(
        and(
          eq(ytmAgentSessions.sessionKey, sessionKey),
          eq(ytmAgentSessions.workspaceId, workspace.id),
          eq(ytmAgentSessions.userId, user.id)
        )
      );

    return okJson(res, { deleted: true });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to delete AI Agent session.');
  }
});

// ==============================================================================
// COMMAND EXECUTION & BACKGROUND TASK LIFECYCLE
// ==============================================================================

router.post('/agent/commands', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace, role } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const command = typeof req.body?.command === 'string' ? req.body.command.trim() : '';
    if (!command) {
      return failJson(res, 400, 'EMPTY_COMMAND', 'Please enter a command for the AI Agent.');
    }
    if (command.length > 4000) {
      return failJson(res, 400, 'COMMAND_TOO_LONG', 'Command must be under 4,000 characters.');
    }

    const permissions = await getOrCreateAgentPermissions(workspace.id, user.id);
    const mode = normalizeMode(req.body?.mode, permissions.defaultMode);
    const uiContext: YtmAgentUiContext =
      req.body?.uiContext && typeof req.body.uiContext === 'object' ? req.body.uiContext : {};
    const idempotencyKey =
      typeof req.body?.idempotencyKey === 'string' && req.body.idempotencyKey.trim()
        ? req.body.idempotencyKey.trim().slice(0, 80)
        : null;

    // Resolve or create session owned by this user in this workspace
    let sessionRow: typeof ytmAgentSessions.$inferSelect | null = null;
    const requestedSessionKey =
      typeof req.body?.sessionKey === 'string' ? req.body.sessionKey.trim() : '';
    if (requestedSessionKey) {
      const found = await db
        .select()
        .from(ytmAgentSessions)
        .where(
          and(
            eq(ytmAgentSessions.sessionKey, requestedSessionKey),
            eq(ytmAgentSessions.workspaceId, workspace.id),
            eq(ytmAgentSessions.userId, user.id)
          )
        )
        .limit(1);
      sessionRow = found[0] || null;
    }

    if (!sessionRow) {
      const created = await db
        .insert(ytmAgentSessions)
        .values({
          sessionKey: `ags_${crypto.randomBytes(8).toString('hex')}`,
          workspaceId: workspace.id,
          userId: user.id,
          channelProfileId: uiContext.channelProfileId ?? null,
          title: command.slice(0, 64),
          mode,
          messagesJson: '[]',
        })
        .returning();
      sessionRow = created[0];
    }

    const task = await launchAgentTask({
      workspace,
      role,
      userId: user.id,
      userEmail: user.email,
      sessionId: sessionRow.id,
      command,
      mode,
      uiContext,
      idempotencyKey,
    });

    const refreshedSessionRows = await db
      .select()
      .from(ytmAgentSessions)
      .where(eq(ytmAgentSessions.id, sessionRow.id))
      .limit(1);

    return okJson(
      res,
      {
        task,
        session: hydrateAgentSession(refreshedSessionRows[0] || sessionRow),
      },
      202
    );
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to start AI Agent task.');
  }
});

router.get('/agent/tasks', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const tasks = await listWorkspaceAgentTasks(workspace.id, user.id, 30);
    return okJson(res, { tasks });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to load AI Agent task history.');
  }
});

router.get('/agent/tasks/:taskKey', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const taskKey = String(req.params.taskKey || '').trim();
    const rows = await db
      .select()
      .from(ytmAgentTasks)
      .where(
        and(
          eq(ytmAgentTasks.taskKey, taskKey),
          eq(ytmAgentTasks.workspaceId, workspace.id),
          eq(ytmAgentTasks.userId, user.id)
        )
      )
      .limit(1);

    if (!rows[0]) {
      return failJson(res, 404, 'TASK_NOT_FOUND', 'Agent task not found.');
    }

    const steps = await db
      .select()
      .from(ytmAgentTaskSteps)
      .where(eq(ytmAgentTaskSteps.taskId, rows[0].id))
      .orderBy(asc(ytmAgentTaskSteps.stepOrder));

    let session = null;
    if (rows[0].sessionId) {
      const sRows = await db
        .select()
        .from(ytmAgentSessions)
        .where(eq(ytmAgentSessions.id, rows[0].sessionId))
        .limit(1);
      if (sRows[0]) session = hydrateAgentSession(sRows[0]);
    }

    return okJson(res, {
      task: hydrateAgentTask(rows[0], steps),
      session,
    });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to fetch AI Agent task status.');
  }
});

async function loadOwnedTask(workspaceId: number, userId: number, taskKey: string) {
  const rows = await db
    .select()
    .from(ytmAgentTasks)
    .where(
      and(
        eq(ytmAgentTasks.taskKey, taskKey),
        eq(ytmAgentTasks.workspaceId, workspaceId),
        eq(ytmAgentTasks.userId, userId)
      )
    )
    .limit(1);
  return rows[0] || null;
}

router.post('/agent/tasks/:taskKey/pause', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const taskRow = await loadOwnedTask(workspace.id, user.id, String(req.params.taskKey || ''));
    if (!taskRow) return failJson(res, 404, 'TASK_NOT_FOUND', 'Agent task not found.');

    await pauseAgentTask(taskRow.id);
    const updated = await loadOwnedTask(workspace.id, user.id, taskRow.taskKey);
    const steps = await db
      .select()
      .from(ytmAgentTaskSteps)
      .where(eq(ytmAgentTaskSteps.taskId, taskRow.id))
      .orderBy(asc(ytmAgentTaskSteps.stepOrder));

    return okJson(res, { task: hydrateAgentTask(updated || taskRow, steps) });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to pause AI Agent task.');
  }
});

router.post('/agent/tasks/:taskKey/resume', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace, role } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const taskRow = await loadOwnedTask(workspace.id, user.id, String(req.params.taskKey || ''));
    if (!taskRow) return failJson(res, 404, 'TASK_NOT_FOUND', 'Agent task not found.');

    await resumeAgentTask({
      taskId: taskRow.id,
      workspace,
      role,
      userEmail: user.email,
    });
    const updated = await loadOwnedTask(workspace.id, user.id, taskRow.taskKey);
    const steps = await db
      .select()
      .from(ytmAgentTaskSteps)
      .where(eq(ytmAgentTaskSteps.taskId, taskRow.id))
      .orderBy(asc(ytmAgentTaskSteps.stepOrder));

    return okJson(res, { task: hydrateAgentTask(updated || taskRow, steps) });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to resume AI Agent task.');
  }
});

router.post('/agent/tasks/:taskKey/cancel', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const taskRow = await loadOwnedTask(workspace.id, user.id, String(req.params.taskKey || ''));
    if (!taskRow) return failJson(res, 404, 'TASK_NOT_FOUND', 'Agent task not found.');

    await cancelAgentTask(taskRow.id);
    const updated = await loadOwnedTask(workspace.id, user.id, taskRow.taskKey);
    const steps = await db
      .select()
      .from(ytmAgentTaskSteps)
      .where(eq(ytmAgentTaskSteps.taskId, taskRow.id))
      .orderBy(asc(ytmAgentTaskSteps.stepOrder));

    return okJson(res, { task: hydrateAgentTask(updated || taskRow, steps) });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to cancel AI Agent task.');
  }
});

router.post('/agent/tasks/:taskKey/approve', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace, role } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const taskRow = await loadOwnedTask(workspace.id, user.id, String(req.params.taskKey || ''));
    if (!taskRow) return failJson(res, 404, 'TASK_NOT_FOUND', 'Agent task not found.');

    const decision = req.body?.decision === 'reject' ? 'reject' : 'approve';
    const task = await handleAgentApprovalDecision({
      taskId: taskRow.id,
      decision,
      workspace,
      role,
      userEmail: user.email,
    });
    if (!task) {
      return failJson(res, 409, 'NOT_WAITING_FOR_APPROVAL', 'This task is not awaiting approval.');
    }

    return okJson(res, { task });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to process approval decision.');
  }
});

router.post('/agent/tasks/:taskKey/retry', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace, role } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const taskRow = await loadOwnedTask(workspace.id, user.id, String(req.params.taskKey || ''));
    if (!taskRow) return failJson(res, 404, 'TASK_NOT_FOUND', 'Agent task not found.');

    const task = await retryFailedAgentTask({
      taskId: taskRow.id,
      workspace,
      role,
      userEmail: user.email,
    });
    if (!task) {
      return failJson(res, 409, 'TASK_NOT_FAILED', 'Only failed tasks can be retried.');
    }

    return okJson(res, { task });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to retry failed step.');
  }
});

// ==============================================================================
// USER PERMISSIONS & DEFAULT MODE
// ==============================================================================

router.get('/agent/permissions', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const permissions = await getOrCreateAgentPermissions(workspace.id, user.id);
    return okJson(res, { permissions });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to fetch AI Agent permissions.');
  }
});

router.put('/agent/permissions', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: user.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const defaultMode =
      req.body?.defaultMode === 'chat' ||
      req.body?.defaultMode === 'assist' ||
      req.body?.defaultMode === 'autopilot'
        ? (req.body.defaultMode as YtmAgentMode)
        : undefined;
    const approvalRequiredActions = Array.isArray(req.body?.approvalRequiredActions)
      ? req.body.approvalRequiredActions.map((x: unknown) => String(x))
      : undefined;

    const permissions = await updateAgentPermissions({
      workspaceId: workspace.id,
      userId: user.id,
      defaultMode,
      approvalRequiredActions,
    });

    return okJson(res, { permissions });
  } catch (err) {
    return handleAgentRouteError(res, err, 'Unable to update AI Agent permissions.');
  }
});

export default router;
