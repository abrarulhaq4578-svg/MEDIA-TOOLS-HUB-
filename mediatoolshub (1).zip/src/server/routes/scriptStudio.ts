import crypto from 'node:crypto';
import express from 'express';
import { and, desc, eq, inArray, isNull, or } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  competitorChannelCaches,
  competitorReports,
  scriptProjects,
  ytmWorkflowProjects,
  ytmWorkspaceCompetitors,
  ytmWorkspaceMembers,
} from '../../db/schema.ts';
import type { AuthRequest } from '../middleware/auth.ts';
import {
  countSpokenWords,
  createDefaultScriptSettings,
  createInitialScriptState,
} from '../../shared/scriptStudioHelpers.ts';
import type {
  ScriptAiModelId,
  ScriptCompetitorResearchContext,
  ScriptPersonalizationSettings,
  ScriptProjectRecord,
  ScriptProjectState,
  ScriptStageNumber,
  ScriptStudioSeed,
} from '../../shared/types.ts';
import {
  aiAnalyzeCustomTopic,
  aiAssembleFinalScript,
  aiExplainDecision,
  aiGenerateBodySection,
  aiGenerateIntroduction,
  aiGenerateOutline,
  aiGenerateOutro,
  aiGeneratePackaging,
  aiGenerateTopicIdeas,
  ScriptAiError,
} from '../services/scriptStudioAi.ts';

const router = express.Router();

function fail(res: express.Response, status: number, code: string, message: string) {
  return res.status(status).json({
    ok: false,
    error: { code, message },
  });
}

function getGuestToken(req: express.Request): string | null {
  const raw = req.header('x-script-guest-token');
  if (!raw) return null;
  const trimmed = raw.trim();
  return /^[a-zA-Z0-9_-]{8,120}$/.test(trimmed) ? trimmed : null;
}

function safeParseJson<T>(raw: string, fallback: T): T {
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function hydrateProject(row: typeof scriptProjects.$inferSelect): ScriptProjectRecord {
  const defaultSettings = createDefaultScriptSettings();
  const defaultState = createInitialScriptState();
  const validStatuses = new Set([
    'NOT STARTED',
    'IN PROGRESS',
    'WAITING FOR APPROVAL',
    'COMPLETED',
    'PUBLISHED',
  ]);
  const derivedStatus = validStatuses.has(row.projectStatus)
    ? (row.projectStatus as ScriptProjectRecord['projectStatus'])
    : row.highestApprovedStage >= 7
      ? 'COMPLETED'
      : row.highestApprovedStage > 0
        ? 'IN PROGRESS'
        : 'NOT STARTED';

  return {
    id: row.id,
    projectKey: row.projectKey,
    ytmWorkflowProjectId: row.ytmWorkflowProjectId ?? null,
    title: row.title,
    currentStage: Math.min(7, Math.max(1, row.currentStage)) as ScriptStageNumber,
    highestApprovedStage: Math.min(7, Math.max(0, row.highestApprovedStage)),
    modelName: row.modelName === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen',
    projectStatus: derivedStatus,
    finalApprovedScript: row.finalApprovedScript ?? null,
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
    approvalTimestamps: safeParseJson<Record<string, string>>(row.approvalTimestampsJson, {}),
    settings: { ...defaultSettings, ...safeParseJson<Partial<ScriptPersonalizationSettings>>(row.settingsJson, {}) },
    state: { ...defaultState, ...safeParseJson<Partial<ScriptProjectState>>(row.stateJson, {}) },
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function appendRevision(
  state: ScriptProjectState,
  stage: ScriptStageNumber,
  action: string,
  summary: string
): ScriptProjectState {
  const entry = {
    id: crypto.randomUUID().slice(0, 8),
    stage,
    action,
    summary,
    timestamp: new Date().toISOString(),
  };
  return {
    ...state,
    revisionHistory: [entry, ...(state.revisionHistory || [])].slice(0, 50),
  };
}

function recomputeHighestApproved(state: ScriptProjectState): number {
  if (!state.stage1.approved) return 0;
  if (!state.stage2.approved) return 1;
  if (!state.stage3.approved) return 2;
  if (!state.stage4.approved) return 3;
  if (!state.stage5.approved) return 4;
  if (!state.stage6.approved) return 5;
  if (!state.stage7.approved) return 6;
  return 7;
}

function invalidateDownstreamFrom(
  state: ScriptProjectState,
  changedStage: ScriptStageNumber,
  reason: string
): ScriptProjectState {
  let affected = false;
  const next: ScriptProjectState = {
    ...state,
    stage2: { ...state.stage2 },
    stage3: { ...state.stage3 },
    stage4: { ...state.stage4 },
    stage5: { ...state.stage5, sections: state.stage5.sections.map((s) => ({ ...s })) },
    stage6: { ...state.stage6 },
    stage7: { ...state.stage7 },
  };

  if (changedStage <= 1 && (next.stage2.approved || next.stage2.titleConcepts.length > 0)) {
    next.stage2.approved = false;
    next.stage2.titleApproved = false;
    next.stage2.approvedAt = null;
    affected = true;
  }
  if (changedStage <= 2 && (next.stage3.approved || next.stage3.sections.length > 0)) {
    next.stage3.approved = false;
    next.stage3.approvedAt = null;
    affected = true;
  }
  if (changedStage <= 3 && (next.stage4.approved || Boolean(next.stage4.spokenNarration))) {
    next.stage4.approved = false;
    next.stage4.approvedAt = null;
    affected = true;
  }
  if (changedStage <= 4 && (next.stage5.approved || next.stage5.sections.length > 0)) {
    next.stage5.approved = false;
    next.stage5.approvedAt = null;
    next.stage5.sections = next.stage5.sections.map((s) => ({ ...s, approved: false, approvedAt: null }));
    affected = true;
  }
  if (changedStage <= 5 && (next.stage6.approved || Boolean(next.stage6.outro))) {
    next.stage6.approved = false;
    next.stage6.approvedAt = null;
    affected = true;
  }
  if (changedStage <= 6 && (next.stage7.approved || Boolean(next.stage7.assembled))) {
    next.stage7.approved = false;
    next.stage7.approvedAt = null;
    affected = true;
  }

  if (affected) {
    next.needsReviewFromStage = Math.min(7, changedStage + 1) as ScriptStageNumber;
    next.dependencyWarning = reason;
  }
  return next;
}

async function loadOwnedProject(req: AuthRequest, projectKey: string) {
  const rows = await db
    .select()
    .from(scriptProjects)
    .where(eq(scriptProjects.projectKey, projectKey))
    .limit(1);

  const row = rows[0];
  if (!row) return null;

  const userId = req.dbUser?.id ?? null;
  const guestToken = getGuestToken(req);

  const ownedByUser = userId !== null && row.userId === userId;
  const ownedByGuest = guestToken !== null && row.guestToken === guestToken;
  const legacyOrClaimable = row.userId === null && row.guestToken === null;

  if (!ownedByUser && !ownedByGuest && !legacyOrClaimable) {
    return 'forbidden' as const;
  }

  // Seamlessly claim guest project if user signed in
  if (userId !== null && row.userId === null && (ownedByGuest || legacyOrClaimable)) {
    await db
      .update(scriptProjects)
      .set({ userId, updatedAt: new Date() })
      .where(eq(scriptProjects.id, row.id));
    row.userId = userId;
  }

  return row;
}

// List saved / unfinished projects for the current user or browser session
router.get('/projects', async (req: AuthRequest, res) => {
  const userId = req.dbUser?.id ?? null;
  const guestToken = getGuestToken(req);

  if (!userId && !guestToken) {
    return res.json({ ok: true, projects: [] });
  }

  try {
    const ownerCondition =
      userId && guestToken
        ? or(eq(scriptProjects.userId, userId), eq(scriptProjects.guestToken, guestToken))
        : userId
          ? eq(scriptProjects.userId, userId)
          : eq(scriptProjects.guestToken, guestToken!);

    const rows = await db
      .select()
      .from(scriptProjects)
      .where(and(ownerCondition, isNull(scriptProjects.ytmWorkflowProjectId)))
      .orderBy(desc(scriptProjects.updatedAt))
      .limit(30);

    return res.json({ ok: true, projects: rows.map(hydrateProject) });
  } catch (err) {
    console.error('Failed to list script projects:', err);
    return fail(res, 500, 'PROJECT_LIST_FAILED', 'Unable to load saved scriptwriting projects.');
  }
});

// Saved competitor channels & reports available without re-entering URLs
router.get('/competitor-options', async (req: AuthRequest, res) => {
  const userId = req.dbUser?.id ?? null;
  const guestToken = getGuestToken(req);

  try {
    let savedWorkspaceCompetitors: Array<{
      id: number;
      channelId: string;
      title: string;
      handle: string | null;
      channelUrl: string;
      thumbnailUrl: string | null;
      subscriberCount: number | null;
      notes: string;
    }> = [];

    if (userId) {
      const memberships = await db
        .select({ workspaceId: ytmWorkspaceMembers.workspaceId })
        .from(ytmWorkspaceMembers)
        .where(
          and(
            eq(ytmWorkspaceMembers.userId, userId),
            eq(ytmWorkspaceMembers.status, 'active')
          )
        );
      const wsIds = memberships.map((m) => m.workspaceId);
      if (wsIds.length > 0) {
        const compRows = await db
          .select()
          .from(ytmWorkspaceCompetitors)
          .where(inArray(ytmWorkspaceCompetitors.workspaceId, wsIds))
          .orderBy(desc(ytmWorkspaceCompetitors.updatedAt))
          .limit(30);
        const seen = new Set<string>();
        for (const c of compRows) {
          if (!seen.has(c.channelId)) {
            seen.add(c.channelId);
            savedWorkspaceCompetitors.push({
              id: c.id,
              channelId: c.channelId,
              title: c.title,
              handle: c.handle,
              channelUrl: c.channelUrl,
              thumbnailUrl: c.thumbnailUrl,
              subscriberCount: c.subscriberCount,
              notes: c.notes,
            });
          }
        }
      }
    }

    let reportRows: Array<typeof competitorReports.$inferSelect> = [];
    if (userId || guestToken) {
      const condition =
        userId && guestToken
          ? or(eq(competitorReports.userId, userId), eq(competitorReports.guestToken, guestToken))
          : userId
            ? eq(competitorReports.userId, userId)
            : eq(competitorReports.guestToken, guestToken!);
      reportRows = await db
        .select()
        .from(competitorReports)
        .where(condition)
        .orderBy(desc(competitorReports.updatedAt))
        .limit(12);
    }

    const cachedChannels = await db
      .select()
      .from(competitorChannelCaches)
      .orderBy(desc(competitorChannelCaches.retrievedAt))
      .limit(20);

    const reports = reportRows.map((r) => {
      const synthesis = safeParseJson<{
        contentGaps?: Array<{ gapTitle?: string; opportunity?: string }>;
        reusableTitleFormulas?: Array<{ formula?: string }>;
        hookPatterns?: Array<{ pattern?: string }>;
        executiveSummary?: string;
      } | null>(r.synthesisJson || '', null);
      const collections = safeParseJson<Array<{ profile?: { channelId?: string; title?: string } }>>(
        r.rawCollectionJson || '[]',
        []
      );

      return {
        reportKey: r.reportKey,
        title: r.title,
        status: r.status,
        updatedAt: r.updatedAt.toISOString(),
        channelTitles: collections.map((c) => c.profile?.title || '').filter(Boolean),
        channelIds: collections.map((c) => c.profile?.channelId || '').filter(Boolean),
        executiveSummary: synthesis?.executiveSummary || '',
        titlePatterns: (synthesis?.reusableTitleFormulas || [])
          .map((f) => f.formula || '')
          .filter(Boolean)
          .slice(0, 6),
        hookAngles: (synthesis?.hookPatterns || [])
          .map((h) => h.pattern || '')
          .filter(Boolean)
          .slice(0, 5),
        contentGaps: (synthesis?.contentGaps || [])
          .map((g) => g.gapTitle || g.opportunity || '')
          .filter(Boolean)
          .slice(0, 5),
      };
    });

    return res.json({
      ok: true,
      workspaceCompetitors: savedWorkspaceCompetitors,
      reports,
      cachedChannels: cachedChannels.map((c) => ({
        channelId: c.channelId,
        handle: c.handle,
        title: c.title,
        channelUrl: `https://www.youtube.com/channel/${c.channelId}`,
      })),
    });
  } catch (err) {
    console.error('Failed to load competitor options for Script Studio:', err);
    return fail(res, 500, 'COMPETITOR_OPTIONS_FAILED', 'Unable to load saved competitors.');
  }
});

// Create new script project
router.post('/projects', async (req: AuthRequest, res) => {
  const guestToken = getGuestToken(req);
  const title =
    typeof req.body?.title === 'string' && req.body.title.trim()
      ? req.body.title.trim().slice(0, 180)
      : 'Untitled Video Script';
  const modelName: ScriptAiModelId =
    req.body?.modelName === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

  const seed = req.body?.seed as Partial<ScriptStudioSeed> | undefined;
  const settings: ScriptPersonalizationSettings = {
    ...createDefaultScriptSettings(),
    ...(typeof req.body?.settings === 'object' && req.body.settings ? req.body.settings : {}),
    ...(seed?.targetAudience ? { targetAudience: seed.targetAudience.slice(0, 200) } : {}),
    ...(seed?.recommendedDurationMinutes && Number.isFinite(seed.recommendedDurationMinutes)
      ? { targetDurationMinutes: Math.min(60, Math.max(1, Math.round(seed.recommendedDurationMinutes))) }
      : {}),
    ...(seed?.competitorInsights
      ? {
          customInstructions: [
            seed.contentAngle ? `Content Angle: ${seed.contentAngle}` : '',
            seed.thumbnailDirection ? `Thumbnail Direction: ${seed.thumbnailDirection}` : '',
            seed.recommendedFormat ? `Recommended Format: ${seed.recommendedFormat}` : '',
            `Competitor Research Notes: ${seed.competitorInsights}`,
          ]
            .filter(Boolean)
            .join('\n')
            .slice(0, 1200),
        }
      : {}),
  };

  const state = createInitialScriptState();
  if (seed?.topic) {
    state.stage1.entryMode = 'custom';
    state.stage1.customTopicInput = seed.topic.slice(0, 600);
    state.stage1.selectedTopic = {
      id: 'seed_topic_1',
      title: seed.suggestedTitle || seed.topic,
      targetAudience: seed.targetAudience || settings.targetAudience,
      mainAudienceProblem: seed.contentAngle || 'Addressing an underserved viewer gap identified across competitors.',
      viewerTransformation: 'Clear, practical resolution aligned with competitor white-space opportunity.',
      whyAttractive:
        seed.competitorInsights ||
        'Identified from competitor white-space opportunity analysis.',
      storytellingAngle: seed.contentAngle || seed.topic,
    };
    state.stage1.topicAnalysis = {
      centralIdea: seed.suggestedTitle || seed.topic,
      targetViewer: seed.targetAudience || settings.targetAudience,
      mainProblem: seed.contentAngle || seed.topic,
      desiredOutcome: 'Actionable clarity and stronger retention from opening promise to payoff.',
      curiosityGap: seed.contentAngle || 'What competitors left unexplained for this audience.',
      contentOpportunities: [
        seed.competitorInsights || 'Competitor white-space opportunity ready for Stage 2 packaging.',
      ],
      directorRecommendation: 'Review the seeded concept below, adjust if needed, or approve Stage 1 to unlock full packaging.',
    };
    if (seed.suggestedTitle) {
      state.stage2.titleConcepts = [
        {
          id: 'seed_title_1',
          angleType: 'curiosity',
          angleLabel: 'Competitor Gap Concept',
          title: seed.suggestedTitle,
          psychologicalAngle: seed.contentAngle || 'Underserved audience curiosity',
          viewerPromise: seed.topic,
          whyItAttractsClicks: seed.competitorInsights || 'Matches identified competitor white-space.',
          potentialLimitation: 'Generate additional options in Stage 2 to compare angles.',
          isRecommended: true,
        },
      ];
      state.stage2.selectedTitleId = 'seed_title_1';
      state.stage2.customTitleText = seed.suggestedTitle;
    }
    if (seed.thumbnailDirection) {
      state.stage2.customThumbnailNotes = seed.thumbnailDirection;
      state.stage2.thumbnailConcepts = [
        {
          id: 'seed_thumb_1',
          conceptName: 'Competitor Gap Concept',
          mainSubject: seed.thumbnailDirection,
          positioning: 'Clear focal point on left or center with breathing room for 2-4 words',
          facialExpression: 'Curiosity or clarity matching the video promise',
          background: 'Uncluttered high-contrast backdrop',
          composition: 'Visual hook aligned directly with title promise',
          lighting: 'High contrast between foreground subject and background',
          visualContrast: 'Bold separation for mobile feed readability',
          emotionalTrigger: 'Curiosity & immediate relevance',
          visualStorytelling: seed.thumbnailDirection,
        },
      ];
      state.stage2.selectedThumbnailId = 'seed_thumb_1';
    }
  }

  const projectKey = `sp_${crypto.randomBytes(10).toString('hex')}`;

  try {
    const inserted = await db
      .insert(scriptProjects)
      .values({
        projectKey,
        userId: req.dbUser?.id ?? null,
        guestToken,
        title: seed?.suggestedTitle?.slice(0, 180) || title,
        currentStage: 1,
        highestApprovedStage: 0,
        modelName,
        projectStatus: 'NOT STARTED',
        finalApprovedScript: null,
        completedAt: null,
        approvalTimestampsJson: '{}',
        settingsJson: JSON.stringify(settings),
        stateJson: JSON.stringify(state),
      })
      .returning();

    return res.status(201).json({ ok: true, project: hydrateProject(inserted[0]) });
  } catch (err) {
    console.error('Failed to create script project:', err);
    return fail(res, 500, 'PROJECT_CREATE_FAILED', 'Unable to create script project.');
  }
});

// Get single project by key
router.get('/projects/:projectKey', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedProject(req, String(req.params.projectKey));
    if (row === null) return fail(res, 404, 'PROJECT_NOT_FOUND', 'Script project not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'Access denied to this project.');
    return res.json({ ok: true, project: hydrateProject(row) });
  } catch (err) {
    console.error('Failed to load project:', err);
    return fail(res, 500, 'PROJECT_LOAD_FAILED', 'Unable to load script project.');
  }
});

// Update settings, manual inline edits, stage navigation, or start again
router.patch('/projects/:projectKey', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedProject(req, String(req.params.projectKey));
    if (row === null) return fail(res, 404, 'PROJECT_NOT_FOUND', 'Script project not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'Access denied to this project.');

    const current = hydrateProject(row);
    let nextTitle = current.title;
    let nextStage = current.currentStage;
    let nextModel = current.modelName;
    let nextSettings = { ...current.settings };
    let nextState = { ...current.state };

    if (typeof req.body?.title === 'string' && req.body.title.trim()) {
      nextTitle = req.body.title.trim().slice(0, 180);
    }
    if (req.body?.modelName === 'gemini-4-hydrogen' || req.body?.modelName === 'gemini-3.1-flash-lite') {
      nextModel = req.body.modelName;
    }
    if (typeof req.body?.settings === 'object' && req.body.settings) {
      nextSettings = { ...nextSettings, ...req.body.settings };
    }

    // Reset workflow cleanly ("Start again")
    if (req.body?.resetScriptOnly === true && row.ytmWorkflowProjectId) {
      const fresh = createInitialScriptState();
      fresh.stage1 = current.state.stage1;
      fresh.stage2 = current.state.stage2;
      fresh.competitorResearch = current.state.competitorResearch ?? null;
      nextState = appendRevision(
        fresh,
        3,
        'Reset workflow script stages',
        'Reset Outline through Complete Script while preserving synced Title and Topic'
      );
      nextStage = 3;
    } else if (req.body?.resetAll === true) {
      nextState = appendRevision(createInitialScriptState(), 1, 'Reset project', 'Started workflow from Stage 1');
      nextStage = 1;
      nextTitle = 'Untitled Video Script';
    } else {
      if (typeof req.body?.currentStage === 'number') {
        const target = Math.min(7, Math.max(1, Math.floor(req.body.currentStage))) as ScriptStageNumber;
        if (target <= current.highestApprovedStage + 1) {
          nextStage = target;
        }
      }

      if (req.body?.competitorResearch && typeof req.body.competitorResearch === 'object') {
        const cr = req.body.competitorResearch as Partial<ScriptCompetitorResearchContext>;
        nextState.competitorResearch = {
          selectedChannelIds: Array.isArray(cr.selectedChannelIds) ? cr.selectedChannelIds : [],
          selectedChannelTitles: Array.isArray(cr.selectedChannelTitles) ? cr.selectedChannelTitles : [],
          reportKey: typeof cr.reportKey === 'string' ? cr.reportKey : null,
          competitorSummary: typeof cr.competitorSummary === 'string' ? cr.competitorSummary.slice(0, 2000) : '',
          keyTitlePatterns: Array.isArray(cr.keyTitlePatterns) ? cr.keyTitlePatterns.slice(0, 10) : [],
          keyHookAngles: Array.isArray(cr.keyHookAngles) ? cr.keyHookAngles.slice(0, 10) : [],
          contentGaps: Array.isArray(cr.contentGaps) ? cr.contentGaps.slice(0, 10) : [],
          skipped: Boolean(cr.skipped),
          updatedAt: new Date().toISOString(),
        };
        nextState = appendRevision(
          nextState,
          2,
          cr.skipped ? 'Skipped Competitor Research' : 'Updated Competitor Research',
          cr.skipped
            ? 'Proceeded directly to packaging'
            : `Selected ${nextState.competitorResearch.selectedChannelTitles.length || 1} competitor source(s)`
        );
      }

      // Manual stage updates with automatic downstream dependency invalidation
      if (req.body?.stagePatch && typeof req.body.stagePatch === 'object') {
        const { stage, data } = req.body.stagePatch as { stage: ScriptStageNumber; data: Record<string, unknown> };

        if (stage === 1) {
          const wasApproved = nextState.stage1.approved;
          nextState.stage1 = { ...nextState.stage1, ...data, approved: false, approvedAt: null };
          if (typeof nextState.stage1.selectedTopic?.title === 'string' && nextState.stage1.selectedTopic.title) {
            nextTitle = nextState.stage1.selectedTopic.title.slice(0, 180);
          }
          if (wasApproved) {
            nextState = invalidateDownstreamFrom(
              nextState,
              1,
              'Stage 1 Topic changed after earlier approval. Packaging and downstream stages have been unlocked for review.'
            );
          }
          nextState = appendRevision(nextState, 1, 'Edited Stage 1', 'Updated topic discovery details');
        } else if (stage === 2) {
          const wasApproved = nextState.stage2.approved;
          nextState.stage2 = { ...nextState.stage2, ...data, approved: false, approvedAt: null };
          if (typeof nextState.stage2.customTitleText === 'string' && nextState.stage2.customTitleText.trim()) {
            nextTitle = nextState.stage2.customTitleText.trim().slice(0, 180);
          }
          if (wasApproved) {
            nextState = invalidateDownstreamFrom(
              nextState,
              2,
              'Packaging (title/thumbnail/promise) changed. Content outline and introduction depend on this packaging—please review Stage 3+.'
            );
          }
          nextState = appendRevision(nextState, 2, 'Edited Packaging', 'Updated title, thumbnail, or viewer promise');
        } else if (stage === 3) {
          const wasApproved = nextState.stage3.approved;
          nextState.stage3 = { ...nextState.stage3, ...data, approved: false, approvedAt: null };
          if (Array.isArray(nextState.stage3.sections)) {
            nextState.stage3.sections = nextState.stage3.sections.map((s, idx) => ({
              ...s,
              order: idx + 1,
            }));
          }
          if (wasApproved) {
            nextState = invalidateDownstreamFrom(
              nextState,
              3,
              'Content outline was modified. Introduction and body sections should be reviewed to match the updated outline.'
            );
          }
          nextState = appendRevision(nextState, 3, 'Edited Outline', 'Modified outline sections or ordering');
        } else if (stage === 4) {
          const wasApproved = nextState.stage4.approved;
          const narration =
            typeof data.spokenNarration === 'string'
              ? data.spokenNarration
              : nextState.stage4.spokenNarration;
          const words = countSpokenWords(narration);
          nextState.stage4 = {
            ...nextState.stage4,
            ...data,
            spokenNarration: narration,
            wordCount: words,
            estimatedSeconds: Math.round((words / (nextSettings.narrationSpeedWpm || 140)) * 60),
            approved: false,
            approvedAt: null,
          };
          if (wasApproved) {
            nextState = invalidateDownstreamFrom(
              nextState,
              4,
              'Introduction was edited. Final script assembly will need regeneration after re-approval.'
            );
          }
          nextState = appendRevision(nextState, 4, 'Edited Introduction', 'Updated introduction hook or narration');
        } else if (stage === 5) {
          const sectionIndex =
            typeof data.sectionIndex === 'number'
              ? data.sectionIndex
              : nextState.stage5.activeSectionIndex;
          const sections = [...nextState.stage5.sections];
          if (sections[sectionIndex]) {
            const spoken =
              typeof data.spokenNarration === 'string'
                ? data.spokenNarration
                : sections[sectionIndex].spokenNarration;
            sections[sectionIndex] = {
              ...sections[sectionIndex],
              ...data,
              spokenNarration: spoken,
              wordCount: countSpokenWords(spoken),
              approved: false,
              approvedAt: null,
            };
          }
          nextState.stage5 = {
            ...nextState.stage5,
            activeSectionIndex: typeof data.activeSectionIndex === 'number' ? data.activeSectionIndex : sectionIndex,
            sections,
            approved: false,
            approvedAt: null,
          };
          if (current.state.stage5.approved) {
            nextState = invalidateDownstreamFrom(
              nextState,
              5,
              'A body section was modified. Outro & final script assembly require review after re-approval.'
            );
          }
          nextState = appendRevision(
            nextState,
            5,
            `Edited Body Section ${sectionIndex + 1}`,
            `Updated section "${sections[sectionIndex]?.heading || sectionIndex + 1}"`
          );
        } else if (stage === 6 && nextState.stage6.outro) {
          const spoken =
            typeof data.spokenNarration === 'string'
              ? data.spokenNarration
              : nextState.stage6.outro.spokenNarration;
          nextState.stage6 = {
            ...nextState.stage6,
            outro: {
              ...nextState.stage6.outro,
              ...data,
              spokenNarration: spoken,
              wordCount: countSpokenWords(spoken),
            },
            approved: false,
            approvedAt: null,
          };
          if (current.state.stage6.approved) {
            nextState = invalidateDownstreamFrom(
              nextState,
              6,
              'Outro & CTA were edited. Re-assemble Stage 7 script to reflect changes.'
            );
          }
          nextState = appendRevision(nextState, 6, 'Edited Outro & CTA', 'Updated outro wording or CTA');
        } else if (stage === 7 && nextState.stage7.assembled) {
          const full =
            typeof data.fullScriptText === 'string'
              ? data.fullScriptText
              : nextState.stage7.assembled.fullScriptText;
          const words = countSpokenWords(full);
          nextState.stage7 = {
            ...nextState.stage7,
            assembled: {
              ...nextState.stage7.assembled,
              ...data,
              fullScriptText: full,
              estimatedWordCount: words,
            },
          };
          nextState = appendRevision(nextState, 7, 'Edited Final Script', 'Applied manual script polish');
        }
      }
    }

    const highestApprovedStage = recomputeHighestApproved(nextState);
    if (nextStage > highestApprovedStage + 1) {
      nextStage = (highestApprovedStage + 1) as ScriptStageNumber;
    }

    const updated = await db
      .update(scriptProjects)
      .set({
        title: nextTitle,
        currentStage: nextStage,
        highestApprovedStage,
        modelName: nextModel,
        settingsJson: JSON.stringify(nextSettings),
        stateJson: JSON.stringify(nextState),
        updatedAt: new Date(),
      })
      .where(eq(scriptProjects.id, row.id))
      .returning();

    return res.json({ ok: true, project: hydrateProject(updated[0]) });
  } catch (err) {
    console.error('Failed to update script project:', err);
    return fail(res, 500, 'PROJECT_UPDATE_FAILED', 'Unable to save script project changes.');
  }
});

// Delete project
router.delete('/projects/:projectKey', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedProject(req, String(req.params.projectKey));
    if (row === null) return fail(res, 404, 'PROJECT_NOT_FOUND', 'Script project not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'Access denied to this project.');

    await db.delete(scriptProjects).where(eq(scriptProjects.id, row.id));
    return res.json({ ok: true, deleted: true });
  } catch (err) {
    console.error('Failed to delete script project:', err);
    return fail(res, 500, 'PROJECT_DELETE_FAILED', 'Unable to delete project.');
  }
});

// Stage-specific AI generation operations (strict prerequisite enforcement)
router.post('/projects/:projectKey/generate', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedProject(req, String(req.params.projectKey));
    if (row === null) return fail(res, 404, 'PROJECT_NOT_FOUND', 'Script project not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'Access denied to this project.');

    const project = hydrateProject(row);
    const operation = typeof req.body?.operation === 'string' ? req.body.operation : '';
    const instruction = typeof req.body?.instruction === 'string' ? req.body.instruction.trim() : undefined;
    const modelName: ScriptAiModelId =
      req.body?.modelName === 'gemini-3.1-flash-lite'
        ? 'gemini-3.1-flash-lite'
        : req.body?.modelName === 'gemini-4-hydrogen'
          ? 'gemini-4-hydrogen'
          : project.modelName;

    let nextState = { ...project.state };
    let nextTitle = project.title;

    if (operation === 'topics') {
      const niche =
        typeof req.body?.niche === 'string' && req.body.niche.trim()
          ? req.body.niche.trim()
          : project.settings.channelNiche || 'Self-Improvement & Learning';

      const generated = await aiGenerateTopicIdeas({
        niche,
        settings: project.settings,
        modelName,
        instruction,
      });

      nextState.stage1 = {
        ...nextState.stage1,
        entryMode: 'ideas',
        nicheInput: niche,
        generatedIdeas: generated.ideas,
        selectedTopic: generated.ideas[0] || null,
        topicAnalysis: null,
        directorComment: generated.directorComment,
        approved: false,
        approvedAt: null,
      };
      nextState = appendRevision(nextState, 1, 'Generated Topic Ideas', `Generated ${generated.ideas.length} topic ideas for "${niche}"`);
    } else if (operation === 'analyze-topic') {
      const customTopic =
        typeof req.body?.customTopic === 'string' && req.body.customTopic.trim()
          ? req.body.customTopic.trim()
          : nextState.stage1.customTopicInput;

      if (!customTopic) {
        return fail(res, 400, 'INVALID_REQUEST', 'Please enter a video topic idea to analyze.');
      }

      const analyzed = await aiAnalyzeCustomTopic({
        topicInput: customTopic,
        settings: project.settings,
        modelName,
        instruction,
      });

      nextState.stage1 = {
        ...nextState.stage1,
        entryMode: 'custom',
        customTopicInput: customTopic,
        selectedTopic: analyzed.selectedTopic,
        topicAnalysis: analyzed.analysis,
        directorComment: analyzed.directorComment,
        approved: false,
        approvedAt: null,
      };
      nextTitle = analyzed.selectedTopic.title.slice(0, 180);
      nextState = appendRevision(nextState, 1, 'Analyzed Custom Topic', `Analyzed topic "${customTopic.slice(0, 80)}"`);
    } else if (operation === 'packaging') {
      if (!nextState.stage1.approved || !nextState.stage1.selectedTopic) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Approve Stage 1 (Topic Discovery) before generating packaging.');
      }
      const scope =
        req.body?.scope === 'titles' || req.body?.scope === 'thumbnails' ? req.body.scope : 'all';

      const packaging = await aiGeneratePackaging({
        project,
        scope,
        modelName,
        instruction,
      });

      const defaultTitle =
        packaging.titleConcepts.find((t) => t.isRecommended) || packaging.titleConcepts[0] || null;
      const defaultThumb = packaging.thumbnailConcepts[0] || null;

      nextState.stage2 = {
        ...nextState.stage2,
        videoPromise: packaging.videoPromise,
        titleConcepts: packaging.titleConcepts,
        selectedTitleId:
          scope === 'thumbnails'
            ? nextState.stage2.selectedTitleId
            : defaultTitle?.id || null,
        customTitleText:
          scope === 'thumbnails'
            ? nextState.stage2.customTitleText
            : defaultTitle?.title || '',
        titleApproved: scope === 'thumbnails' ? nextState.stage2.titleApproved : false,
        thumbnailConcepts: packaging.thumbnailConcepts,
        selectedThumbnailId:
          scope === 'titles' ? nextState.stage2.selectedThumbnailId : defaultThumb?.id || null,
        thumbnailTextOptions: packaging.thumbnailTextOptions,
        selectedThumbnailText:
          scope === 'titles'
            ? nextState.stage2.selectedThumbnailText
            : packaging.thumbnailTextOptions[0] || '',
        directorComment: packaging.directorComment,
        approved: false,
        approvedAt: null,
      };
      if (nextState.stage2.customTitleText) {
        nextTitle = nextState.stage2.customTitleText.slice(0, 180);
      }
      nextState = appendRevision(nextState, 2, 'Generated Packaging', `Generated ${scope} packaging options`);
    } else if (operation === 'outline') {
      if (!nextState.stage2.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Approve Stage 2 (Video Packaging) before building the outline.');
      }
      const outline = await aiGenerateOutline({
        project,
        modelName,
        instruction,
      });
      nextState.stage3 = {
        research: outline.research,
        retentionArchitectureNote: outline.retentionArchitectureNote,
        sections: outline.sections,
        directorComment: outline.directorComment,
        approved: false,
        approvedAt: null,
      };
      nextState = appendRevision(nextState, 3, 'Generated Outline', `Created ${outline.sections.length}-section retention outline`);
    } else if (operation === 'intro') {
      if (!nextState.stage3.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Approve Stage 3 (Content Outline) before writing the introduction.');
      }
      const intro = await aiGenerateIntroduction({
        project,
        modelName,
        instruction,
      });
      nextState.stage4 = {
        ...intro,
        approved: false,
        approvedAt: null,
      };
      nextState = appendRevision(nextState, 4, 'Generated Introduction', 'Drafted 5-part packaging-aligned introduction');
    } else if (operation === 'body-section') {
      if (!nextState.stage4.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Approve Stage 4 (Introduction) before drafting body sections.');
      }
      const sectionIndex =
        typeof req.body?.sectionIndex === 'number'
          ? Math.floor(req.body.sectionIndex)
          : nextState.stage5.activeSectionIndex;

      if (sectionIndex < 0 || sectionIndex >= nextState.stage3.sections.length) {
        return fail(res, 400, 'INVALID_REQUEST', 'Invalid outline section index.');
      }

      // Enforce strictly section-by-section progression: previous section must be approved first
      if (sectionIndex > 0) {
        const prevSection = nextState.stage5.sections[sectionIndex - 1];
        if (!prevSection || !prevSection.approved) {
          return fail(
            res,
            400,
            'PREREQUISITE_REQUIRED',
            `Approve Body Section ${sectionIndex} before generating Section ${sectionIndex + 1}.`
          );
        }
      }

      const draft = await aiGenerateBodySection({
        project,
        sectionIndex,
        modelName,
        instruction,
      });

      const sections = [...nextState.stage5.sections];
      sections[sectionIndex] = draft;
      nextState.stage5 = {
        activeSectionIndex: sectionIndex,
        sections,
        approved: false,
        approvedAt: null,
      };
      nextState = appendRevision(
        nextState,
        5,
        `Drafted Body Section ${sectionIndex + 1}`,
        `Generated narration for "${draft.heading}" (${draft.wordCount} words)`
      );
    } else if (operation === 'outro') {
      if (!nextState.stage5.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Approve all Stage 5 Body Sections before generating the outro.');
      }
      const outro = await aiGenerateOutro({
        project,
        modelName,
        instruction,
      });
      nextState.stage6 = {
        outro,
        approved: false,
        approvedAt: null,
      };
      nextState = appendRevision(nextState, 6, 'Generated Outro & CTA', 'Drafted Fortune Cookie outro and native CTA');
    } else if (operation === 'assemble') {
      if (!nextState.stage6.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Approve Stage 6 (Outro & CTA) before assembling the complete script.');
      }
      const includeProductionNotes = req.body?.includeProductionNotes === true;
      const assembled = await aiAssembleFinalScript({
        project,
        includeProductionNotes,
        modelName,
        instruction,
      });
      nextState.stage7 = {
        assembled,
        approved: false,
        approvedAt: null,
      };
      nextState = appendRevision(
        nextState,
        7,
        'Assembled Final Script',
        `Assembled ${assembled.estimatedWordCount} spoken words (~${assembled.estimatedDurationFormatted})`
      );
    } else if (operation === 'explain') {
      const stage = (Number(req.body?.stage) || project.currentStage) as ScriptStageNumber;
      const question =
        typeof req.body?.question === 'string' && req.body.question.trim()
          ? req.body.question.trim()
          : 'Explain why you recommended this direction and how it improves viewer retention.';

      const result = await aiExplainDecision({
        project,
        stage,
        question,
        modelName,
      });
      return res.json({ ok: true, explanation: result.explanation });
    } else {
      return fail(res, 400, 'INVALID_REQUEST', `Unknown scriptwriting operation "${operation}".`);
    }

    const updated = await db
      .update(scriptProjects)
      .set({
        title: nextTitle,
        modelName,
        stateJson: JSON.stringify(nextState),
        updatedAt: new Date(),
      })
      .where(eq(scriptProjects.id, row.id))
      .returning();

    return res.json({ ok: true, project: hydrateProject(updated[0]) });
  } catch (err: unknown) {
    if (err instanceof ScriptAiError) {
      return fail(res, err.statusCode, err.code, err.message);
    }
    const msg = err instanceof Error ? err.message : 'Script generation failed.';
    return fail(res, 500, 'AI_GENERATION_FAILED', msg);
  }
});

// Explicit Approval Endpoint (enforces Approval Before Progression)
router.post('/projects/:projectKey/approve', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedProject(req, String(req.params.projectKey));
    if (row === null) return fail(res, 404, 'PROJECT_NOT_FOUND', 'Script project not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'Access denied to this project.');

    const project = hydrateProject(row);
    const stage = Number(req.body?.stage) as ScriptStageNumber;
    const now = new Date().toISOString();
    let nextState = { ...project.state, needsReviewFromStage: null as ScriptStageNumber | null, dependencyWarning: null as string | null };
    let nextStage = project.currentStage;
    let nextTitle = project.title;

    if (stage === 1) {
      const chosenTopic = nextState.stage1.selectedTopic;
      if (!chosenTopic) {
        return fail(res, 400, 'INVALID_REQUEST', 'Select or analyze a video topic before approving Stage 1.');
      }
      nextState.stage1 = { ...nextState.stage1, approved: true, approvedAt: now };
      nextTitle = chosenTopic.title.slice(0, 180);
      nextStage = 2;
      nextState = appendRevision(nextState, 1, 'Approved Stage 1 Topic', `Approved topic "${nextTitle}"`);
    } else if (stage === 2) {
      if (!nextState.stage1.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Stage 1 must be approved first.');
      }
      const chosenTitle =
        nextState.stage2.customTitleText.trim() ||
        nextState.stage2.titleConcepts.find((t) => t.id === nextState.stage2.selectedTitleId)?.title ||
        '';
      if (!chosenTitle || !nextState.stage2.selectedThumbnailId || !nextState.stage2.selectedThumbnailText.trim()) {
        return fail(
          res,
          400,
          'INVALID_REQUEST',
          'Please ensure a video title, thumbnail concept, and thumbnail text are selected before approving Packaging.'
        );
      }
      nextState.stage2 = {
        ...nextState.stage2,
        customTitleText: chosenTitle,
        titleApproved: true,
        approved: true,
        approvedAt: now,
      };
      nextTitle = chosenTitle.slice(0, 180);
      nextStage = 3;
      nextState = appendRevision(nextState, 2, 'Approved Video Packaging', `Locked title "${chosenTitle}"`);
    } else if (stage === 3) {
      if (!nextState.stage2.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Stage 2 Packaging must be approved first.');
      }
      if (!nextState.stage3.sections.length) {
        return fail(res, 400, 'INVALID_REQUEST', 'Generate or add at least one outline section before approving Stage 3.');
      }
      nextState.stage3 = { ...nextState.stage3, approved: true, approvedAt: now };
      nextStage = 4;
      nextState = appendRevision(nextState, 3, 'Approved Content Outline', `Approved ${nextState.stage3.sections.length} outline sections`);
    } else if (stage === 4) {
      if (!nextState.stage3.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Stage 3 Outline must be approved first.');
      }
      if (!nextState.stage4.spokenNarration.trim()) {
        return fail(res, 400, 'INVALID_REQUEST', 'Generate or write an introduction before approving Stage 4.');
      }
      nextState.stage4 = { ...nextState.stage4, approved: true, approvedAt: now };
      nextStage = 5;
      nextState = appendRevision(nextState, 4, 'Approved Introduction', `Approved ${nextState.stage4.wordCount}-word intro`);
    } else if (stage === 5) {
      if (!nextState.stage4.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'Stage 4 Introduction must be approved first.');
      }
      const sectionIndex =
        typeof req.body?.sectionIndex === 'number'
          ? Math.floor(req.body.sectionIndex)
          : nextState.stage5.activeSectionIndex;

      const sections = [...nextState.stage5.sections];
      if (!sections[sectionIndex] || !sections[sectionIndex].spokenNarration.trim()) {
        return fail(res, 400, 'INVALID_REQUEST', `Draft Body Section ${sectionIndex + 1} before approving it.`);
      }
      sections[sectionIndex] = { ...sections[sectionIndex], approved: true, approvedAt: now };

      const totalOutlineSections = nextState.stage3.sections.length;
      const allApproved =
        sections.length >= totalOutlineSections &&
        nextState.stage3.sections.every((_sec, i) => Boolean(sections[i]?.approved));

      nextState.stage5 = {
        activeSectionIndex: allApproved
          ? sectionIndex
          : Math.min(totalOutlineSections - 1, sectionIndex + 1),
        sections,
        approved: allApproved,
        approvedAt: allApproved ? now : null,
      };
      nextStage = allApproved ? 6 : 5;
      nextState = appendRevision(
        nextState,
        5,
        `Approved Body Section ${sectionIndex + 1}`,
        allApproved
          ? 'All main body sections approved — moving to Outro & CTA'
          : `Approved "${sections[sectionIndex].heading}" — ready for Section ${sectionIndex + 2}`
      );
    } else if (stage === 6) {
      if (!nextState.stage5.approved) {
        return fail(res, 400, 'PREREQUISITE_REQUIRED', 'All Stage 5 Body Sections must be approved first.');
      }
      if (!nextState.stage6.outro?.spokenNarration.trim()) {
        return fail(res, 400, 'INVALID_REQUEST', 'Generate or write an outro before approving Stage 6.');
      }
      nextState.stage6 = { ...nextState.stage6, approved: true, approvedAt: now };
      nextStage = 7;
      nextState = appendRevision(nextState, 6, 'Approved Outro & CTA', 'Approved outro and natural call to action');
    } else if (stage === 7) {
      if (
        !nextState.stage1.approved ||
        !nextState.stage2.approved ||
        !nextState.stage3.approved ||
        !nextState.stage4.approved ||
        !nextState.stage5.approved ||
        !nextState.stage6.approved ||
        !nextState.stage7.assembled?.fullScriptText?.trim()
      ) {
        return fail(
          res,
          400,
          'PREREQUISITE_REQUIRED',
          'All prior stages must be approved and the complete script assembled before finalizing.'
        );
      }
      nextState.stage7 = { ...nextState.stage7, approved: true, approvedAt: now };
      nextStage = 7;
      nextState = appendRevision(nextState, 7, 'Finalized Complete Script', 'Marked final script production-ready & archived');
    } else {
      return fail(res, 400, 'INVALID_REQUEST', 'Invalid stage number (1-7).');
    }

    const highestApprovedStage = recomputeHighestApproved(nextState);
    const nextApprovalTimestamps: Record<string, string> = {
      ...project.approvalTimestamps,
      [`stage${stage}`]: now,
    };
    const isCompleted = stage === 7 && highestApprovedStage === 7;
    const finalScriptText = isCompleted
      ? nextState.stage7.assembled?.fullScriptText || project.finalApprovedScript || null
      : project.finalApprovedScript;

    const updated = await db
      .update(scriptProjects)
      .set({
        title: nextTitle,
        currentStage: nextStage,
        highestApprovedStage,
        projectStatus: isCompleted ? 'COMPLETED' : 'IN PROGRESS',
        finalApprovedScript: finalScriptText,
        completedAt: isCompleted ? new Date() : row.completedAt,
        approvalTimestampsJson: JSON.stringify(nextApprovalTimestamps),
        stateJson: JSON.stringify(nextState),
        updatedAt: new Date(),
      })
      .where(eq(scriptProjects.id, row.id))
      .returning();

    // If linked to a YouTube Management Workflow project and Stage 7 (Complete Script) is approved,
    // automatically update Workflow Stage 3 approval and save finalApprovedScript without wiping downstream Stages 4-6.
    if (stage === 7 && row.ytmWorkflowProjectId) {
      const wfRows = await db
        .select()
        .from(ytmWorkflowProjects)
        .where(eq(ytmWorkflowProjects.id, row.ytmWorkflowProjectId))
        .limit(1);
      if (wfRows[0]) {
        const wf = wfRows[0];
        const approvals = safeParseJson<Record<string, boolean>>(wf.approvalsJson, {});
        const approvalTs = safeParseJson<Record<string, string>>(wf.approvalTimestampsJson, {});
        const warnings = safeParseJson<Record<string, string>>(wf.stageWarningsJson, {});
        const nextApprovals = { ...approvals, stage3: true };
        const nextWfTs = { ...approvalTs, stage3: now };
        delete warnings.stage3;

        const hasS4 = wf.stage4ThumbnailJson && wf.stage4ThumbnailJson !== '{}' && wf.stage4ThumbnailJson.includes('"concepts":[{');
        const hasS5 = wf.stage5SeoJson && wf.stage5SeoJson !== '{}' && (wf.stage5SeoJson.includes('"description":"') && !wf.stage5SeoJson.includes('"description":""'));
        if (hasS4 || approvals.stage4) {
          warnings.stage4 = 'Script was updated. Review thumbnail text/concepts for alignment.';
        }
        if (hasS5 || approvals.stage5) {
          warnings.stage5 = 'Script was updated. Review SEO description, tags, and chapters for alignment.';
        }
        if (approvals.stage6) {
          warnings.stage6 = 'Script was updated. Review distribution posts before publishing.';
        }

        await db
          .update(ytmWorkflowProjects)
          .set({
            approvalsJson: JSON.stringify(nextApprovals),
            approvalTimestampsJson: JSON.stringify(nextWfTs),
            stageWarningsJson: JSON.stringify(warnings),
            finalApprovedScript: finalScriptText,
            projectStatus: wf.projectStatus === 'NOT STARTED' ? 'IN PROGRESS' : wf.projectStatus,
            updatedAt: new Date(),
          })
          .where(eq(ytmWorkflowProjects.id, wf.id));
      }
    }

    return res.json({ ok: true, project: hydrateProject(updated[0]) });
  } catch (err) {
    console.error('Approval update failed:', err);
    return fail(res, 500, 'APPROVAL_FAILED', 'Unable to record stage approval.');
  }
});

export default router;
