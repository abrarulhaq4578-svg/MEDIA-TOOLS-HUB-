import crypto from 'node:crypto';
import express from 'express';
import { count, desc, eq, sql } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  abuseReports,
  advertisements,
  apiKeys,
  apiUsage,
  auditLogs,
  blogPosts,
  contactMessages,
  conversionJobs,
  dailyMetrics,
  downloadLogs,
  platforms,
  processingJobs,
  tools,
  users,
  websiteSettings,
} from '../../db/schema.ts';
import { TOOLS_CATALOG } from '../../shared/toolsCatalog.ts';
import {
  optionalAuth,
  requireAdmin,
  requireAuth,
  type AuthRequest,
} from '../middleware/auth.ts';
import {
  apiRateLimiter,
  clearRateLimiterCache,
  hashApiKey,
} from '../middleware/rateLimiter.ts';
import {
  getAdminIntegrationsReport,
  getPublicIntegrationFlags,
  getServerConfig,
  resolveSettingWithEnv,
} from '../config/env.ts';
import { ensureDatabaseSeeded } from '../services/dbSeed.ts';
import {
  fetchMetaPlatformMetadata,
  fetchPinterestMetadata,
  fetchTikTokMetadata,
  fetchTwitterMetadata,
  fetchYouTubeDetails,
  fetchYouTubeTranscript,
  getYouTubeQuotaStats,
  inspectGeneralWebMetadata,
  probeYouTubeThumbnails,
} from '../services/mediaExtractor.ts';
import {
  cleanupMediaJobs,
  getLiveMediaEngineTelemetry,
  parseMediaLimitsConfig,
} from '../services/mediaProcessor.ts';
import { safeFetch } from '../services/ssrfGuard.ts';
import { detectAndNormalizeUrl, detectPlatformFromUrl } from '../services/urlDetector.ts';
import scriptStudioRouter from './scriptStudio.ts';
import competitorIntelRouter from './competitorIntel.ts';
import youtubeManagementRouter from './youtubeManagement.ts';
import {
  buildYtmOAuthConfigValidation,
  resolveOAuthRedirectUri,
} from '../services/ytmOAuthService.ts';

const router = express.Router();

function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

async function incrementDailyMetric(
  field: 'visitors' | 'toolRuns' | 'failedRuns' | 'apiCalls'
) {
  const dateKey = todayKey();
  try {
    await db
      .insert(dailyMetrics)
      .values({
        dateKey,
        visitors: field === 'visitors' ? 1 : 0,
        toolRuns: field === 'toolRuns' ? 1 : 0,
        failedRuns: field === 'failedRuns' ? 1 : 0,
        apiCalls: field === 'apiCalls' ? 1 : 0,
      })
      .onConflictDoUpdate({
        target: dailyMetrics.dateKey,
        set:
          field === 'visitors'
            ? { visitors: sql`${dailyMetrics.visitors} + 1` }
            : field === 'toolRuns'
              ? { toolRuns: sql`${dailyMetrics.toolRuns} + 1` }
              : field === 'failedRuns'
                ? { failedRuns: sql`${dailyMetrics.failedRuns} + 1` }
                : { apiCalls: sql`${dailyMetrics.apiCalls} + 1` },
      });
  } catch {
    // Telemetry failures never disrupt user requests
  }
}

async function logToolJob(params: {
  toolSlug: string;
  platformSlug: string;
  userId?: number;
  targetUrl?: string;
  status: 'completed' | 'failed' | 'restricted';
  errorCode?: string;
  errorMessage?: string;
  durationMs: number;
}) {
  try {
    await db.insert(processingJobs).values({
      toolSlug: params.toolSlug,
      platformSlug: params.platformSlug,
      userId: params.userId ?? null,
      targetUrl: params.targetUrl?.slice(0, 500) ?? null,
      status: params.status,
      errorCode: params.errorCode ?? null,
      errorMessage: params.errorMessage?.slice(0, 300) ?? null,
      durationMs: params.durationMs,
    });

    if (params.status === 'completed') {
      await db
        .update(tools)
        .set({ usageCount: sql`${tools.usageCount} + 1` })
        .where(eq(tools.slug, params.toolSlug));
      await incrementDailyMetric('toolRuns');
    } else if (params.status === 'failed') {
      await incrementDailyMetric('failedRuns');
    }
  } catch {
    // Non-blocking job log
  }
}

async function recordAudit(
  req: AuthRequest,
  action: string,
  resourceType: string,
  resourceId?: string,
  metadata?: unknown
) {
  if (!req.dbUser) return;
  try {
    await db.insert(auditLogs).values({
      actorUid: req.dbUser.uid,
      actorEmail: req.dbUser.email,
      action,
      resourceType,
      resourceId: resourceId ?? null,
      metadataJson: metadata ? JSON.stringify(metadata) : null,
    });
  } catch {
    // Non-blocking audit log
  }
}

router.use(apiRateLimiter);
router.use(optionalAuth);

// Health Check
router.get('/health', async (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  const checkOAuth = req.query.checkOAuth === '1';
  const ytmOAuth = await buildYtmOAuthConfigValidation({
    redirectUri: resolveOAuthRedirectUri(req),
    probeGoogleEndpoint: checkOAuth,
  }).catch(() => null);

  const oauthTopLevel =
    checkOAuth && ytmOAuth
      ? {
          valid: ytmOAuth.valid,
          oauthConfigured: ytmOAuth.oauthConfigured,
          clientIdPresent: ytmOAuth.clientIdPresent,
          clientIdFormatValid: ytmOAuth.clientIdFormatValid,
          clientSecretPresent: ytmOAuth.clientSecretPresent,
          clientSecretFormatValid: ytmOAuth.clientSecretFormatValid,
          redirectUriValid: ytmOAuth.redirectUriValid,
          oauthClientInitialized: ytmOAuth.oauthClientInitialized,
          authorizationUrlReady: ytmOAuth.authorizationUrlReady,
          issues: ytmOAuth.issues,
          redirectUri: ytmOAuth.redirectUri,
        }
      : {};

  try {
    await db.execute(sql`SELECT 1`);
    return res.json({
      status: 'ok',
      service: 'MediaToolsHub API',
      integrations: getPublicIntegrationFlags(),
      ...oauthTopLevel,
      ...(ytmOAuth ? { ytmOAuth } : {}),
      timestamp: new Date().toISOString(),
    });
  } catch {
    return res.status(503).json({
      status: 'degraded',
      service: 'MediaToolsHub API',
      integrations: getPublicIntegrationFlags(),
      ...oauthTopLevel,
      ...(ytmOAuth ? { ytmOAuth } : {}),
      timestamp: new Date().toISOString(),
    });
  }
});

// Tools & Platforms Catalog
router.get('/platforms', async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const rows = await db
      .select()
      .from(platforms)
      .orderBy(platforms.sortOrder);
    return res.json({ platforms: rows });
  } catch (error) {
    console.error('Failed to load platforms:', error);
    return res.status(500).json({ error: 'Unable to load platforms.' });
  }
});

router.get('/tools', async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const dbTools = await db.select().from(tools);
    const dbMap = new Map(dbTools.map((t) => [t.slug, t]));

    const merged = TOOLS_CATALOG.map((cat) => {
      const row = dbMap.get(cat.slug);
      return {
        ...cat,
        isEnabled: row ? row.isEnabled : true,
        isPopular: row ? row.isPopular : cat.isPopular,
        isNew: row ? row.isNew : cat.isNew,
        seoTitle: row ? row.seoTitle : cat.seoTitle,
        seoDescription: row ? row.seoDescription : cat.seoDescription,
        usageCount: row ? row.usageCount : 0,
      };
    });
    return res.json({ tools: merged });
  } catch (error) {
    console.error('Failed to load tools:', error);
    return res.status(500).json({ error: 'Unable to load tool directory.' });
  }
});

// Active Ads & Public Site Config
router.get('/ads/active', async (_req, res) => {
  const cfg = getServerConfig();
  try {
    await ensureDatabaseSeeded();
    const rows = await db
      .select()
      .from(advertisements)
      .where(eq(advertisements.isEnabled, true));
    const settingsRows = await db.select().from(websiteSettings);
    const settingsMap = Object.fromEntries(
      settingsRows.map((s) => [s.key, s.value])
    );

    const adsense = resolveSettingWithEnv(settingsMap, 'adsense_publisher_id', cfg.adsensePublisherId);
    const ga = resolveSettingWithEnv(settingsMap, 'ga_measurement_id', cfg.gaMeasurementId);
    const integrations = getPublicIntegrationFlags(settingsMap);

    // Suppress unconfigured Google AdSense placements so no broken ad slots appear
    const visiblePlacements = rows.filter((p) => {
      if (p.provider === 'google_adsense' && (!integrations.adsenseEnabled || !p.adUnitId.trim())) {
        return false;
      }
      return true;
    });

    return res.json({
      placements: visiblePlacements,
      adsensePublisherId: adsense.value,
      gaMeasurementId: integrations.gaEnabled ? ga.value : '',
      integrations,
    });
  } catch {
    const integrations = getPublicIntegrationFlags();
    return res.json({
      placements: [],
      adsensePublisherId: cfg.adsensePublisherId || '',
      gaMeasurementId: integrations.gaEnabled ? cfg.gaMeasurementId || '' : '',
      integrations,
    });
  }
});

// Public Blog Endpoints
router.get('/blog', async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const posts = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.isPublished, true))
      .orderBy(desc(blogPosts.publishedAt));
    return res.json({ posts });
  } catch (error) {
    console.error('Failed to fetch blog posts:', error);
    return res.status(500).json({ error: 'Unable to load blog articles.' });
  }
});

router.get('/blog/:slug', async (req, res) => {
  try {
    await ensureDatabaseSeeded();
    const rows = await db
      .select()
      .from(blogPosts)
      .where(eq(blogPosts.slug, req.params.slug))
      .limit(1);
    if (!rows[0] || !rows[0].isPublished) {
      return res.status(404).json({ error: 'Article not found.' });
    }
    return res.json({ post: rows[0] });
  } catch (error) {
    console.error('Failed to fetch blog post:', error);
    return res.status(500).json({ error: 'Unable to load article.' });
  }
});

// Visitor Metric
router.post('/analytics/visit', async (_req, res) => {
  await ensureDatabaseSeeded();
  await incrementDailyMetric('visitors');
  return res.json({ recorded: true });
});

// URL Validation & Platform Detection
router.post('/url/validate', async (req: AuthRequest, res) => {
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const result = detectPlatformFromUrl(url);
  return res.status(result.valid ? 200 : 400).json(result);
});

// Stage 1: Full URL Detection, Normalization & Capability Classification
router.post('/url/detect', async (req: AuthRequest, res) => {
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const report = detectAndNormalizeUrl(url);
  return res.status(report.valid ? 200 : 400).json(report);
});

// YouTube Thumbnail Extractor
router.post('/youtube/thumbnail', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const validation = detectPlatformFromUrl(url);

  if (!validation.valid || validation.platform !== 'youtube' || !validation.entityId) {
    await logToolJob({
      toolSlug: 'youtube-thumbnail-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: url,
      status: 'failed',
      errorCode: 'INVALID_YOUTUBE_URL',
      errorMessage: validation.reason || 'Invalid YouTube URL.',
      durationMs: Date.now() - start,
    });
    return res.status(400).json({
      error: validation.reason || 'Please provide a valid YouTube video URL.',
      code: 'INVALID_YOUTUBE_URL',
    });
  }

  try {
    const thumbnails = await probeYouTubeThumbnails(validation.entityId);
    await logToolJob({
      toolSlug: 'youtube-thumbnail-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: validation.normalizedUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json({
      videoId: validation.entityId,
      canonicalUrl: validation.normalizedUrl,
      thumbnails,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Thumbnail probe failed.';
    await logToolJob({
      toolSlug: 'youtube-thumbnail-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: validation.normalizedUrl,
      status: 'failed',
      errorCode: 'THUMBNAIL_PROBE_FAILED',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(502).json({ error: message, code: 'THUMBNAIL_PROBE_FAILED' });
  }
});

// Safe Proxy Download for YouTube Thumbnails (Strict allowlist: i.ytimg.com)
router.get('/youtube/thumbnail/download', async (req: AuthRequest, res) => {
  const videoId = typeof req.query.videoId === 'string' ? req.query.videoId : '';
  const quality = typeof req.query.quality === 'string' ? req.query.quality : 'hqdefault';
  const allowedQualities = new Set([
    'maxresdefault',
    'sddefault',
    'hqdefault',
    'mqdefault',
    'default',
  ]);

  if (!/^[a-zA-Z0-9_-]{11}$/.test(videoId) || !allowedQualities.has(quality)) {
    return res.status(400).json({ error: 'Invalid videoId or thumbnail quality.' });
  }

  const targetUrl = `https://i.ytimg.com/vi/${videoId}/${quality}.jpg`;
  try {
    const upstream = await safeFetch(targetUrl, {
      allowedHosts: ['i.ytimg.com'],
      timeoutMs: 8000,
    });
    if (!upstream.ok) {
      return res.status(404).json({ error: 'Requested thumbnail resolution is unavailable.' });
    }
    const arrayBuffer = await upstream.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    db.insert(downloadLogs)
      .values({
        toolSlug: 'youtube-thumbnail-extractor',
        platformSlug: 'youtube',
        userId: req.dbUser?.id ?? null,
        assetType: 'thumbnail',
        format: 'jpg',
        resolution: quality,
        fileSizeBytes: buffer.byteLength,
      })
      .catch(() => {});

    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'image/jpeg');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="youtube-${videoId}-${quality}.jpg"`
    );
    res.setHeader('Cache-Control', 'public, max-age=3600');
    return res.send(buffer);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Download failed.';
    return res.status(502).json({ error: message });
  }
});

// YouTube Video Details Extractor
router.post('/youtube/details', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const validation = detectPlatformFromUrl(url);

  if (!validation.valid || validation.platform !== 'youtube' || !validation.entityId) {
    return res.status(400).json({
      error: validation.reason || 'Please provide a valid YouTube video URL.',
      code: 'INVALID_YOUTUBE_URL',
    });
  }

  try {
    const details = await fetchYouTubeDetails(validation.entityId);
    await logToolJob({
      toolSlug: 'youtube-video-details-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: validation.normalizedUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(details);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unable to fetch YouTube video details.';
    await logToolJob({
      toolSlug: 'youtube-video-details-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: validation.normalizedUrl,
      status: 'failed',
      errorCode: 'YOUTUBE_DETAILS_FAILED',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(502).json({ error: message, code: 'YOUTUBE_DETAILS_FAILED' });
  }
});

// YouTube Transcript & Captions Extractor
router.post('/youtube/transcript', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const lang = typeof req.body?.lang === 'string' ? req.body.lang.trim() : undefined;
  const validation = detectPlatformFromUrl(url);

  if (!validation.valid || validation.platform !== 'youtube' || !validation.entityId) {
    return res.status(400).json({
      error: validation.reason || 'Please provide a valid YouTube video URL.',
      code: 'INVALID_YOUTUBE_URL',
    });
  }

  try {
    const transcript = await fetchYouTubeTranscript(validation.entityId, lang);
    await logToolJob({
      toolSlug: 'youtube-transcript-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: validation.normalizedUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(transcript);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unable to extract video transcript.';
    await logToolJob({
      toolSlug: 'youtube-transcript-extractor',
      platformSlug: 'youtube',
      userId: req.dbUser?.id,
      targetUrl: validation.normalizedUrl,
      status: 'failed',
      errorCode: 'YOUTUBE_TRANSCRIPT_UNAVAILABLE',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(404).json({ error: message, code: 'YOUTUBE_TRANSCRIPT_UNAVAILABLE' });
  }
});

async function loadSettingsFlags() {
  try {
    const rows = await db.select().from(websiteSettings);
    const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    return getPublicIntegrationFlags(map);
  } catch {
    return getPublicIntegrationFlags();
  }
}

// Instagram Metadata
router.post('/instagram/metadata', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const toolSlug =
    typeof req.body?.toolSlug === 'string' ? req.body.toolSlug : 'instagram-post-metadata';
  try {
    const flags = await loadSettingsFlags();
    const result = await fetchMetaPlatformMetadata(url, 'instagram', {
      allowApi: flags.metaApiConfigured,
    });
    await logToolJob({
      toolSlug,
      platformSlug: 'instagram',
      userId: req.dbUser?.id,
      targetUrl: result.canonicalUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(result);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Invalid Instagram URL.';
    await logToolJob({
      toolSlug,
      platformSlug: 'instagram',
      userId: req.dbUser?.id,
      targetUrl: url,
      status: 'failed',
      errorCode: 'INSTAGRAM_METADATA_ERROR',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(400).json({ error: message, code: 'INSTAGRAM_METADATA_ERROR' });
  }
});

// Pinterest Metadata
router.post('/pinterest/metadata', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const toolSlug =
    typeof req.body?.toolSlug === 'string' ? req.body.toolSlug : 'pinterest-pin-info';
  try {
    const flags = await loadSettingsFlags();
    const result = await fetchPinterestMetadata(url, {
      allowApi: flags.pinterestApiConfigured,
    });
    await logToolJob({
      toolSlug,
      platformSlug: 'pinterest',
      userId: req.dbUser?.id,
      targetUrl: result.canonicalUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(result);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unable to analyze Pinterest URL.';
    await logToolJob({
      toolSlug,
      platformSlug: 'pinterest',
      userId: req.dbUser?.id,
      targetUrl: url,
      status: 'failed',
      errorCode: 'PINTEREST_METADATA_ERROR',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(400).json({ error: message, code: 'PINTEREST_METADATA_ERROR' });
  }
});

// TikTok Metadata
router.post('/tiktok/metadata', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const toolSlug =
    typeof req.body?.toolSlug === 'string' ? req.body.toolSlug : 'tiktok-video-info';
  try {
    const result = await fetchTikTokMetadata(url);
    await logToolJob({
      toolSlug,
      platformSlug: 'tiktok',
      userId: req.dbUser?.id,
      targetUrl: result.canonicalUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(result);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unable to fetch TikTok metadata.';
    await logToolJob({
      toolSlug,
      platformSlug: 'tiktok',
      userId: req.dbUser?.id,
      targetUrl: url,
      status: 'failed',
      errorCode: 'TIKTOK_METADATA_ERROR',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(400).json({ error: message, code: 'TIKTOK_METADATA_ERROR' });
  }
});

// Facebook Metadata
router.post('/facebook/metadata', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const toolSlug =
    typeof req.body?.toolSlug === 'string' ? req.body.toolSlug : 'facebook-post-info';
  try {
    const flags = await loadSettingsFlags();
    const result = await fetchMetaPlatformMetadata(url, 'facebook', {
      allowApi: flags.metaApiConfigured,
    });
    await logToolJob({
      toolSlug,
      platformSlug: 'facebook',
      userId: req.dbUser?.id,
      targetUrl: result.canonicalUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(result);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Invalid Facebook URL.';
    await logToolJob({
      toolSlug,
      platformSlug: 'facebook',
      userId: req.dbUser?.id,
      targetUrl: url,
      status: 'failed',
      errorCode: 'FACEBOOK_METADATA_ERROR',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(400).json({ error: message, code: 'FACEBOOK_METADATA_ERROR' });
  }
});

// Twitter / X Metadata
router.post('/twitter/metadata', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  try {
    const result = await fetchTwitterMetadata(url);
    await logToolJob({
      toolSlug: 'twitter-metadata-extractor',
      platformSlug: 'twitter',
      userId: req.dbUser?.id,
      targetUrl: result.canonicalUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json(result);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unable to fetch Twitter/X metadata.';
    await logToolJob({
      toolSlug: 'twitter-metadata-extractor',
      platformSlug: 'twitter',
      userId: req.dbUser?.id,
      targetUrl: url,
      status: 'failed',
      errorCode: 'TWITTER_METADATA_ERROR',
      errorMessage: message,
      durationMs: Date.now() - start,
    });
    return res.status(400).json({ error: message, code: 'TWITTER_METADATA_ERROR' });
  }
});

// Unified Media Metadata Endpoint
router.post('/media/metadata', async (req: AuthRequest, res) => {
  const start = Date.now();
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const validation = detectPlatformFromUrl(url);
  if (!validation.valid) {
    return res.status(400).json({ error: validation.reason || 'Invalid URL.', validation });
  }

  try {
    const flags = await loadSettingsFlags();
    if (validation.platform === 'youtube' && validation.entityId) {
      const yt = await fetchYouTubeDetails(validation.entityId);
      await logToolJob({
        toolSlug: 'youtube-video-details-extractor',
        platformSlug: 'youtube',
        userId: req.dbUser?.id,
        targetUrl: yt.videoUrl,
        status: 'completed',
        durationMs: Date.now() - start,
      });
      return res.json({ validation, youtube: yt });
    }
    if (validation.platform === 'tiktok') {
      const social = await fetchTikTokMetadata(url);
      return res.json({ validation, social });
    }
    if (validation.platform === 'twitter') {
      const social = await fetchTwitterMetadata(url);
      return res.json({ validation, social });
    }
    if (validation.platform === 'pinterest') {
      const social = await fetchPinterestMetadata(url, {
        allowApi: flags.pinterestApiConfigured,
      });
      return res.json({ validation, social });
    }
    if (validation.platform === 'instagram' || validation.platform === 'facebook') {
      const social = await fetchMetaPlatformMetadata(url, validation.platform, {
        allowApi: flags.metaApiConfigured,
      });
      return res.json({ validation, social });
    }

    const social = await inspectGeneralWebMetadata(url);
    await logToolJob({
      toolSlug: 'url-analyzer',
      platformSlug: 'general',
      userId: req.dbUser?.id,
      targetUrl: social.canonicalUrl,
      status: 'completed',
      durationMs: Date.now() - start,
    });
    return res.json({ validation, social });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Metadata extraction failed.';
    return res.status(502).json({ error: message, validation });
  }
});

// Temporary Storage Cleanup Endpoint (Admin Authorized)
router.post('/media/cleanup', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const forceAll = req.body?.forceAll === true;
  try {
    const summary = await cleanupMediaJobs({ forceAll });
    await recordAudit(req, 'MEDIA_TEMP_CLEANUP', 'media_jobs', 'tmp', {
      forceAll,
      ...summary,
    });
    return res.json(summary);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Temporary media cleanup failed.';
    return res.status(500).json({ error: message });
  }
});

// Log Client-Side Media Conversion
router.post('/media/convert/log', async (req: AuthRequest, res) => {
  const sourceFormat = String(req.body?.sourceFormat || 'unknown').slice(0, 32);
  const targetFormat = String(req.body?.targetFormat || 'unknown').slice(0, 32);
  const sourceSizeBytes = Number(req.body?.sourceSizeBytes || 0);
  const outputSizeBytes = Number(req.body?.outputSizeBytes || 0);

  try {
    await db.insert(conversionJobs).values({
      userId: req.dbUser?.id ?? null,
      sourceFormat,
      targetFormat,
      sourceSizeBytes: Number.isFinite(sourceSizeBytes) ? sourceSizeBytes : 0,
      outputSizeBytes: Number.isFinite(outputSizeBytes) ? outputSizeBytes : 0,
      status: 'completed',
    });
    await incrementDailyMetric('toolRuns');
  } catch {
    // Non-blocking
  }
  return res.json({ logged: true });
});

// AI Video Scriptwriting Studio Routes
router.use('/script-studio', scriptStudioRouter);

// YouTube Competitor Intelligence Studio Routes
router.use('/competitor-intel', competitorIntelRouter);

// YouTube Management Creator Operating System Routes
router.use('/ytm', youtubeManagementRouter);

// Contact & DMCA / Abuse Reports
router.post('/contact', async (req, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  const email = typeof req.body?.email === 'string' ? req.body.email.trim() : '';
  const subject = typeof req.body?.subject === 'string' ? req.body.subject.trim() : '';
  const message = typeof req.body?.message === 'string' ? req.body.message.trim() : '';

  if (!name || !email.includes('@') || !subject || message.length < 10) {
    return res.status(400).json({
      error: 'Please provide your name, a valid email, a subject, and a message (at least 10 characters).',
    });
  }

  try {
    const inserted = await db
      .insert(contactMessages)
      .values({
        name: name.slice(0, 120),
        email: email.slice(0, 160),
        subject: subject.slice(0, 200),
        message: message.slice(0, 4000),
      })
      .returning();
    return res.status(201).json({ id: inserted[0].id, status: 'received' });
  } catch (error) {
    console.error('Contact form save failed:', error);
    return res.status(500).json({ error: 'Unable to submit message right now.' });
  }
});

router.post('/abuse-report', async (req, res) => {
  const targetUrl = typeof req.body?.targetUrl === 'string' ? req.body.targetUrl.trim() : '';
  const reportType = typeof req.body?.reportType === 'string' ? req.body.reportType.trim() : 'dmca';
  const reporterEmail =
    typeof req.body?.reporterEmail === 'string' ? req.body.reporterEmail.trim() : '';
  const details = typeof req.body?.details === 'string' ? req.body.details.trim() : '';

  if (!targetUrl || !reporterEmail.includes('@') || details.length < 15) {
    return res.status(400).json({
      error: 'Please include the target URL, a valid contact email, and sufficient details (min 15 characters).',
    });
  }

  try {
    const inserted = await db
      .insert(abuseReports)
      .values({
        targetUrl: targetUrl.slice(0, 500),
        reportType: ['dmca', 'abuse', 'privacy'].includes(reportType) ? reportType : 'abuse',
        reporterEmail: reporterEmail.slice(0, 160),
        details: details.slice(0, 4000),
      })
      .returning();
    return res.status(201).json({ id: inserted[0].id, status: 'open' });
  } catch (error) {
    console.error('Abuse report save failed:', error);
    return res.status(500).json({ error: 'Unable to record report right now.' });
  }
});

// Authenticated User Account & API Keys
router.get('/me', requireAuth, async (req: AuthRequest, res) => {
  try {
    const keys = await db
      .select({
        id: apiKeys.id,
        name: apiKeys.name,
        keyPrefix: apiKeys.keyPrefix,
        rateLimitPerMin: apiKeys.rateLimitPerMin,
        isActive: apiKeys.isActive,
        lastUsedAt: apiKeys.lastUsedAt,
        createdAt: apiKeys.createdAt,
      })
      .from(apiKeys)
      .where(eq(apiKeys.userId, req.dbUser!.id))
      .orderBy(desc(apiKeys.createdAt));

    const history = await db
      .select()
      .from(processingJobs)
      .where(eq(processingJobs.userId, req.dbUser!.id))
      .orderBy(desc(processingJobs.createdAt))
      .limit(20);

    return res.json({ user: req.dbUser, apiKeys: keys, recentHistory: history });
  } catch (error) {
    console.error('Failed to load /me:', error);
    return res.status(500).json({ error: 'Unable to load account details.' });
  }
});

router.post('/me/api-keys', requireAuth, async (req: AuthRequest, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  if (!name || name.length > 80) {
    return res.status(400).json({ error: 'API key name must be between 1 and 80 characters.' });
  }

  const rawSecret = `mth_live_${crypto.randomBytes(24).toString('hex')}`;
  const keyPrefix = rawSecret.slice(0, 16);
  const keyHash = hashApiKey(rawSecret);

  try {
    const created = await db
      .insert(apiKeys)
      .values({
        userId: req.dbUser!.id,
        name,
        keyPrefix,
        keyHash,
        rateLimitPerMin: req.dbUser!.plan === 'developer' ? 300 : 60,
        isActive: true,
      })
      .returning();

    return res.status(201).json({
      apiKey: {
        id: created[0].id,
        name: created[0].name,
        keyPrefix: created[0].keyPrefix,
        rateLimitPerMin: created[0].rateLimitPerMin,
        createdAt: created[0].createdAt,
      },
      plainTextKey: rawSecret,
    });
  } catch (error) {
    console.error('API key creation failed:', error);
    return res.status(500).json({ error: 'Failed to generate API key.' });
  }
});

router.delete('/me/api-keys/:id', requireAuth, async (req: AuthRequest, res) => {
  const keyId = Number.parseInt(String(req.params.id), 10);
  if (!Number.isFinite(keyId)) {
    return res.status(400).json({ error: 'Invalid API key ID.' });
  }
  try {
    const rows = await db.select().from(apiKeys).where(eq(apiKeys.id, keyId)).limit(1);
    if (!rows[0] || (rows[0].userId !== req.dbUser!.id && req.dbUser!.role !== 'admin')) {
      return res.status(404).json({ error: 'API key not found.' });
    }
    await db.update(apiKeys).set({ isActive: false }).where(eq(apiKeys.id, keyId));
    return res.json({ revoked: true });
  } catch (error) {
    console.error('API key revocation failed:', error);
    return res.status(500).json({ error: 'Unable to revoke API key.' });
  }
});

// ADMIN ROUTES (Require Auth + Admin Role)
router.get('/admin/overview', requireAuth, requireAdmin, async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const [
      userCountRows,
      jobCountRows,
      failedJobRows,
      apiCallRows,
      topTools,
      platformBreakdown,
      metricsHistory,
      recentAudit,
      openReportsRows,
      newContactsRows,
    ] = await Promise.all([
      db.select({ value: count() }).from(users),
      db.select({ value: count() }).from(processingJobs),
      db
        .select({ value: count() })
        .from(processingJobs)
        .where(eq(processingJobs.status, 'failed')),
      db.select({ value: count() }).from(apiUsage),
      db
        .select({
          slug: tools.slug,
          name: tools.name,
          platformSlug: tools.platformSlug,
          usageCount: tools.usageCount,
          isEnabled: tools.isEnabled,
        })
        .from(tools)
        .orderBy(desc(tools.usageCount))
        .limit(8),
      db
        .select({
          platformSlug: processingJobs.platformSlug,
          runs: count(),
        })
        .from(processingJobs)
        .groupBy(processingJobs.platformSlug),
      db.select().from(dailyMetrics).orderBy(desc(dailyMetrics.dateKey)).limit(30),
      db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(15),
      db
        .select({ value: count() })
        .from(abuseReports)
        .where(eq(abuseReports.status, 'open')),
      db
        .select({ value: count() })
        .from(contactMessages)
        .where(eq(contactMessages.status, 'new')),
    ]);

    const todayRow = metricsHistory.find((m) => m.dateKey === todayKey());
    const monthlyVisitors = metricsHistory.reduce((acc, m) => acc + m.visitors, 0);
    const totalVisitors = monthlyVisitors;
    const settingsRows = await db.select().from(websiteSettings);
    const settingsMap = Object.fromEntries(settingsRows.map((r) => [r.key, r.value]));

    return res.json({
      summary: {
        totalVisitors,
        dailyVisitors: todayRow?.visitors ?? 0,
        monthlyVisitors,
        totalToolUsage: jobCountRows[0]?.value ?? 0,
        failedRequests: failedJobRows[0]?.value ?? 0,
        apiUsageCount: apiCallRows[0]?.value ?? 0,
        activeUsers: userCountRows[0]?.value ?? 0,
        openAbuseReports: openReportsRows[0]?.value ?? 0,
        unreadContacts: newContactsRows[0]?.value ?? 0,
      },
      topTools,
      platformBreakdown,
      metricsHistory,
      recentAudit,
      integrations: getAdminIntegrationsReport(settingsMap),
      youtubeQuota: getYouTubeQuotaStats(),
    });
  } catch (error) {
    console.error('Admin overview failed:', error);
    return res.status(500).json({ error: 'Unable to load admin overview.' });
  }
});

router.get('/admin/integrations', requireAuth, requireAdmin, async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const settingsRows = await db.select().from(websiteSettings);
    const settingsMap = Object.fromEntries(settingsRows.map((r) => [r.key, r.value]));
    return res.json({
      integrations: getAdminIntegrationsReport(settingsMap),
      youtubeQuota: getYouTubeQuotaStats(),
    });
  } catch (error) {
    console.error('Admin integrations fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load integration status.' });
  }
});

router.get('/admin/media', requireAuth, requireAdmin, async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const [
      settingsRows,
      totalConvRows,
      successConvRows,
      failedConvRows,
      recentDownloads,
      failedProcJobs,
      engineTelemetry,
    ] = await Promise.all([
      db.select().from(websiteSettings),
      db.select({ value: count() }).from(conversionJobs),
      db
        .select({ value: count() })
        .from(conversionJobs)
        .where(eq(conversionJobs.status, 'completed')),
      db
        .select({ value: count() })
        .from(conversionJobs)
        .where(eq(conversionJobs.status, 'failed')),
      db.select().from(downloadLogs).orderBy(desc(downloadLogs.createdAt)).limit(25),
      db
        .select()
        .from(processingJobs)
        .where(eq(processingJobs.status, 'failed'))
        .orderBy(desc(processingJobs.createdAt))
        .limit(20),
      getLiveMediaEngineTelemetry(),
    ]);

    const settingsMap = Object.fromEntries(settingsRows.map((r) => [r.key, r.value]));
    const limits = parseMediaLimitsConfig(settingsMap);

    const recentErrors = [
      ...engineTelemetry.recentJobs
        .filter((j) => j.status === 'Failed' && j.errorMessage)
        .map((j) => ({
          id: j.jobId,
          source: j.sourceLabel,
          errorCode: 'CONVERSION_FAILED',
          errorMessage: j.errorMessage || 'Media processing failed.',
          createdAt: j.updatedAt,
        })),
      ...failedProcJobs.map((p) => ({
        id: p.id,
        source: p.targetUrl || p.toolSlug,
        errorCode: p.errorCode,
        errorMessage: p.errorMessage || 'Processing failed.',
        createdAt: p.createdAt.toISOString(),
      })),
    ]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 20);

    return res.json({
      totalJobs: totalConvRows[0]?.value ?? 0,
      successfulConversions: successConvRows[0]?.value ?? 0,
      failedConversions: failedConvRows[0]?.value ?? 0,
      activeJobsCount: engineTelemetry.activeJobsCount,
      expiredJobsCount: engineTelemetry.expiredJobsCount,
      storageUsedBytes: engineTelemetry.storageUsedBytes,
      tempFileCount: engineTelemetry.tempFileCount,
      maxUploadMb: limits.maxUploadMb,
      jobTtlMinutes: limits.jobTtlMinutes,
      allowedDomains: limits.allowedDomainsRaw,
      lastCleanupAt: engineTelemetry.lastCleanupAt,
      lastCleanupRemoved: engineTelemetry.lastCleanupRemoved,
      lastCleanupFreedBytes: engineTelemetry.lastCleanupFreedBytes,
      activeAndRecentJobs: engineTelemetry.recentJobs,
      recentDownloads,
      recentErrors,
    });
  } catch (error) {
    console.error('Admin media stats failed:', error);
    return res.status(500).json({ error: 'Unable to load media processing telemetry.' });
  }
});

router.patch('/admin/tools/:slug', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const { slug } = req.params;
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof req.body?.isEnabled === 'boolean') patch.isEnabled = req.body.isEnabled;
  if (typeof req.body?.isPopular === 'boolean') patch.isPopular = req.body.isPopular;
  if (typeof req.body?.isNew === 'boolean') patch.isNew = req.body.isNew;
  if (typeof req.body?.seoTitle === 'string') patch.seoTitle = req.body.seoTitle.trim().slice(0, 120);
  if (typeof req.body?.seoDescription === 'string') {
    patch.seoDescription = req.body.seoDescription.trim().slice(0, 260);
  }

  try {
    const updated = await db
      .update(tools)
      .set(patch)
      .where(eq(tools.slug, String(slug)))
      .returning();
    if (!updated[0]) return res.status(404).json({ error: 'Tool not found.' });
    await recordAudit(req, 'UPDATE_TOOL', 'tool', String(slug), patch);
    return res.json({ tool: updated[0] });
  } catch (error) {
    console.error('Admin tool update failed:', error);
    return res.status(500).json({ error: 'Unable to update tool.' });
  }
});

router.patch('/admin/platforms/:slug', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const { slug } = req.params;
  if (typeof req.body?.isEnabled !== 'boolean') {
    return res.status(400).json({ error: 'isEnabled boolean required.' });
  }
  try {
    const updated = await db
      .update(platforms)
      .set({ isEnabled: req.body.isEnabled, updatedAt: new Date() })
      .where(eq(platforms.slug, String(slug)))
      .returning();
    if (!updated[0]) return res.status(404).json({ error: 'Platform not found.' });
    await recordAudit(req, 'UPDATE_PLATFORM', 'platform', String(slug), {
      isEnabled: req.body.isEnabled,
    });
    return res.json({ platform: updated[0] });
  } catch (error) {
    console.error('Platform update failed:', error);
    return res.status(500).json({ error: 'Unable to update platform.' });
  }
});

router.get('/admin/ads', requireAuth, requireAdmin, async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const rows = await db.select().from(advertisements).orderBy(advertisements.id);
    return res.json({ placements: rows });
  } catch (error) {
    console.error('Admin ads fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load ad placements.' });
  }
});

router.patch('/admin/ads/:placementKey', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const { placementKey } = req.params;
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof req.body?.provider === 'string') patch.provider = req.body.provider.trim();
  if (typeof req.body?.adUnitId === 'string') patch.adUnitId = req.body.adUnitId.trim();
  if (typeof req.body?.desktopEnabled === 'boolean') patch.desktopEnabled = req.body.desktopEnabled;
  if (typeof req.body?.mobileEnabled === 'boolean') patch.mobileEnabled = req.body.mobileEnabled;
  if (typeof req.body?.isEnabled === 'boolean') patch.isEnabled = req.body.isEnabled;
  if (typeof req.body?.notes === 'string') patch.notes = req.body.notes.trim().slice(0, 400);

  try {
    const updated = await db
      .update(advertisements)
      .set(patch)
      .where(eq(advertisements.placementKey, String(placementKey)))
      .returning();
    if (!updated[0]) return res.status(404).json({ error: 'Ad placement not found.' });
    await recordAudit(req, 'UPDATE_AD_PLACEMENT', 'advertisement', String(placementKey), patch);
    return res.json({ placement: updated[0] });
  } catch (error) {
    console.error('Admin ad update failed:', error);
    return res.status(500).json({ error: 'Unable to update ad placement.' });
  }
});

router.get('/admin/blog', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const posts = await db.select().from(blogPosts).orderBy(desc(blogPosts.createdAt));
    return res.json({ posts });
  } catch (error) {
    console.error('Admin blog fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load blog posts.' });
  }
});

router.post('/admin/blog', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
  const slug = typeof req.body?.slug === 'string' ? req.body.slug.trim() : '';
  const excerpt = typeof req.body?.excerpt === 'string' ? req.body.excerpt.trim() : '';
  const contentMarkdown =
    typeof req.body?.contentMarkdown === 'string' ? req.body.contentMarkdown.trim() : '';
  const category = typeof req.body?.category === 'string' ? req.body.category.trim() : 'Guides';

  if (!title || !slug || !excerpt || !contentMarkdown) {
    return res.status(400).json({ error: 'Title, slug, excerpt, and content are required.' });
  }

  try {
    const created = await db
      .insert(blogPosts)
      .values({
        slug,
        title,
        excerpt,
        contentMarkdown,
        coverImage:
          typeof req.body?.coverImage === 'string' && req.body.coverImage.trim()
            ? req.body.coverImage.trim()
            : '/src/assets/images/blog_social_metadata_1794798335567.jpg',
        category,
        readTimeMinutes: Number(req.body?.readTimeMinutes) || 4,
        seoTitle: (typeof req.body?.seoTitle === 'string' && req.body.seoTitle.trim()) || title,
        seoDescription:
          (typeof req.body?.seoDescription === 'string' && req.body.seoDescription.trim()) ||
          excerpt,
        isPublished: req.body?.isPublished !== false,
      })
      .returning();
    await recordAudit(req, 'CREATE_BLOG_POST', 'blog_post', String(created[0].id), { slug });
    return res.status(201).json({ post: created[0] });
  } catch (error) {
    console.error('Create blog post failed:', error);
    return res.status(500).json({ error: 'Unable to create blog post.' });
  }
});

router.patch('/admin/blog/:id', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const id = Number.parseInt(String(req.params.id), 10);
  if (!Number.isFinite(id)) return res.status(400).json({ error: 'Invalid post ID.' });
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof req.body?.isPublished === 'boolean') patch.isPublished = req.body.isPublished;
  if (typeof req.body?.title === 'string') patch.title = req.body.title.trim();
  if (typeof req.body?.seoTitle === 'string') patch.seoTitle = req.body.seoTitle.trim();
  if (typeof req.body?.seoDescription === 'string') {
    patch.seoDescription = req.body.seoDescription.trim();
  }

  try {
    const updated = await db
      .update(blogPosts)
      .set(patch)
      .where(eq(blogPosts.id, id))
      .returning();
    if (!updated[0]) return res.status(404).json({ error: 'Post not found.' });
    await recordAudit(req, 'UPDATE_BLOG_POST', 'blog_post', String(id), patch);
    return res.json({ post: updated[0] });
  } catch (error) {
    console.error('Update blog post failed:', error);
    return res.status(500).json({ error: 'Unable to update post.' });
  }
});

router.get('/admin/users', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const rows = await db.select().from(users).orderBy(desc(users.createdAt));
    return res.json({ users: rows });
  } catch (error) {
    console.error('Admin users fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load users.' });
  }
});

router.patch('/admin/users/:id', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const id = Number.parseInt(String(req.params.id), 10);
  if (!Number.isFinite(id)) return res.status(400).json({ error: 'Invalid user ID.' });
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (typeof req.body?.isActive === 'boolean') patch.isActive = req.body.isActive;
  if (typeof req.body?.plan === 'string' && ['free', 'pro', 'developer'].includes(req.body.plan)) {
    patch.plan = req.body.plan;
  }
  if (typeof req.body?.role === 'string' && ['user', 'admin'].includes(req.body.role)) {
    patch.role = req.body.role;
  }

  try {
    const updated = await db.update(users).set(patch).where(eq(users.id, id)).returning();
    if (!updated[0]) return res.status(404).json({ error: 'User not found.' });
    await recordAudit(req, 'UPDATE_USER', 'user', String(id), patch);
    return res.json({ user: updated[0] });
  } catch (error) {
    console.error('Admin user update failed:', error);
    return res.status(500).json({ error: 'Unable to update user.' });
  }
});

router.get('/admin/reports', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const [reports, contacts] = await Promise.all([
      db.select().from(abuseReports).orderBy(desc(abuseReports.createdAt)),
      db.select().from(contactMessages).orderBy(desc(contactMessages.createdAt)),
    ]);
    return res.json({ abuseReports: reports, contactMessages: contacts });
  } catch (error) {
    console.error('Admin reports fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load reports.' });
  }
});

router.patch('/admin/reports/:id', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const id = Number.parseInt(String(req.params.id), 10);
  const status = typeof req.body?.status === 'string' ? req.body.status : '';
  if (!Number.isFinite(id) || !['open', 'reviewing', 'resolved'].includes(status)) {
    return res.status(400).json({ error: 'Invalid report ID or status.' });
  }
  try {
    const updated = await db
      .update(abuseReports)
      .set({ status, reviewedByUid: req.dbUser!.uid, updatedAt: new Date() })
      .where(eq(abuseReports.id, id))
      .returning();
    if (!updated[0]) return res.status(404).json({ error: 'Report not found.' });
    await recordAudit(req, 'UPDATE_ABUSE_REPORT', 'abuse_report', String(id), { status });
    return res.json({ report: updated[0] });
  } catch (error) {
    console.error('Admin report update failed:', error);
    return res.status(500).json({ error: 'Unable to update report.' });
  }
});

router.get('/admin/logs', requireAuth, requireAdmin, async (_req, res) => {
  try {
    const [jobs, audits, downloads] = await Promise.all([
      db.select().from(processingJobs).orderBy(desc(processingJobs.createdAt)).limit(50),
      db.select().from(auditLogs).orderBy(desc(auditLogs.createdAt)).limit(50),
      db.select().from(downloadLogs).orderBy(desc(downloadLogs.createdAt)).limit(30),
    ]);
    return res.json({ processingJobs: jobs, auditLogs: audits, downloadLogs: downloads });
  } catch (error) {
    console.error('Admin logs fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load system logs.' });
  }
});

router.get('/admin/settings', requireAuth, requireAdmin, async (_req, res) => {
  try {
    await ensureDatabaseSeeded();
    const rows = await db.select().from(websiteSettings);
    const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    return res.json({ settings: map });
  } catch (error) {
    console.error('Admin settings fetch failed:', error);
    return res.status(500).json({ error: 'Unable to load website settings.' });
  }
});

router.patch('/admin/settings', requireAuth, requireAdmin, async (req: AuthRequest, res) => {
  const entries = req.body?.settings;
  if (!entries || typeof entries !== 'object') {
    return res.status(400).json({ error: 'Settings object required.' });
  }

  const allowedKeys = new Set([
    'site_name',
    'rate_limit_per_min',
    'adsense_publisher_id',
    'ga_measurement_id',
    'gsc_verification_token',
    'maintenance_mode',
    'media_max_upload_mb',
    'media_job_ttl_minutes',
    'media_allowed_domains',
    'integration_enabled_meta',
    'integration_enabled_pinterest',
    'integration_enabled_ga',
    'integration_enabled_gsc',
    'integration_enabled_adsense',
  ]);

  try {
    for (const [key, rawVal] of Object.entries(entries)) {
      if (!allowedKeys.has(key)) continue;
      const value = String(rawVal ?? '').trim().slice(0, 200);
      await db
        .insert(websiteSettings)
        .values({ key, value, updatedAt: new Date() })
        .onConflictDoUpdate({
          target: websiteSettings.key,
          set: { value, updatedAt: new Date() },
        });
    }
    clearRateLimiterCache();
    await recordAudit(req, 'UPDATE_SETTINGS', 'website_settings', 'global', entries);
    return res.json({ saved: true });
  } catch (error) {
    console.error('Admin settings update failed:', error);
    return res.status(500).json({ error: 'Unable to save settings.' });
  }
});

// Unknown /api/v1/* endpoints must return structured JSON, never index.html
router.use((_req, res) => {
  return res.status(404).json({
    ok: false,
    error: {
      code: 'API_NOT_FOUND',
      message: 'The requested API endpoint does not exist.',
    },
  });
});

// API Router error handler ensuring all API errors return JSON
router.use(
  (
    err: unknown,
    _req: express.Request,
    res: express.Response,
    _next: express.NextFunction
  ) => {
    if (res.headersSent) return;
    const message = err instanceof Error ? err.message : 'An unexpected server error occurred.';
    return res.status(500).json({
      ok: false,
      error: {
        code: 'INTERNAL_SERVER_ERROR',
        message,
      },
    });
  }
);

export default router;
