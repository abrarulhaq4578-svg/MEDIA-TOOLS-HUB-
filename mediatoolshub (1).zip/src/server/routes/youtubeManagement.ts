import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import express from 'express';
import multer from 'multer';
import { and, desc, eq, inArray } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  adaptedIdeas,
  channelDna,
  channelProfiles,
  competitorChannelCaches,
  competitorReports,
  dailyPlans,
  savedInspiration,
  scriptProjects,
  users,
  ytmActivityLogs,
  ytmAnalyticsSnapshots,
  ytmAssets,
  ytmBrandDeals,
  ytmCommunityItems,
  ytmDistributionAssets,
  ytmNotifications,
  ytmPlannerProjects,
  ytmPlannerTasks,
  ytmPublishingJobs,
  ytmRevenueEntries,
  ytmTeamInvitations,
  ytmWorkflowProjects,
  ytmWorkspaceCompetitors,
  ytmWorkspaceMembers,
  ytmWorkspaces,
} from '../../db/schema.ts';
import type {
  ScriptPersonalizationSettings,
  ScriptProjectRecord,
  ScriptProjectState,
  ScriptStageNumber,
  YtmChannelAnalyticsReport,
  YtmDailyPlanSuggestion,
  YtmDistributionPlatform,
  YtmInspirationCategory,
  YtmInspirationStatus,
  YtmPlannerProjectRecord,
  YtmPriority,
  YtmProjectLifecycleStatus,
  YtmRevenueCategory,
  YtmStage4Mode,
  YtmTaskStatus,
  YtmWorkflowProjectRecord,
  YtmWorkflowStage1Title,
  YtmWorkflowStage2Topic,
  YtmWorkflowStage4Thumbnail,
  YtmWorkflowStage5Seo,
  YtmWorkflowStageNumber,
} from '../../shared/types.ts';
import {
  getTodayDateKey,
  normalizeYtmRole,
  YTM_DEFAULT_PIPELINE_STATUSES,
  YTM_DEFAULT_PRODUCTION_CHECKLIST,
  YTM_DISTRIBUTION_PLATFORMS,
  YTM_REVENUE_CATEGORIES,
} from '../../shared/ytmHelpers.ts';
import {
  createDefaultScriptSettings,
  createInitialScriptState,
} from '../../shared/scriptStudioHelpers.ts';
import { getGoogleOAuthConfig, getYtmOAuthConfigStatus } from '../config/env.ts';
import { requireAuth, type AuthRequest } from '../middleware/auth.ts';
import ytmOsRoutes from './ytmOsRoutes.ts';
import ytmAgentRoutes from './ytmAgentRoutes.ts';
import {
  collectChannelWithVideos,
  resolveYouTubeChannel,
} from '../services/youtubeCompetitorCollector.ts';
import { ScriptAiError } from '../services/scriptStudioAi.ts';
import {
  aiYtmAdaptInspirationForChannel,
  aiYtmAnalyticsInsights,
  aiYtmDailyRecommendations,
  aiYtmDraftCommentReply,
  aiYtmExpandTopic,
  aiYtmGenerateDistribution,
  aiYtmGenerateSeo,
  aiYtmGenerateThumbnails,
  aiYtmGenerateTitles,
  aiYtmSuggestDailyPlan,
} from '../services/ytmAiService.ts';
import {
  buildInspirationDedupeKey,
  ensureDefaultChannelProfile,
  formatChannelDnaForPrompt,
  getActiveChannelProfileWithDna,
  hydrateAdaptedIdea,
  hydrateChannelProfileWithDna,
  hydrateDailyPlan,
  hydrateSavedInspiration,
  listWorkspaceChannelProfiles,
  normalizeStringList,
  parsePlannerChecklist,
  verifyChannelProfileInWorkspace,
} from '../services/ytmChannelDnaService.ts';
import { consumeOAuthState, signOAuthState } from '../services/ytmCrypto.ts';
import {
  buildValidatedGoogleOAuthAuthorizationUrl,
  buildYtmOAuthConfigValidation,
  disconnectWorkspaceChannel,
  exchangeCodeAndStoreYouTubeChannel,
  executeResumableYouTubeUpload,
  fetchAuthorizedChannelAnalytics,
  fetchAuthorizedChannelVideos,
  fetchAuthorizedComments,
  fetchAuthorizedMonetaryRevenue,
  getWorkspaceConnectedChannel,
  postAuthorizedCommentReply,
  resolveOAuthRedirectUri,
  verifyGoogleOAuthClientWithGoogle,
  YOUTUBE_OAUTH_SCOPES,
  YtmOAuthError,
} from '../services/ytmOAuthService.ts';
import {
  createYtmNotification,
  ensureDefaultWorkspaceForUser,
  hydrateWorkspace,
  listUserWorkspaces,
  recordYtmActivity,
  resolveAuthorizedWorkspace,
  safeJsonParse,
  YtmAccessError,
} from '../services/ytmWorkspaceService.ts';

const router = express.Router();

const uploadDir = path.join(os.tmpdir(), 'mth_ytm_uploads');
const videoUpload = multer({
  dest: uploadDir,
  limits: { fileSize: 256 * 1024 * 1024 },
});
const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 6 * 1024 * 1024 },
});

function okJson(res: express.Response, data: unknown, status = 200) {
  return res.status(status).json({
    ok: true,
    success: true,
    data,
  });
}

function toProxySafeErrorStatus(status: number, code: string): number {
  // Hosting reverse proxies (e.g., Nginx proxy_intercept_errors for 403/502/503/504)
  // replace upstream JSON bodies with 200 text/html pages. Map these to proxy-safe
  // JSON error statuses while preserving the original status in the JSON payload.
  if (status === 503 && (code === 'OAUTH_NOT_CONFIGURED' || code === 'OAUTH_CONFIGURATION_ERROR')) {
    return 422;
  }
  if (status === 502 || status === 503 || status === 504) {
    return 500;
  }
  if (status === 403) {
    return 400;
  }
  return status;
}

function failJson(
  res: express.Response,
  status: number,
  code: string,
  message: string,
  extra: Record<string, unknown> = {}
) {
  const safeStatus = toProxySafeErrorStatus(status, code);
  res.setHeader('Cache-Control', 'no-store');
  return res.status(safeStatus).json({
    ok: false,
    success: false,
    error: {
      code,
      message,
      ...(safeStatus !== status ? { httpStatus: status } : {}),
      ...extra,
    },
  });
}

function handleError(res: express.Response, err: unknown, fallback = 'YouTube Management request failed.') {
  if (err instanceof YtmAccessError) {
    return failJson(res, err.statusCode, err.code, err.message);
  }
  if (err instanceof YtmOAuthError) {
    return failJson(
      res,
      err.statusCode,
      err.code,
      err.message,
      err.diagnostics ? { diagnostics: err.diagnostics } : {}
    );
  }
  if (err instanceof ScriptAiError) {
    return failJson(res, err.statusCode, err.code, err.message);
  }
  console.error('[YTM]', fallback, err);
  return failJson(
    res,
    500,
    'YTM_SERVER_ERROR',
    err instanceof Error ? err.message : fallback
  );
}

function getWorkspaceKeyFromReq(req: express.Request): string | null {
  const q = typeof req.query.workspaceKey === 'string' ? req.query.workspaceKey.trim() : '';
  const b = typeof req.body?.workspaceKey === 'string' ? req.body.workspaceKey.trim() : '';
  const h = typeof req.header('x-ytm-workspace') === 'string' ? req.header('x-ytm-workspace')!.trim() : '';
  return q || b || h || null;
}

function defaultStage1(): YtmWorkflowStage1Title {
  return { seedIdea: '', options: [], selectedTitle: '', notes: '' };
}
function defaultStage2(): YtmWorkflowStage2Topic {
  return {
    centralTopic: '',
    targetAudience: '',
    coreProblem: '',
    desiredOutcome: '',
    valueAngle: '',
    supportingPoints: [],
    notes: '',
  };
}
function defaultStage4(): YtmWorkflowStage4Thumbnail {
  return {
    concepts: [],
    selectedConceptId: null,
    selectedTextOverlay: '',
    customImagePrompt: '',
    uploadedThumbnailAssetId: null,
    uploadedThumbnailUrl: null,
    notes: '',
  };
}
function defaultStage5(): YtmWorkflowStage5Seo {
  return {
    description: '',
    keywords: [],
    tags: [],
    hashtags: [],
    chapters: [],
    pinnedComment: '',
    playlistRecommendation: '',
    uploadChecklist: [],
  };
}

function hydratePlannerProject(
  p: typeof ytmPlannerProjects.$inferSelect
): YtmPlannerProjectRecord {
  return {
    id: p.id,
    workspaceId: p.workspaceId,
    assigneeUserId: p.assigneeUserId ?? null,
    title: p.title,
    topic: p.topic || '',
    description: p.description || '',
    notes: p.notes || '',
    targetAudience: p.targetAudience || '',
    category: p.category || 'General',
    status: p.status || 'Idea',
    priority: (p.priority || 'medium') as YtmPriority,
    plannedDate: p.plannedDate ?? null,
    deadline: p.deadline ?? null,
    recurrenceRule: (p.recurrenceRule || 'none') as 'none' | 'weekly' | 'biweekly' | 'monthly',
    workflowProjectId: p.workflowProjectId ?? null,
    channelProfileId: p.channelProfileId ?? null,
    savedInspirationId: p.savedInspirationId ?? null,
    adaptedIdeaId: p.adaptedIdeaId ?? null,
    inspirationSourceLabel: p.inspirationSourceLabel || '',
    inspirationSourceUrl: p.inspirationSourceUrl || '',
    adaptedAngle: p.adaptedAngle || '',
    productionChecklist: parsePlannerChecklist(p.productionChecklistJson),
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  };
}

function hydrateLinkedScriptProject(
  row: typeof scriptProjects.$inferSelect
): ScriptProjectRecord {
  const defaultSettings = createDefaultScriptSettings();
  const defaultState = createInitialScriptState();
  const validStatuses = new Set<YtmProjectLifecycleStatus>([
    'NOT STARTED',
    'IN PROGRESS',
    'WAITING FOR APPROVAL',
    'COMPLETED',
    'PUBLISHED',
  ]);
  const derivedStatus: YtmProjectLifecycleStatus = validStatuses.has(
    row.projectStatus as YtmProjectLifecycleStatus
  )
    ? (row.projectStatus as YtmProjectLifecycleStatus)
    : row.highestApprovedStage >= 7
      ? 'COMPLETED'
      : row.highestApprovedStage > 0
        ? 'IN PROGRESS'
        : 'NOT STARTED';

  return {
    id: row.id,
    projectKey: row.projectKey,
    ytmWorkflowProjectId: row.ytmWorkflowProjectId ?? null,
    title: row.title,
    currentStage: Math.min(7, Math.max(1, row.currentStage)) as ScriptStageNumber,
    highestApprovedStage: Math.min(7, Math.max(0, row.highestApprovedStage)),
    modelName:
      row.modelName === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen',
    projectStatus: derivedStatus,
    finalApprovedScript: row.finalApprovedScript ?? null,
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
    approvalTimestamps: safeJsonParse<Record<string, string>>(row.approvalTimestampsJson, {}),
    settings: {
      ...defaultSettings,
      ...safeJsonParse<Partial<ScriptPersonalizationSettings>>(row.settingsJson, {}),
    },
    state: {
      ...defaultState,
      ...safeJsonParse<Partial<ScriptProjectState>>(row.stateJson, {}),
    },
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function hydrateWorkflow(row: typeof ytmWorkflowProjects.$inferSelect): YtmWorkflowProjectRecord {
  const s1 = { ...defaultStage1(), ...safeJsonParse<Partial<YtmWorkflowStage1Title>>(row.stage1TitleJson, {}) };
  const s2 = { ...defaultStage2(), ...safeJsonParse<Partial<YtmWorkflowStage2Topic>>(row.stage2TopicJson, {}) };
  const s4 = { ...defaultStage4(), ...safeJsonParse<Partial<YtmWorkflowStage4Thumbnail>>(row.stage4ThumbnailJson, {}) };
  const s5 = { ...defaultStage5(), ...safeJsonParse<Partial<YtmWorkflowStage5Seo>>(row.stage5SeoJson, {}) };
  const approvals = safeJsonParse<Record<string, boolean>>(row.approvalsJson, {});
  const stageWarnings = safeJsonParse<Record<string, string>>(row.stageWarningsJson, {});
  const approvalTimestamps = safeJsonParse<Record<string, string>>(row.approvalTimestampsJson, {});

  const validStatuses = new Set<YtmProjectLifecycleStatus>([
    'NOT STARTED',
    'IN PROGRESS',
    'WAITING FOR APPROVAL',
    'COMPLETED',
    'PUBLISHED',
  ]);
  const allApproved =
    Boolean(approvals.stage1) &&
    Boolean(approvals.stage2) &&
    Boolean(approvals.stage3) &&
    Boolean(approvals.stage4) &&
    Boolean(approvals.stage5) &&
    Boolean(approvals.stage6);
  const anyStarted =
    Boolean(approvals.stage1) ||
    Boolean(approvals.stage2) ||
    Boolean(approvals.stage3) ||
    Boolean(approvals.stage4) ||
    Boolean(approvals.stage5) ||
    Boolean(row.scriptProjectKey) ||
    row.currentStage > 1;

  const projectStatus: YtmProjectLifecycleStatus = validStatuses.has(
    row.projectStatus as YtmProjectLifecycleStatus
  )
    ? (row.projectStatus as YtmProjectLifecycleStatus)
    : row.youtubeVideoId
      ? 'PUBLISHED'
      : allApproved
        ? 'COMPLETED'
        : anyStarted
          ? 'IN PROGRESS'
          : 'NOT STARTED';

  const stage4Mode: YtmStage4Mode =
    row.stage4Mode === 'community_post' ? 'community_post' : 'thumbnail';

  return {
    id: row.id,
    workspaceId: row.workspaceId,
    plannerProjectId: row.plannerProjectId ?? null,
    assigneeUserId: row.assigneeUserId ?? null,
    title: row.title,
    currentStage: Math.min(6, Math.max(1, row.currentStage)) as YtmWorkflowStageNumber,
    projectStatus,
    stage4Mode,
    stage1Title: s1,
    stage2Topic: s2,
    scriptProjectKey: row.scriptProjectKey ?? null,
    finalApprovedScript: row.finalApprovedScript ?? null,
    stage4Thumbnail: s4,
    stage5Seo: s5,
    approvals,
    approvalTimestamps,
    stageWarnings,
    reviewStatus: (['draft', 'in_review', 'changes_requested', 'approved'].includes(row.reviewStatus)
      ? row.reviewStatus
      : 'draft') as YtmWorkflowProjectRecord['reviewStatus'],
    reviewNotes: row.reviewNotes || '',
    youtubeVideoId: row.youtubeVideoId ?? null,
    youtubeVideoUrl: row.youtubeVideoUrl ?? null,
    channelProfileId: row.channelProfileId ?? null,
    savedInspirationId: row.savedInspirationId ?? null,
    adaptedIdeaId: row.adaptedIdeaId ?? null,
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

// ==============================================================================
// GOOGLE OAUTH CALLBACK (Authenticated via HMAC-signed CSRF state token)
// ==============================================================================
async function handleOAuthCallback(req: express.Request, res: express.Response) {
  const errParam = typeof req.query.error === 'string' ? req.query.error : '';
  const code = typeof req.query.code === 'string' ? req.query.code : '';
  const stateRaw = typeof req.query.state === 'string' ? req.query.state : '';

  const escapeHtml = (input: string) =>
    input
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');

  const renderPopupResult = (ok: boolean, payload: Record<string, unknown>) => {
    const safeJson = JSON.stringify({
      type: ok ? 'YTM_OAUTH_SUCCESS' : 'YTM_OAUTH_ERROR',
      ...payload,
    });
    const fallbackPath = `/youtube-management/others?oauth=${ok ? 'connected' : 'error'}`;
    const heading = ok ? 'YouTube Channel Connected' : 'YouTube Authorization Notice';
    const message = ok
      ? 'Authorization completed. Returning to MediaToolsHub YouTube Management...'
      : String(payload.message || 'Authorization cancelled.');
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    return res.send(`<!DOCTYPE html>
<html><head><title>YouTube Authorization</title></head>
<body style="font-family:system-ui,sans-serif;padding:24px;text-align:center;">
  <h3>${escapeHtml(heading)}</h3>
  <p>${escapeHtml(message)}</p>
  <p style="margin-top:16px;"><a href="${fallbackPath}" style="color:#2563eb;font-weight:600;">Return to YouTube Management</a></p>
  <script>
    try {
      if (window.opener && !window.opener.closed) {
        window.opener.postMessage(${safeJson}, '*');
        setTimeout(function(){ window.close(); }, 600);
      } else {
        setTimeout(function(){ window.location.replace(${JSON.stringify(fallbackPath)}); }, 900);
      }
    } catch (e) {
      setTimeout(function(){ window.location.replace(${JSON.stringify(fallbackPath)}); }, 900);
    }
  </script>
</body></html>`);
  };

  if (errParam) {
    return renderPopupResult(false, { code: 'OAUTH_DENIED', message: `Google OAuth denied: ${errParam}` });
  }
  if (!code || !stateRaw) {
    return renderPopupResult(false, { code: 'OAUTH_MISSING_PARAMS', message: 'Missing code or state parameter.' });
  }

  const state = consumeOAuthState(stateRaw);
  if (!state) {
    return renderPopupResult(false, {
      code: 'OAUTH_INVALID_STATE',
      message: 'Invalid, expired, or already-used OAuth security state. Please restart channel connection.',
    });
  }

  try {
    const channel = await exchangeCodeAndStoreYouTubeChannel({
      code,
      redirectUri: state.redirectUri,
      workspaceId: state.workspaceId,
      userId: state.userId,
    });
    await recordYtmActivity({
      workspaceId: state.workspaceId,
      actorUserId: state.userId,
      action: 'CONNECT_YOUTUBE_CHANNEL',
      resourceType: 'connected_account',
      resourceId: channel.channelId,
      details: { channelTitle: channel.channelTitle },
    });
    return renderPopupResult(true, { channel });
  } catch (err: unknown) {
    return renderPopupResult(false, {
      code: 'OAUTH_CALLBACK_FAILED',
      message: err instanceof Error ? err.message : 'Unable to complete YouTube OAuth connection.',
    });
  }
}

router.get('/auth/google/callback', handleOAuthCallback);
router.get('/auth/google/callback/', handleOAuthCallback);

// All remaining YTM Creator OS routes require authenticated MediaToolsHub account
router.use(requireAuth);

// Mount OS modules: Content Planner AI Strategy Assistant, Workflow Stage 4 Community Posts, Creator Performance Coach
router.use(ytmOsRoutes);
// Mount YouTube OS Central AI Agent routes (/api/v1/ytm/agent/*)
router.use(ytmAgentRoutes);

// ==============================================================================
// WORKSPACES & INVITATIONS
// ==============================================================================
router.get('/workspaces', async (req: AuthRequest, res) => {
  try {
    const user = req.dbUser!;
    await ensureDefaultWorkspaceForUser(user);
    const workspaces = await listUserWorkspaces(user.id);
    const pendingInvites = await db
      .select({
        invite: ytmTeamInvitations,
        workspaceName: ytmWorkspaces.name,
      })
      .from(ytmTeamInvitations)
      .innerJoin(ytmWorkspaces, eq(ytmTeamInvitations.workspaceId, ytmWorkspaces.id))
      .where(
        and(
          eq(ytmTeamInvitations.email, user.email.toLowerCase()),
          eq(ytmTeamInvitations.status, 'pending')
        )
      );

    return okJson(res, {
      workspaces,
      pendingInvites: pendingInvites.map((p) => ({
        token: p.invite.token,
        role: normalizeYtmRole(p.invite.role),
        workspaceName: p.workspaceName,
        expiresAt: p.invite.expiresAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Failed to load workspaces.');
  }
});

router.post('/workspaces', async (req: AuthRequest, res) => {
  const name = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
  if (!name || name.length > 120) {
    return failJson(res, 400, 'INVALID_REQUEST', 'Workspace name must be between 1 and 120 characters.');
  }
  try {
    const workspaceKey = `ytm_ws_${crypto.randomBytes(8).toString('hex')}`;
    const inserted = await db
      .insert(ytmWorkspaces)
      .values({
        workspaceKey,
        ownerUserId: req.dbUser!.id,
        name,
        description: typeof req.body?.description === 'string' ? req.body.description.trim().slice(0, 400) : '',
        channelGoal: typeof req.body?.channelGoal === 'string' ? req.body.channelGoal.trim().slice(0, 300) : '',
        customStatusesJson: JSON.stringify(YTM_DEFAULT_PIPELINE_STATUSES),
      })
      .returning();

    await db.insert(ytmWorkspaceMembers).values({
      workspaceId: inserted[0].id,
      userId: req.dbUser!.id,
      role: 'owner',
      invitedByUserId: req.dbUser!.id,
      status: 'active',
    });

    await recordYtmActivity({
      workspaceId: inserted[0].id,
      actorUserId: req.dbUser!.id,
      actorEmail: req.dbUser!.email,
      action: 'CREATE_WORKSPACE',
      resourceType: 'workspace',
      resourceId: workspaceKey,
    });

    return okJson(res, { workspace: hydrateWorkspace(inserted[0], 'owner') }, 201);
  } catch (err) {
    return handleError(res, err, 'Unable to create workspace.');
  }
});

router.patch('/workspaces/:workspaceKey', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: String(req.params.workspaceKey),
      requiredPermission: 'workspace:manage',
    });

    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof req.body?.name === 'string' && req.body.name.trim()) {
      patch.name = req.body.name.trim().slice(0, 120);
    }
    if (typeof req.body?.description === 'string') {
      patch.description = req.body.description.trim().slice(0, 400);
    }
    if (typeof req.body?.channelGoal === 'string') {
      patch.channelGoal = req.body.channelGoal.trim().slice(0, 300);
    }
    if (Array.isArray(req.body?.customStatuses)) {
      const cleaned = req.body.customStatuses
        .filter((s: unknown): s is string => typeof s === 'string' && s.trim().length > 0)
        .map((s: string) => s.trim().slice(0, 40))
        .slice(0, 12);
      if (cleaned.length > 0) {
        patch.customStatusesJson = JSON.stringify(cleaned);
      }
    }

    const updated = await db
      .update(ytmWorkspaces)
      .set(patch)
      .where(eq(ytmWorkspaces.id, workspace.id))
      .returning();

    return okJson(res, { workspace: hydrateWorkspace(updated[0], workspace.myRole) });
  } catch (err) {
    return handleError(res, err, 'Failed to update workspace settings.');
  }
});

router.post('/workspaces/invitations/:token/accept', async (req: AuthRequest, res) => {
  try {
    const token = String(req.params.token).trim();
    const invRows = await db
      .select()
      .from(ytmTeamInvitations)
      .where(eq(ytmTeamInvitations.token, token))
      .limit(1);

    const invite = invRows[0];
    if (!invite || invite.status !== 'pending' || invite.expiresAt.getTime() < Date.now()) {
      return failJson(res, 404, 'INVITE_INVALID', 'Invitation token is invalid or expired.');
    }

    if (invite.email.toLowerCase() !== req.dbUser!.email.toLowerCase()) {
      return failJson(
        res,
        403,
        'INVITE_EMAIL_MISMATCH',
        'This invitation was issued for a different Google account email.'
      );
    }

    const existing = await db
      .select()
      .from(ytmWorkspaceMembers)
      .where(
        and(
          eq(ytmWorkspaceMembers.workspaceId, invite.workspaceId),
          eq(ytmWorkspaceMembers.userId, req.dbUser!.id)
        )
      )
      .limit(1);

    if (existing[0]) {
      await db
        .update(ytmWorkspaceMembers)
        .set({ role: invite.role, status: 'active', updatedAt: new Date() })
        .where(eq(ytmWorkspaceMembers.id, existing[0].id));
    } else {
      await db.insert(ytmWorkspaceMembers).values({
        workspaceId: invite.workspaceId,
        userId: req.dbUser!.id,
        role: invite.role,
        invitedByUserId: invite.invitedByUserId,
        status: 'active',
      });
    }

    await db
      .update(ytmTeamInvitations)
      .set({ status: 'accepted', acceptedAt: new Date() })
      .where(eq(ytmTeamInvitations.id, invite.id));

    return okJson(res, { accepted: true, workspaceId: invite.workspaceId });
  } catch (err) {
    return handleError(res, err, 'Failed to accept invitation.');
  }
});

// ==============================================================================
// 1. DASHBOARD OVERVIEW & AI DAILY RECOMMENDATIONS
// ==============================================================================
router.get('/dashboard', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const requestedChannelId = req.query.channelProfileId
      ? Number.parseInt(String(req.query.channelProfileId), 10)
      : null;

    const todayKey = getTodayDateKey();
    const [
      connectedChannel,
      channelProfileList,
      plannerProjects,
      plannerTasks,
      workflowRows,
      revenueRows,
      dealRows,
      savedInspRows,
      dailyPlanRows,
    ] = await Promise.all([
      getWorkspaceConnectedChannel(workspace.id),
      listWorkspaceChannelProfiles(workspace, req.dbUser!.id),
      db
        .select()
        .from(ytmPlannerProjects)
        .where(eq(ytmPlannerProjects.workspaceId, workspace.id))
        .orderBy(desc(ytmPlannerProjects.updatedAt)),
      db
        .select()
        .from(ytmPlannerTasks)
        .where(eq(ytmPlannerTasks.workspaceId, workspace.id))
        .orderBy(desc(ytmPlannerTasks.updatedAt)),
      db
        .select()
        .from(ytmWorkflowProjects)
        .where(eq(ytmWorkflowProjects.workspaceId, workspace.id))
        .orderBy(desc(ytmWorkflowProjects.updatedAt)),
      db.select().from(ytmRevenueEntries).where(eq(ytmRevenueEntries.workspaceId, workspace.id)),
      db.select().from(ytmBrandDeals).where(eq(ytmBrandDeals.workspaceId, workspace.id)),
      db
        .select()
        .from(savedInspiration)
        .where(
          and(
            eq(savedInspiration.workspaceId, workspace.id),
            eq(savedInspiration.status, 'saved')
          )
        )
        .orderBy(desc(savedInspiration.savedAt))
        .limit(10),
      db
        .select()
        .from(dailyPlans)
        .where(
          and(
            eq(dailyPlans.workspaceId, workspace.id),
            eq(dailyPlans.planDate, todayKey)
          )
        )
        .orderBy(desc(dailyPlans.updatedAt))
        .limit(1),
    ]);

    const activeChannelProfile =
      (Number.isFinite(requestedChannelId)
        ? channelProfileList.find((c) => c.id === requestedChannelId)
        : null) ||
      channelProfileList.find((c) => c.isDefault) ||
      channelProfileList[0] ||
      null;

    const channelNameMap = new Map(channelProfileList.map((c) => [c.id, c.channelName]));
    const mappedProjects = plannerProjects.map(hydratePlannerProject);
    const mappedTasks = plannerTasks.map((t) => ({
      ...t,
      priority: (t.priority || 'medium') as YtmPriority,
      status: (t.status || 'Not Started') as YtmTaskStatus,
      createdAt: t.createdAt.toISOString(),
      updatedAt: t.updatedAt.toISOString(),
    }));

    const todaysPlan = mappedTasks.filter(
      (t) => t.scheduledAt?.slice(0, 10) === todayKey || t.deadline?.slice(0, 10) === todayKey
    );
    const todaysScheduledProjects = mappedProjects.filter(
      (p) => p.plannedDate?.slice(0, 10) === todayKey || p.deadline?.slice(0, 10) === todayKey
    );
    const inProgressVideos = mappedProjects
      .filter((p) =>
        ['Selected', 'Researching', 'Scripting', 'Production', 'Ready to Publish', 'In Progress', 'Filming', 'Editing'].includes(
          p.status
        )
      )
      .slice(0, 12);
    const completedTasks = mappedTasks.filter((t) => t.status === 'Completed').slice(0, 12);
    const overdueTasks = mappedTasks.filter(
      (t) =>
        t.status !== 'Completed' &&
        (t.status === 'Overdue' || (t.deadline && t.deadline.slice(0, 10) < todayKey))
    );
    const upcomingDeadlines = mappedTasks
      .filter((t) => t.status !== 'Completed' && t.deadline && t.deadline.slice(0, 10) >= todayKey)
      .sort((a, b) => (a.deadline || '').localeCompare(b.deadline || ''))
      .slice(0, 8);

    const weeklyCalendar = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setUTCDate(d.getUTCDate() + i);
      const dk = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
      return {
        dateKey: dk,
        label,
        projects: mappedProjects.filter((p) => p.plannedDate?.slice(0, 10) === dk),
        tasks: mappedTasks.filter((t) => t.scheduledAt?.slice(0, 10) === dk || t.deadline?.slice(0, 10) === dk),
      };
    });

    const STAGE_LABELS: Record<number, string> = {
      1: 'Stage 1 · Title',
      2: 'Stage 2 · Topic',
      3: 'Stage 3 · Script',
      4: 'Stage 4 · Thumbnail',
      5: 'Stage 5 · SEO',
      6: 'Stage 6 · Publish',
    };

    const inferPlatform = (titleText: string, hintText?: string | null): string => {
      const combined = `${titleText} ${hintText || ''}`.toLowerCase();
      if (/\binstagram\b|\breel\b|\bcarousel\b/.test(combined)) return 'Instagram';
      if (/\btiktok\b/.test(combined)) return 'TikTok';
      if (/\byoutube shorts\b|\bshorts\b/.test(combined)) return 'YouTube Shorts';
      if (/\blinkedin\b/.test(combined)) return 'LinkedIn';
      if (/\bfacebook\b/.test(combined)) return 'Facebook';
      if (/\bpinterest\b/.test(combined)) return 'Pinterest';
      if (/\btwitter\b|\bx thread\b/.test(combined)) return 'X / Twitter';
      if (/\bebook\b|\be-book\b/.test(combined)) return 'Ebook';
      if (/\bnewsletter\b/.test(combined)) return 'Newsletter';
      if (/\bpodcast\b/.test(combined)) return 'Podcast';
      if (/\bblog\b|\barticle\b/.test(combined)) return 'Blog';
      return 'YouTube';
    };

    const extractTimeFromIso = (iso: string | null | undefined): string | null => {
      if (!iso) return null;
      const match = iso.match(/T(\d{2}:\d{2})/);
      if (!match || match[1] === '00:00') return null;
      return match[1];
    };

    const workflowStagesById: Record<
      number,
      { currentStage: number; stageLabel: string; reviewStatus: string }
    > = {};
    const activeWorkflowLinkedProjectIds = new Set<number>();
    let activeUnpublishedWorkflows = 0;

    for (const w of workflowRows) {
      workflowStagesById[w.id] = {
        currentStage: w.currentStage,
        stageLabel: STAGE_LABELS[w.currentStage] || `Stage ${w.currentStage}`,
        reviewStatus: w.reviewStatus || 'draft',
      };
      if (!w.youtubeVideoId) {
        activeUnpublishedWorkflows += 1;
        if (w.plannerProjectId) {
          activeWorkflowLinkedProjectIds.add(w.plannerProjectId);
        }
      }
    }

    const unlinkedProjectsInProduction = mappedProjects.filter(
      (p) =>
        p.status !== 'Published' &&
        !activeWorkflowLinkedProjectIds.has(p.id) &&
        !(p.workflowProjectId && workflowStagesById[p.workflowProjectId])
    ).length;

    const videosInProductionCount = activeUnpublishedWorkflows + unlinkedProjectsInProduction;

    const projectById = new Map(mappedProjects.map((p) => [p.id, p]));
    const upcomingCombined: Array<{
      id: string;
      itemType: 'project' | 'task';
      title: string;
      platform: string;
      scheduledDate: string;
      scheduledTime: string | null;
      status: string;
      priority: YtmPriority;
      plannerProjectId: number | null;
      workflowProjectId: number | null;
      project?: YtmPlannerProjectRecord;
    }> = [];

    for (const p of mappedProjects) {
      const rawDate = p.plannedDate || p.deadline;
      const dateKey = rawDate?.slice(0, 10);
      if (!dateKey || dateKey <= todayKey) continue;
      if (p.status === 'Published') continue;
      const wfStage = p.workflowProjectId ? workflowStagesById[p.workflowProjectId] : undefined;
      upcomingCombined.push({
        id: `project-${p.id}`,
        itemType: 'project',
        title: p.title,
        platform: inferPlatform(p.title, p.category),
        scheduledDate: dateKey,
        scheduledTime: extractTimeFromIso(rawDate),
        status: wfStage ? wfStage.stageLabel : p.status,
        priority: p.priority,
        plannerProjectId: p.id,
        workflowProjectId: p.workflowProjectId,
        project: p,
      });
    }

    for (const t of mappedTasks) {
      const rawDate = t.scheduledAt || t.deadline;
      const dateKey = rawDate?.slice(0, 10);
      if (!dateKey || dateKey <= todayKey) continue;
      if (t.status === 'Completed') continue;
      const linkedProj = t.plannerProjectId ? projectById.get(t.plannerProjectId) : undefined;
      upcomingCombined.push({
        id: `task-${t.id}`,
        itemType: 'task',
        title: t.taskName,
        platform: inferPlatform(t.taskName, linkedProj?.category || t.workspaceSection),
        scheduledDate: dateKey,
        scheduledTime: extractTimeFromIso(rawDate),
        status: t.status,
        priority: t.priority,
        plannerProjectId: t.plannerProjectId ?? null,
        workflowProjectId: linkedProj?.workflowProjectId ?? null,
        project: linkedProj,
      });
    }

    upcomingCombined.sort((a, b) => a.scheduledDate.localeCompare(b.scheduledDate));
    const upcomingContent = upcomingCombined.slice(0, 5);

    const totalReceivedCents = revenueRows
      .filter((r) => r.paymentStatus === 'received')
      .reduce((acc, r) => acc + r.amountCents, 0);
    const totalPendingCents = revenueRows
      .filter((r) => r.paymentStatus === 'pending')
      .reduce((acc, r) => acc + r.amountCents, 0);

    return okJson(res, {
      workspace,
      connectedChannel,
      activeChannelProfile,
      oauthConfigured: getYtmOAuthConfigStatus().configured,
      todayDateKey: todayKey,
      todaysPlan,
      todaysScheduledProjects,
      upcomingContent,
      videosInProductionCount,
      workflowStagesById,
      inProgressVideos,
      savedInspirationAwaitingReview: savedInspRows.map((row) =>
        hydrateSavedInspiration(row, { channelNameMap })
      ),
      completedTasks,
      dailyPlan: dailyPlanRows[0] ? hydrateDailyPlan(dailyPlanRows[0]) : null,
      upcomingDeadlines,
      overdueTasks,
      videosInProgressCount: mappedProjects.filter(
        (p) => !['Published', 'Scheduled'].includes(p.status)
      ).length,
      scheduledVideosCount: mappedProjects.filter((p) => Boolean(p.plannedDate) && p.status !== 'Published').length,
      recentlyPublished: workflowRows
        .filter((w) => w.youtubeVideoId)
        .slice(0, 5)
        .map((w) => ({
          id: w.id,
          title: w.title,
          youtubeVideoId: w.youtubeVideoId,
          youtubeVideoUrl: w.youtubeVideoUrl,
          updatedAt: w.updatedAt.toISOString(),
        })),
      weeklyCalendar,
      revenueSummary: {
        totalReceivedCents,
        totalPendingCents,
        activeDealsCount: dealRows.filter((d) => !['cancelled', 'delivered'].includes(d.contractStatus)).length,
      },
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load dashboard overview.');
  }
});

router.post('/dashboard/recommendations', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const todayKey = getTodayDateKey();
    const channelProfileId =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;
    const [channel, activeChannelProfile, tasks, projects] = await Promise.all([
      getWorkspaceConnectedChannel(workspace.id),
      getActiveChannelProfileWithDna(workspace, req.dbUser!.id, channelProfileId),
      db.select().from(ytmPlannerTasks).where(eq(ytmPlannerTasks.workspaceId, workspace.id)),
      db.select().from(ytmPlannerProjects).where(eq(ytmPlannerProjects.workspaceId, workspace.id)),
    ]);

    const mappedTasks = tasks.map((t) => ({
      ...t,
      priority: t.priority as YtmPriority,
      status: t.status as YtmTaskStatus,
      createdAt: t.createdAt.toISOString(),
      updatedAt: t.updatedAt.toISOString(),
    }));

    const mappedProjects = projects.map(hydratePlannerProject);

    const recommendations = await aiYtmDailyRecommendations({
      channelTitle: channel?.channelTitle || activeChannelProfile?.channelName || null,
      channelGoal: workspace.channelGoal,
      channelDnaPrompt: formatChannelDnaForPrompt(activeChannelProfile),
      todaysTasks: mappedTasks.filter((t) => t.scheduledAt?.slice(0, 10) === todayKey),
      overdueTasks: mappedTasks.filter(
        (t) => t.status !== 'Completed' && t.deadline && t.deadline.slice(0, 10) < todayKey
      ),
      activeProjects: mappedProjects,
    });

    return okJson(res, { recommendations });
  } catch (err) {
    return handleError(res, err, 'Failed to generate daily recommendations.');
  }
});

router.post('/dashboard/daily-plan', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const todayKey =
      typeof req.body?.planDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.planDate)
        ? req.body.planDate
        : getTodayDateKey();
    const channelProfileId =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;

    const [activeProfile, tasks, projects, awaitingInsp] = await Promise.all([
      getActiveChannelProfileWithDna(workspace, req.dbUser!.id, channelProfileId),
      db.select().from(ytmPlannerTasks).where(eq(ytmPlannerTasks.workspaceId, workspace.id)),
      db.select().from(ytmPlannerProjects).where(eq(ytmPlannerProjects.workspaceId, workspace.id)),
      db
        .select()
        .from(savedInspiration)
        .where(and(eq(savedInspiration.workspaceId, workspace.id), eq(savedInspiration.status, 'saved')))
        .orderBy(desc(savedInspiration.savedAt))
        .limit(8),
    ]);

    const mappedProjects = projects.map(hydratePlannerProject);
    const todaysTopics = mappedProjects.filter(
      (p) => p.plannedDate?.slice(0, 10) === todayKey || p.deadline?.slice(0, 10) === todayKey
    );
    const tasksDueToday = tasks.filter(
      (t) => t.scheduledAt?.slice(0, 10) === todayKey || t.deadline?.slice(0, 10) === todayKey
    );
    const overdueTasks = tasks.filter(
      (t) =>
        t.status !== 'Completed' &&
        (t.status === 'Overdue' || (t.deadline && t.deadline.slice(0, 10) < todayKey))
    );
    const inProgressVideos = mappedProjects.filter((p) => !['Published', 'Idea'].includes(p.status));

    const generated = await aiYtmSuggestDailyPlan({
      todayDateKey: todayKey,
      channelName: activeProfile.channelName,
      channelDnaPrompt: formatChannelDnaForPrompt(activeProfile),
      todaysTopics: todaysTopics.map((p) => ({
        title: p.title,
        status: p.status,
        priority: p.priority,
      })),
      tasksDueToday: tasksDueToday.map((t) => ({
        taskName: t.taskName,
        status: t.status,
        priority: t.priority,
      })),
      overdueTasks: overdueTasks.map((t) => ({
        taskName: t.taskName,
        deadline: t.deadline ?? null,
      })),
      inProgressVideos: inProgressVideos.map((p) => ({
        title: p.title,
        status: p.status,
        plannedDate: p.plannedDate ?? null,
      })),
      savedInspirationAwaitingReview: awaitingInsp.map((i) => ({
        originalVideoTitle: i.originalVideoTitle,
        inspirationCategory: i.inspirationCategory,
        competitorChannelName: i.competitorChannelName,
      })),
    });

    const existing = await db
      .select()
      .from(dailyPlans)
      .where(and(eq(dailyPlans.workspaceId, workspace.id), eq(dailyPlans.planDate, todayKey)))
      .limit(1);

    let savedRow: typeof dailyPlans.$inferSelect;
    if (existing[0]) {
      const updated = await db
        .update(dailyPlans)
        .set({
          channelProfileId: activeProfile.id,
          summary: generated.summary,
          suggestedItemsJson: JSON.stringify(generated.suggestedItems),
          updatedAt: new Date(),
        })
        .where(eq(dailyPlans.id, existing[0].id))
        .returning();
      savedRow = updated[0];
    } else {
      const inserted = await db
        .insert(dailyPlans)
        .values({
          userId: req.dbUser!.id,
          workspaceId: workspace.id,
          channelProfileId: activeProfile.id,
          planDate: todayKey,
          summary: generated.summary,
          suggestedItemsJson: JSON.stringify(generated.suggestedItems),
          userNotes: '',
        })
        .returning();
      savedRow = inserted[0];
    }

    return okJson(res, { dailyPlan: hydrateDailyPlan(savedRow) });
  } catch (err) {
    return handleError(res, err, 'Failed to generate daily work plan.');
  }
});

router.patch('/dashboard/daily-plan/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const planId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(planId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid daily plan ID.');
    }

    const rows = await db
      .select()
      .from(dailyPlans)
      .where(and(eq(dailyPlans.id, planId), eq(dailyPlans.workspaceId, workspace.id)))
      .limit(1);

    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Daily plan not found.');
    }

    const current = hydrateDailyPlan(rows[0]);
    let nextItems = [...current.suggestedItems];
    let createdTask: (typeof ytmPlannerTasks.$inferSelect) | null = null;

    if (typeof req.body?.itemId === 'string' && req.body?.action) {
      const itemId = req.body.itemId;
      const action = String(req.body.action);
      const idx = nextItems.findIndex((item) => item.id === itemId);
      if (idx === -1) {
        return failJson(res, 404, 'NOT_FOUND', 'Suggested plan item not found.');
      }
      const target = { ...nextItems[idx] };
      if (action === 'dismiss') {
        target.status = 'dismissed';
      } else if (action === 'edit') {
        if (typeof req.body?.title === 'string' && req.body.title.trim()) {
          target.title = req.body.title.trim().slice(0, 200);
        }
        if (typeof req.body?.suggestedAction === 'string') {
          target.suggestedAction = req.body.suggestedAction.trim().slice(0, 300);
        }
        if (['low', 'medium', 'high', 'urgent'].includes(req.body?.suggestedPriority)) {
          target.suggestedPriority = req.body.suggestedPriority;
        }
      } else if (action === 'accept') {
        if (typeof req.body?.title === 'string' && req.body.title.trim()) {
          target.title = req.body.title.trim().slice(0, 200);
        }
        if (target.status !== 'accepted' || !target.linkedTaskId) {
          const insertedTask = await db
            .insert(ytmPlannerTasks)
            .values({
              workspaceId: workspace.id,
              createdByUserId: req.dbUser!.id,
              taskName: target.title.slice(0, 240),
              workspaceSection: target.suggestedWorkspaceSection || 'planner',
              scheduledAt: current.planDate,
              deadline: current.planDate,
              priority: target.suggestedPriority || 'medium',
              status: 'Not Started',
              aiSuggested: true,
            })
            .returning();
          createdTask = insertedTask[0];
          target.linkedTaskId = insertedTask[0].id;
        }
        target.status = 'accepted';
      }
      nextItems[idx] = target;
    } else if (Array.isArray(req.body?.suggestedItems)) {
      nextItems = req.body.suggestedItems as YtmDailyPlanSuggestion[];
    }

    const patch: Record<string, unknown> = {
      suggestedItemsJson: JSON.stringify(nextItems),
      updatedAt: new Date(),
    };
    if (typeof req.body?.userNotes === 'string') {
      patch.userNotes = req.body.userNotes.slice(0, 2000);
    }

    const updated = await db
      .update(dailyPlans)
      .set(patch)
      .where(eq(dailyPlans.id, planId))
      .returning();

    return okJson(res, {
      dailyPlan: hydrateDailyPlan(updated[0]),
      createdTask: createdTask
        ? {
            ...createdTask,
            createdAt: createdTask.createdAt.toISOString(),
            updatedAt: createdTask.updatedAt.toISOString(),
          }
        : null,
    });
  } catch (err) {
    return handleError(res, err, 'Failed to update daily plan.');
  }
});

// ==============================================================================
// 2. CONTENT PLANNER (Projects + Tasks)
// ==============================================================================
router.get('/planner', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const [projects, tasks] = await Promise.all([
      db
        .select()
        .from(ytmPlannerProjects)
        .where(eq(ytmPlannerProjects.workspaceId, workspace.id))
        .orderBy(desc(ytmPlannerProjects.updatedAt)),
      db
        .select()
        .from(ytmPlannerTasks)
        .where(eq(ytmPlannerTasks.workspaceId, workspace.id))
        .orderBy(desc(ytmPlannerTasks.updatedAt)),
    ]);
    return okJson(res, {
      projects: projects.map(hydratePlannerProject),
      tasks: tasks.map((t) => ({
        ...t,
        createdAt: t.createdAt.toISOString(),
        updatedAt: t.updatedAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load Content Planner.');
  }
});

router.post('/planner/projects', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
    if (!title) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Video title is required.');
    }

    let channelProfileId: number | null =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;
    if (channelProfileId !== null) {
      const valid = await verifyChannelProfileInWorkspace(workspace.id, channelProfileId);
      if (!valid) channelProfileId = null;
    }

    const checklist = Array.isArray(req.body?.productionChecklist)
      ? parsePlannerChecklist(JSON.stringify(req.body.productionChecklist))
      : YTM_DEFAULT_PRODUCTION_CHECKLIST.map((item) => ({ ...item }));

    const inserted = await db
      .insert(ytmPlannerProjects)
      .values({
        workspaceId: workspace.id,
        createdByUserId: req.dbUser!.id,
        assigneeUserId: typeof req.body?.assigneeUserId === 'number' ? req.body.assigneeUserId : null,
        title: title.slice(0, 180),
        topic: typeof req.body?.topic === 'string' ? req.body.topic.trim().slice(0, 300) : '',
        description:
          typeof req.body?.description === 'string' ? req.body.description.trim().slice(0, 2000) : '',
        notes: typeof req.body?.notes === 'string' ? req.body.notes.trim().slice(0, 3000) : '',
        targetAudience:
          typeof req.body?.targetAudience === 'string'
            ? req.body.targetAudience.trim().slice(0, 200)
            : '',
        category: typeof req.body?.category === 'string' ? req.body.category.trim().slice(0, 80) : 'General',
        status: typeof req.body?.status === 'string' ? req.body.status.trim().slice(0, 40) : 'Idea',
        priority: ['low', 'medium', 'high', 'urgent'].includes(req.body?.priority)
          ? req.body.priority
          : 'medium',
        plannedDate: typeof req.body?.plannedDate === 'string' && req.body.plannedDate ? req.body.plannedDate : null,
        deadline: typeof req.body?.deadline === 'string' && req.body.deadline ? req.body.deadline : null,
        recurrenceRule: ['none', 'weekly', 'biweekly', 'monthly'].includes(req.body?.recurrenceRule)
          ? req.body.recurrenceRule
          : 'none',
        channelProfileId,
        savedInspirationId:
          typeof req.body?.savedInspirationId === 'number' ? req.body.savedInspirationId : null,
        adaptedIdeaId: typeof req.body?.adaptedIdeaId === 'number' ? req.body.adaptedIdeaId : null,
        inspirationSourceLabel:
          typeof req.body?.inspirationSourceLabel === 'string'
            ? req.body.inspirationSourceLabel.trim().slice(0, 240)
            : '',
        inspirationSourceUrl:
          typeof req.body?.inspirationSourceUrl === 'string'
            ? req.body.inspirationSourceUrl.trim().slice(0, 500)
            : '',
        adaptedAngle:
          typeof req.body?.adaptedAngle === 'string' ? req.body.adaptedAngle.trim().slice(0, 1500) : '',
        productionChecklistJson: JSON.stringify(checklist),
      })
      .returning();

    await recordYtmActivity({
      workspaceId: workspace.id,
      actorUserId: req.dbUser!.id,
      actorEmail: req.dbUser!.email,
      action: 'CREATE_PLANNER_PROJECT',
      resourceType: 'planner_project',
      resourceId: inserted[0].id,
    });

    return okJson(res, { project: hydratePlannerProject(inserted[0]) }, 201);
  } catch (err) {
    return handleError(res, err, 'Failed to create planner video project.');
  }
});

router.patch('/planner/projects/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const projectId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(projectId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid planner project ID.');
    }

    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const key of [
      'title',
      'topic',
      'description',
      'notes',
      'targetAudience',
      'category',
      'status',
      'priority',
      'plannedDate',
      'deadline',
      'recurrenceRule',
      'inspirationSourceLabel',
      'inspirationSourceUrl',
      'adaptedAngle',
    ] as const) {
      if (req.body?.[key] !== undefined) {
        patch[key] = req.body[key];
      }
    }
    if (req.body?.assigneeUserId !== undefined) {
      patch.assigneeUserId = req.body.assigneeUserId;
    }
    if (req.body?.channelProfileId !== undefined) {
      if (req.body.channelProfileId === null) {
        patch.channelProfileId = null;
      } else if (typeof req.body.channelProfileId === 'number') {
        const valid = await verifyChannelProfileInWorkspace(workspace.id, req.body.channelProfileId);
        if (valid) patch.channelProfileId = req.body.channelProfileId;
      }
    }
    if (Array.isArray(req.body?.productionChecklist)) {
      patch.productionChecklistJson = JSON.stringify(
        parsePlannerChecklist(JSON.stringify(req.body.productionChecklist))
      );
    }

    const updated = await db
      .update(ytmPlannerProjects)
      .set(patch)
      .where(
        and(
          eq(ytmPlannerProjects.id, projectId),
          eq(ytmPlannerProjects.workspaceId, workspace.id)
        )
      )
      .returning();

    if (!updated[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Planner project not found in this workspace.');
    }
    return okJson(res, { project: hydratePlannerProject(updated[0]) });
  } catch (err) {
    return handleError(res, err, 'Failed to update planner project.');
  }
});

router.delete('/planner/projects/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const projectId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmPlannerProjects)
      .where(
        and(
          eq(ytmPlannerProjects.id, projectId),
          eq(ytmPlannerProjects.workspaceId, workspace.id)
        )
      );
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete planner project.');
  }
});

router.post('/planner/tasks', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const taskName = typeof req.body?.taskName === 'string' ? req.body.taskName.trim() : '';
    if (!taskName) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Task name is required.');
    }

    const inserted = await db
      .insert(ytmPlannerTasks)
      .values({
        workspaceId: workspace.id,
        plannerProjectId:
          typeof req.body?.plannerProjectId === 'number' ? req.body.plannerProjectId : null,
        createdByUserId: req.dbUser!.id,
        assigneeUserId: typeof req.body?.assigneeUserId === 'number' ? req.body.assigneeUserId : null,
        taskName: taskName.slice(0, 240),
        workspaceSection:
          typeof req.body?.workspaceSection === 'string'
            ? req.body.workspaceSection.trim().slice(0, 60)
            : 'Workflow',
        scheduledAt: typeof req.body?.scheduledAt === 'string' ? req.body.scheduledAt : null,
        deadline: typeof req.body?.deadline === 'string' ? req.body.deadline : null,
        priority: ['low', 'medium', 'high', 'urgent'].includes(req.body?.priority)
          ? req.body.priority
          : 'medium',
        status: [
          'Not Started',
          'In Progress',
          'Completed',
          'Overdue',
          'Waiting for Approval',
        ].includes(req.body?.status)
          ? req.body.status
          : 'Not Started',
        aiSuggested: req.body?.aiSuggested === true,
      })
      .returning();

    return okJson(
      res,
      {
        task: {
          ...inserted[0],
          createdAt: inserted[0].createdAt.toISOString(),
          updatedAt: inserted[0].updatedAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to create task.');
  }
});

router.patch('/planner/tasks/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const taskId = Number.parseInt(String(req.params.id), 10);
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const key of [
      'taskName',
      'workspaceSection',
      'scheduledAt',
      'deadline',
      'priority',
      'status',
      'assigneeUserId',
      'plannerProjectId',
    ] as const) {
      if (req.body?.[key] !== undefined) patch[key] = req.body[key];
    }

    const updated = await db
      .update(ytmPlannerTasks)
      .set(patch)
      .where(
        and(eq(ytmPlannerTasks.id, taskId), eq(ytmPlannerTasks.workspaceId, workspace.id))
      )
      .returning();
    if (!updated[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Task not found.');
    }
    return okJson(res, {
      task: {
        ...updated[0],
        createdAt: updated[0].createdAt.toISOString(),
        updatedAt: updated[0].updatedAt.toISOString(),
      },
    });
  } catch (err) {
    return handleError(res, err, 'Failed to update task.');
  }
});

router.delete('/planner/tasks/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const taskId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmPlannerTasks)
      .where(and(eq(ytmPlannerTasks.id, taskId), eq(ytmPlannerTasks.workspaceId, workspace.id)));
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete task.');
  }
});

function shiftIsoDateKey(dateKey: string, shiftDays: number): string {
  const base = /^\d{4}-\d{2}-\d{2}$/.test(dateKey) ? dateKey : getTodayDateKey();
  const d = new Date(`${base}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + shiftDays);
  return d.toISOString().slice(0, 10);
}

router.post('/planner/calendar/manage', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const action = typeof req.body?.action === 'string' ? req.body.action : '';
    const parsePositiveIds = (raw: unknown): number[] =>
      Array.isArray(raw)
        ? Array.from(
            new Set(
              raw
                .map((v) => Number.parseInt(String(v), 10))
                .filter((n) => Number.isFinite(n) && n > 0)
            )
          ).slice(0, 200)
        : [];

    if (action === 'delete_projects') {
      const projectIds = parsePositiveIds(req.body?.projectIds);
      if (projectIds.length === 0) {
        return failJson(res, 400, 'INVALID_REQUEST', 'Select at least one planned video to delete.');
      }
      const deleted = await db
        .delete(ytmPlannerProjects)
        .where(
          and(
            eq(ytmPlannerProjects.workspaceId, workspace.id),
            inArray(ytmPlannerProjects.id, projectIds)
          )
        )
        .returning({ id: ytmPlannerProjects.id });
      return okJson(res, { action, affectedProjects: deleted.length });
    }

    if (action === 'unschedule_projects') {
      const projectIds = parsePositiveIds(req.body?.projectIds);
      if (projectIds.length === 0) {
        return failJson(res, 400, 'INVALID_REQUEST', 'Select at least one planned video to unschedule.');
      }
      const updated = await db
        .update(ytmPlannerProjects)
        .set({ plannedDate: null, updatedAt: new Date() })
        .where(
          and(
            eq(ytmPlannerProjects.workspaceId, workspace.id),
            inArray(ytmPlannerProjects.id, projectIds)
          )
        )
        .returning({ id: ytmPlannerProjects.id });
      return okJson(res, { action, affectedProjects: updated.length });
    }

    if (action === 'reschedule_projects') {
      const projectIds = parsePositiveIds(req.body?.projectIds);
      if (projectIds.length === 0) {
        return failJson(res, 400, 'INVALID_REQUEST', 'Select at least one planned video to reschedule.');
      }
      const targetDate =
        typeof req.body?.plannedDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.plannedDate)
          ? req.body.plannedDate
          : null;
      const shiftDays =
        typeof req.body?.shiftDays === 'number' &&
        Number.isInteger(req.body.shiftDays) &&
        req.body.shiftDays !== 0 &&
        Math.abs(req.body.shiftDays) <= 365
          ? req.body.shiftDays
          : null;

      if (!targetDate && shiftDays === null) {
        return failJson(
          res,
          400,
          'INVALID_REQUEST',
          'Provide either a valid plannedDate (YYYY-MM-DD) or a non-zero shiftDays integer.'
        );
      }

      if (targetDate) {
        const updated = await db
          .update(ytmPlannerProjects)
          .set({ plannedDate: targetDate, updatedAt: new Date() })
          .where(
            and(
              eq(ytmPlannerProjects.workspaceId, workspace.id),
              inArray(ytmPlannerProjects.id, projectIds)
            )
          )
          .returning({ id: ytmPlannerProjects.id });
        return okJson(res, { action, affectedProjects: updated.length, plannedDate: targetDate });
      }

      const existing = await db
        .select({ id: ytmPlannerProjects.id, plannedDate: ytmPlannerProjects.plannedDate })
        .from(ytmPlannerProjects)
        .where(
          and(
            eq(ytmPlannerProjects.workspaceId, workspace.id),
            inArray(ytmPlannerProjects.id, projectIds)
          )
        );
      for (const row of existing) {
        const nextDate = shiftIsoDateKey(row.plannedDate?.slice(0, 10) || getTodayDateKey(), shiftDays!);
        await db
          .update(ytmPlannerProjects)
          .set({ plannedDate: nextDate, updatedAt: new Date() })
          .where(
            and(
              eq(ytmPlannerProjects.id, row.id),
              eq(ytmPlannerProjects.workspaceId, workspace.id)
            )
          );
      }
      return okJson(res, { action, affectedProjects: existing.length, shiftDays });
    }

    if (action === 'clear_month') {
      const yearMonth =
        typeof req.body?.yearMonth === 'string' && /^\d{4}-\d{2}$/.test(req.body.yearMonth)
          ? req.body.yearMonth
          : null;
      const mode = req.body?.mode === 'delete' ? 'delete' : 'unschedule';
      const includeTasks = req.body?.includeTasks === true;
      if (!yearMonth) {
        return failJson(res, 400, 'INVALID_REQUEST', 'Provide a valid yearMonth (YYYY-MM).');
      }

      const allProjects = await db
        .select({ id: ytmPlannerProjects.id, plannedDate: ytmPlannerProjects.plannedDate })
        .from(ytmPlannerProjects)
        .where(eq(ytmPlannerProjects.workspaceId, workspace.id));
      const matchingProjectIds = allProjects
        .filter((p) => p.plannedDate && p.plannedDate.slice(0, 7) === yearMonth)
        .map((p) => p.id);

      let affectedProjects = 0;
      if (matchingProjectIds.length > 0) {
        if (mode === 'delete') {
          const deleted = await db
            .delete(ytmPlannerProjects)
            .where(
              and(
                eq(ytmPlannerProjects.workspaceId, workspace.id),
                inArray(ytmPlannerProjects.id, matchingProjectIds)
              )
            )
            .returning({ id: ytmPlannerProjects.id });
          affectedProjects = deleted.length;
        } else {
          const updated = await db
            .update(ytmPlannerProjects)
            .set({ plannedDate: null, updatedAt: new Date() })
            .where(
              and(
                eq(ytmPlannerProjects.workspaceId, workspace.id),
                inArray(ytmPlannerProjects.id, matchingProjectIds)
              )
            )
            .returning({ id: ytmPlannerProjects.id });
          affectedProjects = updated.length;
        }
      }

      let affectedTasks = 0;
      if (includeTasks) {
        const allTasks = await db
          .select({
            id: ytmPlannerTasks.id,
            scheduledAt: ytmPlannerTasks.scheduledAt,
            deadline: ytmPlannerTasks.deadline,
          })
          .from(ytmPlannerTasks)
          .where(eq(ytmPlannerTasks.workspaceId, workspace.id));
        const matchingTaskIds = allTasks
          .filter(
            (t) =>
              (t.scheduledAt && t.scheduledAt.slice(0, 7) === yearMonth) ||
              (t.deadline && t.deadline.slice(0, 7) === yearMonth)
          )
          .map((t) => t.id);

        if (matchingTaskIds.length > 0) {
          if (mode === 'delete') {
            const deletedTasks = await db
              .delete(ytmPlannerTasks)
              .where(
                and(
                  eq(ytmPlannerTasks.workspaceId, workspace.id),
                  inArray(ytmPlannerTasks.id, matchingTaskIds)
                )
              )
              .returning({ id: ytmPlannerTasks.id });
            affectedTasks = deletedTasks.length;
          } else {
            const updatedTasks = await db
              .update(ytmPlannerTasks)
              .set({ scheduledAt: null, deadline: null, updatedAt: new Date() })
              .where(
                and(
                  eq(ytmPlannerTasks.workspaceId, workspace.id),
                  inArray(ytmPlannerTasks.id, matchingTaskIds)
                )
              )
              .returning({ id: ytmPlannerTasks.id });
            affectedTasks = updatedTasks.length;
          }
        }
      }

      return okJson(res, {
        action,
        mode,
        yearMonth,
        affectedProjects,
        affectedTasks,
      });
    }

    if (action === 'delete_tasks') {
      const completedOnly = req.body?.completedOnly === true;
      if (completedOnly) {
        const deleted = await db
          .delete(ytmPlannerTasks)
          .where(
            and(
              eq(ytmPlannerTasks.workspaceId, workspace.id),
              eq(ytmPlannerTasks.status, 'Completed')
            )
          )
          .returning({ id: ytmPlannerTasks.id });
        return okJson(res, { action, affectedTasks: deleted.length });
      }
      const taskIds = parsePositiveIds(req.body?.taskIds);
      if (taskIds.length === 0) {
        return failJson(res, 400, 'INVALID_REQUEST', 'Select at least one task to delete.');
      }
      const deleted = await db
        .delete(ytmPlannerTasks)
        .where(
          and(
            eq(ytmPlannerTasks.workspaceId, workspace.id),
            inArray(ytmPlannerTasks.id, taskIds)
          )
        )
        .returning({ id: ytmPlannerTasks.id });
      return okJson(res, { action, affectedTasks: deleted.length });
    }

    return failJson(
      res,
      400,
      'INVALID_ACTION',
      'Unsupported calendar management action. Use delete_projects, unschedule_projects, reschedule_projects, clear_month, or delete_tasks.'
    );
  } catch (err) {
    return handleError(res, err, 'Failed to manage calendar items.');
  }
});

// ==============================================================================
// 3. COMPETITOR & ANALYTICS (Public Competitor Channels Only)
// ==============================================================================
router.get('/competitors', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const [saved, userReports, cachedChannels] = await Promise.all([
      db
        .select()
        .from(ytmWorkspaceCompetitors)
        .where(eq(ytmWorkspaceCompetitors.workspaceId, workspace.id))
        .orderBy(desc(ytmWorkspaceCompetitors.updatedAt)),
      db
        .select()
        .from(competitorReports)
        .where(eq(competitorReports.userId, req.dbUser!.id))
        .orderBy(desc(competitorReports.updatedAt))
        .limit(15),
      db
        .select()
        .from(competitorChannelCaches)
        .orderBy(desc(competitorChannelCaches.retrievedAt))
        .limit(20),
    ]);

    return okJson(res, {
      competitors: saved.map((c) => ({
        ...c,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
      reports: userReports.map((r) => ({
        reportKey: r.reportKey,
        title: r.title,
        status: r.status,
        updatedAt: r.updatedAt.toISOString(),
      })),
      cachedChannels: cachedChannels.map((c) => ({
        channelId: c.channelId,
        handle: c.handle,
        title: c.title,
        sampleSize: c.sampleSize,
        retrievedAt: c.retrievedAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load workspace competitors.');
  }
});

router.post('/competitors', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const input = typeof req.body?.input === 'string' ? req.body.input.trim() : '';
    if (!input) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Provide a YouTube channel URL, @handle, or UC channel ID.');
    }

    const { profile } = await resolveYouTubeChannel(input);

    const existing = await db
      .select()
      .from(ytmWorkspaceCompetitors)
      .where(
        and(
          eq(ytmWorkspaceCompetitors.workspaceId, workspace.id),
          eq(ytmWorkspaceCompetitors.channelId, profile.channelId)
        )
      )
      .limit(1);

    if (existing[0]) {
      const updated = await db
        .update(ytmWorkspaceCompetitors)
        .set({
          title: profile.title,
          handle: profile.handle,
          channelUrl: profile.channelUrl,
          thumbnailUrl: profile.thumbnailUrl,
          subscriberCount: profile.subscriberCount,
          notes: typeof req.body?.notes === 'string' ? req.body.notes : existing[0].notes,
          updatedAt: new Date(),
        })
        .where(eq(ytmWorkspaceCompetitors.id, existing[0].id))
        .returning();
      return okJson(res, {
        competitor: {
          ...updated[0],
          createdAt: updated[0].createdAt.toISOString(),
          updatedAt: updated[0].updatedAt.toISOString(),
        },
      });
    }

    const inserted = await db
      .insert(ytmWorkspaceCompetitors)
      .values({
        workspaceId: workspace.id,
        addedByUserId: req.dbUser!.id,
        channelId: profile.channelId,
        channelUrl: profile.channelUrl,
        handle: profile.handle,
        title: profile.title,
        thumbnailUrl: profile.thumbnailUrl,
        subscriberCount: profile.subscriberCount,
        notes: typeof req.body?.notes === 'string' ? req.body.notes : '',
      })
      .returning();

    return okJson(
      res,
      {
        competitor: {
          ...inserted[0],
          createdAt: inserted[0].createdAt.toISOString(),
          updatedAt: inserted[0].updatedAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to resolve and save competitor channel.');
  }
});

router.delete('/competitors/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const compId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmWorkspaceCompetitors)
      .where(
        and(
          eq(ytmWorkspaceCompetitors.id, compId),
          eq(ytmWorkspaceCompetitors.workspaceId, workspace.id)
        )
      );
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Unable to remove competitor.');
  }
});

router.get('/competitors/:channelId/videos', async (req: AuthRequest, res) => {
  try {
    await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const channelId = String(req.params.channelId || '').trim();
    if (!channelId) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Competitor channel ID is required.');
    }
    const sampleSizeRaw = Number.parseInt(String(req.query.sampleSize || '20'), 10);
    const sampleSize = Number.isFinite(sampleSizeRaw) ? Math.min(30, Math.max(8, sampleSizeRaw)) : 20;
    const collection = await collectChannelWithVideos(channelId, {
      sampleSize,
      forceRefresh: req.query.refresh === '1',
    });
    return okJson(res, {
      profile: collection.profile,
      metrics: collection.metrics,
      videos: collection.videos,
      cached: collection.cached,
    });
  } catch (err) {
    return handleError(res, err, 'Unable to fetch competitor channel videos.');
  }
});

// ==============================================================================
// 4. WORKFLOW (6 Sequential Stages + Distribution Assets + Thumbnail Upload)
// ==============================================================================
router.get('/workflow', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const workflows = await db
      .select()
      .from(ytmWorkflowProjects)
      .where(eq(ytmWorkflowProjects.workspaceId, workspace.id))
      .orderBy(desc(ytmWorkflowProjects.updatedAt));

    const wfIds = workflows.map((w) => w.id);
    const distAssets =
      wfIds.length > 0
        ? await db
            .select()
            .from(ytmDistributionAssets)
            .where(inArray(ytmDistributionAssets.workflowProjectId, wfIds))
        : [];

    return okJson(res, {
      workflows: workflows.map(hydrateWorkflow),
      distributionAssets: distAssets.map((d) => ({
        ...d,
        carouselSlides: safeJsonParse<string[]>(d.carouselSlidesJson, []),
        createdAt: d.createdAt.toISOString(),
        updatedAt: d.updatedAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load workflows.');
  }
});

router.post('/workflow/projects', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });

    const plannerProjectId =
      typeof req.body?.plannerProjectId === 'number' ? req.body.plannerProjectId : null;
    let plannerRow: typeof ytmPlannerProjects.$inferSelect | null = null;
    if (plannerProjectId) {
      const pRows = await db
        .select()
        .from(ytmPlannerProjects)
        .where(
          and(
            eq(ytmPlannerProjects.id, plannerProjectId),
            eq(ytmPlannerProjects.workspaceId, workspace.id)
          )
        )
        .limit(1);
      plannerRow = pRows[0] || null;
      if (plannerRow?.workflowProjectId) {
        const existingWf = await db
          .select()
          .from(ytmWorkflowProjects)
          .where(
            and(
              eq(ytmWorkflowProjects.id, plannerRow.workflowProjectId),
              eq(ytmWorkflowProjects.workspaceId, workspace.id)
            )
          )
          .limit(1);
        if (existingWf[0]) {
          return okJson(res, { workflow: hydrateWorkflow(existingWf[0]), reused: true });
        }
      }
    }

    const adaptedIdeaId =
      typeof req.body?.adaptedIdeaId === 'number'
        ? req.body.adaptedIdeaId
        : plannerRow?.adaptedIdeaId ?? null;
    let adaptedRow: typeof adaptedIdeas.$inferSelect | null = null;
    if (adaptedIdeaId) {
      const aRows = await db
        .select()
        .from(adaptedIdeas)
        .where(and(eq(adaptedIdeas.id, adaptedIdeaId), eq(adaptedIdeas.workspaceId, workspace.id)))
        .limit(1);
      adaptedRow = aRows[0] || null;
    }

    const savedInspirationId =
      typeof req.body?.savedInspirationId === 'number'
        ? req.body.savedInspirationId
        : plannerRow?.savedInspirationId ?? adaptedRow?.savedInspirationId ?? null;

    const requestedChannelId =
      typeof req.body?.channelProfileId === 'number'
        ? req.body.channelProfileId
        : plannerRow?.channelProfileId ?? adaptedRow?.channelProfileId ?? null;
    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      requestedChannelId
    );

    const hydratedAdapted = adaptedRow ? hydrateAdaptedIdea(adaptedRow) : null;
    const title =
      (typeof req.body?.title === 'string' && req.body.title.trim()) ||
      plannerRow?.title ||
      hydratedAdapted?.selectedTitle ||
      'Untitled Video Production';

    const titleOptions = hydratedAdapted
      ? hydratedAdapted.titleOptions.map((opt, idx) => ({
          id: `adapted_t_${idx + 1}`,
          title: opt,
          angle: hydratedAdapted.freshAngle || 'Adapted channel angle',
          psychologicalAppeal: hydratedAdapted.whyItWorks || 'Aligned with Channel DNA',
          curiosityGap: hydratedAdapted.channelFitExplanation || 'Tailored for target audience',
          isSelected: opt === title || (idx === 0 && !hydratedAdapted.titleOptions.includes(title)),
        }))
      : [];

    const stage1NotesParts = [
      typeof req.body?.notes === 'string' ? req.body.notes.trim() : '',
      plannerRow?.notes || '',
      plannerRow?.inspirationSourceLabel
        ? `Inspiration Source: ${plannerRow.inspirationSourceLabel}${
            plannerRow.inspirationSourceUrl ? ` (${plannerRow.inspirationSourceUrl})` : ''
          }`
        : '',
    ].filter(Boolean);

    const s1: YtmWorkflowStage1Title = {
      ...defaultStage1(),
      seedIdea:
        (typeof req.body?.seedIdea === 'string' && req.body.seedIdea.trim()) ||
        plannerRow?.topic ||
        hydratedAdapted?.originalConceptSummary ||
        title,
      options: titleOptions,
      selectedTitle: title.slice(0, 180),
      notes: stage1NotesParts.join('\n\n'),
    };

    const s2: YtmWorkflowStage2Topic = {
      ...defaultStage2(),
      centralTopic:
        (typeof req.body?.topic === 'string' && req.body.topic.trim()) ||
        plannerRow?.topic ||
        hydratedAdapted?.originalConceptSummary ||
        title,
      targetAudience:
        (typeof req.body?.targetAudience === 'string' && req.body.targetAudience.trim()) ||
        plannerRow?.targetAudience ||
        activeProfile.dna.targetAudience ||
        '',
      valueAngle:
        (typeof req.body?.adaptedAngle === 'string' && req.body.adaptedAngle.trim()) ||
        plannerRow?.adaptedAngle ||
        hydratedAdapted?.freshAngle ||
        '',
      supportingPoints: hydratedAdapted?.videoOutline || [],
      notes: [
        hydratedAdapted?.uniqueHook ? `Opening Hook Draft:\n${hydratedAdapted.uniqueHook}` : '',
        hydratedAdapted?.channelFitExplanation
          ? `Channel Fit:\n${hydratedAdapted.channelFitExplanation}`
          : '',
        plannerRow?.description || '',
      ]
        .filter(Boolean)
        .join('\n\n'),
    };

    const s4: YtmWorkflowStage4Thumbnail = {
      ...defaultStage4(),
      notes: hydratedAdapted?.thumbnailDirection || '',
    };

    const inserted = await db
      .insert(ytmWorkflowProjects)
      .values({
        workspaceId: workspace.id,
        plannerProjectId,
        createdByUserId: req.dbUser!.id,
        assigneeUserId:
          typeof req.body?.assigneeUserId === 'number'
            ? req.body.assigneeUserId
            : plannerRow?.assigneeUserId ?? null,
        title: title.slice(0, 180),
        currentStage: 1,
        projectStatus: 'NOT STARTED',
        stage4Mode: 'thumbnail',
        stage1TitleJson: JSON.stringify(s1),
        stage2TopicJson: JSON.stringify(s2),
        stage4ThumbnailJson: JSON.stringify(s4),
        stage5SeoJson: JSON.stringify(defaultStage5()),
        approvalsJson: '{}',
        approvalTimestampsJson: '{}',
        channelProfileId: activeProfile.id,
        savedInspirationId,
        adaptedIdeaId,
      })
      .returning();

    if (plannerProjectId && plannerRow) {
      const nextStatus = ['Idea', 'Selected'].includes(plannerRow.status)
        ? 'Scripting'
        : plannerRow.status;
      await db
        .update(ytmPlannerProjects)
        .set({
          workflowProjectId: inserted[0].id,
          status: nextStatus,
          updatedAt: new Date(),
        })
        .where(
          and(
            eq(ytmPlannerProjects.id, plannerProjectId),
            eq(ytmPlannerProjects.workspaceId, workspace.id)
          )
        );
    }

    return okJson(res, { workflow: hydrateWorkflow(inserted[0]) }, 201);
  } catch (err) {
    return handleError(res, err, 'Failed to create workflow project.');
  }
});

router.patch('/workflow/projects/:id', async (req: AuthRequest, res) => {
  try {
    const requiredPerm =
      req.body?.reviewStatus === 'approved' || req.body?.approveStage ? 'workflow:approve' : 'workflow:write';
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: requiredPerm,
    });

    const wfId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmWorkflowProjects)
      .where(and(eq(ytmWorkflowProjects.id, wfId), eq(ytmWorkflowProjects.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Workflow project not found.');
    }

    const current = hydrateWorkflow(rows[0]);
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    let completedNow = false;

    if (typeof req.body?.title === 'string' && req.body.title.trim()) {
      patch.title = req.body.title.trim().slice(0, 180);
    }
    if (typeof req.body?.currentStage === 'number') {
      patch.currentStage = Math.min(6, Math.max(1, Math.floor(req.body.currentStage)));
    }
    if (req.body?.stage4Mode === 'thumbnail' || req.body?.stage4Mode === 'community_post') {
      patch.stage4Mode = req.body.stage4Mode;
    }
    if (req.body?.stage1Title) {
      patch.stage1TitleJson = JSON.stringify({ ...current.stage1Title, ...req.body.stage1Title });
      if (req.body.stage1Title.selectedTitle) {
        patch.title = String(req.body.stage1Title.selectedTitle).slice(0, 180);
      }
      if (current.projectStatus === 'NOT STARTED') {
        patch.projectStatus = 'IN PROGRESS';
      }
    }
    if (req.body?.stage2Topic) {
      patch.stage2TopicJson = JSON.stringify({ ...current.stage2Topic, ...req.body.stage2Topic });
      if (current.projectStatus === 'NOT STARTED') {
        patch.projectStatus = 'IN PROGRESS';
      }
    }
    if (req.body?.stage4Thumbnail) {
      patch.stage4ThumbnailJson = JSON.stringify({
        ...current.stage4Thumbnail,
        ...req.body.stage4Thumbnail,
      });
      if (current.projectStatus === 'NOT STARTED') {
        patch.projectStatus = 'IN PROGRESS';
      }
    }
    if (req.body?.stage5Seo) {
      patch.stage5SeoJson = JSON.stringify({ ...current.stage5Seo, ...req.body.stage5Seo });
      if (current.projectStatus === 'NOT STARTED') {
        patch.projectStatus = 'IN PROGRESS';
      }
    }
    if (typeof req.body?.finalApprovedScript === 'string') {
      patch.finalApprovedScript = req.body.finalApprovedScript;
    }

    let nextApprovals = { ...current.approvals };
    const nextTimestamps = { ...(current.approvalTimestamps || {}) };

    if (req.body?.approvals) {
      nextApprovals = { ...nextApprovals, ...req.body.approvals };
      patch.approvalsJson = JSON.stringify(nextApprovals);
    }

    if (typeof req.body?.approveStage === 'number') {
      const approveNum = Math.floor(req.body.approveStage);
      if (approveNum < 1 || approveNum > 6) {
        return failJson(res, 400, 'INVALID_STAGE', 'Workflow stage must be between 1 and 6.');
      }

      if (approveNum === 6) {
        const missingStages = [1, 2, 3, 4, 5].filter((s) => !nextApprovals[`stage${s}`]);
        if (missingStages.length > 0) {
          return failJson(
            res,
            400,
            'INCOMPLETE_STAGES',
            `Cannot complete production before approving earlier stages: Stage ${missingStages.join(', Stage ')}.`
          );
        }
      }

      const nowIso = new Date().toISOString();
      nextApprovals = {
        ...nextApprovals,
        [`stage${approveNum}`]: true,
      };
      nextTimestamps[`stage${approveNum}`] = nowIso;
      patch.approvalsJson = JSON.stringify(nextApprovals);
      patch.approvalTimestampsJson = JSON.stringify(nextTimestamps);

      if (approveNum < 6) {
        if (req.body.currentStage === undefined) {
          patch.currentStage = approveNum + 1;
        }
        if (current.projectStatus !== 'COMPLETED' && current.projectStatus !== 'PUBLISHED') {
          patch.projectStatus = 'IN PROGRESS';
        }
      } else {
        // Stage 6 Final Approval -> Complete & Archive production cleanly
        let capturedScript =
          (typeof req.body?.finalApprovedScript === 'string' && req.body.finalApprovedScript.trim()) ||
          current.finalApprovedScript ||
          '';

        if (!capturedScript && current.scriptProjectKey) {
          const spRows = await db
            .select()
            .from(scriptProjects)
            .where(eq(scriptProjects.projectKey, current.scriptProjectKey))
            .limit(1);
          if (spRows[0]) {
            const spState = safeJsonParse<Partial<ScriptProjectState>>(spRows[0].stateJson, {});
            capturedScript =
              spRows[0].finalApprovedScript ||
              spState.stage7?.assembled?.spokenOnlyText ||
              spState.stage7?.assembled?.fullScriptText ||
              '';
          }
        }

        patch.finalApprovedScript = capturedScript || current.finalApprovedScript || null;
        patch.projectStatus = current.youtubeVideoId ? 'PUBLISHED' : 'COMPLETED';
        patch.reviewStatus = 'approved';
        patch.completedAt = new Date();
        patch.currentStage = 6;
        completedNow = true;
      }
    }

    if (typeof req.body?.projectStatus === 'string') {
      const validStatuses = new Set([
        'NOT STARTED',
        'IN PROGRESS',
        'WAITING FOR APPROVAL',
        'COMPLETED',
        'PUBLISHED',
      ]);
      if (validStatuses.has(req.body.projectStatus)) {
        patch.projectStatus = req.body.projectStatus;
      }
    }
    if (typeof req.body?.reviewStatus === 'string' && !completedNow) {
      patch.reviewStatus = req.body.reviewStatus;
      if (
        req.body.reviewStatus === 'in_review' &&
        current.projectStatus !== 'COMPLETED' &&
        current.projectStatus !== 'PUBLISHED'
      ) {
        patch.projectStatus = 'WAITING FOR APPROVAL';
      }
    }
    if (typeof req.body?.reviewNotes === 'string') {
      patch.reviewNotes = req.body.reviewNotes.slice(0, 1000);
    }
    if (req.body?.assigneeUserId !== undefined) {
      patch.assigneeUserId = req.body.assigneeUserId;
    }
    if (typeof req.body?.clearStageWarning === 'number') {
      const nextWarnings = { ...(current.stageWarnings || {}) };
      delete nextWarnings[`stage${req.body.clearStageWarning}`];
      patch.stageWarningsJson = JSON.stringify(nextWarnings);
    }
    if (typeof req.body?.scriptProjectKey === 'string') {
      patch.scriptProjectKey = req.body.scriptProjectKey;
    }

    const updated = await db
      .update(ytmWorkflowProjects)
      .set(patch)
      .where(eq(ytmWorkflowProjects.id, wfId))
      .returning();

    if (completedNow) {
      await recordYtmActivity({
        workspaceId: workspace.id,
        actorUserId: req.dbUser!.id,
        actorEmail: req.dbUser!.email,
        action: 'COMPLETE_WORKFLOW_PRODUCTION',
        resourceType: 'workflow_project',
        resourceId: String(wfId),
        details: { title: updated[0].title, completedAt: updated[0].completedAt?.toISOString() },
      });
    }

    return okJson(res, {
      workflow: hydrateWorkflow(updated[0]),
      completed: completedNow,
    });
  } catch (err) {
    return handleError(res, err, 'Failed to save workflow stage.');
  }
});

router.post('/workflow/projects/:id/ai', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const wfId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmWorkflowProjects)
      .where(and(eq(ytmWorkflowProjects.id, wfId), eq(ytmWorkflowProjects.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Workflow project not found.');
    }

    const wf = hydrateWorkflow(rows[0]);
    const action = typeof req.body?.action === 'string' ? req.body.action : '';
    const activeChannelProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      typeof req.body?.channelProfileId === 'number'
        ? req.body.channelProfileId
        : wf.channelProfileId ?? null
    );
    const channelDnaPrompt = formatChannelDnaForPrompt(activeChannelProfile);

    if (action === 'titles') {
      const seedIdea =
        typeof req.body?.seedIdea === 'string' && req.body.seedIdea.trim()
          ? req.body.seedIdea.trim()
          : wf.stage1Title.seedIdea || wf.title;
      const options = await aiYtmGenerateTitles({
        seedIdea,
        targetAudience: wf.stage2Topic.targetAudience || activeChannelProfile.dna.targetAudience,
        notes: req.body?.notes || wf.stage1Title.notes,
        channelDnaPrompt,
      });
      const nextStage1: YtmWorkflowStage1Title = {
        ...wf.stage1Title,
        seedIdea,
        options,
        selectedTitle: options[0]?.title || wf.stage1Title.selectedTitle || wf.title,
      };
      const updated = await db
        .update(ytmWorkflowProjects)
        .set({
          stage1TitleJson: JSON.stringify(nextStage1),
          title: nextStage1.selectedTitle.slice(0, 180) || wf.title,
          updatedAt: new Date(),
        })
        .where(eq(ytmWorkflowProjects.id, wfId))
        .returning();
      return okJson(res, { workflow: hydrateWorkflow(updated[0]) });
    }

    if (action === 'topic') {
      const topic = await aiYtmExpandTopic({
        selectedTitle: wf.stage1Title.selectedTitle || wf.title,
        seedIdea: wf.stage1Title.seedIdea || wf.title,
        notes: req.body?.notes || wf.stage2Topic.notes,
        channelDnaPrompt,
      });
      const updated = await db
        .update(ytmWorkflowProjects)
        .set({
          stage2TopicJson: JSON.stringify(topic),
          updatedAt: new Date(),
        })
        .where(eq(ytmWorkflowProjects.id, wfId))
        .returning();
      return okJson(res, { workflow: hydrateWorkflow(updated[0]) });
    }

    if (action === 'thumbnail') {
      const concepts = await aiYtmGenerateThumbnails({
        title: wf.stage1Title.selectedTitle || wf.title,
        topicSummary: wf.stage2Topic.centralTopic || wf.stage2Topic.coreProblem || wf.title,
        notes: req.body?.notes || wf.stage4Thumbnail.notes,
        channelDnaPrompt,
      });
      const nextStage4: YtmWorkflowStage4Thumbnail = {
        ...wf.stage4Thumbnail,
        concepts,
        selectedConceptId: concepts[0]?.id || null,
        selectedTextOverlay: concepts[0]?.textOverlayOptions?.[0] || '',
        customImagePrompt: concepts[0]?.imagePrompt || '',
      };
      const updated = await db
        .update(ytmWorkflowProjects)
        .set({
          stage4ThumbnailJson: JSON.stringify(nextStage4),
          updatedAt: new Date(),
        })
        .where(eq(ytmWorkflowProjects.id, wfId))
        .returning();
      return okJson(res, { workflow: hydrateWorkflow(updated[0]) });
    }

    if (action === 'seo') {
      let scriptExcerpt = '';
      if (wf.scriptProjectKey) {
        const sp = await db
          .select()
          .from(scriptProjects)
          .where(eq(scriptProjects.projectKey, wf.scriptProjectKey))
          .limit(1);
        if (sp[0]) {
          const parsed = safeJsonParse<{ stage7?: { assembled?: { spokenOnlyText?: string } } }>(
            sp[0].stateJson,
            {}
          );
          scriptExcerpt = parsed.stage7?.assembled?.spokenOnlyText || '';
        }
      }
      const seo = await aiYtmGenerateSeo({
        title: wf.stage1Title.selectedTitle || wf.title,
        topicSummary: wf.stage2Topic.centralTopic || wf.title,
        scriptExcerpt,
        channelDnaPrompt,
      });
      const updated = await db
        .update(ytmWorkflowProjects)
        .set({
          stage5SeoJson: JSON.stringify(seo),
          updatedAt: new Date(),
        })
        .where(eq(ytmWorkflowProjects.id, wfId))
        .returning();
      return okJson(res, { workflow: hydrateWorkflow(updated[0]) });
    }

    if (action === 'distribution') {
      const requestedPlatforms: YtmDistributionPlatform[] = Array.isArray(req.body?.platforms)
        ? req.body.platforms
        : YTM_DISTRIBUTION_PLATFORMS.map((p) => p.id);

      const generated = await aiYtmGenerateDistribution({
        title: wf.stage1Title.selectedTitle || wf.title,
        topicSummary: wf.stage2Topic.centralTopic || wf.title,
        youtubeVideoUrl: wf.youtubeVideoUrl,
        platforms: requestedPlatforms,
        channelDnaPrompt,
      });

      const savedAssets = [];
      for (const item of generated) {
        const existing = await db
          .select()
          .from(ytmDistributionAssets)
          .where(
            and(
              eq(ytmDistributionAssets.workflowProjectId, wfId),
              eq(ytmDistributionAssets.platform, item.platform)
            )
          )
          .limit(1);

        if (existing[0]) {
          const upd = await db
            .update(ytmDistributionAssets)
            .set({
              assetType: item.assetType,
              title: item.title,
              bodyCopy: item.bodyCopy,
              hashtags: item.hashtags,
              carouselSlidesJson: JSON.stringify(item.carouselSlides),
              imagePrompt: item.imagePrompt,
              updatedAt: new Date(),
            })
            .where(eq(ytmDistributionAssets.id, existing[0].id))
            .returning();
          savedAssets.push(upd[0]);
        } else {
          const ins = await db
            .insert(ytmDistributionAssets)
            .values({
              workspaceId: workspace.id,
              workflowProjectId: wfId,
              platform: item.platform,
              assetType: item.assetType,
              title: item.title,
              bodyCopy: item.bodyCopy,
              hashtags: item.hashtags,
              carouselSlidesJson: JSON.stringify(item.carouselSlides),
              imagePrompt: item.imagePrompt,
              status: 'draft',
            })
            .returning();
          savedAssets.push(ins[0]);
        }
      }

      return okJson(res, {
        distributionAssets: savedAssets.map((d) => ({
          ...d,
          carouselSlides: safeJsonParse<string[]>(d.carouselSlidesJson, []),
          createdAt: d.createdAt.toISOString(),
          updatedAt: d.updatedAt.toISOString(),
        })),
      });
    }

    return failJson(res, 400, 'INVALID_ACTION', `Unsupported workflow AI action "${action}".`);
  } catch (err) {
    return handleError(res, err, 'Workflow AI generation failed.');
  }
});

router.post('/workflow/projects/:id/link-script', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const wfId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmWorkflowProjects)
      .where(and(eq(ytmWorkflowProjects.id, wfId), eq(ytmWorkflowProjects.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Workflow project not found.');
    }
    const wf = hydrateWorkflow(rows[0]);

    if (wf.scriptProjectKey) {
      const existing = await db
        .select()
        .from(scriptProjects)
        .where(eq(scriptProjects.projectKey, wf.scriptProjectKey))
        .limit(1);
      if (existing[0]) {
        return okJson(res, {
          workflow: wf,
          scriptProjectKey: existing[0].projectKey,
          scriptProject: hydrateLinkedScriptProject(existing[0]),
        });
      }
    }

    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      wf.channelProfileId ?? null
    );
    const projectKey = `sp_${crypto.randomBytes(10).toString('hex')}`;
    const baseSettings = createDefaultScriptSettings();
    const settings = {
      ...baseSettings,
      channelNiche: activeProfile.niche || baseSettings.channelNiche,
      targetAudience:
        wf.stage2Topic.targetAudience ||
        activeProfile.dna.targetAudience ||
        baseSettings.targetAudience,
      scriptLanguage: activeProfile.dna.preferredLanguage || baseSettings.scriptLanguage,
      contentTone: activeProfile.dna.toneOfVoice || baseSettings.contentTone,
      videoFormat: activeProfile.dna.contentFormat || baseSettings.videoFormat,
      customInstructions:
        [
          activeProfile.dna.uniquePositioning
            ? `Unique Channel Positioning: ${activeProfile.dna.uniquePositioning}`
            : '',
          activeProfile.dna.brandVoice
            ? `Brand Voice: ${activeProfile.dna.brandVoice}`
            : '',
          activeProfile.dna.storytellingApproach
            ? `Storytelling Approach: ${activeProfile.dna.storytellingApproach}`
            : '',
          activeProfile.dna.scriptStructure
            ? `Script Structure: ${activeProfile.dna.scriptStructure}`
            : '',
          activeProfile.dna.contentRules
            ? `Content Rules: ${activeProfile.dna.contentRules}`
            : '',
          activeProfile.dna.creativeGuidelines
            ? `Creative Guidelines: ${activeProfile.dna.creativeGuidelines}`
            : '',
          activeProfile.dna.wordsToUse.length > 0
            ? `Words/Phrases to Use: ${activeProfile.dna.wordsToUse.join(', ')}`
            : '',
          activeProfile.dna.wordsToAvoid.length > 0
            ? `Words/Styles to Avoid: ${activeProfile.dna.wordsToAvoid.join(', ')}`
            : '',
        ]
          .filter(Boolean)
          .join('\n') || baseSettings.customInstructions,
    };
    const state = createInitialScriptState();
    const nowIso = new Date().toISOString();
    const chosenTitle = wf.stage1Title.selectedTitle || wf.title;
    state.stage1.entryMode = 'custom';
    state.stage1.customTopicInput = wf.stage2Topic.centralTopic || chosenTitle;
    state.stage1.selectedTopic = {
      id: `wf_linked_${wfId}`,
      title: chosenTitle,
      targetAudience: settings.targetAudience,
      mainAudienceProblem: wf.stage2Topic.coreProblem || 'Core viewer tension',
      viewerTransformation: wf.stage2Topic.desiredOutcome || 'Actionable transformation',
      whyAttractive: wf.stage2Topic.valueAngle || 'Aligned with YouTube Management Workflow',
      storytellingAngle: wf.stage2Topic.valueAngle || chosenTitle,
    };
    state.stage1.approved = true;
    state.stage1.approvedAt = nowIso;
    const linkedTitleId = `wf_title_${wfId}`;
    state.stage2.titleConcepts = [
      {
        id: linkedTitleId,
        angleType: 'curiosity',
        angleLabel: 'Workflow Stage 1 Approved Title',
        title: chosenTitle,
        psychologicalAngle: wf.stage2Topic.valueAngle || 'Workflow Stage 1 packaging angle',
        viewerPromise: wf.stage2Topic.desiredOutcome || 'Clear viewer transformation',
        whyItAttractsClicks: wf.stage2Topic.coreProblem || 'Directly addresses core audience pain point',
        potentialLimitation: 'Refine in Stage 4 thumbnail pairing if needed',
        isRecommended: true,
      },
    ];
    state.stage2.selectedTitleId = linkedTitleId;
    state.stage2.customTitleText = chosenTitle;
    state.stage2.titleApproved = true;
    state.stage2.approved = true;
    state.stage2.approvedAt = nowIso;

    const insertedScript = await db
      .insert(scriptProjects)
      .values({
        projectKey,
        userId: req.dbUser!.id,
        ytmWorkflowProjectId: wfId,
        title: chosenTitle.slice(0, 180),
        currentStage: 3,
        highestApprovedStage: 2,
        projectStatus: 'IN PROGRESS',
        approvalTimestampsJson: JSON.stringify({ stage1: nowIso, stage2: nowIso }),
        modelName: 'gemini-4-hydrogen',
        settingsJson: JSON.stringify(settings),
        stateJson: JSON.stringify(state),
      })
      .returning();

    const wfPatch: Record<string, unknown> = {
      scriptProjectKey: projectKey,
      updatedAt: new Date(),
    };
    if (wf.projectStatus === 'NOT STARTED') {
      wfPatch.projectStatus = 'IN PROGRESS';
    }

    const updated = await db
      .update(ytmWorkflowProjects)
      .set(wfPatch)
      .where(eq(ytmWorkflowProjects.id, wfId))
      .returning();

    return okJson(res, {
      workflow: hydrateWorkflow(updated[0]),
      scriptProjectKey: projectKey,
      scriptProject: hydrateLinkedScriptProject(insertedScript[0]),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to link Scriptwriting Studio project.');
  }
});

router.post(
  '/workflow/projects/:id/thumbnail-upload',
  imageUpload.single('thumbnail'),
  async (req: AuthRequest, res) => {
    try {
      const { workspace } = await resolveAuthorizedWorkspace({
        userId: req.dbUser!.id,
        workspaceKey: getWorkspaceKeyFromReq(req),
        requiredPermission: 'workflow:write',
      });
      const wfId = Number.parseInt(String(req.params.id), 10);
      if (!req.file || !req.file.mimetype.startsWith('image/')) {
        return failJson(res, 400, 'INVALID_IMAGE', 'Please upload a valid PNG, JPG, or WebP image file.');
      }

      const rows = await db
        .select()
        .from(ytmWorkflowProjects)
        .where(and(eq(ytmWorkflowProjects.id, wfId), eq(ytmWorkflowProjects.workspaceId, workspace.id)))
        .limit(1);
      if (!rows[0]) {
        return failJson(res, 404, 'NOT_FOUND', 'Workflow project not found.');
      }

      const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
      const asset = await db
        .insert(ytmAssets)
        .values({
          workspaceId: workspace.id,
          uploadedByUserId: req.dbUser!.id,
          assetType: 'thumbnail',
          title: `${rows[0].title.slice(0, 80)} Thumbnail`,
          mimeType: req.file.mimetype,
          fileSizeBytes: req.file.size,
          dataUrlOrPath: dataUrl,
          tagsJson: JSON.stringify(['thumbnail', `workflow-${wfId}`]),
        })
        .returning();

      const wf = hydrateWorkflow(rows[0]);
      const nextStage4: YtmWorkflowStage4Thumbnail = {
        ...wf.stage4Thumbnail,
        uploadedThumbnailAssetId: asset[0].id,
        uploadedThumbnailUrl: dataUrl,
      };
      const updated = await db
        .update(ytmWorkflowProjects)
        .set({ stage4ThumbnailJson: JSON.stringify(nextStage4), updatedAt: new Date() })
        .where(eq(ytmWorkflowProjects.id, wfId))
        .returning();

      return okJson(res, {
        workflow: hydrateWorkflow(updated[0]),
        assetId: asset[0].id,
      });
    } catch (err) {
      return handleError(res, err, 'Failed to upload thumbnail image.');
    }
  }
);

router.patch('/distribution/:assetId', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const assetId = Number.parseInt(String(req.params.assetId), 10);
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const k of ['title', 'bodyCopy', 'hashtags', 'imagePrompt', 'scheduledAt', 'publishedExternalUrl'] as const) {
      if (req.body?.[k] !== undefined) patch[k] = req.body[k];
    }
    if (Array.isArray(req.body?.carouselSlides)) {
      patch.carouselSlidesJson = JSON.stringify(req.body.carouselSlides);
    }
    if (['draft', 'approved', 'manually_published'].includes(req.body?.status)) {
      // Security & honesty: never allow client to force 'published_api' without an authorized API publish response
      patch.status = req.body.status;
    }

    const updated = await db
      .update(ytmDistributionAssets)
      .set(patch)
      .where(
        and(
          eq(ytmDistributionAssets.id, assetId),
          eq(ytmDistributionAssets.workspaceId, workspace.id)
        )
      )
      .returning();

    if (!updated[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Distribution asset not found.');
    }
    return okJson(res, {
      asset: {
        ...updated[0],
        carouselSlides: safeJsonParse<string[]>(updated[0].carouselSlidesJson, []),
        createdAt: updated[0].createdAt.toISOString(),
        updatedAt: updated[0].updatedAt.toISOString(),
      },
    });
  } catch (err) {
    return handleError(res, err, 'Unable to update distribution asset.');
  }
});

// ==============================================================================
// 5. YOUTUBE CHANNEL OAUTH & VIDEO PUBLISHING
// ==============================================================================
router.get('/auth/status', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const oauthStatus = getYtmOAuthConfigStatus();
    const connectedChannel = await getWorkspaceConnectedChannel(workspace.id);
    const redirectUri = resolveOAuthRedirectUri(req);
    const probeGoogleEndpoint = req.query.probe === '1';
    const configValidation = await buildYtmOAuthConfigValidation({
      redirectUri,
      probeGoogleEndpoint,
    });

    const missingScopes = connectedChannel
      ? YOUTUBE_OAUTH_SCOPES.filter((s) => !connectedChannel.scopes.includes(s))
      : [];

    let connectionState:
      | 'not_connected'
      | 'connected'
      | 'expired'
      | 'permission_required'
      | 'error' = 'not_connected';
    let statusLabel = 'Not Connected';
    let statusMessage = 'No YouTube channel connected to this workspace.';

    if (!configValidation.valid) {
      connectionState = connectedChannel ? 'error' : 'not_connected';
      statusLabel = configValidation.code === 'OAUTH_INVALID_CLIENT' ? 'Invalid Client' : 'Configuration Incomplete';
      statusMessage = configValidation.details;
    } else if (connectedChannel) {
      if (connectedChannel.connectionStatus === 'reconnect_required') {
        connectionState = 'expired';
        statusLabel = 'Reconnect Required';
        statusMessage = 'Stored OAuth refresh token expired or was revoked. Reconnect your channel.';
      } else if (missingScopes.length > 0) {
        connectionState = 'permission_required';
        statusLabel = 'Permissions Incomplete';
        statusMessage = 'Channel is connected, but some required YouTube scopes were not granted.';
      } else {
        connectionState = 'connected';
        statusLabel = 'Connected';
        statusMessage = 'Official YouTube Data, Analytics & Upload scopes active.';
      }
    }

    return okJson(res, {
      oauthConfigured: configValidation.valid,
      configValidation,
      missingVars: oauthStatus.missingVars,
      hasEncryptionKey: oauthStatus.hasEncryptionKey,
      redirectUri,
      connectionState,
      statusLabel,
      statusMessage,
      missingScopes,
      connectedChannel,
    });
  } catch (err) {
    return handleError(res, err, 'Unable to inspect YouTube OAuth connection status.');
  }
});

async function handleOAuthInitiate(req: AuthRequest, res: express.Response) {
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'oauth:manage',
    });

    const redirectUri = resolveOAuthRedirectUri(req);
    const oauthConfig = getGoogleOAuthConfig(process.env, redirectUri);
    const validation = await buildYtmOAuthConfigValidation({
      redirectUri,
      probeGoogleEndpoint: false,
    });

    if (!validation.valid) {
      const errorMessage = validation.details || validation.message;
      const setupRequired =
        !oauthConfig.configured ||
        Boolean(validation.diagnostics?.clientIdIsPlaceholderLiteral) ||
        Boolean(validation.diagnostics?.clientSecretIsPlaceholderLiteral);
      return res.status(400).json({
        ok: false,
        success: false,
        code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
        message: errorMessage,
        redirectUri: validation.redirectUri,
        missingVars: validation.missingVars,
        diagnostics: validation.diagnostics,
        error: {
          code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
          message: errorMessage,
          setupRequired,
          missingVars: validation.missingVars,
          redirectUri: validation.redirectUri,
          diagnostics: validation.diagnostics,
        },
      });
    }

    const state = signOAuthState({
      workspaceId: workspace.id,
      workspaceKey: workspace.workspaceKey,
      userId: req.dbUser!.id,
      redirectUri: validation.redirectUri,
    });

    const { authorizationUrl, diagnostics, credentialDiagnostics } =
      buildValidatedGoogleOAuthAuthorizationUrl({
        redirectUri: validation.redirectUri,
        state,
      });

    const googleProbe = await verifyGoogleOAuthClientWithGoogle(authorizationUrl);
    credentialDiagnostics.googleEndpointCheck = googleProbe.status;
    credentialDiagnostics.googleEndpointMessage = googleProbe.message;

    if (googleProbe.status === 'invalid_client') {
      console.warn(
        '[YTM OAuth] Preflight client check returned invalid_client:',
        JSON.stringify({
          source: credentialDiagnostics.source,
          clientIdLength: credentialDiagnostics.clientIdLength,
          clientIdFormatValid: credentialDiagnostics.clientIdFormatValid,
          redirectUri: validation.redirectUri,
        })
      );
      return res.status(400).json({
        ok: false,
        success: false,
        code: 'OAUTH_INVALID_CLIENT',
        message: googleProbe.message,
        redirectUri: validation.redirectUri,
        diagnostics: credentialDiagnostics,
        error: {
          code: 'OAUTH_INVALID_CLIENT',
          message: googleProbe.message,
          redirectUri: validation.redirectUri,
          diagnostics,
          credentialDiagnostics,
        },
      });
    }

    if (googleProbe.status === 'redirect_uri_mismatch') {
      return res.status(400).json({
        ok: false,
        success: false,
        code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
        message: googleProbe.message,
        redirectUri: validation.redirectUri,
        diagnostics: credentialDiagnostics,
        error: {
          code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
          message: googleProbe.message,
          redirectUri: validation.redirectUri,
          diagnostics,
          credentialDiagnostics,
        },
      });
    }

    return okJson(res, {
      authorizationUrl,
      url: authorizationUrl,
      redirectUri: validation.redirectUri,
      diagnostics,
      credentialDiagnostics,
    });
  } catch (err) {
    return handleError(res, err, 'Failed to initiate Google OAuth.');
  }
}

router.get('/auth/google', handleOAuthInitiate);
router.get('/auth/google/', handleOAuthInitiate);

router.post('/auth/disconnect', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'oauth:manage',
    });

    await disconnectWorkspaceChannel(workspace.id);
    await recordYtmActivity({
      workspaceId: workspace.id,
      actorUserId: req.dbUser!.id,
      actorEmail: req.dbUser!.email,
      action: 'DISCONNECT_YOUTUBE_CHANNEL',
      resourceType: 'connected_account',
    });
    return okJson(res, { disconnected: true });
  } catch (err) {
    return handleError(res, err, 'Failed to disconnect YouTube channel.');
  }
});

router.get('/youtube/videos', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'analytics:read',
    });
    const videos = await fetchAuthorizedChannelVideos(workspace.id);
    return okJson(res, { videos });
  } catch (err) {
    return handleError(res, err, 'Unable to load connected channel videos.');
  }
});

router.get('/youtube/publishing-jobs', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const jobs = await db
      .select()
      .from(ytmPublishingJobs)
      .where(eq(ytmPublishingJobs.workspaceId, workspace.id))
      .orderBy(desc(ytmPublishingJobs.createdAt))
      .limit(20);

    return okJson(res, {
      jobs: jobs.map((j) => ({
        ...j,
        tags: safeJsonParse<string[]>(j.tagsJson, []),
        createdAt: j.createdAt.toISOString(),
        updatedAt: j.updatedAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load publishing jobs.');
  }
});

router.post(
  '/youtube/upload',
  videoUpload.single('video'),
  async (req: AuthRequest, res) => {
    const tempFilePath = req.file?.path;
    try {
      const { workspace } = await resolveAuthorizedWorkspace({
        userId: req.dbUser!.id,
        workspaceKey: getWorkspaceKeyFromReq(req),
        requiredPermission: 'publish:youtube',
      });

      if (!req.file) {
        return failJson(res, 400, 'VIDEO_FILE_REQUIRED', 'Select a video file to upload.');
      }

      const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
      if (!title) {
        return failJson(res, 400, 'INVALID_REQUEST', 'Video title is required for YouTube upload.');
      }

      const description = typeof req.body?.description === 'string' ? req.body.description : '';
      const rawTags = typeof req.body?.tags === 'string' ? req.body.tags : '';
      const tags = rawTags
        .split(',')
        .map((t: string) => t.trim())
        .filter(Boolean)
        .slice(0, 30);
      const privacyStatus = ['public', 'unlisted', 'private'].includes(req.body?.privacyStatus)
        ? (req.body.privacyStatus as 'public' | 'unlisted' | 'private')
        : 'private';
      const categoryId = typeof req.body?.categoryId === 'string' ? req.body.categoryId : '22';
      const publishAt = typeof req.body?.publishAt === 'string' && req.body.publishAt ? req.body.publishAt : null;
      const workflowProjectId = req.body?.workflowProjectId
        ? Number.parseInt(String(req.body.workflowProjectId), 10)
        : null;

      const jobRows = await db
        .insert(ytmPublishingJobs)
        .values({
          workspaceId: workspace.id,
          workflowProjectId: Number.isFinite(workflowProjectId) ? workflowProjectId : null,
          initiatedByUserId: req.dbUser!.id,
          title: title.slice(0, 100),
          description: description.slice(0, 5000),
          tagsJson: JSON.stringify(tags),
          categoryId,
          privacyStatus,
          publishAt,
          fileName: req.file.originalname,
          fileSizeBytes: req.file.size,
          status: 'uploading',
          progressPercent: 5,
        })
        .returning();

      const job = jobRows[0];

      try {
        const result = await executeResumableYouTubeUpload({
          workspaceId: workspace.id,
          filePath: req.file.path,
          mimeType: req.file.mimetype,
          title,
          description,
          tags,
          categoryId,
          privacyStatus,
          publishAt,
          onProgress: async (percent) => {
            await db
              .update(ytmPublishingJobs)
              .set({ progressPercent: percent, updatedAt: new Date() })
              .where(eq(ytmPublishingJobs.id, job.id));
          },
        });

        const completed = await db
          .update(ytmPublishingJobs)
          .set({
            status: 'completed',
            progressPercent: 100,
            youtubeVideoId: result.videoId,
            youtubeVideoUrl: result.videoUrl,
            updatedAt: new Date(),
          })
          .where(eq(ytmPublishingJobs.id, job.id))
          .returning();

        if (Number.isFinite(workflowProjectId)) {
          await db
            .update(ytmWorkflowProjects)
            .set({
              youtubeVideoId: result.videoId,
              youtubeVideoUrl: result.videoUrl,
              projectStatus: 'PUBLISHED',
              completedAt: new Date(),
              updatedAt: new Date(),
            })
            .where(
              and(
                eq(ytmWorkflowProjects.id, workflowProjectId!),
                eq(ytmWorkflowProjects.workspaceId, workspace.id)
              )
            );
        }

        await recordYtmActivity({
          workspaceId: workspace.id,
          actorUserId: req.dbUser!.id,
          actorEmail: req.dbUser!.email,
          action: 'PUBLISH_YOUTUBE_VIDEO',
          resourceType: 'publishing_job',
          resourceId: result.videoId,
        });

        return okJson(res, {
          job: {
            ...completed[0],
            tags,
            createdAt: completed[0].createdAt.toISOString(),
            updatedAt: completed[0].updatedAt.toISOString(),
          },
        });
      } catch (uploadErr: unknown) {
        const msg = uploadErr instanceof Error ? uploadErr.message : 'YouTube upload failed.';
        await db
          .update(ytmPublishingJobs)
          .set({
            status: 'failed',
            errorMessage: msg.slice(0, 500),
            updatedAt: new Date(),
          })
          .where(eq(ytmPublishingJobs.id, job.id));
        throw uploadErr;
      }
    } catch (err) {
      return handleError(res, err, 'Video publishing failed.');
    } finally {
      if (tempFilePath) {
        await fs.unlink(tempFilePath).catch(() => {});
      }
    }
  }
);

// ==============================================================================
// 6. ANALYTICS & GROWTH (Own Connected Channel Only)
// ==============================================================================
router.get('/analytics', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'analytics:read',
    });

    const endDefault = new Date().toISOString().slice(0, 10);
    const startDefault = new Date(Date.now() - 28 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
    const startDate =
      typeof req.query.startDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.query.startDate)
        ? req.query.startDate
        : startDefault;
    const endDate =
      typeof req.query.endDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.query.endDate)
        ? req.query.endDate
        : endDefault;

    const report = await fetchAuthorizedChannelAnalytics({
      workspaceId: workspace.id,
      startDate,
      endDate,
    });

    return okJson(res, { report });
  } catch (err) {
    return handleError(res, err, 'Unable to load YouTube Analytics.');
  }
});

router.post('/analytics/insights', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'analytics:read',
    });

    let report = req.body?.report as YtmChannelAnalyticsReport | undefined;
    if (!report) {
      const snaps = await db
        .select()
        .from(ytmAnalyticsSnapshots)
        .where(eq(ytmAnalyticsSnapshots.workspaceId, workspace.id))
        .orderBy(desc(ytmAnalyticsSnapshots.retrievedAt))
        .limit(1);
      if (snaps[0]) {
        report = safeJsonParse<YtmChannelAnalyticsReport | undefined>(snaps[0].metricsJson, undefined);
      }
    }

    if (!report) {
      return failJson(
        res,
        400,
        'ANALYTICS_REQUIRED',
        'Connect your YouTube channel and load Analytics data before generating insights.'
      );
    }

    const insights = await aiYtmAnalyticsInsights(report);
    return okJson(res, { insights });
  } catch (err) {
    return handleError(res, err, 'Failed to generate AI performance summary.');
  }
});

// ==============================================================================
// 7. EARN (Monetization Categories + API vs Manual + Brand Deal CRM)
// ==============================================================================
router.get('/earn/overview', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'earn:read',
    });

    const [entries, deals] = await Promise.all([
      db
        .select()
        .from(ytmRevenueEntries)
        .where(eq(ytmRevenueEntries.workspaceId, workspace.id))
        .orderBy(desc(ytmRevenueEntries.monthKey), desc(ytmRevenueEntries.createdAt)),
      db
        .select()
        .from(ytmBrandDeals)
        .where(eq(ytmBrandDeals.workspaceId, workspace.id))
        .orderBy(desc(ytmBrandDeals.updatedAt)),
    ]);

    let apiMonetary: {
      available: boolean;
      estimatedRevenue: number | null;
      currency: string;
      note: string;
    } | null = null;

    if (req.query.includeApiMonetary === '1') {
      try {
        const endDate = new Date().toISOString().slice(0, 10);
        const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
        apiMonetary = await fetchAuthorizedMonetaryRevenue({
          workspaceId: workspace.id,
          startDate,
          endDate,
        });
      } catch (monErr: unknown) {
        apiMonetary = {
          available: false,
          estimatedRevenue: null,
          currency: 'USD',
          note: monErr instanceof Error ? monErr.message : 'Channel not connected for Monetary API.',
        };
      }
    }

    const categoryTotals = YTM_REVENUE_CATEGORIES.map((cat) => {
      const catEntries = entries.filter((e) => e.category === cat.id);
      return {
        category: cat.id,
        label: cat.label,
        receivedCents: catEntries
          .filter((e) => e.paymentStatus === 'received')
          .reduce((acc, e) => acc + e.amountCents, 0),
        pendingCents: catEntries
          .filter((e) => e.paymentStatus === 'pending')
          .reduce((acc, e) => acc + e.amountCents, 0),
        projectedCents: catEntries
          .filter((e) => e.paymentStatus === 'projected')
          .reduce((acc, e) => acc + e.amountCents, 0),
        targetCents: catEntries.find((e) => e.targetCents)?.targetCents ?? null,
      };
    });

    return okJson(res, {
      entries: entries.map((e) => ({
        ...e,
        createdAt: e.createdAt.toISOString(),
        updatedAt: e.updatedAt.toISOString(),
      })),
      deals: deals.map((d) => ({
        ...d,
        createdAt: d.createdAt.toISOString(),
        updatedAt: d.updatedAt.toISOString(),
      })),
      categoryTotals,
      apiMonetary,
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load monetization data.');
  }
});

router.post('/earn/entries', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'earn:write',
    });

    const validCats: YtmRevenueCategory[] = [
      'ads',
      'membership',
      'brands_shopping',
      'collaborations',
      'super_thanks',
      'other',
    ];
    const category = validCats.includes(req.body?.category) ? req.body.category : 'other';
    const sourceLabel = typeof req.body?.sourceLabel === 'string' ? req.body.sourceLabel.trim() : '';
    if (!sourceLabel) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Revenue source label is required.');
    }

    const amountCents = Math.max(0, Math.round(Number(req.body?.amountCents || 0)));
    const inserted = await db
      .insert(ytmRevenueEntries)
      .values({
        workspaceId: workspace.id,
        createdByUserId: req.dbUser!.id,
        category,
        sourceLabel: sourceLabel.slice(0, 140),
        entryType: ['api', 'manual', 'estimate'].includes(req.body?.entryType)
          ? req.body.entryType
          : 'manual',
        amountCents,
        currency: typeof req.body?.currency === 'string' ? req.body.currency.toUpperCase().slice(0, 8) : 'USD',
        monthKey:
          typeof req.body?.monthKey === 'string' && /^\d{4}-\d{2}$/.test(req.body.monthKey)
            ? req.body.monthKey
            : new Date().toISOString().slice(0, 7),
        paymentStatus: ['received', 'pending', 'projected'].includes(req.body?.paymentStatus)
          ? req.body.paymentStatus
          : 'pending',
        targetCents:
          req.body?.targetCents !== undefined && req.body?.targetCents !== null
            ? Math.max(0, Math.round(Number(req.body.targetCents)))
            : null,
        notes: typeof req.body?.notes === 'string' ? req.body.notes.slice(0, 600) : '',
      })
      .returning();

    return okJson(
      res,
      {
        entry: {
          ...inserted[0],
          createdAt: inserted[0].createdAt.toISOString(),
          updatedAt: inserted[0].updatedAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to add revenue entry.');
  }
});

router.delete('/earn/entries/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'earn:write',
    });
    const entryId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmRevenueEntries)
      .where(
        and(eq(ytmRevenueEntries.id, entryId), eq(ytmRevenueEntries.workspaceId, workspace.id))
      );
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete revenue entry.');
  }
});

router.post('/earn/deals', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'earn:write',
    });
    const brandName = typeof req.body?.brandName === 'string' ? req.body.brandName.trim() : '';
    if (!brandName) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Brand name is required.');
    }

    const inserted = await db
      .insert(ytmBrandDeals)
      .values({
        workspaceId: workspace.id,
        createdByUserId: req.dbUser!.id,
        brandName: brandName.slice(0, 140),
        contactDetails:
          typeof req.body?.contactDetails === 'string' ? req.body.contactDetails.slice(0, 300) : '',
        campaign: typeof req.body?.campaign === 'string' ? req.body.campaign.slice(0, 200) : '',
        dealAmountCents: Math.max(0, Math.round(Number(req.body?.dealAmountCents || 0))),
        currency: typeof req.body?.currency === 'string' ? req.body.currency.toUpperCase().slice(0, 8) : 'USD',
        deliverables:
          typeof req.body?.deliverables === 'string' ? req.body.deliverables.slice(0, 1000) : '',
        deadline: typeof req.body?.deadline === 'string' ? req.body.deadline : null,
        contractStatus: ['lead', 'negotiating', 'signed', 'delivered', 'cancelled'].includes(
          req.body?.contractStatus
        )
          ? req.body.contractStatus
          : 'negotiating',
        paymentStatus: ['unpaid', 'invoiced', 'partial', 'paid'].includes(req.body?.paymentStatus)
          ? req.body.paymentStatus
          : 'unpaid',
        followUpDate: typeof req.body?.followUpDate === 'string' ? req.body.followUpDate : null,
        notes: typeof req.body?.notes === 'string' ? req.body.notes.slice(0, 1000) : '',
      })
      .returning();

    return okJson(
      res,
      {
        deal: {
          ...inserted[0],
          createdAt: inserted[0].createdAt.toISOString(),
          updatedAt: inserted[0].updatedAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to create brand deal.');
  }
});

router.patch('/earn/deals/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'earn:write',
    });
    const dealId = Number.parseInt(String(req.params.id), 10);
    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const k of [
      'brandName',
      'contactDetails',
      'campaign',
      'dealAmountCents',
      'deliverables',
      'deadline',
      'contractStatus',
      'paymentStatus',
      'followUpDate',
      'notes',
    ] as const) {
      if (req.body?.[k] !== undefined) patch[k] = req.body[k];
    }

    const updated = await db
      .update(ytmBrandDeals)
      .set(patch)
      .where(and(eq(ytmBrandDeals.id, dealId), eq(ytmBrandDeals.workspaceId, workspace.id)))
      .returning();
    if (!updated[0]) return failJson(res, 404, 'NOT_FOUND', 'Brand deal not found.');
    return okJson(res, {
      deal: {
        ...updated[0],
        createdAt: updated[0].createdAt.toISOString(),
        updatedAt: updated[0].updatedAt.toISOString(),
      },
    });
  } catch (err) {
    return handleError(res, err, 'Failed to update brand deal.');
  }
});

router.delete('/earn/deals/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'earn:write',
    });
    const dealId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmBrandDeals)
      .where(and(eq(ytmBrandDeals.id, dealId), eq(ytmBrandDeals.workspaceId, workspace.id)));
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete brand deal.');
  }
});

// ==============================================================================
// 8. COMMUNITY (Comments, AI Reply Drafting + User Approval, Community Planner)
// ==============================================================================
router.get('/community', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const items = await db
      .select()
      .from(ytmCommunityItems)
      .where(eq(ytmCommunityItems.workspaceId, workspace.id))
      .orderBy(desc(ytmCommunityItems.createdAt))
      .limit(100);

    return okJson(res, {
      items: items.map((c) => ({
        ...c,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load community items.');
  }
});

router.post('/community/sync-comments', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'community:write',
    });
    const videoId = typeof req.body?.videoId === 'string' ? req.body.videoId.trim() : undefined;
    const fetched = await fetchAuthorizedComments(workspace.id, videoId);

    for (const c of fetched) {
      const existing = await db
        .select()
        .from(ytmCommunityItems)
        .where(
          and(
            eq(ytmCommunityItems.workspaceId, workspace.id),
            eq(ytmCommunityItems.externalCommentId, c.externalCommentId)
          )
        )
        .limit(1);

      if (!existing[0]) {
        const lower = c.content.toLowerCase();
        const cat = lower.includes('?') ? 'question' : lower.includes('love') || lower.includes('suggest') ? 'feedback' : 'general';
        await db.insert(ytmCommunityItems).values({
          workspaceId: workspace.id,
          itemType: 'comment',
          externalCommentId: c.externalCommentId,
          videoId: c.videoId,
          authorName: c.authorName,
          content: c.content,
          category: cat,
          replyStatus: 'none',
        });
      }
    }

    const updated = await db
      .select()
      .from(ytmCommunityItems)
      .where(eq(ytmCommunityItems.workspaceId, workspace.id))
      .orderBy(desc(ytmCommunityItems.createdAt))
      .limit(100);

    return okJson(res, {
      syncedCount: fetched.length,
      items: updated.map((c) => ({
        ...c,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Failed to sync YouTube comments.');
  }
});

router.post('/community/items', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'community:write',
    });
    const content = typeof req.body?.content === 'string' ? req.body.content.trim() : '';
    if (!content) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Content text is required.');
    }

    const inserted = await db
      .insert(ytmCommunityItems)
      .values({
        workspaceId: workspace.id,
        itemType: ['comment', 'community_post', 'engagement_task'].includes(req.body?.itemType)
          ? req.body.itemType
          : 'community_post',
        authorName: typeof req.body?.authorName === 'string' ? req.body.authorName : req.dbUser!.displayName || 'Creator',
        content: content.slice(0, 3000),
        category: ['question', 'feedback', 'general'].includes(req.body?.category)
          ? req.body.category
          : 'general',
        scheduledAt: typeof req.body?.scheduledAt === 'string' ? req.body.scheduledAt : null,
        replyStatus: 'none',
      })
      .returning();

    return okJson(
      res,
      {
        item: {
          ...inserted[0],
          createdAt: inserted[0].createdAt.toISOString(),
          updatedAt: inserted[0].updatedAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to create community item.');
  }
});

router.post('/community/items/:id/draft-reply', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'community:write',
    });
    const itemId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmCommunityItems)
      .where(and(eq(ytmCommunityItems.id, itemId), eq(ytmCommunityItems.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) return failJson(res, 404, 'NOT_FOUND', 'Community item not found.');

    const draft = await aiYtmDraftCommentReply({
      commentText: rows[0].content,
      authorName: rows[0].authorName || 'Viewer',
      videoTitle: rows[0].videoTitle,
      tone: req.body?.tone,
    });

    const updated = await db
      .update(ytmCommunityItems)
      .set({
        aiDraftReply: draft,
        replyStatus: 'drafted',
        updatedAt: new Date(),
      })
      .where(eq(ytmCommunityItems.id, itemId))
      .returning();

    return okJson(res, {
      item: {
        ...updated[0],
        createdAt: updated[0].createdAt.toISOString(),
        updatedAt: updated[0].updatedAt.toISOString(),
      },
    });
  } catch (err) {
    return handleError(res, err, 'Failed to draft AI reply.');
  }
});

router.post('/community/items/:id/publish-reply', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'community:write',
    });
    const itemId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmCommunityItems)
      .where(and(eq(ytmCommunityItems.id, itemId), eq(ytmCommunityItems.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) return failJson(res, 404, 'NOT_FOUND', 'Community item not found.');

    const replyText =
      typeof req.body?.replyText === 'string' && req.body.replyText.trim()
        ? req.body.replyText.trim()
        : rows[0].aiDraftReply;
    const mode = req.body?.mode === 'manual' ? 'manual' : 'api';

    if (!replyText) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Reply text cannot be empty.');
    }

    let nextStatus: 'published_api' | 'handled_manually' = 'handled_manually';
    if (mode === 'api' && rows[0].externalCommentId) {
      await postAuthorizedCommentReply({
        workspaceId: workspace.id,
        parentCommentId: rows[0].externalCommentId,
        replyText,
      });
      nextStatus = 'published_api';
    }

    const updated = await db
      .update(ytmCommunityItems)
      .set({
        aiDraftReply: replyText,
        replyStatus: nextStatus,
        updatedAt: new Date(),
      })
      .where(eq(ytmCommunityItems.id, itemId))
      .returning();

    return okJson(res, {
      item: {
        ...updated[0],
        createdAt: updated[0].createdAt.toISOString(),
        updatedAt: updated[0].updatedAt.toISOString(),
      },
    });
  } catch (err) {
    return handleError(res, err, 'Failed to publish comment reply.');
  }
});

router.delete('/community/items/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'community:write',
    });
    const itemId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmCommunityItems)
      .where(and(eq(ytmCommunityItems.id, itemId), eq(ytmCommunityItems.workspaceId, workspace.id)));
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete community item.');
  }
});

// ==============================================================================
// 9. TEAM & DELEGATION (Members, Invitations, Strict Role Checks)
// ==============================================================================
router.get('/team', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const [memberRows, inviteRows] = await Promise.all([
      db
        .select({
          member: ytmWorkspaceMembers,
          user: users,
        })
        .from(ytmWorkspaceMembers)
        .innerJoin(users, eq(ytmWorkspaceMembers.userId, users.id))
        .where(eq(ytmWorkspaceMembers.workspaceId, workspace.id)),
      db
        .select()
        .from(ytmTeamInvitations)
        .where(eq(ytmTeamInvitations.workspaceId, workspace.id))
        .orderBy(desc(ytmTeamInvitations.createdAt)),
    ]);

    return okJson(res, {
      members: memberRows.map((r) => ({
        id: r.member.id,
        workspaceId: r.member.workspaceId,
        userId: r.member.userId,
        email: r.user.email,
        displayName: r.user.displayName,
        photoUrl: r.user.photoUrl,
        role: normalizeYtmRole(r.member.role),
        status: r.member.status,
        createdAt: r.member.createdAt.toISOString(),
      })),
      invitations: inviteRows.map((i) => ({
        id: i.id,
        workspaceId: i.workspaceId,
        email: i.email,
        role: normalizeYtmRole(i.role),
        token: i.token,
        status: i.status,
        expiresAt: i.expiresAt.toISOString(),
        createdAt: i.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Failed to load team details.');
  }
});

router.post('/team/invite', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'team:manage',
    });

    const email = typeof req.body?.email === 'string' ? req.body.email.trim().toLowerCase() : '';
    if (!email || !email.includes('@')) {
      return failJson(res, 400, 'INVALID_EMAIL', 'Please enter a valid teammate email address.');
    }

    const role = normalizeYtmRole(req.body?.role);
    if (role === 'owner') {
      return failJson(res, 400, 'INVALID_ROLE', 'Workspace ownership cannot be assigned via invite.');
    }

    const token = `inv_${crypto.randomBytes(12).toString('hex')}`;
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    // If user already has an account in MediaToolsHub, also notify them
    const existingUsers = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    const invite = await db
      .insert(ytmTeamInvitations)
      .values({
        workspaceId: workspace.id,
        email,
        role,
        token,
        invitedByUserId: req.dbUser!.id,
        status: 'pending',
        expiresAt,
      })
      .returning();

    if (existingUsers[0]) {
      await createYtmNotification({
        workspaceId: workspace.id,
        userId: existingUsers[0].id,
        title: `Invited to ${workspace.name}`,
        message: `${req.dbUser!.email} invited you as ${role}. Open YouTube Management to accept.`,
        linkSection: 'team',
      });
    }

    await recordYtmActivity({
      workspaceId: workspace.id,
      actorUserId: req.dbUser!.id,
      actorEmail: req.dbUser!.email,
      action: 'INVITE_TEAM_MEMBER',
      resourceType: 'invitation',
      resourceId: invite[0].id,
      details: { email, role },
    });

    return okJson(
      res,
      {
        invitation: {
          ...invite[0],
          role,
          expiresAt: invite[0].expiresAt.toISOString(),
          createdAt: invite[0].createdAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to invite team member.');
  }
});

router.patch('/team/members/:memberId', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'team:manage',
    });

    const memberId = Number.parseInt(String(req.params.memberId), 10);
    const rows = await db
      .select()
      .from(ytmWorkspaceMembers)
      .where(
        and(
          eq(ytmWorkspaceMembers.id, memberId),
          eq(ytmWorkspaceMembers.workspaceId, workspace.id)
        )
      )
      .limit(1);

    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Team member not found.');
    }
    if (rows[0].role === 'owner') {
      return failJson(res, 400, 'CANNOT_MODIFY_OWNER', 'Workspace owner role cannot be downgraded or removed.');
    }

    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (req.body?.role) {
      const nextRole = normalizeYtmRole(req.body.role);
      if (nextRole === 'owner') {
        return failJson(res, 400, 'INVALID_ROLE', 'Cannot promote another member to owner.');
      }
      patch.role = nextRole;
    }
    if (['active', 'revoked'].includes(req.body?.status)) {
      patch.status = req.body.status;
    }

    const updated = await db
      .update(ytmWorkspaceMembers)
      .set(patch)
      .where(eq(ytmWorkspaceMembers.id, memberId))
      .returning();

    return okJson(res, { member: updated[0] });
  } catch (err) {
    return handleError(res, err, 'Failed to update team member.');
  }
});

// ==============================================================================
// 10. OTHERS (Assets, Prompts, Templates, Notifications, Export, Activity)
// ==============================================================================
router.get('/others', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const [assets, notifications, activity] = await Promise.all([
      db
        .select()
        .from(ytmAssets)
        .where(eq(ytmAssets.workspaceId, workspace.id))
        .orderBy(desc(ytmAssets.createdAt))
        .limit(80),
      db
        .select()
        .from(ytmNotifications)
        .where(
          and(
            eq(ytmNotifications.workspaceId, workspace.id),
            eq(ytmNotifications.userId, req.dbUser!.id)
          )
        )
        .orderBy(desc(ytmNotifications.createdAt))
        .limit(30),
      db
        .select()
        .from(ytmActivityLogs)
        .where(eq(ytmActivityLogs.workspaceId, workspace.id))
        .orderBy(desc(ytmActivityLogs.createdAt))
        .limit(50),
    ]);

    return okJson(res, {
      assets: assets.map((a) => ({
        ...a,
        tags: safeJsonParse<string[]>(a.tagsJson, []),
        createdAt: a.createdAt.toISOString(),
      })),
      notifications: notifications.map((n) => ({
        ...n,
        createdAt: n.createdAt.toISOString(),
      })),
      activity: activity.map((l) => ({
        ...l,
        createdAt: l.createdAt.toISOString(),
      })),
    });
  } catch (err) {
    return handleError(res, err, 'Unable to load workspace library & logs.');
  }
});

router.post('/others/assets', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });

    const title = typeof req.body?.title === 'string' ? req.body.title.trim() : '';
    if (!title) return failJson(res, 400, 'INVALID_REQUEST', 'Asset title is required.');

    const inserted = await db
      .insert(ytmAssets)
      .values({
        workspaceId: workspace.id,
        uploadedByUserId: req.dbUser!.id,
        assetType: ['thumbnail', 'video', 'prompt', 'template', 'export'].includes(req.body?.assetType)
          ? req.body.assetType
          : 'prompt',
        title: title.slice(0, 140),
        mimeType: 'text/plain',
        fileSizeBytes: String(req.body?.promptText || '').length,
        dataUrlOrPath: typeof req.body?.dataUrlOrPath === 'string' ? req.body.dataUrlOrPath : '',
        promptText: typeof req.body?.promptText === 'string' ? req.body.promptText.slice(0, 4000) : '',
        tagsJson: JSON.stringify(Array.isArray(req.body?.tags) ? req.body.tags : []),
      })
      .returning();

    return okJson(
      res,
      {
        asset: {
          ...inserted[0],
          tags: safeJsonParse<string[]>(inserted[0].tagsJson, []),
          createdAt: inserted[0].createdAt.toISOString(),
        },
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to save asset.');
  }
});

router.delete('/others/assets/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const assetId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmAssets)
      .where(and(eq(ytmAssets.id, assetId), eq(ytmAssets.workspaceId, workspace.id)));
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete asset.');
  }
});

router.post('/others/notifications/read-all', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    await db
      .update(ytmNotifications)
      .set({ isRead: true })
      .where(
        and(
          eq(ytmNotifications.workspaceId, workspace.id),
          eq(ytmNotifications.userId, req.dbUser!.id)
        )
      );
    return okJson(res, { updated: true });
  } catch (err) {
    return handleError(res, err, 'Failed to mark notifications read.');
  }
});

router.get('/others/export', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const format = req.query.format === 'csv' ? 'csv' : 'json';

    const [projects, tasks, workflows, deals, revenue] = await Promise.all([
      db.select().from(ytmPlannerProjects).where(eq(ytmPlannerProjects.workspaceId, workspace.id)),
      db.select().from(ytmPlannerTasks).where(eq(ytmPlannerTasks.workspaceId, workspace.id)),
      db.select().from(ytmWorkflowProjects).where(eq(ytmWorkflowProjects.workspaceId, workspace.id)),
      db.select().from(ytmBrandDeals).where(eq(ytmBrandDeals.workspaceId, workspace.id)),
      db.select().from(ytmRevenueEntries).where(eq(ytmRevenueEntries.workspaceId, workspace.id)),
    ]);

    if (format === 'csv') {
      const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
      const lines = [
        ['Type', 'Title', 'Status', 'Date', 'Notes'].join(','),
        ...projects.map((p) =>
          [esc('Planner Video'), esc(p.title), esc(p.status), esc(p.plannedDate || ''), esc(p.topic)].join(',')
        ),
        ...tasks.map((t) =>
          [esc('Task'), esc(t.taskName), esc(t.status), esc(t.deadline || ''), esc(t.workspaceSection)].join(',')
        ),
        ...deals.map((d) =>
          [esc('Brand Deal'), esc(d.brandName), esc(d.contractStatus), esc(d.deadline || ''), esc(`$${(d.dealAmountCents / 100).toFixed(2)}`)].join(',')
        ),
      ];
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="ytm-${workspace.workspaceKey}-export.csv"`
      );
      return res.send(lines.join('\n'));
    }

    return okJson(res, {
      exportedAt: new Date().toISOString(),
      workspace,
      plannerProjects: projects,
      plannerTasks: tasks,
      workflows: workflows.map(hydrateWorkflow),
      brandDeals: deals,
      revenueEntries: revenue,
    });
  } catch (err) {
    return handleError(res, err, 'Export failed.');
  }
});

// ==============================================================================
// 10. CHANNEL PROFILES & CHANNEL DNA (Multi-Channel Persistent Identities)
// ==============================================================================
router.get('/channel-profiles', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });
    const profiles = await listWorkspaceChannelProfiles(workspace, req.dbUser!.id);
    return okJson(res, { profiles });
  } catch (err) {
    return handleError(res, err, 'Unable to load channel profiles.');
  }
});

router.post('/channel-profiles', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const channelName = typeof req.body?.channelName === 'string' ? req.body.channelName.trim() : '';
    if (!channelName || channelName.length > 140) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Channel name is required (max 140 characters).');
    }

    const makeDefault = req.body?.isDefault === true;
    if (makeDefault) {
      await db
        .update(channelProfiles)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(eq(channelProfiles.workspaceId, workspace.id));
    }

    const dnaBody = req.body?.dna && typeof req.body.dna === 'object' ? req.body.dna : req.body || {};

    const insertedProfile = await db
      .insert(channelProfiles)
      .values({
        userId: req.dbUser!.id,
        workspaceId: workspace.id,
        channelName: channelName.slice(0, 140),
        channelHandle:
          typeof req.body?.channelHandle === 'string' ? req.body.channelHandle.trim().slice(0, 80) : '',
        youtubeChannelId:
          typeof req.body?.youtubeChannelId === 'string' && req.body.youtubeChannelId.trim()
            ? req.body.youtubeChannelId.trim().slice(0, 80)
            : null,
        description:
          typeof req.body?.description === 'string' ? req.body.description.trim().slice(0, 1200) : '',
        niche: typeof req.body?.niche === 'string' ? req.body.niche.trim().slice(0, 120) : '',
        subNiche: typeof req.body?.subNiche === 'string' ? req.body.subNiche.trim().slice(0, 120) : '',
        isDefault: makeDefault,
      })
      .returning();

    const insertedDna = await db
      .insert(channelDna)
      .values({
        channelProfileId: insertedProfile[0].id,
        userId: req.dbUser!.id,
        workspaceId: workspace.id,
        targetAudience:
          typeof dnaBody.targetAudience === 'string' ? dnaBody.targetAudience.trim().slice(0, 600) : '',
        audienceProblemsJson: JSON.stringify(normalizeStringList(dnaBody.audienceProblems, 20, 140)),
        preferredLanguage:
          typeof dnaBody.preferredLanguage === 'string' && dnaBody.preferredLanguage.trim()
            ? dnaBody.preferredLanguage.trim().slice(0, 60)
            : 'English',
        contentCategoriesJson: JSON.stringify(normalizeStringList(dnaBody.contentCategories, 20, 60)),
        preferredFormatsJson: JSON.stringify(normalizeStringList(dnaBody.preferredFormats, 15, 80)),
        contentFormat:
          typeof dnaBody.contentFormat === 'string' && dnaBody.contentFormat.trim()
            ? dnaBody.contentFormat.trim().slice(0, 120)
            : 'Long-form YouTube',
        videoStyle: typeof dnaBody.videoStyle === 'string' ? dnaBody.videoStyle.trim().slice(0, 400) : '',
        toneOfVoice:
          typeof dnaBody.toneOfVoice === 'string' ? dnaBody.toneOfVoice.trim().slice(0, 400) : '',
        brandVoice:
          typeof dnaBody.brandVoice === 'string' ? dnaBody.brandVoice.trim().slice(0, 600) : '',
        storytellingApproach:
          typeof dnaBody.storytellingApproach === 'string'
            ? dnaBody.storytellingApproach.trim().slice(0, 600)
            : '',
        scriptStructure:
          typeof dnaBody.scriptStructure === 'string' ? dnaBody.scriptStructure.trim().slice(0, 600) : '',
        preferredVideoDuration:
          typeof dnaBody.preferredVideoDuration === 'string' && dnaBody.preferredVideoDuration.trim()
            ? dnaBody.preferredVideoDuration.trim().slice(0, 80)
            : '8–12 minutes',
        publishingPreferences:
          typeof dnaBody.publishingPreferences === 'string'
            ? dnaBody.publishingPreferences.trim().slice(0, 600)
            : '',
        contentRules:
          typeof dnaBody.contentRules === 'string' ? dnaBody.contentRules.trim().slice(0, 800) : '',
        creativeGuidelines:
          typeof dnaBody.creativeGuidelines === 'string'
            ? dnaBody.creativeGuidelines.trim().slice(0, 800)
            : '',
        titlePreferences:
          typeof dnaBody.titlePreferences === 'string' ? dnaBody.titlePreferences.trim().slice(0, 600) : '',
        thumbnailDesignPreferences:
          typeof dnaBody.thumbnailDesignPreferences === 'string'
            ? dnaBody.thumbnailDesignPreferences.trim().slice(0, 600)
            : '',
        colorPaletteJson: JSON.stringify(normalizeStringList(dnaBody.colorPalette, 12, 40)),
        typography: typeof dnaBody.typography === 'string' ? dnaBody.typography.trim().slice(0, 200) : '',
        wordsToUseJson: JSON.stringify(normalizeStringList(dnaBody.wordsToUse, 30, 80)),
        wordsToAvoidJson: JSON.stringify(normalizeStringList(dnaBody.wordsToAvoid, 30, 80)),
        uniquePositioning:
          typeof dnaBody.uniquePositioning === 'string'
            ? dnaBody.uniquePositioning.trim().slice(0, 800)
            : '',
      })
      .returning();

    return okJson(
      res,
      { profile: hydrateChannelProfileWithDna(insertedProfile[0], insertedDna[0]) },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to create channel profile.');
  }
});

router.patch('/channel-profiles/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const profileId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(profileId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid channel profile ID.');
    }

    const existing = await db
      .select()
      .from(channelProfiles)
      .where(and(eq(channelProfiles.id, profileId), eq(channelProfiles.workspaceId, workspace.id)))
      .limit(1);
    if (!existing[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Channel profile not found.');
    }

    if (req.body?.isDefault === true) {
      await db
        .update(channelProfiles)
        .set({ isDefault: false, updatedAt: new Date() })
        .where(eq(channelProfiles.workspaceId, workspace.id));
    }

    const profilePatch: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof req.body?.channelName === 'string' && req.body.channelName.trim()) {
      profilePatch.channelName = req.body.channelName.trim().slice(0, 140);
    }
    if (typeof req.body?.channelHandle === 'string') {
      profilePatch.channelHandle = req.body.channelHandle.trim().slice(0, 80);
    }
    if (req.body?.youtubeChannelId !== undefined) {
      profilePatch.youtubeChannelId =
        typeof req.body.youtubeChannelId === 'string' && req.body.youtubeChannelId.trim()
          ? req.body.youtubeChannelId.trim().slice(0, 80)
          : null;
    }
    if (typeof req.body?.description === 'string') {
      profilePatch.description = req.body.description.trim().slice(0, 1200);
    }
    if (typeof req.body?.niche === 'string') {
      profilePatch.niche = req.body.niche.trim().slice(0, 120);
    }
    if (typeof req.body?.subNiche === 'string') {
      profilePatch.subNiche = req.body.subNiche.trim().slice(0, 120);
    }
    if (typeof req.body?.isDefault === 'boolean') {
      profilePatch.isDefault = req.body.isDefault;
    }

    const updatedProfile = await db
      .update(channelProfiles)
      .set(profilePatch)
      .where(eq(channelProfiles.id, profileId))
      .returning();

    const dnaBody = req.body?.dna && typeof req.body.dna === 'object' ? req.body.dna : req.body || {};
    const dnaPatch: Record<string, unknown> = { updatedAt: new Date() };

    const stringFields: Array<[string, number]> = [
      ['targetAudience', 600],
      ['preferredLanguage', 60],
      ['contentFormat', 120],
      ['videoStyle', 400],
      ['toneOfVoice', 400],
      ['brandVoice', 600],
      ['storytellingApproach', 600],
      ['scriptStructure', 600],
      ['preferredVideoDuration', 80],
      ['publishingPreferences', 600],
      ['contentRules', 800],
      ['creativeGuidelines', 800],
      ['titlePreferences', 600],
      ['thumbnailDesignPreferences', 600],
      ['typography', 200],
      ['uniquePositioning', 800],
    ];
    for (const [field, maxLen] of stringFields) {
      if (typeof dnaBody[field] === 'string') {
        dnaPatch[field] = dnaBody[field].trim().slice(0, maxLen);
      }
    }
    if (dnaBody.audienceProblems !== undefined) {
      dnaPatch.audienceProblemsJson = JSON.stringify(
        normalizeStringList(dnaBody.audienceProblems, 20, 140)
      );
    }
    if (dnaBody.contentCategories !== undefined) {
      dnaPatch.contentCategoriesJson = JSON.stringify(
        normalizeStringList(dnaBody.contentCategories, 20, 60)
      );
    }
    if (dnaBody.preferredFormats !== undefined) {
      dnaPatch.preferredFormatsJson = JSON.stringify(
        normalizeStringList(dnaBody.preferredFormats, 15, 80)
      );
    }
    if (dnaBody.colorPalette !== undefined) {
      dnaPatch.colorPaletteJson = JSON.stringify(normalizeStringList(dnaBody.colorPalette, 12, 40));
    }
    if (dnaBody.wordsToUse !== undefined) {
      dnaPatch.wordsToUseJson = JSON.stringify(normalizeStringList(dnaBody.wordsToUse, 30, 80));
    }
    if (dnaBody.wordsToAvoid !== undefined) {
      dnaPatch.wordsToAvoidJson = JSON.stringify(normalizeStringList(dnaBody.wordsToAvoid, 30, 80));
    }

    const existingDna = await db
      .select()
      .from(channelDna)
      .where(eq(channelDna.channelProfileId, profileId))
      .limit(1);

    let updatedDnaRow: typeof channelDna.$inferSelect;
    if (existingDna[0]) {
      const upd = await db
        .update(channelDna)
        .set(dnaPatch)
        .where(eq(channelDna.channelProfileId, profileId))
        .returning();
      updatedDnaRow = upd[0];
    } else {
      const ins = await db
        .insert(channelDna)
        .values({
          channelProfileId: profileId,
          userId: req.dbUser!.id,
          workspaceId: workspace.id,
          ...dnaPatch,
        })
        .returning();
      updatedDnaRow = ins[0];
    }

    return okJson(res, {
      profile: hydrateChannelProfileWithDna(updatedProfile[0], updatedDnaRow),
    });
  } catch (err) {
    return handleError(res, err, 'Failed to update Channel DNA profile.');
  }
});

router.delete('/channel-profiles/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const profileId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(profileId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid channel profile ID.');
    }

    const allProfiles = await db
      .select()
      .from(channelProfiles)
      .where(eq(channelProfiles.workspaceId, workspace.id));
    if (allProfiles.length <= 1) {
      return failJson(
        res,
        400,
        'CANNOT_DELETE_LAST_PROFILE',
        'Keep at least one Channel DNA profile in your workspace.'
      );
    }

    const target = allProfiles.find((p) => p.id === profileId);
    if (!target) {
      return failJson(res, 404, 'NOT_FOUND', 'Channel profile not found.');
    }

    await db
      .delete(channelProfiles)
      .where(and(eq(channelProfiles.id, profileId), eq(channelProfiles.workspaceId, workspace.id)));

    if (target.isDefault) {
      const replacement = allProfiles.find((p) => p.id !== profileId);
      if (replacement) {
        await db
          .update(channelProfiles)
          .set({ isDefault: true, updatedAt: new Date() })
          .where(eq(channelProfiles.id, replacement.id));
      }
    }

    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete channel profile.');
  }
});

// ==============================================================================
// 11. SAVED INSPIRATION LIBRARY & AI IDEA ADAPTATION
// ==============================================================================
router.get('/inspirations', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const [profiles, rows, adaptedRows] = await Promise.all([
      listWorkspaceChannelProfiles(workspace, req.dbUser!.id),
      db
        .select()
        .from(savedInspiration)
        .where(eq(savedInspiration.workspaceId, workspace.id))
        .orderBy(desc(savedInspiration.savedAt)),
      db
        .select()
        .from(adaptedIdeas)
        .where(eq(adaptedIdeas.workspaceId, workspace.id))
        .orderBy(desc(adaptedIdeas.updatedAt)),
    ]);

    const channelNameMap = new Map(profiles.map((p) => [p.id, p.channelName]));
    const latestAdaptedMap = new Map<number, ReturnType<typeof hydrateAdaptedIdea>>();
    for (const a of adaptedRows) {
      if (a.savedInspirationId && !latestAdaptedMap.has(a.savedInspirationId)) {
        latestAdaptedMap.set(a.savedInspirationId, hydrateAdaptedIdea(a));
      }
    }

    let items = rows.map((row) =>
      hydrateSavedInspiration(row, { channelNameMap, latestAdaptedMap })
    );

    const q = typeof req.query.q === 'string' ? req.query.q.trim().toLowerCase() : '';
    const category = typeof req.query.category === 'string' ? req.query.category.trim() : '';
    const status = typeof req.query.status === 'string' ? req.query.status.trim() : '';
    const channelProfileId = req.query.channelProfileId
      ? Number.parseInt(String(req.query.channelProfileId), 10)
      : null;
    const sort = req.query.sort === 'oldest' ? 'oldest' : 'newest';

    if (q) {
      items = items.filter(
        (i) =>
          i.originalVideoTitle.toLowerCase().includes(q) ||
          i.competitorChannelName.toLowerCase().includes(q) ||
          i.inspirationSnippet.toLowerCase().includes(q) ||
          i.userNotes.toLowerCase().includes(q)
      );
    }
    if (category && category !== 'all') {
      items = items.filter((i) => i.inspirationCategory === category);
    }
    if (status && status !== 'all') {
      items = items.filter((i) => i.status === status);
    }
    if (Number.isFinite(channelProfileId)) {
      items = items.filter((i) => i.channelProfileId === channelProfileId);
    }
    if (sort === 'oldest') {
      items = [...items].reverse();
    }

    return okJson(res, { inspirations: items });
  } catch (err) {
    return handleError(res, err, 'Unable to load saved inspirations.');
  }
});

router.post('/inspirations', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const originalVideoTitle =
      typeof req.body?.originalVideoTitle === 'string' ? req.body.originalVideoTitle.trim() : '';
    if (!originalVideoTitle) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Original video title or inspiration headline is required.');
    }

    const validCategories = new Set<YtmInspirationCategory>([
      'video_topic',
      'video_title',
      'thumbnail_concept',
      'hook_opening',
      'video_format',
      'storytelling_structure',
      'content_strategy',
      'creative_observation',
    ]);
    const inspirationCategory: YtmInspirationCategory = validCategories.has(
      req.body?.inspirationCategory
    )
      ? req.body.inspirationCategory
      : 'video_topic';

    let channelProfileId: number | null =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;
    if (channelProfileId !== null) {
      const valid = await verifyChannelProfileInWorkspace(workspace.id, channelProfileId);
      if (!valid) channelProfileId = null;
    } else {
      const defaultProfile = await ensureDefaultChannelProfile(workspace, req.dbUser!.id);
      channelProfileId = defaultProfile.id;
    }

    const originalVideoUrl =
      typeof req.body?.originalVideoUrl === 'string' ? req.body.originalVideoUrl.trim().slice(0, 600) : '';
    const competitorChannelName =
      typeof req.body?.competitorChannelName === 'string'
        ? req.body.competitorChannelName.trim().slice(0, 160)
        : '';
    const competitorChannelId =
      typeof req.body?.competitorChannelId === 'string'
        ? req.body.competitorChannelId.trim().slice(0, 100)
        : '';
    const thumbnailUrl =
      typeof req.body?.thumbnailUrl === 'string' && req.body.thumbnailUrl.trim()
        ? req.body.thumbnailUrl.trim().slice(0, 600)
        : null;
    const inspirationSnippet =
      typeof req.body?.inspirationSnippet === 'string'
        ? req.body.inspirationSnippet.trim().slice(0, 1200)
        : '';
    const userNotes =
      typeof req.body?.userNotes === 'string' ? req.body.userNotes.trim().slice(0, 2000) : '';

    const dedupeKey = buildInspirationDedupeKey({
      originalVideoUrl,
      originalVideoTitle,
      inspirationCategory,
      inspirationSnippet,
      channelProfileId,
    });

    const existing = await db
      .select()
      .from(savedInspiration)
      .where(
        and(
          eq(savedInspiration.workspaceId, workspace.id),
          eq(savedInspiration.dedupeKey, dedupeKey)
        )
      )
      .limit(1);

    if (existing[0]) {
      return failJson(
        res,
        409,
        'DUPLICATE_INSPIRATION',
        'This competitor inspiration is already saved in your library for this channel.',
        { existingInspiration: hydrateSavedInspiration(existing[0]) }
      );
    }

    const inserted = await db
      .insert(savedInspiration)
      .values({
        userId: req.dbUser!.id,
        workspaceId: workspace.id,
        channelProfileId,
        dedupeKey,
        originalVideoTitle: originalVideoTitle.slice(0, 240),
        originalVideoUrl,
        competitorChannelName,
        competitorChannelId,
        thumbnailUrl,
        inspirationCategory,
        inspirationSnippet,
        userNotes,
        status: 'saved',
      })
      .returning();

    await recordYtmActivity({
      workspaceId: workspace.id,
      actorUserId: req.dbUser!.id,
      actorEmail: req.dbUser!.email,
      action: 'SAVE_COMPETITOR_INSPIRATION',
      resourceType: 'saved_inspiration',
      resourceId: inserted[0].id,
      details: { inspirationCategory, competitorChannelName },
    });

    return okJson(res, { inspiration: hydrateSavedInspiration(inserted[0]) }, 201);
  } catch (err) {
    return handleError(res, err, 'Failed to save inspiration to planner.');
  }
});

router.patch('/inspirations/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const inspId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(inspId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid inspiration ID.');
    }

    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (typeof req.body?.userNotes === 'string') {
      patch.userNotes = req.body.userNotes.trim().slice(0, 2000);
    }
    if (typeof req.body?.inspirationSnippet === 'string') {
      patch.inspirationSnippet = req.body.inspirationSnippet.trim().slice(0, 1200);
    }
    const validCategories = new Set<YtmInspirationCategory>([
      'video_topic',
      'video_title',
      'thumbnail_concept',
      'hook_opening',
      'video_format',
      'storytelling_structure',
      'content_strategy',
      'creative_observation',
    ]);
    if (validCategories.has(req.body?.inspirationCategory)) {
      patch.inspirationCategory = req.body.inspirationCategory;
    }
    const validStatuses = new Set<YtmInspirationStatus>([
      'saved',
      'reviewed',
      'adapted',
      'converted',
      'archived',
    ]);
    if (validStatuses.has(req.body?.status)) {
      patch.status = req.body.status;
    }
    if (req.body?.channelProfileId !== undefined) {
      if (req.body.channelProfileId === null) {
        patch.channelProfileId = null;
      } else if (typeof req.body.channelProfileId === 'number') {
        const valid = await verifyChannelProfileInWorkspace(workspace.id, req.body.channelProfileId);
        if (valid) patch.channelProfileId = req.body.channelProfileId;
      }
    }

    const updated = await db
      .update(savedInspiration)
      .set(patch)
      .where(
        and(eq(savedInspiration.id, inspId), eq(savedInspiration.workspaceId, workspace.id))
      )
      .returning();

    if (!updated[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Saved inspiration not found.');
    }
    return okJson(res, { inspiration: hydrateSavedInspiration(updated[0]) });
  } catch (err) {
    return handleError(res, err, 'Failed to update saved inspiration.');
  }
});

router.delete('/inspirations/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const inspId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(savedInspiration)
      .where(
        and(eq(savedInspiration.id, inspId), eq(savedInspiration.workspaceId, workspace.id))
      );
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleError(res, err, 'Failed to delete saved inspiration.');
  }
});

router.post('/inspirations/:id/adapt', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const inspId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(inspId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid inspiration ID.');
    }

    const rows = await db
      .select()
      .from(savedInspiration)
      .where(
        and(eq(savedInspiration.id, inspId), eq(savedInspiration.workspaceId, workspace.id))
      )
      .limit(1);

    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Saved inspiration not found.');
    }

    const insp = rows[0];
    const targetChannelProfileId =
      typeof req.body?.channelProfileId === 'number'
        ? req.body.channelProfileId
        : insp.channelProfileId ?? null;
    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      targetChannelProfileId
    );

    const adapted = await aiYtmAdaptInspirationForChannel({
      originalVideoTitle: insp.originalVideoTitle,
      originalVideoUrl: insp.originalVideoUrl,
      competitorChannelName: insp.competitorChannelName,
      inspirationCategory: insp.inspirationCategory,
      inspirationSnippet: insp.inspirationSnippet,
      userNotes: insp.userNotes,
      channelDnaPrompt: formatChannelDnaForPrompt(activeProfile),
      creatorDirection:
        typeof req.body?.creatorDirection === 'string' ? req.body.creatorDirection.trim() : '',
    });

    const inserted = await db
      .insert(adaptedIdeas)
      .values({
        userId: req.dbUser!.id,
        workspaceId: workspace.id,
        channelProfileId: activeProfile.id,
        savedInspirationId: insp.id,
        originalConceptSummary: adapted.originalConceptSummary,
        whyItWorks: adapted.whyItWorks,
        freshAngle: adapted.freshAngle,
        titleOptionsJson: JSON.stringify(adapted.titleOptions),
        selectedTitle: adapted.titleOptions[0] || insp.originalVideoTitle,
        uniqueHook: adapted.uniqueHook,
        videoOutlineJson: JSON.stringify(adapted.videoOutline),
        thumbnailDirection: adapted.thumbnailDirection,
        channelFitExplanation: adapted.channelFitExplanation,
        userNotes: insp.userNotes || '',
      })
      .returning();

    await db
      .update(savedInspiration)
      .set({
        status: insp.status === 'converted' ? 'converted' : 'adapted',
        channelProfileId: activeProfile.id,
        updatedAt: new Date(),
      })
      .where(eq(savedInspiration.id, insp.id));

    return okJson(
      res,
      {
        adaptedIdea: hydrateAdaptedIdea(inserted[0]),
        channelProfile: activeProfile,
      },
      201
    );
  } catch (err) {
    return handleError(res, err, 'Failed to adapt inspiration for your channel.');
  }
});

router.patch('/adapted-ideas/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const ideaId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(ideaId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid adapted idea ID.');
    }

    const patch: Record<string, unknown> = { updatedAt: new Date() };
    for (const field of [
      'originalConceptSummary',
      'whyItWorks',
      'freshAngle',
      'selectedTitle',
      'uniqueHook',
      'thumbnailDirection',
      'channelFitExplanation',
      'userNotes',
    ] as const) {
      if (typeof req.body?.[field] === 'string') {
        patch[field] = req.body[field].trim().slice(0, 3000);
      }
    }
    if (Array.isArray(req.body?.titleOptions)) {
      patch.titleOptionsJson = JSON.stringify(normalizeStringList(req.body.titleOptions, 8, 180));
    }
    if (Array.isArray(req.body?.videoOutline)) {
      patch.videoOutlineJson = JSON.stringify(normalizeStringList(req.body.videoOutline, 15, 300));
    }

    const updated = await db
      .update(adaptedIdeas)
      .set(patch)
      .where(and(eq(adaptedIdeas.id, ideaId), eq(adaptedIdeas.workspaceId, workspace.id)))
      .returning();

    if (!updated[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Adapted idea not found.');
    }

    return okJson(res, { adaptedIdea: hydrateAdaptedIdea(updated[0]) });
  } catch (err) {
    return handleError(res, err, 'Failed to save edits to adapted idea.');
  }
});

router.post('/inspirations/:id/convert-to-planner', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const inspId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(inspId)) {
      return failJson(res, 400, 'INVALID_ID', 'Invalid inspiration ID.');
    }

    const inspRows = await db
      .select()
      .from(savedInspiration)
      .where(
        and(eq(savedInspiration.id, inspId), eq(savedInspiration.workspaceId, workspace.id))
      )
      .limit(1);
    if (!inspRows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Saved inspiration not found.');
    }
    const insp = inspRows[0];

    let adaptedRow: typeof adaptedIdeas.$inferSelect | null = null;
    if (typeof req.body?.adaptedIdeaId === 'number') {
      const aRows = await db
        .select()
        .from(adaptedIdeas)
        .where(
          and(
            eq(adaptedIdeas.id, req.body.adaptedIdeaId),
            eq(adaptedIdeas.workspaceId, workspace.id)
          )
        )
        .limit(1);
      adaptedRow = aRows[0] || null;
    } else {
      const latestAdapted = await db
        .select()
        .from(adaptedIdeas)
        .where(
          and(
            eq(adaptedIdeas.savedInspirationId, insp.id),
            eq(adaptedIdeas.workspaceId, workspace.id)
          )
        )
        .orderBy(desc(adaptedIdeas.updatedAt))
        .limit(1);
      adaptedRow = latestAdapted[0] || null;
    }

    const hydratedAdapted = adaptedRow ? hydrateAdaptedIdea(adaptedRow) : null;
    const channelProfileId =
      typeof req.body?.channelProfileId === 'number'
        ? req.body.channelProfileId
        : adaptedRow?.channelProfileId ?? insp.channelProfileId ?? null;
    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      channelProfileId
    );

    const title =
      (typeof req.body?.title === 'string' && req.body.title.trim()) ||
      hydratedAdapted?.selectedTitle ||
      insp.originalVideoTitle;

    const topic =
      (typeof req.body?.topic === 'string' && req.body.topic.trim()) ||
      hydratedAdapted?.originalConceptSummary ||
      insp.inspirationSnippet ||
      insp.originalVideoTitle;

    const adaptedAngle =
      (typeof req.body?.adaptedAngle === 'string' && req.body.adaptedAngle.trim()) ||
      hydratedAdapted?.freshAngle ||
      '';

    const combinedNotes = [
      typeof req.body?.notes === 'string' ? req.body.notes.trim() : '',
      hydratedAdapted?.userNotes || insp.userNotes || '',
      hydratedAdapted?.uniqueHook ? `Opening Hook:\n${hydratedAdapted.uniqueHook}` : '',
      hydratedAdapted?.thumbnailDirection
        ? `Thumbnail Direction:\n${hydratedAdapted.thumbnailDirection}`
        : '',
    ]
      .filter(Boolean)
      .join('\n\n')
      .slice(0, 3000);

    const sourceLabel = insp.competitorChannelName
      ? `${insp.competitorChannelName} — ${insp.originalVideoTitle}`
      : insp.originalVideoTitle;

    const inserted = await db
      .insert(ytmPlannerProjects)
      .values({
        workspaceId: workspace.id,
        createdByUserId: req.dbUser!.id,
        title: title.slice(0, 180),
        topic: topic.slice(0, 300),
        description: (hydratedAdapted?.whyItWorks || insp.inspirationSnippet || '').slice(0, 2000),
        notes: combinedNotes,
        targetAudience: activeProfile.dna.targetAudience.slice(0, 200),
        category:
          typeof req.body?.category === 'string' && req.body.category.trim()
            ? req.body.category.trim().slice(0, 80)
            : activeProfile.dna.contentCategories[0] || 'General',
        status:
          typeof req.body?.status === 'string' && req.body.status.trim()
            ? req.body.status.trim().slice(0, 40)
            : 'Selected',
        priority: ['low', 'medium', 'high', 'urgent'].includes(req.body?.priority)
          ? req.body.priority
          : 'medium',
        plannedDate:
          typeof req.body?.plannedDate === 'string' && req.body.plannedDate
            ? req.body.plannedDate
            : null,
        deadline:
          typeof req.body?.deadline === 'string' && req.body.deadline ? req.body.deadline : null,
        recurrenceRule: 'none',
        channelProfileId: activeProfile.id,
        savedInspirationId: insp.id,
        adaptedIdeaId: adaptedRow?.id ?? null,
        inspirationSourceLabel: sourceLabel.slice(0, 240),
        inspirationSourceUrl: insp.originalVideoUrl.slice(0, 500),
        adaptedAngle: adaptedAngle.slice(0, 1500),
        productionChecklistJson: JSON.stringify(
          YTM_DEFAULT_PRODUCTION_CHECKLIST.map((item) => ({ ...item }))
        ),
      })
      .returning();

    await db
      .update(savedInspiration)
      .set({
        status: 'converted',
        convertedPlannerProjectId: inserted[0].id,
        updatedAt: new Date(),
      })
      .where(eq(savedInspiration.id, insp.id));

    if (adaptedRow) {
      await db
        .update(adaptedIdeas)
        .set({
          convertedPlannerProjectId: inserted[0].id,
          updatedAt: new Date(),
        })
        .where(eq(adaptedIdeas.id, adaptedRow.id));
    }

    return okJson(res, { project: hydratePlannerProject(inserted[0]) }, 201);
  } catch (err) {
    return handleError(res, err, 'Failed to convert inspiration to Content Planner.');
  }
});

export default router;
