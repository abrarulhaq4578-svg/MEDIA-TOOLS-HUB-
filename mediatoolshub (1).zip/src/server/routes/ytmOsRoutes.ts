import crypto from 'node:crypto';
import express from 'express';
import multer from 'multer';
import { and, desc, eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  competitorReports,
  savedInspiration,
  ytmAssets,
  ytmCoachActions,
  ytmCoachSnapshots,
  ytmCommunityPosts,
  ytmContentStrategies,
  ytmPlannerProjects,
  ytmPlannerTasks,
  ytmWorkflowProjects,
} from '../../db/schema.ts';
import type {
  YtmAudienceCommunicationStrategy,
  YtmCalendarAuditReport,
  YtmCoachActionRecord,
  YtmCoachDiagnosis,
  YtmCoachImprovementItem,
  YtmCoachLearningLesson,
  YtmCoachMetricSnapshot,
  YtmCoachOpportunity,
  YtmCoachSnapshotRecord,
  YtmCommunityPostFormat,
  YtmCommunityPostPayload,
  YtmCommunityPostRecord,
  YtmContentStrategyRecord,
  YtmPlannerProjectRecord,
  YtmPlannerTaskRecord,
  YtmPriority,
  YtmPublishingStrategyPlan,
  YtmStrategyCalendarItem,
  YtmStrategyIntake,
} from '../../shared/types.ts';
import {
  getTodayDateKey,
  YTM_DEFAULT_PRODUCTION_CHECKLIST,
} from '../../shared/ytmHelpers.ts';
import type { AuthRequest } from '../middleware/auth.ts';
import { ScriptAiError } from '../services/scriptStudioAi.ts';
import {
  formatChannelDnaForPrompt,
  getActiveChannelProfileWithDna,
  parsePlannerChecklist,
} from '../services/ytmChannelDnaService.ts';
import {
  fetchAuthorizedChannelAnalytics,
  getWorkspaceConnectedChannel,
  YtmOAuthError,
} from '../services/ytmOAuthService.ts';
import {
  aiYtmGenerateCommunityPost,
  aiYtmGenerateContentStrategy,
  aiYtmRegenerateStrategyDates,
  aiYtmRunPerformanceCoach,
  buildDeterministicCalendarAudit,
} from '../services/ytmOsAiService.ts';
import {
  resolveAuthorizedWorkspace,
  safeJsonParse,
  YtmAccessError,
} from '../services/ytmWorkspaceService.ts';

const router = express.Router();

const imageUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 },
});

function getWorkspaceKeyFromReq(req: express.Request): string | null {
  const q = typeof req.query.workspaceKey === 'string' ? req.query.workspaceKey : null;
  const h = req.header('x-ytm-workspace');
  const b = typeof req.body?.workspaceKey === 'string' ? req.body.workspaceKey : null;
  return (q || h || b || '').trim() || null;
}

function okJson(res: express.Response, data: Record<string, unknown>, status = 200) {
  return res.status(status).json({ ok: true, data, ...data });
}

function failJson(res: express.Response, status: number, code: string, message: string) {
  return res.status(status).json({ ok: false, error: { code, message } });
}

function handleErr(res: express.Response, err: unknown, fallback: string) {
  if (err instanceof YtmAccessError) {
    return failJson(res, err.statusCode, err.code, err.message);
  }
  if (err instanceof YtmOAuthError) {
    return failJson(res, err.statusCode, err.code, err.message);
  }
  if (err instanceof ScriptAiError) {
    return failJson(res, err.statusCode, err.code, err.message);
  }
  const message = err instanceof Error ? err.message : fallback;
  return failJson(res, 500, 'YTM_OS_ERROR', message || fallback);
}

function hydrateStrategy(row: typeof ytmContentStrategies.$inferSelect): YtmContentStrategyRecord {
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    channelProfileId: row.channelProfileId ?? null,
    title: row.title,
    intake: safeJsonParse<YtmStrategyIntake>(row.intakeJson, {
      mainPlatform: 'YouTube',
      niche: '',
      targetAudience: '',
      contentFormats: ['Long-form YouTube', 'YouTube Shorts', 'Community Posts'],
      publishingGoals: '',
      availableHoursPerWeek: 8,
      preferredFrequency: '1 long-form video per week',
      monthlyContentTarget: '4 long-form videos + 4 Shorts',
      audienceEngagementGoals: 'Build loyal subscriber discussion',
    }),
    publishingStrategy: safeJsonParse<YtmPublishingStrategyPlan>(row.publishingStrategyJson, {
      summary: '',
      longFormMonthlyTarget: '',
      shortsWeeklyTarget: '',
      communityPostsCadence: '',
      pollsAndQuizzesCadence: '',
      behindTheScenesAndPromoMix: '',
      commentEngagementRoutine: '',
      capacityRealismNote: '',
      contentPillarsMix: [],
    }),
    communicationStrategy: safeJsonParse<YtmAudienceCommunicationStrategy>(
      row.communicationStrategyJson,
      {
        overview: '',
        weeklyEngagementSchedule: [],
        subscriberQuestionPrompts: [],
        pollIdeas: [],
        quizIdeas: [],
        discussionPrompts: [],
        feedbackCollectionRoutine: '',
        commentResponseSessions: '',
        launchAnnouncementFlow: '',
        postPublicationEngagementPlan: '',
      }
    ),
    calendarItems: safeJsonParse<YtmStrategyCalendarItem[]>(row.calendarItemsJson, []),
    auditReport: safeJsonParse<YtmCalendarAuditReport | null>(row.auditReportJson, null),
    status: (['draft', 'partially_applied', 'applied'].includes(row.status)
      ? row.status
      : 'draft') as YtmContentStrategyRecord['status'],
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function hydrateCommunityPost(row: typeof ytmCommunityPosts.$inferSelect): YtmCommunityPostRecord {
  const validFormats = new Set<YtmCommunityPostFormat>([
    'quiz',
    'text_poll',
    'image_poll',
    'image_post',
    'simple_text',
  ]);
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    workflowProjectId: row.workflowProjectId ?? null,
    channelProfileId: row.channelProfileId ?? null,
    formatType: (validFormats.has(row.formatType as YtmCommunityPostFormat)
      ? row.formatType
      : 'simple_text') as YtmCommunityPostFormat,
    topic: row.topic || '',
    title: row.title || '',
    payload: safeJsonParse<YtmCommunityPostPayload>(row.payloadJson, {}),
    status: (['draft', 'approved', 'manually_published'].includes(row.status)
      ? row.status
      : 'draft') as YtmCommunityPostRecord['status'],
    approvedAt: row.approvedAt ? row.approvedAt.toISOString() : null,
    scheduledAt: row.scheduledAt ?? null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

function hydrateCoachSnapshot(row: typeof ytmCoachSnapshots.$inferSelect): YtmCoachSnapshotRecord {
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    channelProfileId: row.channelProfileId ?? null,
    channelId: row.channelId,
    periodStart: row.periodStart,
    periodEnd: row.periodEnd,
    previousPeriodStart: row.previousPeriodStart,
    previousPeriodEnd: row.previousPeriodEnd,
    dataSource: row.dataSource,
    metricsSummary: safeJsonParse<YtmCoachMetricSnapshot>(row.metricsSummaryJson, {
      currentPeriod: { start: row.periodStart, end: row.periodEnd },
      previousPeriod: { start: row.previousPeriodStart, end: row.previousPeriodEnd },
      views: null,
      previousViews: null,
      watchTimeMinutes: null,
      previousWatchTimeMinutes: null,
      avgViewDurationSec: null,
      previousAvgViewDurationSec: null,
      subscribersNet: null,
      previousSubscribersNet: null,
      likes: null,
      comments: null,
      uploadsInPeriod: 0,
      impressionsAvailable: false,
      impressionsCtrAvailable: false,
      returningViewersAvailable: false,
      unavailableMetricsDisclosure:
        'YouTube Analytics API v2 does not expose Impressions, Impressions CTR, or Returning vs New Viewers via standard OAuth scopes.',
    }),
    diagnosis: safeJsonParse<YtmCoachDiagnosis>(row.diagnosisJson, {
      headline: '',
      overallStatus: 'steady',
      whatsWorking: [],
      notImproving: [],
      underperformingVideos: [],
      strongestTopics: [],
      decliningTopics: [],
      publishingHabitAssessment: '',
      periodComparisonSummary: '',
    }),
    improvements: safeJsonParse<YtmCoachImprovementItem[]>(row.improvementsJson, []),
    opportunities: safeJsonParse<YtmCoachOpportunity[]>(row.opportunitiesJson, []),
    learningLessons: safeJsonParse<YtmCoachLearningLesson[]>(row.learningLessonsJson, []),
    createdAt: row.createdAt.toISOString(),
  };
}

function hydrateCoachAction(row: typeof ytmCoachActions.$inferSelect): YtmCoachActionRecord {
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    snapshotId: row.snapshotId ?? null,
    horizon: (['daily', 'weekly', 'monthly', 'experiment'].includes(row.horizon)
      ? row.horizon
      : 'weekly') as YtmCoachActionRecord['horizon'],
    title: row.title,
    rationale: row.rationale || '',
    actionSteps: row.actionSteps || '',
    expectedOutcome: row.expectedOutcome || '',
    metricToMeasure: row.metricToMeasure || '',
    priority: (['low', 'medium', 'high', 'urgent'].includes(row.priority)
      ? row.priority
      : 'medium') as YtmPriority,
    status: (['pending', 'approved', 'in_progress', 'completed', 'dismissed'].includes(row.status)
      ? row.status
      : 'pending') as YtmCoachActionRecord['status'],
    linkedPlannerProjectId: row.linkedPlannerProjectId ?? null,
    linkedPlannerTaskId: row.linkedPlannerTaskId ?? null,
    linkedWorkflowProjectId: row.linkedWorkflowProjectId ?? null,
    outcomeNotes: row.outcomeNotes || '',
    completedAt: row.completedAt ? row.completedAt.toISOString() : null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

// ==============================================================================
// 1. AI STRATEGY ASSISTANT ROUTES (Content Planner → AI Strategy Assistant)
// ==============================================================================
router.get('/strategy', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const [strategies, projects, tasks] = await Promise.all([
      db
        .select()
        .from(ytmContentStrategies)
        .where(eq(ytmContentStrategies.workspaceId, workspace.id))
        .orderBy(desc(ytmContentStrategies.updatedAt))
        .limit(10),
      db
        .select()
        .from(ytmPlannerProjects)
        .where(eq(ytmPlannerProjects.workspaceId, workspace.id))
        .orderBy(desc(ytmPlannerProjects.updatedAt))
        .limit(80),
      db
        .select()
        .from(ytmPlannerTasks)
        .where(eq(ytmPlannerTasks.workspaceId, workspace.id))
        .orderBy(desc(ytmPlannerTasks.updatedAt))
        .limit(120),
    ]);

    const mappedProjects: YtmPlannerProjectRecord[] = projects.map((p) => ({
      id: p.id,
      workspaceId: p.workspaceId,
      assigneeUserId: p.assigneeUserId ?? null,
      title: p.title,
      topic: p.topic || '',
      description: p.description || '',
      notes: p.notes || '',
      targetAudience: p.targetAudience || '',
      category: p.category || 'General',
      status: p.status || 'Idea',
      priority: (p.priority || 'medium') as YtmPriority,
      plannedDate: p.plannedDate ?? null,
      deadline: p.deadline ?? null,
      recurrenceRule: (p.recurrenceRule || 'none') as 'none' | 'weekly' | 'biweekly' | 'monthly',
      workflowProjectId: p.workflowProjectId ?? null,
      channelProfileId: p.channelProfileId ?? null,
      savedInspirationId: p.savedInspirationId ?? null,
      adaptedIdeaId: p.adaptedIdeaId ?? null,
      inspirationSourceLabel: p.inspirationSourceLabel || '',
      inspirationSourceUrl: p.inspirationSourceUrl || '',
      adaptedAngle: p.adaptedAngle || '',
      productionChecklist: parsePlannerChecklist(p.productionChecklistJson),
      createdAt: p.createdAt.toISOString(),
      updatedAt: p.updatedAt.toISOString(),
    }));
    const mappedTasks: YtmPlannerTaskRecord[] = tasks.map((t) => ({
      id: t.id,
      workspaceId: t.workspaceId,
      plannerProjectId: t.plannerProjectId ?? null,
      assigneeUserId: t.assigneeUserId ?? null,
      taskName: t.taskName,
      workspaceSection: t.workspaceSection,
      scheduledAt: t.scheduledAt ?? null,
      deadline: t.deadline ?? null,
      priority: (t.priority || 'medium') as YtmPriority,
      status: (t.status || 'Not Started') as YtmPlannerTaskRecord['status'],
      aiSuggested: t.aiSuggested,
      createdAt: t.createdAt.toISOString(),
      updatedAt: t.updatedAt.toISOString(),
    }));

    const latestStrategy = strategies[0] ? hydrateStrategy(strategies[0]) : null;
    const liveAudit = buildDeterministicCalendarAudit({
      todayKey: getTodayDateKey(),
      projects: mappedProjects,
      tasks: mappedTasks,
      availableHoursPerWeek: latestStrategy?.intake?.availableHoursPerWeek,
    });

    return okJson(res, {
      strategy: latestStrategy,
      strategies: strategies.map(hydrateStrategy),
      liveAudit,
    });
  } catch (err) {
    return handleErr(res, err, 'Unable to load Content Strategy Assistant.');
  }
});

router.post('/strategy/generate', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const requestedChannelId =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;
    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      requestedChannelId
    );
    const channelDnaPrompt = formatChannelDnaForPrompt(activeProfile);

    const rawIntake = (req.body?.intake || req.body || {}) as Partial<YtmStrategyIntake>;
    const intake: YtmStrategyIntake = {
      mainPlatform: String(rawIntake.mainPlatform || 'YouTube').slice(0, 80),
      niche: String(rawIntake.niche || activeProfile.niche || workspace.name || 'YouTube Creator').slice(
        0,
        200
      ),
      targetAudience: String(
        rawIntake.targetAudience || activeProfile.dna.targetAudience || 'Engaged YouTube viewers'
      ).slice(0, 400),
      contentFormats: Array.isArray(rawIntake.contentFormats) && rawIntake.contentFormats.length > 0
        ? rawIntake.contentFormats.map((f) => String(f).slice(0, 60)).slice(0, 10)
        : activeProfile.dna.preferredFormats.length > 0
          ? activeProfile.dna.preferredFormats
          : [activeProfile.dna.contentFormat || 'Long-form YouTube', 'YouTube Shorts', 'Community Posts'],
      publishingGoals: String(
        rawIntake.publishingGoals || workspace.channelGoal || 'Consistent sustainable channel growth'
      ).slice(0, 500),
      availableHoursPerWeek: Math.min(
        80,
        Math.max(1, Number(rawIntake.availableHoursPerWeek) || 8)
      ),
      preferredFrequency: String(
        rawIntake.preferredFrequency || activeProfile.dna.publishingPreferences || '1 long-form video/week'
      ).slice(0, 180),
      monthlyContentTarget: String(
        rawIntake.monthlyContentTarget || '4 long-form videos + 4 Shorts + 4 Community Posts'
      ).slice(0, 220),
      audienceEngagementGoals: String(
        rawIntake.audienceEngagementGoals || 'Increase comment conversations, polls, and loyal viewers'
      ).slice(0, 300),
      additionalConstraints: rawIntake.additionalConstraints
        ? String(rawIntake.additionalConstraints).slice(0, 400)
        : undefined,
    };

    const existingProjects = await db
      .select()
      .from(ytmPlannerProjects)
      .where(eq(ytmPlannerProjects.workspaceId, workspace.id))
      .orderBy(desc(ytmPlannerProjects.updatedAt))
      .limit(25);

    const existingProjectsSummary = existingProjects
      .map((p) => `- ${p.title} (${p.status}${p.plannedDate ? `, planned ${p.plannedDate}` : ''})`)
      .join('\n');

    const startDateKey =
      typeof req.body?.startDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.startDate)
        ? req.body.startDate
        : getTodayDateKey();

    const generated = await aiYtmGenerateContentStrategy({
      intake,
      channelDnaPrompt,
      startDateKey,
      existingProjectsSummary,
    });

    const inserted = await db
      .insert(ytmContentStrategies)
      .values({
        workspaceId: workspace.id,
        channelProfileId: activeProfile.id,
        createdByUserId: req.dbUser!.id,
        title: generated.title,
        intakeJson: JSON.stringify(intake),
        publishingStrategyJson: JSON.stringify(generated.publishingStrategy),
        communicationStrategyJson: JSON.stringify(generated.communicationStrategy),
        calendarItemsJson: JSON.stringify(generated.calendarItems),
        status: 'draft',
      })
      .returning();

    return okJson(res, { strategy: hydrateStrategy(inserted[0]) }, 201);
  } catch (err) {
    return handleErr(res, err, 'Failed to generate AI content strategy.');
  }
});

router.patch('/strategy/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const strategyId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmContentStrategies)
      .where(
        and(
          eq(ytmContentStrategies.id, strategyId),
          eq(ytmContentStrategies.workspaceId, workspace.id)
        )
      )
      .limit(1);
    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Content strategy not found.');
    }

    const patch: Record<string, unknown> = { updatedAt: new Date() };
    if (Array.isArray(req.body?.calendarItems)) {
      patch.calendarItemsJson = JSON.stringify(req.body.calendarItems);
    }
    if (req.body?.publishingStrategy && typeof req.body.publishingStrategy === 'object') {
      patch.publishingStrategyJson = JSON.stringify(req.body.publishingStrategy);
    }
    if (req.body?.communicationStrategy && typeof req.body.communicationStrategy === 'object') {
      patch.communicationStrategyJson = JSON.stringify(req.body.communicationStrategy);
    }
    if (typeof req.body?.title === 'string' && req.body.title.trim()) {
      patch.title = req.body.title.trim().slice(0, 180);
    }

    const updated = await db
      .update(ytmContentStrategies)
      .set(patch)
      .where(eq(ytmContentStrategies.id, strategyId))
      .returning();

    return okJson(res, { strategy: hydrateStrategy(updated[0]) });
  } catch (err) {
    return handleErr(res, err, 'Unable to update content strategy draft.');
  }
});

router.delete('/strategy/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const strategyId = Number.parseInt(String(req.params.id), 10);
    if (!Number.isFinite(strategyId) || strategyId <= 0) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Valid strategy plan ID is required.');
    }

    const deleted = await db
      .delete(ytmContentStrategies)
      .where(
        and(
          eq(ytmContentStrategies.id, strategyId),
          eq(ytmContentStrategies.workspaceId, workspace.id)
        )
      )
      .returning({ id: ytmContentStrategies.id });

    if (!deleted[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Content strategy plan not found in this workspace.');
    }

    return okJson(res, { deleted: true, deletedId: strategyId });
  } catch (err) {
    return handleErr(res, err, 'Unable to delete content strategy plan.');
  }
});

router.post('/strategy/:id/regenerate-dates', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const strategyId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmContentStrategies)
      .where(
        and(
          eq(ytmContentStrategies.id, strategyId),
          eq(ytmContentStrategies.workspaceId, workspace.id)
        )
      )
      .limit(1);
    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Content strategy not found.');
    }

    const strategy = hydrateStrategy(rows[0]);
    const selectedDates = Array.isArray(req.body?.dates)
      ? req.body.dates.filter((d: unknown): d is string => typeof d === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(d))
      : [];
    if (selectedDates.length === 0) {
      return failJson(res, 400, 'INVALID_REQUEST', 'Select at least one valid YYYY-MM-DD date to regenerate.');
    }

    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      strategy.channelProfileId
    );
    const replacementItems = await aiYtmRegenerateStrategyDates({
      intake: strategy.intake,
      channelDnaPrompt: formatChannelDnaForPrompt(activeProfile),
      selectedDates,
      existingItems: strategy.calendarItems,
      note: typeof req.body?.note === 'string' ? req.body.note.trim().slice(0, 300) : undefined,
    });

    const dateSet = new Set(selectedDates);
    const kept = strategy.calendarItems.filter(
      (item) => !dateSet.has(item.date) || item.status === 'saved_to_calendar'
    );
    const merged = [...kept, ...replacementItems].sort((a, b) => a.date.localeCompare(b.date));

    const updated = await db
      .update(ytmContentStrategies)
      .set({ calendarItemsJson: JSON.stringify(merged), updatedAt: new Date() })
      .where(eq(ytmContentStrategies.id, strategyId))
      .returning();

    return okJson(res, { strategy: hydrateStrategy(updated[0]) });
  } catch (err) {
    return handleErr(res, err, 'Failed to regenerate selected calendar dates.');
  }
});

// Explicit Approval Gate: ONLY selected/approved items become real Planner projects/tasks; NEVER overwrites existing calendar.
router.post('/strategy/:id/apply', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const strategyId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmContentStrategies)
      .where(
        and(
          eq(ytmContentStrategies.id, strategyId),
          eq(ytmContentStrategies.workspaceId, workspace.id)
        )
      )
      .limit(1);
    if (!rows[0]) {
      return failJson(res, 404, 'NOT_FOUND', 'Content strategy not found.');
    }

    const strategy = hydrateStrategy(rows[0]);
    const approveAll = req.body?.approveAll === true;
    const selectedIds = new Set<string>(
      Array.isArray(req.body?.itemIds)
        ? req.body.itemIds.filter((id: unknown): id is string => typeof id === 'string')
        : []
    );

    const targets = strategy.calendarItems.filter((item) => {
      if (item.status === 'saved_to_calendar' || item.status === 'rejected') return false;
      if (approveAll) return true;
      return selectedIds.has(item.id) || item.status === 'approved';
    });

    if (targets.length === 0) {
      return failJson(
        res,
        400,
        'NO_APPROVED_ITEMS',
        'Select or approve at least one pending strategy item before saving to Content Planner.'
      );
    }

    let createdProjectsCount = 0;
    let createdTasksCount = 0;
    const updatedMap = new Map<string, YtmStrategyCalendarItem>();

    for (const item of targets) {
      const isVideoItem =
        item.contentType === 'long_form_video' || item.contentType === 'youtube_short';

      if (isVideoItem) {
        const insProj = await db
          .insert(ytmPlannerProjects)
          .values({
            workspaceId: workspace.id,
            createdByUserId: req.dbUser!.id,
            title: item.title.slice(0, 180),
            topic: item.objective.slice(0, 400),
            description: `[AI Strategy Assistant · ${item.platform} · ${item.contentType}] ${item.objective}`,
            category: item.contentType === 'youtube_short' ? 'YouTube Shorts' : 'Long-Form Video',
            status: 'Selected',
            priority: item.priority,
            plannedDate: item.publishingDeadline || item.date,
            deadline: item.productionDeadline || item.date,
            channelProfileId: strategy.channelProfileId ?? null,
            productionChecklistJson: JSON.stringify(YTM_DEFAULT_PRODUCTION_CHECKLIST),
          })
          .returning();
        createdProjectsCount++;

        const insTask = await db
          .insert(ytmPlannerTasks)
          .values({
            workspaceId: workspace.id,
            plannerProjectId: insProj[0].id,
            createdByUserId: req.dbUser!.id,
            taskName: `Produce: ${item.title}`.slice(0, 240),
            workspaceSection: 'Workflow',
            scheduledAt: item.time ? `${item.productionDeadline} ${item.time}` : item.productionDeadline,
            deadline: item.productionDeadline || item.date,
            priority: item.priority,
            status: 'Not Started',
            aiSuggested: true,
          })
          .returning();
        createdTasksCount++;

        updatedMap.set(item.id, {
          ...item,
          status: 'saved_to_calendar',
          savedPlannerProjectId: insProj[0].id,
          savedPlannerTaskId: insTask[0].id,
        });
      } else {
        const sectionLabel =
          item.contentType === 'engagement_session' ||
          item.contentType === 'community_post' ||
          item.contentType === 'poll' ||
          item.contentType === 'quiz'
            ? 'Community'
            : 'Planner';
        const insTask = await db
          .insert(ytmPlannerTasks)
          .values({
            workspaceId: workspace.id,
            createdByUserId: req.dbUser!.id,
            taskName: `[${item.contentType.replace(/_/g, ' ')}] ${item.title}`.slice(0, 240),
            workspaceSection: sectionLabel,
            scheduledAt: item.time ? `${item.date} ${item.time}` : item.date,
            deadline: item.publishingDeadline || item.date,
            priority: item.priority,
            status: 'Not Started',
            aiSuggested: true,
          })
          .returning();
        createdTasksCount++;

        updatedMap.set(item.id, {
          ...item,
          status: 'saved_to_calendar',
          savedPlannerTaskId: insTask[0].id,
        });
      }
    }

    const nextItems = strategy.calendarItems.map((it) => updatedMap.get(it.id) || it);
    const allResolved = nextItems.every(
      (it) => it.status === 'saved_to_calendar' || it.status === 'rejected'
    );
    const nextStatus = allResolved ? 'applied' : 'partially_applied';

    const updated = await db
      .update(ytmContentStrategies)
      .set({
        calendarItemsJson: JSON.stringify(nextItems),
        status: nextStatus,
        updatedAt: new Date(),
      })
      .where(eq(ytmContentStrategies.id, strategyId))
      .returning();

    return okJson(res, {
      strategy: hydrateStrategy(updated[0]),
      createdProjectsCount,
      createdTasksCount,
    });
  } catch (err) {
    return handleErr(res, err, 'Failed to save approved strategy items to Content Planner.');
  }
});

router.post('/strategy/calendar-audit/apply', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });

    const targetType = req.body?.targetType;
    const targetId = typeof req.body?.targetId === 'number' ? req.body.targetId : null;
    const suggestedDate =
      typeof req.body?.suggestedDate === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.suggestedDate)
        ? req.body.suggestedDate
        : null;

    if (!suggestedDate) {
      return failJson(res, 400, 'INVALID_REQUEST', 'A valid YYYY-MM-DD suggestedDate is required.');
    }

    if (targetType === 'project' && targetId) {
      const upd = await db
        .update(ytmPlannerProjects)
        .set({ plannedDate: suggestedDate, deadline: suggestedDate, updatedAt: new Date() })
        .where(
          and(eq(ytmPlannerProjects.id, targetId), eq(ytmPlannerProjects.workspaceId, workspace.id))
        )
        .returning();
      if (!upd[0]) return failJson(res, 404, 'NOT_FOUND', 'Planner project not found.');
      return okJson(res, { applied: true, targetType: 'project', targetId, suggestedDate });
    }

    if (targetType === 'task' && targetId) {
      const upd = await db
        .update(ytmPlannerTasks)
        .set({ deadline: suggestedDate, scheduledAt: suggestedDate, updatedAt: new Date() })
        .where(and(eq(ytmPlannerTasks.id, targetId), eq(ytmPlannerTasks.workspaceId, workspace.id)))
        .returning();
      if (!upd[0]) return failJson(res, 404, 'NOT_FOUND', 'Planner task not found.');
      return okJson(res, { applied: true, targetType: 'task', targetId, suggestedDate });
    }

    if (targetType === 'gap') {
      const title =
        typeof req.body?.targetTitle === 'string' && req.body.targetTitle.trim()
          ? req.body.targetTitle.trim().slice(0, 200)
          : 'Community Check-In / Gap Filler Post';
      const ins = await db
        .insert(ytmPlannerTasks)
        .values({
          workspaceId: workspace.id,
          createdByUserId: req.dbUser!.id,
          taskName: title,
          workspaceSection: 'Community',
          scheduledAt: suggestedDate,
          deadline: suggestedDate,
          priority: 'medium',
          status: 'Not Started',
          aiSuggested: true,
        })
        .returning();
      return okJson(res, { applied: true, targetType: 'gap', createdTaskId: ins[0].id, suggestedDate });
    }

    return failJson(res, 400, 'INVALID_REQUEST', 'Unsupported calendar audit adjustment target.');
  } catch (err) {
    return handleErr(res, err, 'Failed to apply approved calendar adjustment.');
  }
});

// ==============================================================================
// 2. STAGE 4 COMMUNITY POST CREATOR ROUTES (ALL 5 FORMATS)
// ==============================================================================
router.get('/community-posts', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workspace:read',
    });

    const wfIdParam = req.query.workflowProjectId
      ? Number.parseInt(String(req.query.workflowProjectId), 10)
      : null;

    const whereClause =
      wfIdParam && Number.isFinite(wfIdParam)
        ? and(
            eq(ytmCommunityPosts.workspaceId, workspace.id),
            eq(ytmCommunityPosts.workflowProjectId, wfIdParam)
          )
        : eq(ytmCommunityPosts.workspaceId, workspace.id);

    const rows = await db
      .select()
      .from(ytmCommunityPosts)
      .where(whereClause)
      .orderBy(desc(ytmCommunityPosts.updatedAt))
      .limit(50);

    return okJson(res, {
      posts: rows.map(hydrateCommunityPost),
      youtubeApiLimitationNotice:
        'YouTube Data API v3 does not provide a public endpoint to directly publish YouTube Community Posts (Quizzes, Polls, Image Posts, or Text Posts). Approved posts are saved in your workspace queue with one-click copy and YouTube Studio handoff.',
    });
  } catch (err) {
    return handleErr(res, err, 'Unable to load community posts.');
  }
});

router.post('/community-posts/generate', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });

    const validFormats = new Set<YtmCommunityPostFormat>([
      'quiz',
      'text_poll',
      'image_poll',
      'image_post',
      'simple_text',
    ]);
    const formatType = validFormats.has(req.body?.formatType)
      ? (req.body.formatType as YtmCommunityPostFormat)
      : 'simple_text';

    const workflowProjectId =
      typeof req.body?.workflowProjectId === 'number' ? req.body.workflowProjectId : null;
    let projectTitle: string | undefined;
    let projectTopicSummary: string | undefined;
    let channelProfileId: number | null =
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null;

    if (workflowProjectId) {
      const wfRows = await db
        .select()
        .from(ytmWorkflowProjects)
        .where(
          and(
            eq(ytmWorkflowProjects.id, workflowProjectId),
            eq(ytmWorkflowProjects.workspaceId, workspace.id)
          )
        )
        .limit(1);
      if (wfRows[0]) {
        projectTitle = wfRows[0].title;
        const s2 = safeJsonParse<{ centralTopic?: string; coreProblem?: string }>(
          wfRows[0].stage2TopicJson,
          {}
        );
        projectTopicSummary = [s2.centralTopic, s2.coreProblem].filter(Boolean).join(' — ');
        if (!channelProfileId && wfRows[0].channelProfileId) {
          channelProfileId = wfRows[0].channelProfileId;
        }
      }
    }

    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      channelProfileId
    );
    const topic =
      (typeof req.body?.topic === 'string' && req.body.topic.trim()) ||
      projectTitle ||
      activeProfile.niche ||
      'Audience engagement question';

    const generated = await aiYtmGenerateCommunityPost({
      formatType,
      topic: topic.slice(0, 300),
      projectTitle,
      projectTopicSummary,
      channelDnaPrompt: formatChannelDnaForPrompt(activeProfile),
      instruction:
        typeof req.body?.instruction === 'string' ? req.body.instruction.trim().slice(0, 300) : undefined,
    });

    return okJson(res, {
      formatType,
      topic,
      title: generated.title,
      payload: generated.payload,
    });
  } catch (err) {
    return handleErr(res, err, 'Failed to generate Community Post draft.');
  }
});

router.post('/community-posts', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });

    const validFormats = new Set<YtmCommunityPostFormat>([
      'quiz',
      'text_poll',
      'image_poll',
      'image_post',
      'simple_text',
    ]);
    const formatType = validFormats.has(req.body?.formatType)
      ? (req.body.formatType as YtmCommunityPostFormat)
      : 'simple_text';

    const status = ['draft', 'approved', 'manually_published'].includes(req.body?.status)
      ? req.body.status
      : 'draft';

    const inserted = await db
      .insert(ytmCommunityPosts)
      .values({
        workspaceId: workspace.id,
        workflowProjectId:
          typeof req.body?.workflowProjectId === 'number' ? req.body.workflowProjectId : null,
        channelProfileId:
          typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null,
        createdByUserId: req.dbUser!.id,
        formatType,
        topic: typeof req.body?.topic === 'string' ? req.body.topic.trim().slice(0, 300) : '',
        title:
          typeof req.body?.title === 'string' && req.body.title.trim()
            ? req.body.title.trim().slice(0, 180)
            : `Community ${formatType.replace(/_/g, ' ')} Draft`,
        payloadJson: JSON.stringify(req.body?.payload || {}),
        status,
        approvedAt: status === 'approved' ? new Date() : null,
        scheduledAt: typeof req.body?.scheduledAt === 'string' ? req.body.scheduledAt : null,
      })
      .returning();

    return okJson(res, { post: hydrateCommunityPost(inserted[0]) }, 201);
  } catch (err) {
    return handleErr(res, err, 'Failed to save Community Post draft.');
  }
});

router.patch('/community-posts/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const postId = Number.parseInt(String(req.params.id), 10);
    const patch: Record<string, unknown> = { updatedAt: new Date() };

    if (typeof req.body?.title === 'string') patch.title = req.body.title.trim().slice(0, 180);
    if (typeof req.body?.topic === 'string') patch.topic = req.body.topic.trim().slice(0, 300);
    if (req.body?.payload && typeof req.body.payload === 'object') {
      patch.payloadJson = JSON.stringify(req.body.payload);
    }
    if (['draft', 'approved', 'manually_published'].includes(req.body?.status)) {
      patch.status = req.body.status;
      if (req.body.status === 'approved') patch.approvedAt = new Date();
    }
    if (req.body?.scheduledAt !== undefined) {
      patch.scheduledAt = typeof req.body.scheduledAt === 'string' ? req.body.scheduledAt : null;
    }

    const updated = await db
      .update(ytmCommunityPosts)
      .set(patch)
      .where(
        and(eq(ytmCommunityPosts.id, postId), eq(ytmCommunityPosts.workspaceId, workspace.id))
      )
      .returning();

    if (!updated[0]) return failJson(res, 404, 'NOT_FOUND', 'Community post not found.');
    return okJson(res, { post: hydrateCommunityPost(updated[0]) });
  } catch (err) {
    return handleErr(res, err, 'Failed to update Community Post.');
  }
});

router.delete('/community-posts/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const postId = Number.parseInt(String(req.params.id), 10);
    await db
      .delete(ytmCommunityPosts)
      .where(
        and(eq(ytmCommunityPosts.id, postId), eq(ytmCommunityPosts.workspaceId, workspace.id))
      );
    return okJson(res, { deleted: true });
  } catch (err) {
    return handleErr(res, err, 'Failed to delete Community Post.');
  }
});

router.post(
  '/community-posts/upload-image',
  imageUpload.single('image'),
  async (req: AuthRequest, res) => {
    try {
      const { workspace } = await resolveAuthorizedWorkspace({
        userId: req.dbUser!.id,
        workspaceKey: getWorkspaceKeyFromReq(req),
        requiredPermission: 'workflow:write',
      });
      if (!req.file || !req.file.mimetype.startsWith('image/')) {
        return failJson(res, 400, 'INVALID_IMAGE', 'Please upload a valid PNG, JPG, or WebP image.');
      }
      const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
      const inserted = await db
        .insert(ytmAssets)
        .values({
          workspaceId: workspace.id,
          uploadedByUserId: req.dbUser!.id,
          assetType: 'thumbnail',
          title: `Community Post Visual (${req.file.originalname.slice(0, 60)})`,
          mimeType: req.file.mimetype,
          fileSizeBytes: req.file.size,
          dataUrlOrPath: dataUrl,
          tagsJson: JSON.stringify(['community_post']),
        })
        .returning();

      return okJson(res, { imageUrl: dataUrl, assetId: inserted[0].id }, 201);
    } catch (err) {
      return handleErr(res, err, 'Unable to upload community post image.');
    }
  }
);

// ==============================================================================
// 3. CREATOR PERFORMANCE COACH ROUTES (Sidebar Option 6 — Real Data Only)
// ==============================================================================
router.get('/coach', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'analytics:read',
    });

    const [connectedChannel, snapshots, actions] = await Promise.all([
      getWorkspaceConnectedChannel(workspace.id),
      db
        .select()
        .from(ytmCoachSnapshots)
        .where(eq(ytmCoachSnapshots.workspaceId, workspace.id))
        .orderBy(desc(ytmCoachSnapshots.createdAt))
        .limit(12),
      db
        .select()
        .from(ytmCoachActions)
        .where(eq(ytmCoachActions.workspaceId, workspace.id))
        .orderBy(desc(ytmCoachActions.createdAt))
        .limit(40),
    ]);

    return okJson(res, {
      connectedChannel,
      latestSnapshot: snapshots[0] ? hydrateCoachSnapshot(snapshots[0]) : null,
      snapshotHistory: snapshots.map(hydrateCoachSnapshot),
      actions: actions.map(hydrateCoachAction),
    });
  } catch (err) {
    return handleErr(res, err, 'Unable to load Creator Performance Coach.');
  }
});

router.post('/coach/analyze', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'analytics:read',
    });

    const connectedChannel = await getWorkspaceConnectedChannel(workspace.id);
    if (!connectedChannel) {
      return failJson(
        res,
        400,
        'YOUTUBE_AUTHORIZATION_REQUIRED',
        'Connect your YouTube channel via Google OAuth to run Creator Performance Coach. Coach never fabricates channel performance metrics.'
      );
    }

    const days = Math.min(90, Math.max(7, Number(req.body?.days) || 28));
    const endDate = new Date().toISOString().slice(0, 10);
    const startDate = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
    const prevEndDate = new Date(Date.now() - (days + 1) * 86400000).toISOString().slice(0, 10);
    const prevStartDate = new Date(Date.now() - (days * 2 + 1) * 86400000)
      .toISOString()
      .slice(0, 10);

    const currentReport = await fetchAuthorizedChannelAnalytics({
      workspaceId: workspace.id,
      startDate,
      endDate,
    });

    let previousReport = null;
    try {
      previousReport = await fetchAuthorizedChannelAnalytics({
        workspaceId: workspace.id,
        startDate: prevStartDate,
        endDate: prevEndDate,
      });
    } catch {
      previousReport = null;
    }

    const activeProfile = await getActiveChannelProfileWithDna(
      workspace,
      req.dbUser!.id,
      typeof req.body?.channelProfileId === 'number' ? req.body.channelProfileId : null
    );

    // Optional external competitor intelligence context (explicitly separated from own channel data)
    const [recentCompReports, savedInsp, recentWorkflows] = await Promise.all([
      db
        .select()
        .from(competitorReports)
        .where(eq(competitorReports.userId, req.dbUser!.id))
        .orderBy(desc(competitorReports.updatedAt))
        .limit(2),
      db
        .select()
        .from(savedInspiration)
        .where(eq(savedInspiration.workspaceId, workspace.id))
        .orderBy(desc(savedInspiration.updatedAt))
        .limit(6),
      db
        .select()
        .from(ytmWorkflowProjects)
        .where(eq(ytmWorkflowProjects.workspaceId, workspace.id))
        .orderBy(desc(ytmWorkflowProjects.updatedAt))
        .limit(10),
    ]);

    const externalParts: string[] = [];
    for (const r of recentCompReports) {
      const synth = safeJsonParse<{
        executiveSummary?: string;
        module10ContentGaps?: { underservedTopics?: string[] };
      } | null>(r.synthesisJson || '', null);
      if (synth?.executiveSummary) {
        externalParts.push(`Report "${r.title}": ${synth.executiveSummary.slice(0, 350)}`);
      }
      if (synth?.module10ContentGaps?.underservedTopics?.length) {
        externalParts.push(
          `Competitor White-Space Topics: ${synth.module10ContentGaps.underservedTopics
            .slice(0, 5)
            .join(', ')}`
        );
      }
    }
    if (savedInsp.length > 0) {
      externalParts.push(
        `Saved Competitor Inspirations: ${savedInsp
          .map((i) => `"${i.originalVideoTitle}" (${i.competitorChannelName})`)
          .join('; ')}`
      );
    }

    const netSubs =
      currentReport.totals.subscribersGained !== null
        ? currentReport.totals.subscribersGained - (currentReport.totals.subscribersLost || 0)
        : null;
    const prevNetSubs =
      previousReport && previousReport.totals.subscribersGained !== null
        ? previousReport.totals.subscribersGained - (previousReport.totals.subscribersLost || 0)
        : null;

    const uploadsInPeriod = currentReport.topVideos.filter(
      (v) => v.publishedAt && v.publishedAt.slice(0, 10) >= startDate
    ).length;

    const metricsSummary: YtmCoachMetricSnapshot = {
      currentPeriod: { start: startDate, end: endDate },
      previousPeriod: { start: prevStartDate, end: prevEndDate },
      views: currentReport.totals.views,
      previousViews: previousReport?.totals.views ?? null,
      watchTimeMinutes: currentReport.totals.estimatedMinutesWatched,
      previousWatchTimeMinutes: previousReport?.totals.estimatedMinutesWatched ?? null,
      avgViewDurationSec: currentReport.totals.averageViewDurationSec,
      previousAvgViewDurationSec: previousReport?.totals.averageViewDurationSec ?? null,
      subscribersNet: netSubs,
      previousSubscribersNet: prevNetSubs,
      likes: currentReport.totals.likes,
      comments: currentReport.totals.comments,
      uploadsInPeriod,
      impressionsAvailable: currentReport.totals.impressions !== null,
      impressionsCtrAvailable: currentReport.totals.impressionsCtr !== null,
      returningViewersAvailable: false,
      unavailableMetricsDisclosure:
        currentReport.unavailableMetricsNote ||
        'Impressions, Impressions CTR, and Returning vs New Viewers are not exposed by the standard YouTube Analytics API v2 OAuth endpoints and are never fabricated.',
    };

    const coaching = await aiYtmRunPerformanceCoach({
      channelTitle: connectedChannel.channelTitle,
      currentReport,
      previousReport,
      metricsSummary,
      channelDnaPrompt: formatChannelDnaForPrompt(activeProfile),
      externalCompetitorSummary: externalParts.join('\n') || undefined,
      recentPublishingCadenceNote: `Videos detected in period: ${uploadsInPeriod}. Active/recent workflow productions in workspace: ${recentWorkflows.length}.`,
    });

    const insertedSnap = await db
      .insert(ytmCoachSnapshots)
      .values({
        workspaceId: workspace.id,
        channelProfileId: activeProfile.id,
        channelId: connectedChannel.channelId,
        periodStart: startDate,
        periodEnd: endDate,
        previousPeriodStart: prevStartDate,
        previousPeriodEnd: prevEndDate,
        dataSource: currentReport.source,
        metricsSummaryJson: JSON.stringify(metricsSummary),
        diagnosisJson: JSON.stringify(coaching.diagnosis),
        improvementsJson: JSON.stringify(coaching.improvements),
        opportunitiesJson: JSON.stringify(coaching.opportunities),
        learningLessonsJson: JSON.stringify(coaching.learningLessons),
      })
      .returning();

    const insertedActions = [];
    for (const act of coaching.recommendedActions) {
      const ins = await db
        .insert(ytmCoachActions)
        .values({
          workspaceId: workspace.id,
          snapshotId: insertedSnap[0].id,
          horizon: act.horizon,
          title: act.title,
          rationale: act.rationale,
          actionSteps: act.actionSteps,
          expectedOutcome: act.expectedOutcome,
          metricToMeasure: act.metricToMeasure,
          priority: act.priority,
          status: 'pending',
        })
        .returning();
      insertedActions.push(hydrateCoachAction(ins[0]));
    }

    return okJson(
      res,
      {
        snapshot: hydrateCoachSnapshot(insertedSnap[0]),
        newActions: insertedActions,
      },
      201
    );
  } catch (err) {
    return handleErr(res, err, 'Unable to run Creator Performance Coach analysis.');
  }
});

router.patch('/coach/actions/:id', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const actionId = Number.parseInt(String(req.params.id), 10);
    const patch: Record<string, unknown> = { updatedAt: new Date() };

    if (
      ['pending', 'approved', 'in_progress', 'completed', 'dismissed'].includes(req.body?.status)
    ) {
      patch.status = req.body.status;
      if (req.body.status === 'completed') patch.completedAt = new Date();
    }
    if (typeof req.body?.outcomeNotes === 'string') {
      patch.outcomeNotes = req.body.outcomeNotes.trim().slice(0, 1200);
    }

    const updated = await db
      .update(ytmCoachActions)
      .set(patch)
      .where(and(eq(ytmCoachActions.id, actionId), eq(ytmCoachActions.workspaceId, workspace.id)))
      .returning();

    if (!updated[0]) return failJson(res, 404, 'NOT_FOUND', 'Coach action not found.');
    return okJson(res, { action: hydrateCoachAction(updated[0]) });
  } catch (err) {
    return handleErr(res, err, 'Failed to update coach action.');
  }
});

router.post('/coach/actions/:id/send-to-planner', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'planner:write',
    });
    const actionId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmCoachActions)
      .where(and(eq(ytmCoachActions.id, actionId), eq(ytmCoachActions.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) return failJson(res, 404, 'NOT_FOUND', 'Coach action not found.');

    const action = rows[0];
    const deadline =
      typeof req.body?.deadline === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(req.body.deadline)
        ? req.body.deadline
        : getTodayDateKey();

    const task = await db
      .insert(ytmPlannerTasks)
      .values({
        workspaceId: workspace.id,
        createdByUserId: req.dbUser!.id,
        taskName: `[Coach] ${action.title}`.slice(0, 240),
        workspaceSection: 'Coach',
        scheduledAt: deadline,
        deadline,
        priority: action.priority,
        status: 'Not Started',
        aiSuggested: true,
      })
      .returning();

    const updated = await db
      .update(ytmCoachActions)
      .set({
        status: 'in_progress',
        linkedPlannerTaskId: task[0].id,
        updatedAt: new Date(),
      })
      .where(eq(ytmCoachActions.id, actionId))
      .returning();

    return okJson(res, {
      action: hydrateCoachAction(updated[0]),
      plannerTaskId: task[0].id,
    });
  } catch (err) {
    return handleErr(res, err, 'Unable to send Coach action to Content Planner.');
  }
});

router.post('/coach/actions/:id/send-to-workflow', async (req: AuthRequest, res) => {
  try {
    const { workspace } = await resolveAuthorizedWorkspace({
      userId: req.dbUser!.id,
      workspaceKey: getWorkspaceKeyFromReq(req),
      requiredPermission: 'workflow:write',
    });
    const actionId = Number.parseInt(String(req.params.id), 10);
    const rows = await db
      .select()
      .from(ytmCoachActions)
      .where(and(eq(ytmCoachActions.id, actionId), eq(ytmCoachActions.workspaceId, workspace.id)))
      .limit(1);
    if (!rows[0]) return failJson(res, 404, 'NOT_FOUND', 'Coach action not found.');

    const action = rows[0];
    const activeProfile = await getActiveChannelProfileWithDna(workspace, req.dbUser!.id, null);

    const wf = await db
      .insert(ytmWorkflowProjects)
      .values({
        workspaceId: workspace.id,
        createdByUserId: req.dbUser!.id,
        title: action.title.slice(0, 180),
        currentStage: 1,
        projectStatus: 'NOT STARTED',
        stage4Mode: 'thumbnail',
        stage1TitleJson: JSON.stringify({
          seedIdea: action.title,
          options: [],
          selectedTitle: action.title,
          notes: `Created from Creator Performance Coach:\n${action.rationale}\n\nSteps:\n${action.actionSteps}`,
        }),
        stage2TopicJson: JSON.stringify({
          centralTopic: action.title,
          targetAudience: activeProfile.dna.targetAudience || '',
          coreProblem: action.rationale,
          desiredOutcome: action.expectedOutcome,
          valueAngle: action.actionSteps,
          supportingPoints: [],
          notes: `Measure: ${action.metricToMeasure}`,
        }),
        stage4ThumbnailJson: JSON.stringify({
          concepts: [],
          selectedConceptId: null,
          selectedTextOverlay: '',
          customImagePrompt: '',
          uploadedThumbnailAssetId: null,
          uploadedThumbnailUrl: null,
          notes: '',
        }),
        stage5SeoJson: JSON.stringify({
          description: '',
          keywords: [],
          tags: [],
          hashtags: [],
          chapters: [],
          pinnedComment: '',
          playlistRecommendation: '',
          uploadChecklist: [],
        }),
        approvalsJson: '{}',
        approvalTimestampsJson: '{}',
        channelProfileId: activeProfile.id,
      })
      .returning();

    const updated = await db
      .update(ytmCoachActions)
      .set({
        status: 'in_progress',
        linkedWorkflowProjectId: wf[0].id,
        updatedAt: new Date(),
      })
      .where(eq(ytmCoachActions.id, actionId))
      .returning();

    return okJson(res, {
      action: hydrateCoachAction(updated[0]),
      workflowProjectId: wf[0].id,
    });
  } catch (err) {
    return handleErr(res, err, 'Unable to create Workflow project from Coach action.');
  }
});

export default router;
