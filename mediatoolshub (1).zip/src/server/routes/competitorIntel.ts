import crypto from 'node:crypto';
import express from 'express';
import { desc, eq, or } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  competitorChannelCaches,
  competitorReports,
} from '../../db/schema.ts';
import type {
  ChannelDeepDiveAnalysis,
  CompetitorChannelCollection,
  CompetitorChannelProfile,
  CompetitorReportRecord,
  CrossCompetitorSynthesis,
  ScriptAiModelId,
} from '../../shared/types.ts';
import type { AuthRequest } from '../middleware/auth.ts';
import {
  aiAnalyzeSingleChannel,
  aiSynthesizeCrossCompetitorReport,
} from '../services/competitorAi.ts';
import { ScriptAiError } from '../services/scriptStudioAi.ts';
import {
  CollectorError,
  collectChannelWithVideos,
  resolveYouTubeChannel,
  searchYouTubeChannels,
} from '../services/youtubeCompetitorCollector.ts';

const router = express.Router();

function fail(res: express.Response, status: number, code: string, message: string) {
  return res.status(status).json({
    ok: false,
    error: { code, message },
  });
}

function getGuestToken(req: express.Request): string | null {
  const raw = req.header('x-script-guest-token') || req.header('x-competitor-guest-token');
  if (!raw) return null;
  const trimmed = raw.trim();
  return /^[a-zA-Z0-9_-]{8,120}$/.test(trimmed) ? trimmed : null;
}

function safeParseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function normalizeModelName(raw: unknown): ScriptAiModelId {
  return raw === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';
}

function hydrateReport(row: typeof competitorReports.$inferSelect): CompetitorReportRecord {
  const channelInputs = safeParseJson<string[]>(row.channelIdsJson, []);
  const collections = safeParseJson<CompetitorChannelCollection[]>(row.rawCollectionJson, []);
  const ownChannelCollection = safeParseJson<CompetitorChannelCollection | null>(
    row.ownChannelJson && row.ownChannelJson.startsWith('{') ? row.ownChannelJson : null,
    null
  );
  const ownChannelInput =
    row.ownChannelJson && !row.ownChannelJson.startsWith('{')
      ? row.ownChannelJson
      : ownChannelCollection?.profile?.channelUrl || null;
  const channelAnalyses = safeParseJson<Record<string, ChannelDeepDiveAnalysis>>(
    row.channelAnalysesJson,
    {}
  );
  const synthesis = safeParseJson<CrossCompetitorSynthesis | null>(row.synthesisJson, null);

  const validStatus = (
    ['draft', 'collecting', 'collected', 'analyzing', 'completed', 'failed'].includes(row.status)
      ? row.status
      : 'draft'
  ) as CompetitorReportRecord['status'];

  return {
    id: row.id,
    reportKey: row.reportKey,
    title: row.title,
    status: validStatus,
    currentStep: row.currentStep,
    modelName: normalizeModelName(row.modelName),
    sampleSize: row.sampleSize,
    ownChannelInput,
    ownChannelCollection,
    channelInputs,
    collections,
    channelAnalyses,
    synthesis,
    errorMessage: row.errorMessage || null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

async function loadOwnedReport(req: AuthRequest, reportKey: string) {
  const rows = await db
    .select()
    .from(competitorReports)
    .where(eq(competitorReports.reportKey, reportKey))
    .limit(1);

  const row = rows[0];
  if (!row) return null;

  const userId = req.dbUser?.id ?? null;
  const guestToken = getGuestToken(req);

  const ownedByUser = userId !== null && row.userId === userId;
  const ownedByGuest = guestToken !== null && row.guestToken === guestToken;
  const claimable = row.userId === null && row.guestToken === null;

  if (!ownedByUser && !ownedByGuest && !claimable) {
    return 'forbidden' as const;
  }

  if (userId !== null && row.userId === null && (ownedByGuest || claimable)) {
    await db
      .update(competitorReports)
      .set({ userId, updatedAt: new Date() })
      .where(eq(competitorReports.id, row.id));
    row.userId = userId;
  }

  return row;
}

function handleRouteError(res: express.Response, err: unknown, fallbackMessage: string) {
  if (err instanceof CollectorError) {
    return fail(res, err.statusCode, err.code, err.message);
  }
  if (err instanceof ScriptAiError) {
    return fail(res, err.statusCode, err.code, err.message);
  }
  console.error('[CompetitorIntel]', fallbackMessage, err);
  return fail(res, 500, 'COMPETITOR_INTEL_ERROR', fallbackMessage);
}

// Search YouTube channels by name
router.get('/channels/search', async (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim() : '';
  if (q.length < 2) {
    return fail(res, 400, 'INVALID_QUERY', 'Enter at least 2 characters to search YouTube channels.');
  }
  try {
    const results = await searchYouTubeChannels(q, 6);
    return res.json({ ok: true, results });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to search YouTube channels right now.');
  }
});

// Resolve one or multiple YouTube channel URLs / @handles / UC IDs
router.post('/channels/resolve', async (req, res) => {
  const rawInput = typeof req.body?.input === 'string' ? req.body.input.trim() : '';
  const rawInputs = Array.isArray(req.body?.inputs)
    ? req.body.inputs.filter((x: unknown): x is string => typeof x === 'string' && x.trim().length > 0)
    : rawInput
      ? [rawInput]
      : [];

  if (rawInputs.length === 0) {
    return fail(res, 400, 'INVALID_INPUT', 'Provide a YouTube channel URL, @handle, or UC channel ID.');
  }
  if (rawInputs.length > 10) {
    return fail(res, 400, 'TOO_MANY_CHANNELS', 'You can resolve up to 10 channels at once.');
  }

  try {
    const resolved: CompetitorChannelProfile[] = [];
    const errors: Array<{ input: string; message: string }> = [];

    for (const item of rawInputs) {
      try {
        const { profile } = await resolveYouTubeChannel(item);
        if (!resolved.some((r) => r.channelId === profile.channelId)) {
          resolved.push(profile);
        }
      } catch (itemErr) {
        if (itemErr instanceof CollectorError && itemErr.code === 'YOUTUBE_API_KEY_MISSING') {
          throw itemErr;
        }
        errors.push({
          input: item,
          message: itemErr instanceof Error ? itemErr.message : 'Unable to resolve channel.',
        });
      }
    }

    if (resolved.length === 0 && errors.length > 0) {
      return fail(res, 404, 'CHANNEL_NOT_FOUND', errors[0].message);
    }

    return res.json({ ok: true, channels: resolved, errors });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to resolve channel information.');
  }
});

// Entry Hub: saved reports + recently analyzed cached channels
router.get('/hub', async (req: AuthRequest, res) => {
  const userId = req.dbUser?.id ?? null;
  const guestToken = getGuestToken(req);

  try {
    let reportRows: Array<typeof competitorReports.$inferSelect> = [];
    if (userId || guestToken) {
      const condition =
        userId && guestToken
          ? or(eq(competitorReports.userId, userId), eq(competitorReports.guestToken, guestToken))
          : userId
            ? eq(competitorReports.userId, userId)
            : eq(competitorReports.guestToken, guestToken!);

      reportRows = await db
        .select()
        .from(competitorReports)
        .where(condition)
        .orderBy(desc(competitorReports.updatedAt))
        .limit(25);
    }

    const cachedRows = await db
      .select()
      .from(competitorChannelCaches)
      .orderBy(desc(competitorChannelCaches.retrievedAt))
      .limit(16);

    const reports = reportRows.map((row) => {
      const collections = safeParseJson<CompetitorChannelCollection[]>(row.rawCollectionJson, []);
      const channelInputs = safeParseJson<string[]>(row.channelIdsJson, []);
      return {
        reportKey: row.reportKey,
        title: row.title,
        status: row.status,
        channelCount: Math.max(collections.length, channelInputs.length),
        channelNames: collections.map((c) => c.profile.title),
        modelName: normalizeModelName(row.modelName),
        updatedAt: row.updatedAt.toISOString(),
        createdAt: row.createdAt.toISOString(),
      };
    });

    const cachedChannels = cachedRows.map((row) => {
      const profile = safeParseJson<{
        thumbnailUrl?: string | null;
        subscriberCount?: number | null;
      }>(row.channelJson, {});
      return {
        channelId: row.channelId,
        handle: row.handle,
        title: row.title,
        thumbnailUrl: profile.thumbnailUrl || null,
        subscriberCount: profile.subscriberCount ?? null,
        sampleSize: row.sampleSize,
        retrievedAt: row.retrievedAt.toISOString(),
      };
    });

    return res.json({ ok: true, reports, cachedChannels });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to load Competitor Intelligence hub.');
  }
});

// Create a new Competitor Intelligence report
router.post('/reports', async (req: AuthRequest, res) => {
  const guestToken = getGuestToken(req);
  const channelInputs = Array.isArray(req.body?.channelInputs)
    ? Array.from(
        new Set(
          req.body.channelInputs
            .filter((x: unknown): x is string => typeof x === 'string' && x.trim().length > 0)
            .map((x: string) => x.trim())
        )
      )
    : [];

  if (channelInputs.length < 1 || channelInputs.length > 10) {
    return fail(
      res,
      400,
      'INVALID_CHANNEL_COUNT',
      'Select between 1 and 10 YouTube competitor channels to analyze.'
    );
  }

  const ownChannelInput =
    typeof req.body?.ownChannelInput === 'string' && req.body.ownChannelInput.trim()
      ? req.body.ownChannelInput.trim()
      : null;

  const sampleSizeRaw = Number(req.body?.sampleSize ?? 20);
  const sampleSize = Number.isFinite(sampleSizeRaw)
    ? Math.min(50, Math.max(5, Math.round(sampleSizeRaw)))
    : 20;

  const modelName = normalizeModelName(req.body?.modelName);
  const title =
    typeof req.body?.title === 'string' && req.body.title.trim()
      ? req.body.title.trim().slice(0, 160)
      : `Competitor Report (${channelInputs.length} ${channelInputs.length === 1 ? 'Channel' : 'Channels'})`;

  const reportKey = `ci_${crypto.randomBytes(10).toString('hex')}`;

  try {
    const inserted = await db
      .insert(competitorReports)
      .values({
        reportKey,
        userId: req.dbUser?.id ?? null,
        guestToken,
        title,
        status: 'draft',
        currentStep: 'selection',
        modelName,
        sampleSize,
        ownChannelJson: ownChannelInput,
        channelIdsJson: JSON.stringify(channelInputs),
      })
      .returning();

    return res.status(201).json({ ok: true, report: hydrateReport(inserted[0]) });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to create competitor report.');
  }
});

// Load a saved report
router.get('/reports/:reportKey', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedReport(req, String(req.params.reportKey));
    if (row === null) return fail(res, 404, 'REPORT_NOT_FOUND', 'Competitor report not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'You do not have access to this report.');
    return res.json({ ok: true, report: hydrateReport(row) });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to load competitor report.');
  }
});

// Update report settings / channel selection / model
router.patch('/reports/:reportKey', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedReport(req, String(req.params.reportKey));
    if (row === null) return fail(res, 404, 'REPORT_NOT_FOUND', 'Competitor report not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'You do not have access to this report.');

    const patch: Partial<typeof competitorReports.$inferInsert> = {
      updatedAt: new Date(),
    };
    if (typeof req.body?.title === 'string' && req.body.title.trim()) {
      patch.title = req.body.title.trim().slice(0, 160);
    }
    if (req.body?.modelName) {
      patch.modelName = normalizeModelName(req.body.modelName);
    }
    if (typeof req.body?.sampleSize === 'number' && Number.isFinite(req.body.sampleSize)) {
      patch.sampleSize = Math.min(50, Math.max(5, Math.round(req.body.sampleSize)));
    }
    if (Array.isArray(req.body?.channelInputs) && req.body.channelInputs.length > 0 && req.body.channelInputs.length <= 10) {
      patch.channelIdsJson = JSON.stringify(req.body.channelInputs);
    }
    if (req.body?.ownChannelInput !== undefined) {
      patch.ownChannelJson =
        typeof req.body.ownChannelInput === 'string' && req.body.ownChannelInput.trim()
          ? req.body.ownChannelInput.trim()
          : null;
    }

    const updated = await db
      .update(competitorReports)
      .set(patch)
      .where(eq(competitorReports.id, row.id))
      .returning();

    return res.json({ ok: true, report: hydrateReport(updated[0]) });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to update report settings.');
  }
});

// Delete report
router.delete('/reports/:reportKey', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedReport(req, String(req.params.reportKey));
    if (row === null) return fail(res, 404, 'REPORT_NOT_FOUND', 'Competitor report not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'You do not have access to this report.');

    await db.delete(competitorReports).where(eq(competitorReports.id, row.id));
    return res.json({ ok: true, deleted: true });
  } catch (err) {
    return handleRouteError(res, err, 'Unable to delete competitor report.');
  }
});

// Step 1 of pipeline: Collect live YouTube API channel & video data + calculate outliers
router.post('/reports/:reportKey/collect', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedReport(req, String(req.params.reportKey));
    if (row === null) return fail(res, 404, 'REPORT_NOT_FOUND', 'Competitor report not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'You do not have access to this report.');

    const hydrated = hydrateReport(row);
    const forceRefresh = Boolean(req.body?.forceRefresh);
    const sampleSize =
      typeof req.body?.sampleSize === 'number' && Number.isFinite(req.body.sampleSize)
        ? Math.min(50, Math.max(5, Math.round(req.body.sampleSize)))
        : hydrated.sampleSize;

    const collections: CompetitorChannelCollection[] = [];
    const seenIds = new Set<string>();

    for (const input of hydrated.channelInputs) {
      const col = await collectChannelWithVideos(input, {
        sampleSize,
        forceRefresh,
        sampleTranscripts: true,
      });
      if (!seenIds.has(col.profile.channelId)) {
        seenIds.add(col.profile.channelId);
        collections.push(col);
      }
    }

    let ownCollection: CompetitorChannelCollection | null = null;
    if (hydrated.ownChannelInput) {
      try {
        ownCollection = await collectChannelWithVideos(hydrated.ownChannelInput, {
          sampleSize: Math.min(20, sampleSize),
          forceRefresh,
          sampleTranscripts: false,
        });
      } catch (ownErr) {
        if (ownErr instanceof CollectorError && ownErr.code === 'YOUTUBE_API_KEY_MISSING') {
          throw ownErr;
        }
        // Do not fail competitor collection if optional own channel lookup failed; clear note handled downstream
      }
    }

    const nextTitle =
      hydrated.title.startsWith('Competitor Report (') && collections.length > 0
        ? collections.map((c) => c.profile.title).slice(0, 3).join(' vs ') +
          (collections.length > 3 ? ` +${collections.length - 3}` : '')
        : hydrated.title;

    const updated = await db
      .update(competitorReports)
      .set({
        title: nextTitle.slice(0, 160),
        sampleSize,
        status: 'collected',
        currentStep: 'collected',
        rawCollectionJson: JSON.stringify(collections),
        ownChannelJson: ownCollection
          ? JSON.stringify(ownCollection)
          : hydrated.ownChannelInput,
        errorMessage: null,
        updatedAt: new Date(),
      })
      .where(eq(competitorReports.id, row.id))
      .returning();

    return res.json({ ok: true, report: hydrateReport(updated[0]) });
  } catch (err) {
    return handleRouteError(res, err, 'Failed to collect YouTube channel data.');
  }
});

// Step 2 of pipeline: Run Deep-Dive AI Modules 1-9 for ONE collected competitor channel (saves immediately)
router.post('/reports/:reportKey/analyze-channel', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedReport(req, String(req.params.reportKey));
    if (row === null) return fail(res, 404, 'REPORT_NOT_FOUND', 'Competitor report not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'You do not have access to this report.');

    const channelId = typeof req.body?.channelId === 'string' ? req.body.channelId.trim() : '';
    if (!channelId) {
      return fail(res, 400, 'CHANNEL_ID_REQUIRED', 'Provide channelId to analyze.');
    }

    const hydrated = hydrateReport(row);
    const collection = hydrated.collections.find((c) => c.profile.channelId === channelId);
    if (!collection) {
      return fail(
        res,
        400,
        'CHANNEL_NOT_COLLECTED',
        'Collect channel metrics first before running AI deep-dive analysis.'
      );
    }

    const modelName = req.body?.modelName
      ? normalizeModelName(req.body.modelName)
      : hydrated.modelName;

    const deepDive = await aiAnalyzeSingleChannel(collection, modelName);

    const nextAnalyses: Record<string, ChannelDeepDiveAnalysis> = {
      ...hydrated.channelAnalyses,
      [channelId]: deepDive,
    };

    const updated = await db
      .update(competitorReports)
      .set({
        modelName,
        status: 'analyzing',
        currentStep: `analyzed:${channelId}`,
        channelAnalysesJson: JSON.stringify(nextAnalyses),
        errorMessage: null,
        updatedAt: new Date(),
      })
      .where(eq(competitorReports.id, row.id))
      .returning();

    return res.json({
      ok: true,
      analyzedChannelId: channelId,
      report: hydrateReport(updated[0]),
    });
  } catch (err) {
    return handleRouteError(res, err, 'Failed to analyze competitor channel.');
  }
});

// Step 3 of pipeline: Cross-Competitor Synthesis, Module 10 Gaps, Module 11 Plan & 19-Section Report
router.post('/reports/:reportKey/synthesize', async (req: AuthRequest, res) => {
  try {
    const row = await loadOwnedReport(req, String(req.params.reportKey));
    if (row === null) return fail(res, 404, 'REPORT_NOT_FOUND', 'Competitor report not found.');
    if (row === 'forbidden') return fail(res, 403, 'FORBIDDEN', 'You do not have access to this report.');

    const hydrated = hydrateReport(row);
    if (hydrated.collections.length === 0) {
      return fail(
        res,
        400,
        'NO_COLLECTIONS',
        'Collect channel data before synthesizing the final report.'
      );
    }

    const modelName = req.body?.modelName
      ? normalizeModelName(req.body.modelName)
      : hydrated.modelName;

    const analysesList = Object.values(hydrated.channelAnalyses);
    const synthesis = await aiSynthesizeCrossCompetitorReport({
      collections: hydrated.collections,
      channelAnalyses: analysesList,
      ownChannelCollection: hydrated.ownChannelCollection,
      requestedModel: modelName,
    });

    const updated = await db
      .update(competitorReports)
      .set({
        modelName,
        status: 'completed',
        currentStep: 'completed',
        synthesisJson: JSON.stringify(synthesis),
        errorMessage: null,
        updatedAt: new Date(),
      })
      .where(eq(competitorReports.id, row.id))
      .returning();

    return res.json({ ok: true, report: hydrateReport(updated[0]) });
  } catch (err) {
    return handleRouteError(res, err, 'Failed to synthesize cross-competitor report.');
  }
});

export default router;
