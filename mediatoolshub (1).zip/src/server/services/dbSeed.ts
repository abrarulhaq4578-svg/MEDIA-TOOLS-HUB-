import { count } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  advertisements,
  blogPosts,
  platforms,
  seoPages,
  tools,
  websiteSettings,
} from '../../db/schema.ts';
import { PLATFORMS_CATALOG, TOOLS_CATALOG } from '../../shared/toolsCatalog.ts';
import { getServerConfig } from '../config/env.ts';

let seedPromise: Promise<void> | null = null;

async function runSeed() {
  try {
    // 1. Seed platforms
    for (const p of PLATFORMS_CATALOG) {
      await db
        .insert(platforms)
        .values({
          slug: p.slug,
          name: p.name,
          description: p.description,
          isEnabled: true,
          sortOrder: p.sortOrder,
        })
        .onConflictDoNothing({ target: platforms.slug });
    }

    // 2. Seed tools
    for (const t of TOOLS_CATALOG) {
      await db
        .insert(tools)
        .values({
          slug: t.slug,
          routePath: t.routePath,
          name: t.name,
          category: t.category,
          platformSlug: t.platformSlug,
          shortDescription: t.shortDescription,
          seoTitle: t.seoTitle,
          seoDescription: t.seoDescription,
          isEnabled: true,
          isPopular: t.isPopular,
          isNew: t.isNew,
        })
        .onConflictDoNothing({ target: tools.slug });
    }

    // 3. Seed 8 ad placements (disabled by default until publisher & approval are active)
    const placements = [
      {
        placementKey: 'header_banner',
        label: 'Header Advertisement',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: false,
        isEnabled: false,
        notes: 'Top leaderboard banner below navigation bar (728x90 desktop).',
      },
      {
        placementKey: 'hero_lower',
        label: 'Homepage Hero Lower Section',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: true,
        isEnabled: false,
        notes: 'Responsive unit below the main URL launcher.',
      },
      {
        placementKey: 'category_between',
        label: 'Between Tool Categories',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: true,
        isEnabled: false,
        notes: 'In-feed unit separating platform tool sections.',
      },
      {
        placementKey: 'desktop_sidebar',
        label: 'Desktop Tool Sidebar',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: false,
        isEnabled: false,
        notes: '300x250 or 300x600 sticky-safe sidebar beside tool documentation.',
      },
      {
        placementKey: 'below_results',
        label: 'Below Tool Results',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: true,
        isEnabled: false,
        notes: 'Clearly labeled unit spaced cleanly below extracted output cards.',
      },
      {
        placementKey: 'content_between',
        label: 'Between Educational Content Sections',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: true,
        isEnabled: false,
        notes: 'Spaced between instructions and FAQ sections.',
      },
      {
        placementKey: 'blog_article',
        label: 'Blog Article Advertisement',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: true,
        isEnabled: false,
        notes: 'In-article display slot inside editorial tutorials.',
      },
      {
        placementKey: 'footer_banner',
        label: 'Footer Advertisement',
        provider: 'google_adsense',
        adUnitId: '',
        desktopEnabled: true,
        mobileEnabled: true,
        isEnabled: false,
        notes: 'Subtle horizontal unit above the site footer.',
      },
    ];

    for (const ad of placements) {
      await db
        .insert(advertisements)
        .values(ad)
        .onConflictDoNothing({ target: advertisements.placementKey });
    }

    // 4. Seed blog posts if empty
    const existingPosts = await db.select({ value: count() }).from(blogPosts);
    if ((existingPosts[0]?.value ?? 0) === 0) {
      await db.insert(blogPosts).values([
        {
          slug: 'how-to-extract-youtube-thumbnails',
          title: 'How YouTube Thumbnail Resolutions Work (And Why 1280x720 Is Not Always Available)',
          excerpt:
            'Understand the exact differences between maxresdefault, sddefault, hqdefault, and mqdefault YouTube thumbnail images and how to optimize 16:9 covers.',
          coverImage: '/src/assets/images/blog_youtube_thumbnails_1794798335384.jpg',
          category: 'YouTube Guides',
          readTimeMinutes: 5,
          seoTitle: 'How to Extract YouTube Thumbnails & Understand Resolutions | MediaToolsHub',
          seoDescription:
            'Learn how YouTube stores maxresdefault, sddefault, and hqdefault thumbnails, why HD covers return 404 on older uploads, and best practices for 16:9 sizing.',
          isPublished: true,
          contentMarkdown: `## Why Not Every Video Has a 1280x720 Thumbnail

When you paste a YouTube link into a thumbnail extractor, you might notice that **Max Resolution (1280x720)** is available for recent 1080p uploads while older videos return a 404 for \`maxresdefault.jpg\`.

YouTube generates thumbnail variants based on the source video resolution and whether the creator uploaded a custom high-resolution cover image:

- **maxresdefault.jpg (1280x720)**: Created for HD/4K uploads or custom 16:9 HD thumbnails.
- **sddefault.jpg (640x480)**: Standard definition 4:3 frame (includes black letterboxing bars on 16:9 videos).
- **hqdefault.jpg (480x360)**: Consistently generated across virtually all public YouTube videos.
- **mqdefault.jpg (320x180)**: Clean 16:9 medium-resolution preview without letterboxing.
- **default.jpg (120x90)**: Compact 4:3 legacy thumbnail.

## How MediaToolsHub Verifies Availability

Rather than blindly linking to \`maxresdefault.jpg\` and showing broken images, our YouTube Thumbnail Extractor issues real HTTP \`HEAD\` checks against \`i.ytimg.com\` for each resolution. Only verified \`200 OK\` assets are enabled for preview and download, along with their true \`Content-Length\` file size.

## Best Practices for Your Own Thumbnails

1. Export at **1280 x 720 pixels** (minimum width 640 px) in **16:9 aspect ratio**.
2. Keep file size strictly **under 2 MB** using optimized JPEG or WebP/PNG compression.
3. Keep key typography away from the bottom-right corner where YouTube renders the duration timestamp overlay.`,
        },
        {
          slug: 'understanding-social-oembed-and-opengraph-metadata',
          title: 'Understanding Official oEmbed APIs vs. OpenGraph Metadata Across Social Platforms',
          excerpt:
            'A technical breakdown of how YouTube, TikTok, X/Twitter, Pinterest, and Meta handle public metadata extraction without bypassing platform rules.',
          coverImage: '/src/assets/images/blog_social_metadata_1794798335567.jpg',
          category: 'Platform Engineering',
          readTimeMinutes: 6,
          seoTitle: 'Official oEmbed vs OpenGraph Metadata Guide | MediaToolsHub',
          seoDescription:
            'Compare how YouTube Data API, TikTok oEmbed, X oEmbed, and Meta Graph API expose public post metadata responsibly.',
          isPublished: true,
          contentMarkdown: `## Why Compliant Metadata Extraction Matters

Modern social networks separate **public discovery metadata** from **private user feeds and protected video streams**. Relying on fragile HTML scrapers or credentialed session spoofing breaks quickly and violates platform terms.

### Official Public oEmbed Endpoints

Platforms such as **YouTube**, **TikTok**, and **X (Twitter)** publish documented oEmbed endpoints designed specifically for editorial previews and CMS integrations:

- Returns verified creator attribution (\`author_name\`, \`author_url\`).
- Provides canonical titles, thumbnail dimensions, and safe responsive \`html\` embed blocks.
- Requires zero login bypasses or private cookies.

### Token-Gated APIs (YouTube Data API v3 & Meta Graph API)

Certain engagement counters—such as YouTube view/like/comment totals or Instagram/Facebook oEmbed previews—require an explicit server-side API key or Meta App Access Token.

When those credentials are absent, **MediaToolsHub** transparently states why extended metrics are unavailable instead of fabricating counts or simulating analytics.

### Inspecting Your Own OpenGraph Tags

When publishing articles or landing pages, verify that \`og:title\`, \`og:description\`, \`og:image\`, and \`twitter:card\` are cleanly populated using our **URL Analyzer & OpenGraph Inspector**.`,
        },
        {
          slug: 'privacy-first-browser-media-conversion-and-ssrf-security',
          title: 'Privacy-First Media Utilities: Local Browser Processing & SSRF Defense',
          excerpt:
            'How client-side Canvas image conversion keeps creative drafts private, and how SSRF URL allowlisting protects server-side metadata tools.',
          coverImage: '/src/assets/images/blog_media_privacy_1794798335783.jpg',
          category: 'Security & Privacy',
          readTimeMinutes: 4,
          seoTitle: 'Browser Media Processing & SSRF Security Explained | MediaToolsHub',
          seoDescription:
            'Learn how MediaToolsHub protects user files with local browser conversion and defends backend metadata endpoints against SSRF.',
          isPublished: true,
          contentMarkdown: `## Keeping Creative Files Off External Servers

When converting PNG thumbnails to WebP or inspecting MP4 video dimensions, uploading 200 MB files to a remote server wastes bandwidth and introduces privacy exposure.

MediaToolsHub executes **Image Conversion**, **Image Metadata Extraction**, **Video Metadata Inspection**, **QR Code Generation**, and **Text/JSON Formatting** directly in your browser memory:

- Zero temporary media storage on disk for local conversions.
- Instantaneous file size comparisons between PNG, JPEG, and WebP.
- Immediate download directly from an in-memory Blob URL.

## Securing Server-Side URL Tools Against SSRF

Any web utility that accepts a user-supplied URL on the backend must guard against **Server-Side Request Forgery (SSRF)**—where an attacker submits internal IP addresses like \`127.0.0.1\` or cloud metadata endpoints like \`169.254.169.254\`.

Every server-side URL validation endpoint on MediaToolsHub enforces:

1. Strict \`http:\` / \`https:\` protocol checks with zero embedded credentials.
2. DNS resolution verification blocking private IPv4/IPv6 ranges before opening a socket.
3. Manual redirect inspection on every hop and short request timeouts.`,
        },
      ]);
    }

    // 5. Seed website settings
    const cfg = getServerConfig();
    const defaultSettings = [
      { key: 'site_name', value: 'MediaToolsHub' },
      { key: 'rate_limit_per_min', value: '60' },
      { key: 'adsense_publisher_id', value: cfg.adsensePublisherId || '' },
      { key: 'ga_measurement_id', value: cfg.gaMeasurementId || '' },
      { key: 'gsc_verification_token', value: cfg.gscVerificationToken || '' },
      { key: 'maintenance_mode', value: 'false' },
    ];
    for (const s of defaultSettings) {
      await db
        .insert(websiteSettings)
        .values(s)
        .onConflictDoNothing({ target: websiteSettings.key });
    }

    // 6. Seed core SEO pages
    const defaultSeoPages = [
      {
        path: '/',
        title: 'MediaToolsHub – All Your Social Media Tools in One Place',
        metaDescription:
          'Free online social media utilities to extract YouTube thumbnails, analyze permitted video metadata, convert image formats, and generate QR codes.',
        canonicalPath: '/',
        ogTitle: 'MediaToolsHub – All Your Social Media Tools in One Place',
        ogDescription:
          'Extract YouTube thumbnails, inspect public social metadata, convert images, and generate QR codes in one fast, privacy-conscious workspace.',
        schemaType: 'WebApplication',
      },
      {
        path: '/blog',
        title: 'Blog & Tutorials | MediaToolsHub',
        metaDescription:
          'Practical guides on social media thumbnails, oEmbed metadata APIs, image optimization, and privacy-first web utilities.',
        canonicalPath: '/blog',
        ogTitle: 'MediaToolsHub Editorial Guides & Tutorials',
        ogDescription:
          'Learn how social media metadata, thumbnail sizing, and browser media utilities work.',
        schemaType: 'Blog',
      },
    ];
    for (const sp of defaultSeoPages) {
      await db
        .insert(seoPages)
        .values(sp)
        .onConflictDoNothing({ target: seoPages.path });
    }
  } catch (error) {
    console.error('Database seed warning:', error);
    seedPromise = null;
  }
}

export function ensureDatabaseSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = runSeed();
  }
  return seedPromise;
}
