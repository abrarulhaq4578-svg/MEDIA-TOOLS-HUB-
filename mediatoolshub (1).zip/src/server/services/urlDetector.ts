import type { PlatformSlug, UrlValidationResult } from '../../shared/types.ts';
import { validateUrlSyntaxOnly } from './ssrfGuard.ts';

export function extractYouTubeVideoId(url: URL): string | null {
  const host = url.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '');
  if (host === 'youtu.be') {
    const seg = url.pathname.split('/').filter(Boolean)[0];
    return seg && /^[a-zA-Z0-9_-]{11}$/.test(seg) ? seg : null;
  }

  if (host === 'youtube.com' || host === 'music.youtube.com' || host === 'youtube-nocookie.com') {
    const vParam = url.searchParams.get('v');
    if (vParam && /^[a-zA-Z0-9_-]{11}$/.test(vParam)) {
      return vParam;
    }
    const parts = url.pathname.split('/').filter(Boolean);
    if (
      parts.length >= 2 &&
      (parts[0] === 'shorts' || parts[0] === 'embed' || parts[0] === 'live' || parts[0] === 'v') &&
      /^[a-zA-Z0-9_-]{11}$/.test(parts[1])
    ) {
      return parts[1];
    }
  }
  return null;
}

export function detectPlatformFromUrl(rawUrl: string): UrlValidationResult {
  const syntax = validateUrlSyntaxOnly(rawUrl);
  if (!syntax.safe || !syntax.url) {
    return {
      valid: false,
      platform: 'general',
      ssrfSafe: false,
      reason: syntax.reason || 'Invalid URL.',
    };
  }

  const parsed = syntax.url;
  const host = parsed.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '');

  // YouTube
  if (
    host === 'youtube.com' ||
    host === 'youtu.be' ||
    host === 'music.youtube.com' ||
    host === 'youtube-nocookie.com'
  ) {
    const videoId = extractYouTubeVideoId(parsed);
    if (!videoId) {
      return {
        valid: false,
        normalizedUrl: parsed.toString(),
        hostname: host,
        platform: 'youtube',
        ssrfSafe: true,
        reason: 'Valid YouTube host, but no 11-character video ID was found in this URL.',
      };
    }
    return {
      valid: true,
      normalizedUrl: `https://www.youtube.com/watch?v=${videoId}`,
      hostname: host,
      platform: 'youtube',
      entityId: videoId,
      entityType: parsed.pathname.startsWith('/shorts/') ? 'short' : 'video',
      ssrfSafe: true,
    };
  }

  // Instagram
  if (host === 'instagram.com' || host === 'instagr.am') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    let entityType = 'profile';
    let entityId = parts[0] || '';
    if (parts[0] === 'p' && parts[1]) {
      entityType = 'post';
      entityId = parts[1];
    } else if ((parts[0] === 'reel' || parts[0] === 'reels') && parts[1]) {
      entityType = 'reel';
      entityId = parts[1];
    } else if (parts[0] === 'tv' && parts[1]) {
      entityType = 'video';
      entityId = parts[1];
    }
    return {
      valid: parts.length > 0,
      normalizedUrl: `https://www.instagram.com/${parts.slice(0, 2).join('/')}/`,
      hostname: host,
      platform: 'instagram',
      entityId: entityId || undefined,
      entityType,
      ssrfSafe: true,
      reason: parts.length === 0 ? 'Missing Instagram profile or post path.' : undefined,
    };
  }

  // Pinterest (including international ccTLDs and pin.it shortener)
  if (
    host === 'pin.it' ||
    host === 'pinterest.com' ||
    host.endsWith('.pinterest.com') ||
    /^(?:[a-z]{2}\.)?pinterest\.(?:co\.uk|ca|de|fr|es|it|jp|com\.au|com\.mx)$/.test(host)
  ) {
    const parts = parsed.pathname.split('/').filter(Boolean);
    const pinIdx = parts.indexOf('pin');
    const pinId = pinIdx >= 0 && parts[pinIdx + 1] ? parts[pinIdx + 1] : parts[0];
    return {
      valid: parts.length > 0,
      normalizedUrl:
        pinIdx >= 0 && pinId
          ? `https://www.pinterest.com/pin/${pinId}/`
          : `${parsed.origin}${parsed.pathname}`,
      hostname: host,
      platform: 'pinterest',
      entityId: pinId,
      entityType: pinIdx >= 0 ? 'pin' : 'board_or_profile',
      ssrfSafe: true,
      reason: parts.length === 0 ? 'Missing Pinterest pin path.' : undefined,
    };
  }

  // TikTok
  if (host === 'tiktok.com' || host === 'vm.tiktok.com' || host === 'vt.tiktok.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    const videoIdx = parts.indexOf('video');
    const videoId = videoIdx >= 0 && parts[videoIdx + 1] ? parts[videoIdx + 1] : undefined;
    return {
      valid: parts.length > 0,
      normalizedUrl: `${parsed.origin}${parsed.pathname}`,
      hostname: host,
      platform: 'tiktok',
      entityId: videoId || parts[0],
      entityType: videoId ? 'video' : 'link',
      ssrfSafe: true,
      reason: parts.length === 0 ? 'Missing TikTok video path.' : undefined,
    };
  }

  // Facebook
  if (host === 'facebook.com' || host === 'fb.watch' || host === 'web.facebook.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    const isVideoLike =
      host === 'fb.watch' ||
      parsed.pathname.includes('video') ||
      parts[0] === 'reel' ||
      parts[0] === 'watch' ||
      (parts[0] === 'share' && (parts[1] === 'v' || parts[1] === 'r'));
    return {
      valid: parts.length > 0 || parsed.searchParams.has('v'),
      normalizedUrl: `${parsed.origin}${parsed.pathname}${parsed.searchParams.has('v') ? `?v=${parsed.searchParams.get('v')}` : ''}`,
      hostname: host,
      platform: 'facebook',
      entityId: parsed.searchParams.get('v') || parts[parts.length - 1],
      entityType: isVideoLike ? 'video' : 'post',
      ssrfSafe: true,
    };
  }

  // Twitter / X
  if (host === 'x.com' || host === 'twitter.com') {
    const parts = parsed.pathname.split('/').filter(Boolean);
    const statusIdx = parts.indexOf('status');
    const statusId = statusIdx >= 0 && parts[statusIdx + 1] ? parts[statusIdx + 1] : undefined;
    return {
      valid: Boolean(statusId),
      normalizedUrl: statusId ? `https://x.com/${parts[0]}/status/${statusId}` : parsed.toString(),
      hostname: host,
      platform: 'twitter',
      entityId: statusId,
      entityType: statusId ? 'status' : 'profile',
      ssrfSafe: true,
      reason: statusId ? undefined : 'Include a direct /status/<id> tweet or post URL.',
    };
  }

  const platform: PlatformSlug = 'general';
  return {
    valid: true,
    normalizedUrl: parsed.toString(),
    hostname: host,
    platform,
    entityType: 'webpage',
    ssrfSafe: true,
  };
}

export interface MediaUrlClassification {
  valid: boolean;
  normalizedUrl?: string;
  hostname?: string;
  platform: PlatformSlug;
  entityId?: string;
  entityType?: string;
  sourceType: import('../../shared/types.ts').MediaUrlSourceType;
  downloadable: boolean;
  supportedFunctionality: string[];
  ssrfSafe: boolean;
  reason?: string;
}

export const PLATFORM_DISPLAY_LABELS: Record<PlatformSlug, string> = {
  youtube: 'YouTube',
  instagram: 'Instagram',
  pinterest: 'Pinterest',
  tiktok: 'TikTok',
  facebook: 'Facebook',
  twitter: 'X / Twitter',
  general: 'Direct Media Source',
};

export function classifyMediaUrl(rawUrl: string): MediaUrlClassification {
  const base = detectPlatformFromUrl(rawUrl);
  if (!base.valid || !base.normalizedUrl) {
    return {
      valid: false,
      platform: base.platform,
      hostname: base.hostname,
      entityType: base.entityType,
      sourceType: 'webpage',
      downloadable: false,
      supportedFunctionality: [],
      ssrfSafe: base.ssrfSafe,
      reason: base.reason,
    };
  }

  const parsedInput = new URL(rawUrl.trim());
  const rawHost = parsedInput.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '');

  if (base.platform === 'youtube') {
    const isShort =
      rawHost === 'youtu.be' || parsedInput.pathname.toLowerCase().startsWith('/shorts/');
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'youtube',
      entityId: base.entityId,
      entityType: base.entityType,
      sourceType: isShort ? 'youtube-short' : 'youtube-watch',
      downloadable: false,
      supportedFunctionality: [
        'metadata',
        'thumbnails',
        'channel-info',
        'statistics',
        'transcript',
        'studio-takeout-export',
      ],
      ssrfSafe: true,
    };
  }

  if (
    base.platform === 'instagram' ||
    base.platform === 'pinterest' ||
    base.platform === 'tiktok' ||
    base.platform === 'facebook' ||
    base.platform === 'twitter'
  ) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: base.platform,
      entityId: base.entityId,
      entityType: base.entityType,
      sourceType: base.platform,
      downloadable: false,
      supportedFunctionality: ['metadata', 'oembed', 'official-link'],
      ssrfSafe: true,
    };
  }

  const lowerPath = parsedInput.pathname.toLowerCase();
  if (lowerPath.endsWith('.mp4') || lowerPath.endsWith('.m4v')) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'general',
      entityType: 'direct-video',
      sourceType: 'direct-mp4',
      downloadable: true,
      supportedFunctionality: ['inspect', 'mp4-convert', 'mp3-convert', 'download'],
      ssrfSafe: true,
    };
  }
  if (lowerPath.endsWith('.webm')) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'general',
      entityType: 'direct-video',
      sourceType: 'direct-webm',
      downloadable: true,
      supportedFunctionality: ['inspect', 'mp4-convert', 'mp3-convert', 'download'],
      ssrfSafe: true,
    };
  }
  if (lowerPath.endsWith('.mov')) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'general',
      entityType: 'direct-video',
      sourceType: 'direct-mov',
      downloadable: true,
      supportedFunctionality: ['inspect', 'mp4-convert', 'mp3-convert', 'download'],
      ssrfSafe: true,
    };
  }
  if (lowerPath.endsWith('.mp3')) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'general',
      entityType: 'direct-audio',
      sourceType: 'direct-mp3',
      downloadable: true,
      supportedFunctionality: ['inspect', 'mp3-convert', 'download'],
      ssrfSafe: true,
    };
  }
  if (lowerPath.endsWith('.wav')) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'general',
      entityType: 'direct-audio',
      sourceType: 'direct-wav',
      downloadable: true,
      supportedFunctionality: ['inspect', 'mp3-convert', 'download'],
      ssrfSafe: true,
    };
  }
  if (lowerPath.endsWith('.m4a')) {
    return {
      valid: true,
      normalizedUrl: base.normalizedUrl,
      hostname: base.hostname,
      platform: 'general',
      entityType: 'direct-audio',
      sourceType: 'direct-m4a',
      downloadable: true,
      supportedFunctionality: ['inspect', 'mp3-convert', 'download'],
      ssrfSafe: true,
    };
  }

  return {
    valid: true,
    normalizedUrl: base.normalizedUrl,
    hostname: base.hostname,
    platform: 'general',
    entityType: 'webpage',
    sourceType: 'webpage',
    downloadable: false,
    supportedFunctionality: ['metadata'],
    ssrfSafe: true,
  };
}

export function detectAndNormalizeUrl(rawUrl: string): import('../../shared/types.ts').UrlDetectionReport {
  const classified = classifyMediaUrl(rawUrl);
  return {
    valid: classified.valid,
    rawUrl: rawUrl.trim(),
    normalizedUrl: classified.normalizedUrl,
    hostname: classified.hostname,
    platform: classified.platform,
    platformLabel: PLATFORM_DISPLAY_LABELS[classified.platform] || 'Web Source',
    entityId: classified.entityId,
    entityType: classified.entityType,
    sourceType: classified.sourceType,
    downloadable: classified.downloadable,
    supportedFunctionality: classified.supportedFunctionality,
    ssrfSafe: classified.ssrfSafe,
    reason: classified.reason,
  };
}
