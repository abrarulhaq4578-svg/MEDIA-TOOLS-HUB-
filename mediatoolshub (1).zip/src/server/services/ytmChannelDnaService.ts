import crypto from 'node:crypto';
import { and, desc, eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  adaptedIdeas,
  channelDna,
  channelProfiles,
  dailyPlans,
  savedInspiration,
} from '../../db/schema.ts';
import type {
  YtmAdaptedIdeaRecord,
  YtmChannelDnaRecord,
  YtmChannelProfileWithDna,
  YtmDailyPlanRecord,
  YtmDailyPlanSuggestion,
  YtmInspirationCategory,
  YtmInspirationStatus,
  YtmPlannerChecklistItem,
  YtmSavedInspirationRecord,
  YtmWorkspaceRecord,
} from '../../shared/types.ts';
import { YTM_DEFAULT_PRODUCTION_CHECKLIST } from '../../shared/ytmHelpers.ts';
import { safeJsonParse } from './ytmWorkspaceService.ts';

export function defaultChannelDna(): YtmChannelDnaRecord {
  return {
    targetAudience: '',
    preferredLanguage: 'English',
    contentCategories: [],
    contentFormat: 'Long-form YouTube',
    videoStyle: '',
    toneOfVoice: '',
    storytellingApproach: '',
    scriptStructure: '',
    preferredVideoDuration: '8–12 minutes',
    titlePreferences: '',
    thumbnailDesignPreferences: '',
    colorPalette: [],
    typography: '',
    wordsToUse: [],
    wordsToAvoid: [],
    uniquePositioning: '',
    audienceProblems: [],
    preferredFormats: [],
    brandVoice: '',
    publishingPreferences: '',
    contentRules: '',
    creativeGuidelines: '',
  };
}

export function normalizeStringList(raw: unknown, maxItems = 25, maxLen = 80): string[] {
  if (Array.isArray(raw)) {
    return raw
      .filter((item): item is string => typeof item === 'string' && item.trim().length > 0)
      .map((item) => item.trim().slice(0, maxLen))
      .slice(0, maxItems);
  }
  if (typeof raw === 'string') {
    return raw
      .split(/[\n,]/)
      .map((item) => item.trim().slice(0, maxLen))
      .filter(Boolean)
      .slice(0, maxItems);
  }
  return [];
}

export function hydrateChannelProfileWithDna(
  profile: typeof channelProfiles.$inferSelect,
  dnaRow?: typeof channelDna.$inferSelect | null
): YtmChannelProfileWithDna {
  const defaults = defaultChannelDna();
  const dna: YtmChannelDnaRecord = dnaRow
    ? {
        targetAudience: dnaRow.targetAudience || '',
        preferredLanguage: dnaRow.preferredLanguage || 'English',
        contentCategories: safeJsonParse<string[]>(dnaRow.contentCategoriesJson, []),
        contentFormat: dnaRow.contentFormat || 'Long-form YouTube',
        videoStyle: dnaRow.videoStyle || '',
        toneOfVoice: dnaRow.toneOfVoice || '',
        storytellingApproach: dnaRow.storytellingApproach || '',
        scriptStructure: dnaRow.scriptStructure || '',
        preferredVideoDuration: dnaRow.preferredVideoDuration || '8–12 minutes',
        titlePreferences: dnaRow.titlePreferences || '',
        thumbnailDesignPreferences: dnaRow.thumbnailDesignPreferences || '',
        colorPalette: safeJsonParse<string[]>(dnaRow.colorPaletteJson, []),
        typography: dnaRow.typography || '',
        wordsToUse: safeJsonParse<string[]>(dnaRow.wordsToUseJson, []),
        wordsToAvoid: safeJsonParse<string[]>(dnaRow.wordsToAvoidJson, []),
        uniquePositioning: dnaRow.uniquePositioning || '',
        audienceProblems: safeJsonParse<string[]>(dnaRow.audienceProblemsJson, []),
        preferredFormats: safeJsonParse<string[]>(dnaRow.preferredFormatsJson, []),
        brandVoice: dnaRow.brandVoice || '',
        publishingPreferences: dnaRow.publishingPreferences || '',
        contentRules: dnaRow.contentRules || '',
        creativeGuidelines: dnaRow.creativeGuidelines || '',
      }
    : defaults;

  return {
    id: profile.id,
    userId: profile.userId,
    workspaceId: profile.workspaceId,
    channelName: profile.channelName,
    channelHandle: profile.channelHandle || '',
    youtubeChannelId: profile.youtubeChannelId ?? null,
    description: profile.description || '',
    niche: profile.niche || '',
    subNiche: profile.subNiche || '',
    isDefault: profile.isDefault,
    dna,
    createdAt: profile.createdAt.toISOString(),
    updatedAt: profile.updatedAt.toISOString(),
  };
}

export async function ensureDefaultChannelProfile(
  workspace: YtmWorkspaceRecord,
  userId: number
): Promise<YtmChannelProfileWithDna> {
  const existing = await db
    .select()
    .from(channelProfiles)
    .where(eq(channelProfiles.workspaceId, workspace.id))
    .orderBy(desc(channelProfiles.isDefault), desc(channelProfiles.updatedAt))
    .limit(1);

  if (existing[0]) {
    const dnaRows = await db
      .select()
      .from(channelDna)
      .where(eq(channelDna.channelProfileId, existing[0].id))
      .limit(1);
    if (!dnaRows[0]) {
      const insertedDna = await db
        .insert(channelDna)
        .values({
          channelProfileId: existing[0].id,
          userId,
          workspaceId: workspace.id,
        })
        .returning();
      return hydrateChannelProfileWithDna(existing[0], insertedDna[0]);
    }
    return hydrateChannelProfileWithDna(existing[0], dnaRows[0]);
  }

  const insertedProfile = await db
    .insert(channelProfiles)
    .values({
      userId,
      workspaceId: workspace.id,
      channelName: workspace.name || 'Primary YouTube Channel',
      description: workspace.description || '',
      niche: '',
      subNiche: '',
      isDefault: true,
    })
    .returning();

  const insertedDna = await db
    .insert(channelDna)
    .values({
      channelProfileId: insertedProfile[0].id,
      userId,
      workspaceId: workspace.id,
      uniquePositioning: workspace.channelGoal || '',
    })
    .returning();

  return hydrateChannelProfileWithDna(insertedProfile[0], insertedDna[0]);
}

export async function listWorkspaceChannelProfiles(
  workspace: YtmWorkspaceRecord,
  userId: number
): Promise<YtmChannelProfileWithDna[]> {
  await ensureDefaultChannelProfile(workspace, userId);

  const [profiles, dnas] = await Promise.all([
    db
      .select()
      .from(channelProfiles)
      .where(eq(channelProfiles.workspaceId, workspace.id))
      .orderBy(desc(channelProfiles.isDefault), desc(channelProfiles.updatedAt)),
    db.select().from(channelDna).where(eq(channelDna.workspaceId, workspace.id)),
  ]);

  const dnaMap = new Map(dnas.map((d) => [d.channelProfileId, d]));
  return profiles.map((p) => hydrateChannelProfileWithDna(p, dnaMap.get(p.id) || null));
}

export async function getActiveChannelProfileWithDna(
  workspace: YtmWorkspaceRecord,
  userId: number,
  requestedChannelProfileId?: number | null
): Promise<YtmChannelProfileWithDna> {
  const profiles = await listWorkspaceChannelProfiles(workspace, userId);
  if (requestedChannelProfileId) {
    const matched = profiles.find((p) => p.id === requestedChannelProfileId);
    if (matched) return matched;
  }
  return profiles.find((p) => p.isDefault) || profiles[0];
}

export function formatChannelDnaForPrompt(profile: YtmChannelProfileWithDna | null | undefined): string {
  if (!profile) return '';
  const dna = profile.dna;
  const lines: string[] = [
    `ACTIVE CHANNEL DNA PROFILE (strictly align voice, positioning, format, and preferences to this channel):`,
    `- Channel Name: ${profile.channelName}${profile.channelHandle ? ` (${profile.channelHandle})` : ''}`,
  ];
  if (profile.description) lines.push(`- Channel Description: ${profile.description}`);
  if (profile.niche || profile.subNiche) {
    lines.push(`- Niche / Sub-niche: ${[profile.niche, profile.subNiche].filter(Boolean).join(' / ')}`);
  }
  if (dna.targetAudience) lines.push(`- Target Audience: ${dna.targetAudience}`);
  if (dna.preferredLanguage) lines.push(`- Preferred Language: ${dna.preferredLanguage}`);
  if (dna.contentCategories.length > 0) {
    lines.push(`- Content Categories: ${dna.contentCategories.join(', ')}`);
  }
  if (dna.contentFormat) lines.push(`- Content Format: ${dna.contentFormat}`);
  if (dna.videoStyle) lines.push(`- Video Style: ${dna.videoStyle}`);
  if (dna.toneOfVoice) lines.push(`- Tone of Voice: ${dna.toneOfVoice}`);
  if (dna.storytellingApproach) lines.push(`- Storytelling Approach: ${dna.storytellingApproach}`);
  if (dna.scriptStructure) lines.push(`- Script Structure: ${dna.scriptStructure}`);
  if (dna.preferredVideoDuration) lines.push(`- Preferred Video Duration: ${dna.preferredVideoDuration}`);
  if (dna.titlePreferences) lines.push(`- Title Preferences: ${dna.titlePreferences}`);
  if (dna.thumbnailDesignPreferences) {
    lines.push(`- Thumbnail Design Preferences: ${dna.thumbnailDesignPreferences}`);
  }
  if (dna.colorPalette.length > 0 || dna.typography) {
    lines.push(
      `- Visual Brand (Palette / Typography): ${[
        dna.colorPalette.length > 0 ? dna.colorPalette.join(', ') : '',
        dna.typography,
      ]
        .filter(Boolean)
        .join(' | ')}`
    );
  }
  if (dna.wordsToUse.length > 0) {
    lines.push(`- Preferred Words & Phrases: ${dna.wordsToUse.join(', ')}`);
  }
  if (dna.wordsToAvoid.length > 0) {
    lines.push(`- Words & Styles to AVOID: ${dna.wordsToAvoid.join(', ')}`);
  }
  if (dna.audienceProblems.length > 0) {
    lines.push(`- Core Audience Problems: ${dna.audienceProblems.join('; ')}`);
  }
  if (dna.preferredFormats.length > 0) {
    lines.push(`- Preferred Video Formats: ${dna.preferredFormats.join(', ')}`);
  }
  if (dna.brandVoice) lines.push(`- Brand Voice: ${dna.brandVoice}`);
  if (dna.publishingPreferences) {
    lines.push(`- Publishing Preferences: ${dna.publishingPreferences}`);
  }
  if (dna.contentRules) lines.push(`- Content Rules: ${dna.contentRules}`);
  if (dna.creativeGuidelines) lines.push(`- Creative Guidelines: ${dna.creativeGuidelines}`);
  if (dna.uniquePositioning) lines.push(`- Unique Channel Positioning: ${dna.uniquePositioning}`);

  return lines.join('\n');
}

export function normalizeYouTubeUrlForDedupe(rawUrl: string): string {
  const trimmed = (rawUrl || '').trim();
  if (!trimmed) return '';
  try {
    const u = new URL(trimmed);
    const vParam = u.searchParams.get('v');
    if (vParam) return `yt:${vParam.toLowerCase()}`;
    if (u.hostname.includes('youtu.be') && u.pathname.length > 1) {
      return `yt:${u.pathname.slice(1).split('/')[0].toLowerCase()}`;
    }
    if (u.pathname.includes('/shorts/')) {
      const seg = u.pathname.split('/shorts/')[1]?.split('/')[0];
      if (seg) return `yt:${seg.toLowerCase()}`;
    }
    return `${u.hostname.toLowerCase()}${u.pathname.toLowerCase().replace(/\/+$/, '')}`;
  } catch {
    return trimmed.toLowerCase().replace(/\s+/g, ' ');
  }
}

export function buildInspirationDedupeKey(params: {
  originalVideoUrl?: string | null;
  originalVideoTitle: string;
  inspirationCategory: string;
  inspirationSnippet?: string | null;
  channelProfileId?: number | null;
}): string {
  const urlNorm = normalizeYouTubeUrlForDedupe(params.originalVideoUrl || '');
  const titleNorm = (params.originalVideoTitle || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
  const catNorm = (params.inspirationCategory || 'video_topic').trim().toLowerCase();
  const snippetNorm = (params.inspirationSnippet || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .slice(0, 140);
  const channelPart = params.channelProfileId ? String(params.channelProfileId) : 'any';
  const base = `${channelPart}|${catNorm}|${urlNorm || titleNorm}|${snippetNorm}`;
  return crypto.createHash('sha256').update(base).digest('hex').slice(0, 40);
}

export function parsePlannerChecklist(rawJson: string | null | undefined): YtmPlannerChecklistItem[] {
  const parsed = safeJsonParse<unknown>(rawJson, []);
  if (!Array.isArray(parsed) || parsed.length === 0) {
    return YTM_DEFAULT_PRODUCTION_CHECKLIST.map((item) => ({ ...item }));
  }
  const clean = parsed
    .filter(
      (item): item is { id?: string; label?: string; done?: boolean } =>
        Boolean(item) && typeof item === 'object'
    )
    .map((item, idx) => ({
      id: typeof item.id === 'string' && item.id.trim() ? item.id.trim() : `chk_${idx + 1}`,
      label: typeof item.label === 'string' ? item.label.trim().slice(0, 160) : 'Checklist step',
      done: Boolean(item.done),
    }))
    .filter((item) => item.label.length > 0);
  return clean.length > 0 ? clean : YTM_DEFAULT_PRODUCTION_CHECKLIST.map((item) => ({ ...item }));
}

export function hydrateAdaptedIdea(row: typeof adaptedIdeas.$inferSelect): YtmAdaptedIdeaRecord {
  return {
    id: row.id,
    userId: row.userId,
    workspaceId: row.workspaceId,
    channelProfileId: row.channelProfileId ?? null,
    savedInspirationId: row.savedInspirationId ?? null,
    originalConceptSummary: row.originalConceptSummary || '',
    whyItWorks: row.whyItWorks || '',
    freshAngle: row.freshAngle || '',
    titleOptions: safeJsonParse<string[]>(row.titleOptionsJson, []),
    selectedTitle: row.selectedTitle || '',
    uniqueHook: row.uniqueHook || '',
    videoOutline: safeJsonParse<string[]>(row.videoOutlineJson, []),
    thumbnailDirection: row.thumbnailDirection || '',
    channelFitExplanation: row.channelFitExplanation || '',
    userNotes: row.userNotes || '',
    convertedPlannerProjectId: row.convertedPlannerProjectId ?? null,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function hydrateSavedInspiration(
  row: typeof savedInspiration.$inferSelect,
  opts?: {
    channelNameMap?: Map<number, string>;
    latestAdaptedMap?: Map<number, YtmAdaptedIdeaRecord>;
  }
): YtmSavedInspirationRecord {
  const validCategories = new Set<YtmInspirationCategory>([
    'video_topic',
    'video_title',
    'thumbnail_concept',
    'hook_opening',
    'video_format',
    'storytelling_structure',
    'content_strategy',
    'creative_observation',
  ]);
  const validStatuses = new Set<YtmInspirationStatus>([
    'saved',
    'reviewed',
    'adapted',
    'converted',
    'archived',
  ]);

  return {
    id: row.id,
    userId: row.userId,
    workspaceId: row.workspaceId,
    channelProfileId: row.channelProfileId ?? null,
    channelProfileName:
      row.channelProfileId && opts?.channelNameMap
        ? opts.channelNameMap.get(row.channelProfileId) || null
        : null,
    originalVideoTitle: row.originalVideoTitle,
    originalVideoUrl: row.originalVideoUrl || '',
    competitorChannelName: row.competitorChannelName || '',
    competitorChannelId: row.competitorChannelId || '',
    thumbnailUrl: row.thumbnailUrl ?? null,
    inspirationCategory: (validCategories.has(row.inspirationCategory as YtmInspirationCategory)
      ? row.inspirationCategory
      : 'video_topic') as YtmInspirationCategory,
    inspirationSnippet: row.inspirationSnippet || '',
    userNotes: row.userNotes || '',
    status: (validStatuses.has(row.status as YtmInspirationStatus)
      ? row.status
      : 'saved') as YtmInspirationStatus,
    convertedPlannerProjectId: row.convertedPlannerProjectId ?? null,
    latestAdaptedIdea: opts?.latestAdaptedMap?.get(row.id) ?? null,
    savedAt: row.savedAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function hydrateDailyPlan(row: typeof dailyPlans.$inferSelect): YtmDailyPlanRecord {
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    channelProfileId: row.channelProfileId ?? null,
    planDate: row.planDate,
    summary: row.summary || '',
    suggestedItems: safeJsonParse<YtmDailyPlanSuggestion[]>(row.suggestedItemsJson, []),
    userNotes: row.userNotes || '',
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function verifyChannelProfileInWorkspace(
  workspaceId: number,
  channelProfileId: number
): Promise<boolean> {
  const rows = await db
    .select({ id: channelProfiles.id })
    .from(channelProfiles)
    .where(and(eq(channelProfiles.id, channelProfileId), eq(channelProfiles.workspaceId, workspaceId)))
    .limit(1);
  return Boolean(rows[0]);
}
