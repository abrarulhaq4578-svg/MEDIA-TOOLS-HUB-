import type {
  SocialMetadataResult,
  YouTubeApiQuotaStats,
  YouTubeDetailsResult,
  YouTubeThumbnailVariant,
  YouTubeTranscriptResult,
  YouTubeTranscriptSegment,
} from '../../shared/types.ts';
import { getServerConfig } from '../config/env.ts';
import { safeFetch } from './ssrfGuard.ts';
import { detectPlatformFromUrl } from './urlDetector.ts';

const YOUTUBE_CACHE_TTL_MS = 15 * 60 * 1000;
const YOUTUBE_DAILY_QUOTA_BUDGET = 10_000;

interface CachedYouTubeEntry {
  expiresAt: number;
  data: YouTubeDetailsResult;
}

interface CachedChannelEntry {
  expiresAt: number;
  subscribers: number | null;
  videoCount: number | null;
}

const youtubeDetailsCache = new Map<string, CachedYouTubeEntry>();
const youtubeChannelCache = new Map<string, CachedChannelEntry>();

const youtubeQuotaTracker = {
  dateKey: new Date().toISOString().slice(0, 10),
  estimatedUnitsUsed: 0,
  videosListCalls: 0,
  channelsListCalls: 0,
  cacheHits: 0,
  errorCount: 0,
  lastError: null as string | null,
};

function resetQuotaIfNewDay() {
  const today = new Date().toISOString().slice(0, 10);
  if (youtubeQuotaTracker.dateKey !== today) {
    youtubeQuotaTracker.dateKey = today;
    youtubeQuotaTracker.estimatedUnitsUsed = 0;
    youtubeQuotaTracker.videosListCalls = 0;
    youtubeQuotaTracker.channelsListCalls = 0;
    youtubeQuotaTracker.cacheHits = 0;
    youtubeQuotaTracker.errorCount = 0;
    youtubeQuotaTracker.lastError = null;
  }
}

export function getYouTubeQuotaStats(): YouTubeApiQuotaStats {
  resetQuotaIfNewDay();
  return {
    dateKey: youtubeQuotaTracker.dateKey,
    estimatedUnitsUsed: youtubeQuotaTracker.estimatedUnitsUsed,
    dailyBudgetLimit: YOUTUBE_DAILY_QUOTA_BUDGET,
    videosListCalls: youtubeQuotaTracker.videosListCalls,
    channelsListCalls: youtubeQuotaTracker.channelsListCalls,
    cacheHits: youtubeQuotaTracker.cacheHits,
    cacheEntries: youtubeDetailsCache.size,
    errorCount: youtubeQuotaTracker.errorCount,
    lastError: youtubeQuotaTracker.lastError,
  };
}

function trimMapIfNeeded<T>(map: Map<string, T>, max = 250) {
  if (map.size <= max) return;
  const oldestKey = map.keys().next().value;
  if (oldestKey !== undefined) map.delete(oldestKey);
}

const YOUTUBE_THUMB_VARIANTS = [
  { key: 'maxresdefault', label: 'Max Resolution (HD)', width: 1280, height: 720 },
  { key: 'sddefault', label: 'Standard Definition (SD)', width: 640, height: 480 },
  { key: 'hqdefault', label: 'High Quality (HQ)', width: 480, height: 360 },
  { key: 'mqdefault', label: 'Medium Quality (MQ)', width: 320, height: 180 },
  { key: 'default', label: 'Default Thumbnail', width: 120, height: 90 },
] as const;

export async function probeYouTubeThumbnails(videoId: string): Promise<YouTubeThumbnailVariant[]> {
  if (!/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
    throw new Error('Invalid YouTube video ID.');
  }

  const checks = await Promise.all(
    YOUTUBE_THUMB_VARIANTS.map(async (variant) => {
      const url = `https://i.ytimg.com/vi/${videoId}/${variant.key}.jpg`;
      try {
        const res = await safeFetch(url, {
          method: 'HEAD',
          allowedHosts: ['i.ytimg.com'],
          timeoutMs: 5000,
        });
        const available = res.ok;
        const sizeHeader = res.headers.get('content-length');
        const fileSizeBytes = sizeHeader ? Number.parseInt(sizeHeader, 10) : undefined;
        return {
          key: variant.key,
          label: variant.label,
          width: variant.width,
          height: variant.height,
          url,
          available,
          contentType: res.headers.get('content-type') || 'image/jpeg',
          fileSizeBytes: Number.isFinite(fileSizeBytes) ? fileSizeBytes : undefined,
          downloadPath: available
            ? `/api/v1/youtube/thumbnail/download?videoId=${encodeURIComponent(videoId)}&quality=${encodeURIComponent(variant.key)}`
            : undefined,
        } satisfies YouTubeThumbnailVariant;
      } catch {
        return {
          key: variant.key,
          label: variant.label,
          width: variant.width,
          height: variant.height,
          url,
          available: false,
        } satisfies YouTubeThumbnailVariant;
      }
    })
  );

  return checks;
}

async function fetchYouTubeChannelSummary(
  channelId: string,
  apiKey: string
): Promise<{ subscribers: number | null; videoCount: number | null }> {
  const cached = youtubeChannelCache.get(channelId);
  if (cached && cached.expiresAt > Date.now()) {
    youtubeQuotaTracker.cacheHits += 1;
    return { subscribers: cached.subscribers, videoCount: cached.videoCount };
  }

  try {
    resetQuotaIfNewDay();
    youtubeQuotaTracker.channelsListCalls += 1;
    youtubeQuotaTracker.estimatedUnitsUsed += 1;

    const channelUrl = `https://www.googleapis.com/youtube/v3/channels?part=statistics&id=${encodeURIComponent(channelId)}&key=${encodeURIComponent(apiKey)}`;
    const res = await safeFetch(channelUrl, {
      allowedHosts: ['www.googleapis.com'],
      timeoutMs: 6000,
    });
    if (!res.ok) return { subscribers: null, videoCount: null };

    const json = (await res.json()) as {
      items?: Array<{
        statistics?: {
          subscriberCount?: string;
          hiddenSubscriberCount?: boolean;
          videoCount?: string;
        };
      }>;
    };
    const stats = json.items?.[0]?.statistics;
    const subscribers =
      stats && !stats.hiddenSubscriberCount && stats.subscriberCount
        ? Number(stats.subscriberCount)
        : null;
    const videoCount = stats?.videoCount ? Number(stats.videoCount) : null;

    youtubeChannelCache.set(channelId, {
      expiresAt: Date.now() + YOUTUBE_CACHE_TTL_MS,
      subscribers,
      videoCount,
    });
    trimMapIfNeeded(youtubeChannelCache);

    return { subscribers, videoCount };
  } catch {
    return { subscribers: null, videoCount: null };
  }
}

export async function fetchYouTubeDetails(videoId: string): Promise<YouTubeDetailsResult> {
  if (!/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
    throw new Error('Invalid YouTube video ID.');
  }

  resetQuotaIfNewDay();
  const cached = youtubeDetailsCache.get(videoId);
  if (cached && cached.expiresAt > Date.now()) {
    youtubeQuotaTracker.cacheHits += 1;
    return { ...cached.data, cached: true };
  }

  const canonicalUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const thumbnails = await probeYouTubeThumbnails(videoId);
  const { youtubeApiKey: apiKey } = getServerConfig();
  let apiFallbackNotice: string | null = null;

  if (apiKey && youtubeQuotaTracker.estimatedUnitsUsed < YOUTUBE_DAILY_QUOTA_BUDGET) {
    try {
      youtubeQuotaTracker.videosListCalls += 1;
      youtubeQuotaTracker.estimatedUnitsUsed += 1;

      const apiUrl = `https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails,statistics&id=${encodeURIComponent(videoId)}&key=${encodeURIComponent(apiKey)}`;
      const res = await safeFetch(apiUrl, {
        allowedHosts: ['www.googleapis.com'],
        timeoutMs: 8000,
      });

      if (res.ok) {
        const json = (await res.json()) as {
          items?: Array<{
            snippet?: {
              title?: string;
              description?: string;
              channelTitle?: string;
              channelId?: string;
              publishedAt?: string;
              tags?: string[];
            };
            contentDetails?: { duration?: string };
            statistics?: {
              viewCount?: string;
              likeCount?: string;
              commentCount?: string;
            };
          }>;
        };
        const item = json.items?.[0];
        if (!item) {
          throw new Error('Video not found or is private/unavailable via YouTube Data API v3.');
        }

        const channelId = item.snippet?.channelId || null;
        const channelStats = channelId
          ? await fetchYouTubeChannelSummary(channelId, apiKey)
          : { subscribers: null, videoCount: null };

        const result: YouTubeDetailsResult = {
          videoId,
          videoUrl: canonicalUrl,
          title: item.snippet?.title || 'Untitled Video',
          description: item.snippet?.description || null,
          channelName: item.snippet?.channelTitle || 'Unknown Channel',
          channelId,
          channelUrl: channelId ? `https://www.youtube.com/channel/${channelId}` : null,
          channelSubscribers: channelStats.subscribers,
          channelVideoCount: channelStats.videoCount,
          publishedAt: item.snippet?.publishedAt || null,
          duration: item.contentDetails?.duration || null,
          viewCount: item.statistics?.viewCount ? Number(item.statistics.viewCount) : null,
          likeCount: item.statistics?.likeCount ? Number(item.statistics.likeCount) : null,
          commentCount: item.statistics?.commentCount ? Number(item.statistics.commentCount) : null,
          tags: item.snippet?.tags ?? [],
          thumbnails,
          embedHtml: `<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/${videoId}" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`,
          dataSource: 'youtube-data-api-v3',
          cached: false,
          notice: 'Retrieved from official YouTube Data API v3 (videos.list + channels.list).',
        };

        youtubeDetailsCache.set(videoId, {
          expiresAt: Date.now() + YOUTUBE_CACHE_TTL_MS,
          data: result,
        });
        trimMapIfNeeded(youtubeDetailsCache);
        return result;
      }

      const errBody = await res.text().catch(() => '');
      youtubeQuotaTracker.errorCount += 1;
      youtubeQuotaTracker.lastError = `YouTube API HTTP ${res.status}`;
      if (errBody.includes('quotaExceeded')) {
        apiFallbackNotice =
          'Daily YouTube Data API quota exceeded; falling back to public oEmbed metadata.';
      } else {
        apiFallbackNotice = `YouTube Data API returned HTTP ${res.status}; falling back to public oEmbed metadata.`;
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'YouTube Data API request failed.';
      if (msg.includes('private/unavailable')) {
        throw err;
      }
      youtubeQuotaTracker.errorCount += 1;
      youtubeQuotaTracker.lastError = msg.replace(/key=[^&\s]+/gi, 'key=***');
      apiFallbackNotice = 'YouTube Data API temporarily unavailable; using official public oEmbed.';
    }
  }

  // Fallback to official public YouTube oEmbed
  const oembedUrl = `https://www.youtube.com/oembed?url=${encodeURIComponent(canonicalUrl)}&format=json`;
  const oembedRes = await safeFetch(oembedUrl, {
    allowedHosts: ['www.youtube.com'],
    timeoutMs: 8000,
  });

  if (!oembedRes.ok) {
    throw new Error(
      `YouTube video metadata could not be retrieved (HTTP ${oembedRes.status}). The video may be private, deleted, or embed-restricted.`
    );
  }

  const data = (await oembedRes.json()) as {
    title?: string;
    author_name?: string;
    author_url?: string;
    html?: string;
  };

  return {
    videoId,
    videoUrl: canonicalUrl,
    title: data.title || 'Public YouTube Video',
    description: null,
    channelName: data.author_name || 'YouTube Creator',
    channelId: null,
    channelUrl: data.author_url || null,
    channelSubscribers: null,
    channelVideoCount: null,
    publishedAt: null,
    duration: null,
    viewCount: null,
    likeCount: null,
    commentCount: null,
    tags: [],
    thumbnails,
    embedHtml:
      data.html ||
      `<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/${videoId}" title="YouTube video player" frameborder="0" allowfullscreen></iframe>`,
    dataSource: 'youtube-oembed',
    cached: false,
    notice:
      apiFallbackNotice ||
      'Retrieved via official YouTube oEmbed. View counts, likes, comments, and duration require YOUTUBE_API_KEY (YouTube Data API v3) on the server and are never fabricated.',
  };
}

function parseHtmlMetaTags(html: string): Record<string, string> {
  const tags: Record<string, string> = {};
  const metaRegex = /<meta\s+([^>]*?)>/gi;
  let match: RegExpExecArray | null;
  while ((match = metaRegex.exec(html)) !== null) {
    const attrs = match[1];
    const propMatch = /(?:property|name)=["']([^"']+)["']/i.exec(attrs);
    const contentMatch = /content=["']([^"']*)["']/i.exec(attrs);
    if (propMatch && contentMatch) {
      tags[propMatch[1].toLowerCase()] = decodeHtmlEntities(contentMatch[1]);
    }
  }
  const titleMatch = /<title[^>]*>([^<]+)<\/title>/i.exec(html);
  if (titleMatch && !tags['title']) {
    tags['title'] = decodeHtmlEntities(titleMatch[1].trim());
  }
  return tags;
}

function decodeHtmlEntities(input: string): string {
  return input
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

async function readLimitedText(response: Response, maxBytes = 250_000): Promise<string> {
  if (!response.body) return '';
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      total += value.byteLength;
      chunks.push(value);
      if (total >= maxBytes) {
        await reader.cancel();
        break;
      }
    }
  }
  return Buffer.concat(chunks.map((c) => Buffer.from(c))).toString('utf8');
}

export async function fetchTikTokMetadata(rawUrl: string): Promise<SocialMetadataResult> {
  const validation = detectPlatformFromUrl(rawUrl);
  if (!validation.valid || validation.platform !== 'tiktok' || !validation.normalizedUrl) {
    throw new Error(validation.reason || 'Please provide a valid public TikTok URL.');
  }

  const endpoint = `https://www.tiktok.com/oembed?url=${encodeURIComponent(validation.normalizedUrl)}`;
  const res = await safeFetch(endpoint, {
    allowedHosts: ['www.tiktok.com'],
    timeoutMs: 8000,
  });

  if (!res.ok) {
    throw new Error(`TikTok oEmbed returned HTTP ${res.status}. Ensure the TikTok video is public.`);
  }

  const data = (await res.json()) as {
    title?: string;
    author_name?: string;
    author_url?: string;
    thumbnail_url?: string;
    thumbnail_width?: number;
    thumbnail_height?: number;
    html?: string;
  };

  return {
    platform: 'tiktok',
    sourceUrl: rawUrl,
    canonicalUrl: validation.normalizedUrl,
    title: data.title || null,
    description: null,
    authorName: data.author_name || null,
    authorUrl: data.author_url || null,
    thumbnailUrl: data.thumbnail_url || null,
    mediaType: 'video',
    width: data.thumbnail_width ?? null,
    height: data.thumbnail_height ?? null,
    embedHtml: data.html || null,
    authorizedDownloadUrl: null,
    downloadPolicyStatus: 'platform_restricted',
    downloadPolicyMessage:
      'Direct video downloading without watermarks is disabled to respect TikTok creator rights. Use TikTok’s native Save option when enabled by the creator or embed the official video.',
    officialUrl: validation.normalizedUrl,
    dataSource: 'tiktok-oembed',
  };
}

export async function fetchTwitterMetadata(rawUrl: string): Promise<SocialMetadataResult> {
  const validation = detectPlatformFromUrl(rawUrl);
  if (!validation.valid || validation.platform !== 'twitter' || !validation.normalizedUrl) {
    throw new Error(validation.reason || 'Please provide a valid public X/Twitter status URL.');
  }

  const endpoint = `https://publish.twitter.com/oembed?url=${encodeURIComponent(validation.normalizedUrl)}&omit_script=true`;
  const res = await safeFetch(endpoint, {
    allowedHosts: ['publish.twitter.com'],
    timeoutMs: 8000,
  });

  if (!res.ok) {
    throw new Error(`Twitter oEmbed returned HTTP ${res.status}. Ensure the post is public.`);
  }

  const data = (await res.json()) as {
    author_name?: string;
    author_url?: string;
    html?: string;
    url?: string;
  };

  return {
    platform: 'twitter',
    sourceUrl: rawUrl,
    canonicalUrl: data.url || validation.normalizedUrl,
    title: data.author_name ? `Post by ${data.author_name}` : 'Public X / Twitter Post',
    description: null,
    authorName: data.author_name || null,
    authorUrl: data.author_url || null,
    thumbnailUrl: null,
    mediaType: 'post',
    width: null,
    height: null,
    embedHtml: data.html || null,
    authorizedDownloadUrl: null,
    downloadPolicyStatus: 'platform_restricted',
    downloadPolicyMessage:
      'X/Twitter posts are surfaced via official oEmbed attribution and direct post links.',
    officialUrl: data.url || validation.normalizedUrl,
    dataSource: 'twitter-oembed',
  };
}

export async function fetchPinterestMetadata(
  rawUrl: string,
  options: { allowApi?: boolean } = {}
): Promise<SocialMetadataResult> {
  const validation = detectPlatformFromUrl(rawUrl);
  if (!validation.valid || validation.platform !== 'pinterest' || !validation.normalizedUrl) {
    throw new Error(validation.reason || 'Please provide a valid public Pinterest URL.');
  }

  const { pinterestAccessToken: token } = getServerConfig();
  if (
    options.allowApi !== false &&
    token &&
    validation.entityId &&
    /^\d+$/.test(validation.entityId)
  ) {
    const apiRes = await safeFetch(
      `https://api.pinterest.com/v5/pins/${encodeURIComponent(validation.entityId)}`,
      {
        allowedHosts: ['api.pinterest.com'],
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    if (apiRes.ok) {
      const pin = (await apiRes.json()) as {
        title?: string;
        description?: string;
        link?: string;
        media?: { media_type?: string; images?: { originals?: { url?: string; width?: number; height?: number } } };
      };
      const orig = pin.media?.images?.originals;
      return {
        platform: 'pinterest',
        sourceUrl: rawUrl,
        canonicalUrl: validation.normalizedUrl,
        title: pin.title || 'Pinterest Pin',
        description: pin.description || null,
        authorName: null,
        authorUrl: null,
        thumbnailUrl: orig?.url || null,
        mediaType: pin.media?.media_type === 'video' ? 'video' : 'image',
        width: orig?.width ?? null,
        height: orig?.height ?? null,
        embedHtml: `<a data-pin-do="embedPin" href="${validation.normalizedUrl}"></a>`,
        authorizedDownloadUrl: orig?.url || null,
        downloadPolicyStatus: orig?.url ? 'authorized' : 'platform_restricted',
        downloadPolicyMessage:
          'Retrieved from official Pinterest API v5. Download only assets you own or are licensed to reuse.',
        officialUrl: validation.normalizedUrl,
        dataSource: 'pinterest-api-v5',
      };
    }
  }

  // Public OpenGraph inspection via SSRF-guarded fetch
  const pageRes = await safeFetch(validation.normalizedUrl, {
    timeoutMs: 8000,
  });
  const html = await readLimitedText(pageRes);
  const meta = parseHtmlMetaTags(html);

  const imageUrl = meta['og:image'] || meta['twitter:image:src'] || null;
  const videoUrl = meta['og:video'] || meta['og:video:url'] || null;

  return {
    platform: 'pinterest',
    sourceUrl: rawUrl,
    canonicalUrl: meta['og:url'] || validation.normalizedUrl,
    title: meta['og:title'] || meta['title'] || 'Public Pinterest Pin',
    description: meta['og:description'] || meta['description'] || null,
    authorName: meta['pinterestapp:pinner'] || null,
    authorUrl: null,
    thumbnailUrl: imageUrl,
    mediaType: videoUrl ? 'video' : imageUrl ? 'image' : 'post',
    width: meta['og:image:width'] ? Number(meta['og:image:width']) || null : null,
    height: meta['og:image:height'] ? Number(meta['og:image:height']) || null : null,
    embedHtml: `<a data-pin-do="embedPin" href="${validation.normalizedUrl}"></a>`,
    authorizedDownloadUrl: null,
    downloadPolicyStatus: imageUrl ? 'api_required' : 'platform_restricted',
    downloadPolicyMessage:
      'Public OpenGraph metadata parsed safely. Configure PINTEREST_ACCESS_TOKEN for official Pinterest API v5 media exports, or open the official Pin.',
    officialUrl: validation.normalizedUrl,
    dataSource: 'public-opengraph',
  };
}

export async function fetchMetaPlatformMetadata(
  rawUrl: string,
  expectedPlatform: 'instagram' | 'facebook',
  options: { allowApi?: boolean } = {}
): Promise<SocialMetadataResult> {
  const validation = detectPlatformFromUrl(rawUrl);
  if (!validation.valid || validation.platform !== expectedPlatform || !validation.normalizedUrl) {
    throw new Error(
      validation.reason || `Please provide a valid public ${expectedPlatform} URL.`
    );
  }

  const { metaAppAccessToken: metaToken } = getServerConfig();
  const embedHtml =
    expectedPlatform === 'instagram'
      ? `<blockquote class="instagram-media" data-instgrm-captioned data-instgrm-permalink="${validation.normalizedUrl}" data-instgrm-version="14"></blockquote>\n<script async src="//www.instagram.com/embed.js"></script>`
      : `<div class="fb-post" data-href="${validation.normalizedUrl}" data-width="500" data-show-text="true"></div>`;

  if (options.allowApi !== false && metaToken) {
    const endpoint =
      expectedPlatform === 'instagram'
        ? `https://graph.facebook.com/v20.0/instagram_oembed?url=${encodeURIComponent(validation.normalizedUrl)}&access_token=${encodeURIComponent(metaToken)}`
        : `https://graph.facebook.com/v20.0/oembed_post?url=${encodeURIComponent(validation.normalizedUrl)}&access_token=${encodeURIComponent(metaToken)}`;

    try {
      const apiRes = await safeFetch(endpoint, {
        allowedHosts: ['graph.facebook.com'],
        timeoutMs: 8000,
      });
      if (apiRes.ok) {
        const data = (await apiRes.json()) as {
          author_name?: string;
          author_url?: string;
          title?: string;
          thumbnail_url?: string;
          thumbnail_width?: number;
          thumbnail_height?: number;
          html?: string;
        };
        return {
          platform: expectedPlatform,
          sourceUrl: rawUrl,
          canonicalUrl: validation.normalizedUrl,
          title: data.title || `${expectedPlatform} ${validation.entityType || 'post'}`,
          description: null,
          authorName: data.author_name || null,
          authorUrl: data.author_url || null,
          thumbnailUrl: data.thumbnail_url || null,
          mediaType: validation.entityType === 'reel' || validation.entityType === 'video' ? 'video' : 'post',
          width: data.thumbnail_width ?? null,
          height: data.thumbnail_height ?? null,
          embedHtml: data.html || embedHtml,
          authorizedDownloadUrl: data.thumbnail_url || null,
          downloadPolicyStatus: data.thumbnail_url ? 'authorized' : 'platform_restricted',
          downloadPolicyMessage:
            'Retrieved via authorized Meta Graph oEmbed API. Direct video stream downloads remain governed by Meta Platform Terms.',
          officialUrl: validation.normalizedUrl,
          dataSource: 'meta-graph-oembed',
        };
      }
    } catch {
      // Fall through to compliant embed & canonical descriptor below
    }
  }

  return {
    platform: expectedPlatform,
    sourceUrl: rawUrl,
    canonicalUrl: validation.normalizedUrl,
    title: `${expectedPlatform === 'instagram' ? 'Instagram' : 'Facebook'} ${validation.entityType || 'Content'} (${validation.entityId || 'Verified URL'})`,
    description: null,
    authorName: null,
    authorUrl: null,
    thumbnailUrl: null,
    mediaType:
      validation.entityType === 'reel' || validation.entityType === 'video'
        ? 'video'
        : validation.entityType === 'profile'
          ? 'profile'
          : 'post',
    width: null,
    height: null,
    embedHtml,
    authorizedDownloadUrl: null,
    downloadPolicyStatus: 'api_required',
    downloadPolicyMessage: `Live ${expectedPlatform} Graph API metadata requires a server-side META_APP_ACCESS_TOKEN with Meta oEmbed Read approval. MediaToolsHub does not bypass login walls; use the official link or compliant embed snippet below.`,
    officialUrl: validation.normalizedUrl,
    dataSource: 'canonical-url-validator',
    rawMeta: {
      entityId: validation.entityId || null,
      entityType: validation.entityType || null,
    },
  };
}

export async function inspectGeneralWebMetadata(rawUrl: string): Promise<SocialMetadataResult> {
  const validation = detectPlatformFromUrl(rawUrl);
  if (!validation.valid || !validation.normalizedUrl) {
    throw new Error(validation.reason || 'Invalid URL.');
  }

  const res = await safeFetch(validation.normalizedUrl, { timeoutMs: 8000 });
  const contentType = res.headers.get('content-type') || '';

  if (contentType.startsWith('image/')) {
    return {
      platform: 'general',
      sourceUrl: rawUrl,
      canonicalUrl: validation.normalizedUrl,
      title: 'Direct Public Image Asset',
      description: `Content-Type: ${contentType}`,
      authorName: null,
      authorUrl: null,
      thumbnailUrl: validation.normalizedUrl,
      mediaType: 'image',
      width: null,
      height: null,
      embedHtml: null,
      authorizedDownloadUrl: validation.normalizedUrl,
      downloadPolicyStatus: 'authorized',
      downloadPolicyMessage: 'Direct public image header verified.',
      officialUrl: validation.normalizedUrl,
      dataSource: 'http-headers',
    };
  }

  const html = await readLimitedText(res);
  const meta = parseHtmlMetaTags(html);

  return {
    platform: 'general',
    sourceUrl: rawUrl,
    canonicalUrl: meta['og:url'] || validation.normalizedUrl,
    title: meta['og:title'] || meta['twitter:title'] || meta['title'] || validation.hostname || null,
    description: meta['og:description'] || meta['twitter:description'] || meta['description'] || null,
    authorName: meta['author'] || meta['og:site_name'] || null,
    authorUrl: null,
    thumbnailUrl: meta['og:image'] || meta['twitter:image'] || null,
    mediaType: 'post',
    width: null,
    height: null,
    embedHtml: null,
    authorizedDownloadUrl: null,
    downloadPolicyStatus: 'platform_restricted',
    downloadPolicyMessage: 'Public OpenGraph and HTML meta tags extracted safely.',
    officialUrl: meta['og:url'] || validation.normalizedUrl,
    dataSource: 'public-opengraph',
    rawMeta: {
      contentType,
      httpStatus: res.status,
      ogType: meta['og:type'] || null,
      twitterCard: meta['twitter:card'] || null,
    },
  };
}

function formatTimestamp(totalSec: number): string {
  const mins = Math.floor(totalSec / 60);
  const secs = Math.floor(totalSec % 60);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

function formatSrtTime(totalSec: number): string {
  const hours = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = Math.floor(totalSec % 60);
  const ms = Math.round((totalSec - Math.floor(totalSec)) * 1000);
  return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
}

function extractBalancedJson(source: string, marker: string): string | null {
  const idx = source.indexOf(marker);
  if (idx === -1) return null;
  const start = source.indexOf('{', idx);
  if (start === -1) return null;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (let i = start; i < source.length; i += 1) {
    const ch = source[i];
    if (escaped) {
      escaped = false;
      continue;
    }
    if (ch === '\\' && inString) {
      escaped = true;
      continue;
    }
    if (ch === '"') {
      inString = !inString;
      continue;
    }
    if (!inString) {
      if (ch === '{') depth += 1;
      else if (ch === '}') {
        depth -= 1;
        if (depth === 0) {
          return source.slice(start, i + 1);
        }
      }
    }
  }
  return null;
}

export async function fetchYouTubeTranscript(
  videoId: string,
  preferredLang?: string
): Promise<YouTubeTranscriptResult> {
  if (!/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
    throw new Error('Invalid YouTube video ID.');
  }

  const canonicalUrl = `https://www.youtube.com/watch?v=${videoId}`;
  const watchRes = await safeFetch(canonicalUrl, {
    allowedHosts: ['www.youtube.com'],
    headers: { 'Accept-Language': 'en-US,en;q=0.9' },
    timeoutMs: 8000,
  });

  if (!watchRes.ok) {
    throw new Error(`Unable to inspect YouTube video page (HTTP ${watchRes.status}).`);
  }

  const html = await readLimitedText(watchRes, 2_000_000);
  const rawPlayerJson = extractBalancedJson(html, 'ytInitialPlayerResponse');
  if (!rawPlayerJson) {
    throw new Error('Public caption metadata was not exposed for this video.');
  }

  let playerData: {
    playabilityStatus?: { status?: string; reason?: string };
    videoDetails?: { title?: string };
    captions?: {
      playerCaptionsTracklistRenderer?: {
        captionTracks?: Array<{
          baseUrl?: string;
          languageCode?: string;
          kind?: string;
          name?: { simpleText?: string; runs?: Array<{ text?: string }> };
        }>;
      };
    };
  };

  try {
    playerData = JSON.parse(rawPlayerJson);
  } catch {
    throw new Error('Unable to parse YouTube caption track list.');
  }

  const tracks = playerData.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
  if (tracks.length === 0) {
    if (playerData.playabilityStatus?.status === 'LOGIN_REQUIRED') {
      throw new Error(
        `YouTube requested interactive sign-in verification for this server IP (${playerData.playabilityStatus.reason || 'bot check'}). MediaToolsHub never bypasses platform security gates—open the video on YouTube and select "Show transcript" in the description.`
      );
    }
    throw new Error('No public closed captions or transcripts are available for this video.');
  }

  const availableTracks = tracks
    .filter((t) => t.languageCode && t.baseUrl)
    .map((t) => ({
      languageCode: t.languageCode!,
      name:
        t.name?.simpleText ||
        t.name?.runs?.map((r) => r.text || '').join('') ||
        t.languageCode!,
      isAutoGenerated: t.kind === 'asr',
    }));

  const chosenTrack =
    (preferredLang && tracks.find((t) => t.languageCode === preferredLang)) ||
    tracks.find((t) => t.languageCode === 'en' && t.kind !== 'asr') ||
    tracks.find((t) => t.languageCode?.startsWith('en')) ||
    tracks[0];

  if (!chosenTrack?.baseUrl) {
    throw new Error('No readable caption track URL found.');
  }

  const captionRes = await safeFetch(chosenTrack.baseUrl, {
    allowedHosts: ['www.youtube.com'],
    timeoutMs: 8000,
  });

  if (!captionRes.ok) {
    throw new Error(`Failed to fetch caption track (HTTP ${captionRes.status}).`);
  }

  const xml = await readLimitedText(captionRes, 500_000);
  const segments: YouTubeTranscriptSegment[] = [];
  const textRegex = /<text\s+start="([^"]+)"(?:\s+dur="([^"]+)")?[^>]*>([\s\S]*?)<\/text>/g;
  let match: RegExpExecArray | null;
  while ((match = textRegex.exec(xml)) !== null) {
    const startSec = Number.parseFloat(match[1]) || 0;
    const durationSec = Number.parseFloat(match[2] || '2') || 2;
    const cleaned = decodeHtmlEntities(match[3].replace(/<[^>]+>/g, ''))
      .replace(/\s+/g, ' ')
      .trim();
    if (cleaned) {
      segments.push({
        startSec,
        durationSec,
        timestamp: formatTimestamp(startSec),
        text: cleaned,
      });
    }
  }

  if (segments.length === 0) {
    throw new Error('Caption track returned empty subtitle lines.');
  }

  const plainText = segments.map((s) => s.text).join(' ');
  const srtText = segments
    .map(
      (s, i) =>
        `${i + 1}\n${formatSrtTime(s.startSec)} --> ${formatSrtTime(s.startSec + s.durationSec)}\n${s.text}`
    )
    .join('\n\n');

  const chosenMeta = availableTracks.find(
    (t) => t.languageCode === chosenTrack.languageCode
  );

  return {
    videoId,
    videoUrl: canonicalUrl,
    title: playerData.videoDetails?.title || 'YouTube Video',
    languageCode: chosenTrack.languageCode || 'en',
    languageName: chosenMeta?.name || chosenTrack.languageCode || 'English',
    availableTracks,
    segments,
    plainText,
    srtText,
  };
}

