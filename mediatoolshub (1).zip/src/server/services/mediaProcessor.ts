import { execFile, spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import type {
  MediaAudioFormatOption,
  MediaFormatsResponse,
  MediaInspectResponse,
  MediaInspectionMetadata,
  MediaJobRecord,
  MediaJobStatus,
  MediaUploadResponse,
  MediaVideoFormatOption,
} from '../../shared/types.ts';
import { safeFetch } from './ssrfGuard.ts';
import { classifyMediaUrl } from './urlDetector.ts';

const execFileAsync = promisify(execFile);

export const MEDIA_JOBS_ROOT = path.join(os.tmpdir(), 'mediatoolshub-media-jobs');
export const DEFAULT_MAX_UPLOAD_MB = 100;
export const DEFAULT_JOB_TTL_MINUTES = 30;
const MAX_INSPECT_BYTES = 2 * 1024 * 1024; // 2 MB header probe for remote URLs
const FFMPEG_TIMEOUT_MS = 120_000;

export const ALLOWED_MEDIA_EXTENSIONS = new Set([
  '.mp4',
  '.m4v',
  '.webm',
  '.mov',
  '.mp3',
  '.wav',
  '.m4a',
]);

export const ALLOWED_MEDIA_MIME_TYPES = new Set([
  'video/mp4',
  'video/x-m4v',
  'video/webm',
  'video/quicktime',
  'audio/mpeg',
  'audio/mp3',
  'audio/wav',
  'audio/x-wav',
  'audio/wave',
  'audio/vnd.wave',
  'audio/mp4',
  'audio/x-m4a',
  'audio/aac',
  'application/octet-stream',
]);

export const VIDEO_PRESETS = [
  { formatId: 'mp4-1080', height: 1080, width: 1920, label: 'MP4 1080p Full HD', targetBitrateKbps: 3800 },
  { formatId: 'mp4-720', height: 720, width: 1280, label: 'MP4 720p HD', targetBitrateKbps: 2200 },
  { formatId: 'mp4-480', height: 480, width: 854, label: 'MP4 480p SD', targetBitrateKbps: 1100 },
  { formatId: 'mp4-360', height: 360, width: 640, label: 'MP4 360p', targetBitrateKbps: 650 },
] as const;

export const AUDIO_PRESETS = [
  { formatId: 'mp3-320', bitrateKbps: 320, label: 'MP3 320 kbps' },
  { formatId: 'mp3-192', bitrateKbps: 192, label: 'MP3 192 kbps' },
  { formatId: 'mp3-128', bitrateKbps: 128, label: 'MP3 128 kbps' },
] as const;

const ALLOWED_FORMAT_IDS = new Set<string>([
  'mp4-source',
  ...VIDEO_PRESETS.map((v) => v.formatId),
  ...AUDIO_PRESETS.map((a) => a.formatId),
]);

export interface MediaLimitsConfig {
  maxUploadMb: number;
  maxUploadBytes: number;
  jobTtlMinutes: number;
  allowedDomains: string[];
  allowedDomainsRaw: string;
}

export function parseMediaLimitsConfig(settingsMap: Record<string, string> = {}): MediaLimitsConfig {
  const rawMb = Number.parseInt(settingsMap.media_max_upload_mb || '', 10);
  const maxUploadMb = Number.isFinite(rawMb) && rawMb >= 1 && rawMb <= 500 ? rawMb : DEFAULT_MAX_UPLOAD_MB;

  const rawTtl = Number.parseInt(settingsMap.media_job_ttl_minutes || '', 10);
  const jobTtlMinutes =
    Number.isFinite(rawTtl) && rawTtl >= 1 && rawTtl <= 240 ? rawTtl : DEFAULT_JOB_TTL_MINUTES;

  const allowedDomainsRaw = (settingsMap.media_allowed_domains || '').trim();
  const allowedDomains = allowedDomainsRaw
    .split(',')
    .map((d) => d.trim().toLowerCase())
    .filter(Boolean);

  return {
    maxUploadMb,
    maxUploadBytes: maxUploadMb * 1024 * 1024,
    jobTtlMinutes,
    allowedDomains,
    allowedDomainsRaw,
  };
}

export function validateMediaSignature(header: Buffer, ext: string): { valid: boolean; reason?: string } {
  if (header.byteLength < 8) {
    return { valid: false, reason: 'File is too small or corrupted to be a valid media file.' };
  }

  const normalizedExt = ext.toLowerCase();

  // Reject HTML / XML / plain-text disguised files immediately
  const asciiPrefix = header.subarray(0, Math.min(header.byteLength, 32)).toString('utf8').trimStart().toLowerCase();
  if (asciiPrefix.startsWith('<!doctype') || asciiPrefix.startsWith('<html') || asciiPrefix.startsWith('<?xml')) {
    return { valid: false, reason: 'HTML or XML content rejected: target is not a binary media stream.' };
  }

  if (normalizedExt === '.mp4' || normalizedExt === '.m4v' || normalizedExt === '.mov' || normalizedExt === '.m4a') {
    const boxType = header.subarray(4, 8).toString('ascii');
    if (boxType === 'ftyp' || boxType === 'moov' || boxType === 'mdat' || boxType === 'wide' || boxType === 'free') {
      return { valid: true };
    }
    // Check slightly further in case an offset header atom exists
    if (header.includes(Buffer.from('ftyp', 'ascii'))) {
      return { valid: true };
    }
    return { valid: false, reason: `Invalid ${normalizedExt.toUpperCase()} file signature (missing ISO BMFF/QuickTime header).` };
  }

  if (normalizedExt === '.webm') {
    // EBML header: 1A 45 DF A3
    if (header[0] === 0x1a && header[1] === 0x45 && header[2] === 0xdf && header[3] === 0xa3) {
      return { valid: true };
    }
    return { valid: false, reason: 'Invalid WEBM file signature (missing EBML header).' };
  }

  if (normalizedExt === '.mp3') {
    const isId3 = header[0] === 0x49 && header[1] === 0x44 && header[2] === 0x33; // 'ID3'
    const isMpegFrame = header[0] === 0xff && (header[1] & 0xe0) === 0xe0;
    if (isId3 || isMpegFrame) {
      return { valid: true };
    }
    return { valid: false, reason: 'Invalid MP3 file signature (missing ID3 or MPEG frame sync header).' };
  }

  if (normalizedExt === '.wav') {
    const isRiff = header.subarray(0, 4).toString('ascii') === 'RIFF';
    const isWave = header.byteLength >= 12 && header.subarray(8, 12).toString('ascii') === 'WAVE';
    if (isRiff && isWave) {
      return { valid: true };
    }
    return { valid: false, reason: 'Invalid WAV file signature (missing RIFF/WAVE header).' };
  }

  return { valid: false, reason: 'Unsupported media file extension.' };
}

function normalizeFileFormat(ffprobeFormatName: string | undefined, extHint?: string): string {
  const hint = extHint?.replace('.', '').toUpperCase();
  if (hint && ['MP4', 'WEBM', 'MOV', 'MP3', 'WAV', 'M4A'].includes(hint)) {
    return hint;
  }
  const lower = (ffprobeFormatName || '').toLowerCase();
  if (lower.includes('webm')) return 'WEBM';
  if (lower.includes('mp3')) return 'MP3';
  if (lower.includes('wav')) return 'WAV';
  if (lower.includes('m4a')) return 'M4A';
  if (lower.includes('mov')) return 'MOV';
  if (lower.includes('mp4')) return 'MP4';
  return lower.toUpperCase() || 'UNKNOWN';
}

function parseFrameRate(rawRate?: string): string | null {
  if (!rawRate || rawRate === '0/0') return null;
  const parts = rawRate.split('/');
  if (parts.length === 2) {
    const num = Number.parseFloat(parts[0]);
    const den = Number.parseFloat(parts[1]);
    if (Number.isFinite(num) && Number.isFinite(den) && den > 0 && num > 0) {
      const fps = num / den;
      return `${Number.isInteger(fps) ? fps : fps.toFixed(2)} fps`;
    }
  }
  const single = Number.parseFloat(rawRate);
  if (Number.isFinite(single) && single > 0) {
    return `${Number.isInteger(single) ? single : single.toFixed(2)} fps`;
  }
  return null;
}

export async function inspectMediaFileWithFfprobe(
  filePath: string,
  knownFileSizeBytes?: number | null,
  extHint?: string
): Promise<MediaInspectionMetadata> {
  const stat = await fs.stat(filePath).catch(() => null);
  const fileSizeBytes = knownFileSizeBytes ?? stat?.size ?? null;

  const { stdout } = await execFileAsync(
    'ffprobe',
    ['-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', filePath],
    { timeout: 12000 }
  );

  const parsed = JSON.parse(stdout) as {
    format?: {
      format_name?: string;
      format_long_name?: string;
      duration?: string;
      bit_rate?: string;
    };
    streams?: Array<{
      codec_type?: string;
      codec_name?: string;
      width?: number;
      height?: number;
      r_frame_rate?: string;
      avg_frame_rate?: string;
      bit_rate?: string;
    }>;
  };

  const videoStream = parsed.streams?.find((s) => s.codec_type === 'video');
  const audioStream = parsed.streams?.find((s) => s.codec_type === 'audio');

  if (!videoStream && !audioStream) {
    throw new Error('No playable video or audio streams detected inside this file.');
  }

  const rawDuration = parsed.format?.duration ? Number.parseFloat(parsed.format.duration) : NaN;
  const durationSec =
    Number.isFinite(rawDuration) && rawDuration > 0
      ? Math.round(rawDuration * 100) / 100
      : null;

  const rawBitrate = parsed.format?.bit_rate ? Number.parseInt(parsed.format.bit_rate, 10) : NaN;
  const bitrateKbps = Number.isFinite(rawBitrate) && rawBitrate > 0 ? Math.round(rawBitrate / 1000) : null;

  const width = typeof videoStream?.width === 'number' && videoStream.width > 0 ? videoStream.width : null;
  const height = typeof videoStream?.height === 'number' && videoStream.height > 0 ? videoStream.height : null;

  return {
    fileFormat: normalizeFileFormat(parsed.format?.format_name, extHint),
    containerLongName: parsed.format?.format_long_name || null,
    videoCodec: videoStream?.codec_name ? videoStream.codec_name.toUpperCase() : null,
    audioCodec: audioStream?.codec_name ? audioStream.codec_name.toUpperCase() : null,
    resolution: width && height ? `${width}×${height}` : null,
    width,
    height,
    durationSec,
    frameRate: parseFrameRate(videoStream?.avg_frame_rate || videoStream?.r_frame_rate),
    bitrateKbps,
    fileSizeBytes,
    hasVideo: Boolean(videoStream),
    hasAudio: Boolean(audioStream),
  };
}

export function buildSupportedVideoFormatOptions(params: {
  sourceHeight: number | null;
  sourceWidth: number | null;
  codecLabel: string;
  contentType: string;
  knownSourceBytes: number | null;
  durationSec: number | null;
}): MediaVideoFormatOption[] {
  const { sourceHeight, sourceWidth, codecLabel, contentType, knownSourceBytes, durationSec } = params;
  const formats: MediaVideoFormatOption[] = [];

  if (sourceHeight && sourceHeight >= 360) {
    const matchesExactPreset = VIDEO_PRESETS.some((p) => p.height === sourceHeight);
    if (!matchesExactPreset) {
      formats.push({
        formatId: 'mp4-source',
        container: 'mp4',
        qualityLabel: `MP4 ${sourceHeight}p Original`,
        resolution: sourceWidth ? `${sourceWidth}×${sourceHeight}` : `${sourceHeight}p`,
        width: sourceWidth,
        height: sourceHeight,
        codec: codecLabel,
        fileSizeBytes: knownSourceBytes,
        isEstimatedSize: !contentType.includes('mp4') && knownSourceBytes !== null,
      });
    }

    for (const preset of VIDEO_PRESETS) {
      if (sourceHeight >= preset.height) {
        const isExactSource = sourceHeight === preset.height && contentType.includes('mp4');
        const scaledWidth =
          2 * Math.round(((sourceWidth || preset.width) * (preset.height / sourceHeight)) / 2);
        const estimatedBytes =
          isExactSource && knownSourceBytes
            ? knownSourceBytes
            : durationSec
              ? Math.round((durationSec * preset.targetBitrateKbps * 1000) / 8)
              : null;

        formats.push({
          formatId: isExactSource ? 'mp4-source' : preset.formatId,
          container: 'mp4',
          qualityLabel: preset.label,
          resolution: `${scaledWidth}×${preset.height}`,
          width: scaledWidth,
          height: preset.height,
          codec: 'H264',
          fileSizeBytes: estimatedBytes,
          isEstimatedSize: !isExactSource && estimatedBytes !== null,
        });
      }
    }
  } else {
    formats.push({
      formatId: 'mp4-source',
      container: 'mp4',
      qualityLabel: sourceHeight ? `MP4 ${sourceHeight}p Source` : 'MP4 Original Quality',
      resolution: sourceWidth && sourceHeight ? `${sourceWidth}×${sourceHeight}` : 'Original',
      width: sourceWidth,
      height: sourceHeight,
      codec: codecLabel,
      fileSizeBytes: knownSourceBytes,
      isEstimatedSize: false,
    });
  }

  return formats;
}

export function buildSupportedAudioFormatOptions(
  inspection: MediaInspectionMetadata
): MediaAudioFormatOption[] {
  if (!inspection.hasAudio) {
    return [];
  }
  return AUDIO_PRESETS.map((tier) => {
    const estimatedBytes = inspection.durationSec
      ? Math.round((inspection.durationSec * tier.bitrateKbps * 1000) / 8)
      : null;
    return {
      formatId: tier.formatId,
      container: 'mp3',
      qualityLabel: tier.label,
      bitrateKbps: tier.bitrateKbps,
      fileSizeBytes: estimatedBytes,
      isEstimatedSize: estimatedBytes !== null,
    };
  });
}

export async function readPrefixBytes(response: Response, maxBytes: number): Promise<Buffer> {
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader();
  const chunks: Buffer[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        const buf = Buffer.from(value);
        chunks.push(buf);
        total += buf.byteLength;
        if (total >= maxBytes) {
          await reader.cancel();
          break;
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks).subarray(0, maxBytes);
}

export async function readBoundedBytes(response: Response, maxBytes: number): Promise<Buffer> {
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader();
  const chunks: Buffer[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        const buf = Buffer.from(value);
        total += buf.byteLength;
        if (total > maxBytes) {
          await reader.cancel();
          throw new Error(
            `Source media exceeds maximum supported limit (${Math.round(maxBytes / (1024 * 1024))} MB).`
          );
        }
        chunks.push(buf);
      }
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks);
}

export function getExtFromUrlOrContentType(urlStr: string, contentType: string): string {
  try {
    const pathname = new URL(urlStr).pathname.toLowerCase();
    for (const ext of ALLOWED_MEDIA_EXTENSIONS) {
      if (pathname.endsWith(ext)) return ext;
    }
  } catch {
    // fallback to content-type
  }
  if (contentType.includes('webm')) return '.webm';
  if (contentType.includes('quicktime')) return '.mov';
  if (contentType.includes('mpeg') || contentType.includes('mp3')) return '.mp3';
  if (contentType.includes('wav')) return '.wav';
  if (contentType.includes('m4a') || contentType.includes('audio/mp4')) return '.m4a';
  return '.mp4';
}

export async function inspectMediaUrl(
  rawUrl: string,
  limits: MediaLimitsConfig = parseMediaLimitsConfig()
): Promise<MediaInspectResponse> {
  const classified = classifyMediaUrl(rawUrl);
  if (!classified.valid || !classified.normalizedUrl) {
    throw new Error(classified.reason || 'Please provide a valid public URL starting with https://.');
  }

  if (classified.platform === 'youtube') {
    const studioVideoUrl = classified.entityId
      ? `https://studio.youtube.com/video/${classified.entityId}/edit`
      : 'https://studio.youtube.com/';
    return {
      status: 'unavailable',
      sourceUrl: rawUrl,
      canonicalUrl: classified.normalizedUrl,
      platform: 'youtube',
      entityId: classified.entityId,
      sourceType: classified.sourceType,
      downloadable: false,
      supportedFunctionality: classified.supportedFunctionality,
      inspection: null,
      videoFormats: [],
      audioFormats: [],
      officialAccessUrl: classified.normalizedUrl,
      officialStudioUrl: studioVideoUrl,
      officialTakeoutUrl: 'https://takeout.google.com/',
      complianceNotice:
        'YouTube video downloading is not supported through the YouTube Data API. You can view the video on YouTube, use YouTube Studio or Google Takeout to export your own uploaded videos, and upload your exported file here for conversion.',
    };
  }

  if (classified.platform !== 'general') {
    return {
      status: 'unavailable',
      sourceUrl: rawUrl,
      canonicalUrl: classified.normalizedUrl,
      platform: classified.platform,
      entityId: classified.entityId,
      sourceType: classified.sourceType,
      downloadable: false,
      supportedFunctionality: classified.supportedFunctionality,
      inspection: null,
      videoFormats: [],
      audioFormats: [],
      officialAccessUrl: classified.normalizedUrl,
      officialStudioUrl: null,
      officialTakeoutUrl: null,
      complianceNotice: `Direct video and audio stream downloading is not available for ${classified.platform} URLs under platform terms. View the post on ${classified.platform}, or enter an authorized direct media URL (.mp4, .webm, .mov, .mp3, .wav, .m4a) or upload your own file.`,
    };
  }

  // Enforce optional Admin URL domain allowlist
  if (limits.allowedDomains.length > 0 && classified.hostname) {
    const host = classified.hostname.toLowerCase();
    const isAllowed = limits.allowedDomains.some(
      (allowed) => host === allowed || host.endsWith(`.${allowed}`)
    );
    if (!isAllowed) {
      throw new Error(`Host "${host}" is not in the configured domain allowlist.`);
    }
  }

  const allowedHostsOpt = limits.allowedDomains.length > 0 ? limits.allowedDomains : undefined;

  const headRes = await safeFetch(classified.normalizedUrl, {
    method: 'HEAD',
    timeoutMs: 8000,
    allowedHosts: allowedHostsOpt,
  });

  let contentType = (headRes.headers.get('content-type') || '').toLowerCase();
  const contentLengthHeader = headRes.headers.get('content-length');
  const sourceLength = contentLengthHeader ? Number.parseInt(contentLengthHeader, 10) : NaN;
  const knownSourceBytes = Number.isFinite(sourceLength) && sourceLength > 0 ? sourceLength : null;

  const isMediaHeader = contentType.startsWith('video/') || contentType.startsWith('audio/');
  const isMediaExt = classified.downloadable;

  if (!isMediaHeader && !isMediaExt) {
    throw new Error(
      'This URL does not point to an authorized direct media file (.mp4, .webm, .mov, .mp3, .wav, .m4a).'
    );
  }

  if (knownSourceBytes && knownSourceBytes > limits.maxUploadBytes) {
    throw new Error(
      `Source media is ${Math.round(knownSourceBytes / (1024 * 1024))} MB, exceeding the configured ${limits.maxUploadMb} MB processing limit.`
    );
  }

  const probeRes = await safeFetch(classified.normalizedUrl, {
    method: 'GET',
    headers: { Range: `bytes=0-${MAX_INSPECT_BYTES - 1}` },
    timeoutMs: 12000,
    allowedHosts: allowedHostsOpt,
  });

  if (!probeRes.ok && probeRes.status !== 206) {
    throw new Error(`Unable to read source media stream (HTTP ${probeRes.status}).`);
  }

  if (!contentType) {
    contentType = (probeRes.headers.get('content-type') || '').toLowerCase();
  }

  const sampleBuffer = await readPrefixBytes(probeRes, MAX_INSPECT_BYTES);
  const ext = getExtFromUrlOrContentType(classified.normalizedUrl, contentType);
  const sig = validateMediaSignature(sampleBuffer, ext);
  if (!sig.valid) {
    throw new Error(sig.reason || 'Remote resource failed binary media signature validation.');
  }

  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'mth-probe-'));
  const sampleFile = path.join(tmpDir, `sample${ext}`);
  let inspection: MediaInspectionMetadata;
  try {
    await fs.writeFile(sampleFile, sampleBuffer);
    inspection = await inspectMediaFileWithFfprobe(sampleFile, knownSourceBytes, ext);
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
  }

  const videoFormats = inspection.hasVideo
    ? buildSupportedVideoFormatOptions({
        sourceHeight: inspection.height,
        sourceWidth: inspection.width,
        codecLabel: inspection.videoCodec || 'H264',
        contentType,
        knownSourceBytes: inspection.fileSizeBytes,
        durationSec: inspection.durationSec,
      })
    : [];

  const audioFormats = buildSupportedAudioFormatOptions(inspection);

  return {
    status: 'completed',
    sourceUrl: rawUrl,
    canonicalUrl: classified.normalizedUrl,
    platform: 'general',
    sourceType: classified.sourceType,
    downloadable: videoFormats.length > 0 || audioFormats.length > 0,
    supportedFunctionality: classified.supportedFunctionality,
    inspection,
    videoFormats,
    audioFormats,
    officialAccessUrl: classified.normalizedUrl,
    officialStudioUrl: null,
    officialTakeoutUrl: null,
    complianceNotice:
      'Authorized direct media stream verified via FFprobe and binary signature checks.',
  };
}

// Adapter preserving /api/v1/media/formats compatibility
export async function inspectAvailableMediaFormats(
  rawUrl: string,
  limits: MediaLimitsConfig = parseMediaLimitsConfig()
): Promise<MediaFormatsResponse> {
  const inspected = await inspectMediaUrl(rawUrl, limits);
  return {
    status: inspected.status,
    sourceUrl: inspected.sourceUrl,
    canonicalUrl: inspected.canonicalUrl,
    platform: inspected.platform,
    entityId: inspected.entityId,
    sourceType:
      inspected.platform === 'youtube'
        ? 'youtube'
        : inspected.downloadable
          ? 'authorized-direct-media'
          : 'platform-restricted',
    urlSourceType: inspected.sourceType,
    supportedFunctionality: inspected.supportedFunctionality,
    authorizedForDownload: inspected.downloadable,
    inspection: inspected.inspection,
    videoFormats: inspected.videoFormats,
    audioFormats: inspected.audioFormats,
    officialAccessUrl: inspected.officialAccessUrl,
    officialStudioUrl: inspected.officialStudioUrl,
    officialTakeoutUrl: inspected.officialTakeoutUrl,
    complianceNotice: inspected.complianceNotice,
  };
}

// ============================================================================
// BACKGROUND MEDIA JOB ENGINE (Uploaded -> Validating -> Processing -> Completed | Failed | Expired)
// ============================================================================

interface InternalJobState {
  jobId: string;
  userId: number | null;
  sourceKind: 'upload' | 'url';
  sourceLabel: string;
  sourceUrl: string | null;
  status: MediaJobStatus;
  progressPct: number;
  downloadToken: string;
  jobDir: string;
  inputPath: string | null;
  inputExt: string | null;
  inspection: MediaInspectionMetadata | null;
  outputPath: string | null;
  outputFilename: string | null;
  outputContentType: string | null;
  targetFormat: string | null;
  targetContainer: 'mp4' | 'mp3' | null;
  sourceSizeBytes: number | null;
  outputSizeBytes: number | null;
  outputCodec: string | null;
  outputResolution: string | null;
  outputBitrateKbps: number | null;
  outputDurationSec: number | null;
  errorMessage: string | null;
  createdAtMs: number;
  updatedAtMs: number;
  expiresAtMs: number;
}

const jobStore = new Map<string, InternalJobState>();
let lastCleanupInfo: {
  at: string | null;
  removed: number;
  freedBytes: number;
} = {
  at: null,
  removed: 0,
  freedBytes: 0,
};

let cleanupTimerStarted = false;

export function ensureMediaCleanupWorker(): void {
  if (cleanupTimerStarted) return;
  cleanupTimerStarted = true;
  const timer = setInterval(() => {
    void cleanupMediaJobs({ forceAll: false });
  }, 60_000);
  timer.unref();
}

function toPublicJobRecord(job: InternalJobState): MediaJobRecord {
  return {
    jobId: job.jobId,
    sourceKind: job.sourceKind,
    sourceLabel: job.sourceLabel,
    status: job.status,
    progressPct: job.progressPct,
    sourceFormat: job.inspection?.fileFormat || null,
    targetFormat: job.targetFormat,
    targetContainer: job.targetContainer,
    sourceSizeBytes: job.sourceSizeBytes,
    outputSizeBytes: job.outputSizeBytes,
    outputCodec: job.outputCodec,
    outputResolution: job.outputResolution,
    outputBitrateKbps: job.outputBitrateKbps,
    outputDurationSec: job.outputDurationSec,
    outputFilename: job.outputFilename,
    downloadUrl:
      job.status === 'Completed' && job.outputPath
        ? `/api/v1/media/download/${job.jobId}?token=${encodeURIComponent(job.downloadToken)}`
        : null,
    errorMessage: job.errorMessage,
    createdAt: new Date(job.createdAtMs).toISOString(),
    updatedAt: new Date(job.updatedAtMs).toISOString(),
    expiresAt: new Date(job.expiresAtMs).toISOString(),
  };
}

export async function registerUploadedMediaJob(params: {
  tempFilePath: string;
  originalFilename: string;
  mimeType: string;
  fileSizeBytes: number;
  userId?: number | null;
  limits: MediaLimitsConfig;
}): Promise<MediaUploadResponse> {
  ensureMediaCleanupWorker();
  await fs.mkdir(MEDIA_JOBS_ROOT, { recursive: true });

  const ext = path.extname(params.originalFilename).toLowerCase();
  const jobId = crypto.randomUUID();
  const downloadToken = crypto.randomBytes(24).toString('hex');
  const jobDir = path.join(MEDIA_JOBS_ROOT, jobId);
  const now = Date.now();
  const expiresAtMs = now + params.limits.jobTtlMinutes * 60_000;

  const job: InternalJobState = {
    jobId,
    userId: params.userId ?? null,
    sourceKind: 'upload',
    sourceLabel: params.originalFilename,
    sourceUrl: null,
    status: 'Uploaded',
    progressPct: 0,
    downloadToken,
    jobDir,
    inputPath: null,
    inputExt: ext,
    inspection: null,
    outputPath: null,
    outputFilename: null,
    outputContentType: null,
    targetFormat: null,
    targetContainer: null,
    sourceSizeBytes: params.fileSizeBytes,
    outputSizeBytes: null,
    outputCodec: null,
    outputResolution: null,
    outputBitrateKbps: null,
    outputDurationSec: null,
    errorMessage: null,
    createdAtMs: now,
    updatedAtMs: now,
    expiresAtMs,
  };

  try {
    if (!ALLOWED_MEDIA_EXTENSIONS.has(ext)) {
      throw new Error(
        `Unsupported file extension "${ext || '(none)'}". Allowed: MP4, WEBM, MOV, MP3, WAV, M4A.`
      );
    }

    const normalizedMime = (params.mimeType || '').toLowerCase().split(';')[0].trim();
    if (normalizedMime && !ALLOWED_MEDIA_MIME_TYPES.has(normalizedMime)) {
      throw new Error(`Unsupported MIME type "${normalizedMime}".`);
    }

    if (params.fileSizeBytes <= 0) {
      throw new Error('Uploaded file is empty.');
    }

    if (params.fileSizeBytes > params.limits.maxUploadBytes) {
      throw new Error(
        `Uploaded file (${(params.fileSizeBytes / (1024 * 1024)).toFixed(1)} MB) exceeds the configured ${params.limits.maxUploadMb} MB limit.`
      );
    }

    job.status = 'Validating';
    job.updatedAtMs = Date.now();

    // Signature check on first 64 bytes before touching FFprobe
    const fh = await fs.open(params.tempFilePath, 'r');
    const headerBuf = Buffer.alloc(64);
    try {
      const { bytesRead } = await fh.read(headerBuf, 0, 64, 0);
      const sig = validateMediaSignature(headerBuf.subarray(0, bytesRead), ext);
      if (!sig.valid) {
        throw new Error(sig.reason || 'Uploaded file failed binary media signature validation.');
      }
    } finally {
      await fh.close();
    }

    await fs.mkdir(jobDir, { recursive: true });
    const safeInputPath = path.join(jobDir, `input${ext}`);
    await fs.rename(params.tempFilePath, safeInputPath);
    job.inputPath = safeInputPath;

    const inspection = await inspectMediaFileWithFfprobe(safeInputPath, params.fileSizeBytes, ext);
    job.inspection = inspection;
    job.status = 'Uploaded';
    job.updatedAtMs = Date.now();

    const videoFormats = inspection.hasVideo
      ? buildSupportedVideoFormatOptions({
          sourceHeight: inspection.height,
          sourceWidth: inspection.width,
          codecLabel: inspection.videoCodec || 'H264',
          contentType: ext === '.mp4' ? 'video/mp4' : normalizedMime,
          knownSourceBytes: inspection.fileSizeBytes,
          durationSec: inspection.durationSec,
        })
      : [];

    const audioFormats = buildSupportedAudioFormatOptions(inspection);
    if (videoFormats.length === 0 && audioFormats.length === 0) {
      throw new Error('No convertible video or audio tracks found in uploaded media.');
    }

    jobStore.set(jobId, job);

    return {
      jobId,
      status: job.status,
      downloadToken,
      originalFilename: params.originalFilename,
      mimeType: params.mimeType,
      inspection,
      videoFormats,
      audioFormats,
      expiresAt: new Date(expiresAtMs).toISOString(),
    };
  } catch (err) {
    await fs.rm(params.tempFilePath, { force: true }).catch(() => {});
    await fs.rm(jobDir, { recursive: true, force: true }).catch(() => {});
    job.status = 'Failed';
    job.errorMessage = err instanceof Error ? err.message : 'Invalid uploaded media file.';
    job.updatedAtMs = Date.now();
    jobStore.set(jobId, job);
    throw err;
  }
}

export function runFfmpegWithProgress(params: {
  args: string[];
  durationSec: number | null;
  onProgress: (pct: number) => void;
}): Promise<void> {
  return new Promise((resolve, reject) => {
    const child = spawn('ffmpeg', ['-progress', 'pipe:1', '-nostats', ...params.args], {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stderrTail = '';
    const timeout = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error('Media conversion timed out after 120 seconds.'));
    }, FFMPEG_TIMEOUT_MS);

    child.stdout.on('data', (chunk: Buffer) => {
      const text = chunk.toString('utf8');
      for (const line of text.split('\n')) {
        if (line.startsWith('out_time_us=')) {
          const us = Number.parseInt(line.slice('out_time_us='.length), 10);
          if (Number.isFinite(us) && params.durationSec && params.durationSec > 0) {
            const pct = Math.min(96, Math.max(5, Math.round((us / (params.durationSec * 1_000_000)) * 100)));
            params.onProgress(pct);
          }
        } else if (line.trim() === 'progress=end') {
          params.onProgress(98);
        }
      }
    });

    child.stderr.on('data', (chunk: Buffer) => {
      stderrTail = (stderrTail + chunk.toString('utf8')).slice(-1500);
    });

    child.on('error', (err) => {
      clearTimeout(timeout);
      reject(err);
    });

    child.on('close', (code) => {
      clearTimeout(timeout);
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`FFmpeg conversion failed (exit code ${code}): ${stderrTail.slice(-240).trim()}`));
      }
    });
  });
}

async function executeBackgroundConversion(params: {
  job: InternalJobState;
  formatId: string;
  limits: MediaLimitsConfig;
  onFinishDbLog?: (job: InternalJobState) => Promise<void>;
}): Promise<void> {
  const { job, formatId, limits, onFinishDbLog } = params;

  try {
    if (job.sourceKind === 'url' && job.sourceUrl) {
      job.status = 'Validating';
      job.progressPct = 5;
      job.updatedAtMs = Date.now();

      const allowedHostsOpt = limits.allowedDomains.length > 0 ? limits.allowedDomains : undefined;
      const upstream = await safeFetch(job.sourceUrl, {
        method: 'GET',
        timeoutMs: 30000,
        allowedHosts: allowedHostsOpt,
      });

      if (!upstream.ok) {
        throw new Error(`Unable to fetch authorized media source (HTTP ${upstream.status}).`);
      }

      const contentType = (upstream.headers.get('content-type') || '').toLowerCase();
      const ext = getExtFromUrlOrContentType(job.sourceUrl, contentType);
      const sourceBytes = await readBoundedBytes(upstream, limits.maxUploadBytes);
      if (sourceBytes.byteLength === 0) {
        throw new Error('Upstream media returned an empty file.');
      }

      const sig = validateMediaSignature(sourceBytes.subarray(0, 64), ext);
      if (!sig.valid) {
        throw new Error(sig.reason || 'Upstream file failed binary media signature check.');
      }

      await fs.mkdir(job.jobDir, { recursive: true });
      const inputPath = path.join(job.jobDir, `input${ext}`);
      await fs.writeFile(inputPath, sourceBytes);
      job.inputPath = inputPath;
      job.inputExt = ext;
      job.sourceSizeBytes = sourceBytes.byteLength;
      job.inspection = await inspectMediaFileWithFfprobe(inputPath, sourceBytes.byteLength, ext);
    }

    if (!job.inputPath || !job.inspection) {
      throw new Error('Input media file is missing or expired.');
    }

    const isAudioTarget = formatId.startsWith('mp3-');
    if (isAudioTarget && !job.inspection.hasAudio) {
      throw new Error('Cannot extract MP3 audio because this video has no audio stream.');
    }
    if (!isAudioTarget && !job.inspection.hasVideo) {
      throw new Error('Cannot convert audio-only input into MP4 video.');
    }

    job.status = 'Processing';
    job.progressPct = 10;
    job.updatedAtMs = Date.now();

    const inputExt = job.inputExt || path.extname(job.inputPath).toLowerCase();

    if (isAudioTarget) {
      const tier = AUDIO_PRESETS.find((a) => a.formatId === formatId) || AUDIO_PRESETS[1];
      const outputFilename = `mediatoolshub-${tier.bitrateKbps}kbps-${job.jobId.slice(0, 8)}.mp3`;
      const outputPath = path.join(job.jobDir, outputFilename);

      await runFfmpegWithProgress({
        args: [
          '-y',
          '-i',
          job.inputPath,
          '-vn',
          '-codec:a',
          'libmp3lame',
          '-b:a',
          `${tier.bitrateKbps}k`,
          outputPath,
        ],
        durationSec: job.inspection.durationSec,
        onProgress: (pct) => {
          job.progressPct = pct;
          job.updatedAtMs = Date.now();
        },
      });

      const outProbe = await inspectMediaFileWithFfprobe(outputPath, null, '.mp3');
      job.outputPath = outputPath;
      job.outputFilename = outputFilename;
      job.outputContentType = 'audio/mpeg';
      job.targetContainer = 'mp3';
      job.outputSizeBytes = outProbe.fileSizeBytes;
      job.outputCodec = outProbe.audioCodec || 'MP3';
      job.outputResolution = null;
      job.outputBitrateKbps = tier.bitrateKbps;
      job.outputDurationSec = outProbe.durationSec;
      job.status = 'Completed';
      job.progressPct = 100;
      job.updatedAtMs = Date.now();
    } else {
      const videoPreset = VIDEO_PRESETS.find((v) => v.formatId === formatId);
      if (
        videoPreset &&
        job.inspection.height &&
        job.inspection.height < videoPreset.height
      ) {
        throw new Error(
          `Requested resolution ${videoPreset.height}p exceeds source resolution (${job.inspection.height}p). Upscaling is not permitted.`
        );
      }

      const tag = videoPreset ? `${videoPreset.height}p` : 'source';
      const outputFilename = `mediatoolshub-${tag}-${job.jobId.slice(0, 8)}.mp4`;
      const outputPath = path.join(job.jobDir, outputFilename);

      if (formatId === 'mp4-source' && inputExt === '.mp4') {
        await fs.copyFile(job.inputPath, outputPath);
        job.progressPct = 95;
      } else {
        const args = ['-y', '-i', job.inputPath];
        if (videoPreset) {
          args.push('-vf', `scale=-2:min(ih\\,${videoPreset.height})`);
        }
        args.push(
          '-c:v',
          'libx264',
          '-preset',
          'veryfast',
          '-crf',
          '23',
          '-pix_fmt',
          'yuv420p'
        );
        if (job.inspection.hasAudio) {
          args.push('-c:a', 'aac', '-b:a', '128k');
        } else {
          args.push('-an');
        }
        args.push('-movflags', '+faststart', outputPath);

        await runFfmpegWithProgress({
          args,
          durationSec: job.inspection.durationSec,
          onProgress: (pct) => {
            job.progressPct = pct;
            job.updatedAtMs = Date.now();
          },
        });
      }

      const outProbe = await inspectMediaFileWithFfprobe(outputPath, null, '.mp4');
      job.outputPath = outputPath;
      job.outputFilename = outputFilename;
      job.outputContentType = 'video/mp4';
      job.targetContainer = 'mp4';
      job.outputSizeBytes = outProbe.fileSizeBytes;
      job.outputCodec = outProbe.videoCodec || 'H264';
      job.outputResolution = outProbe.resolution;
      job.outputBitrateKbps = outProbe.bitrateKbps;
      job.outputDurationSec = outProbe.durationSec;
      job.status = 'Completed';
      job.progressPct = 100;
      job.updatedAtMs = Date.now();
    }
  } catch (err) {
    job.status = 'Failed';
    job.progressPct = 0;
    job.errorMessage = err instanceof Error ? err.message : 'Media conversion failed.';
    job.updatedAtMs = Date.now();
  } finally {
    if (onFinishDbLog) {
      await onFinishDbLog(job).catch(() => {});
    }
  }
}

export async function startMediaConversionJob(params: {
  jobId?: string;
  url?: string;
  formatId: string;
  userId?: number | null;
  limits: MediaLimitsConfig;
  onFinishDbLog?: (job: MediaJobRecord) => Promise<void>;
}): Promise<{ job: MediaJobRecord; downloadToken: string }> {
  ensureMediaCleanupWorker();
  await fs.mkdir(MEDIA_JOBS_ROOT, { recursive: true });

  const { jobId, url, formatId, userId, limits, onFinishDbLog } = params;
  if (!ALLOWED_FORMAT_IDS.has(formatId)) {
    throw new Error('Unsupported or invalid media format selected.');
  }

  let job: InternalJobState;
  const now = Date.now();

  if (jobId) {
    const existing = jobStore.get(jobId);
    if (!existing) {
      throw new Error('Upload job not found or expired.');
    }
    if (now > existing.expiresAtMs || existing.status === 'Expired') {
      existing.status = 'Expired';
      throw new Error('Upload job has expired. Please upload the media file again.');
    }
    if (!existing.inputPath) {
      throw new Error('Uploaded source file is no longer available.');
    }
    // If previous output exists on same uploaded job, allow converting another format using new child job or replace output
    job = {
      ...existing,
      jobId: crypto.randomUUID(),
      jobDir: path.join(MEDIA_JOBS_ROOT, crypto.randomUUID()),
      downloadToken: crypto.randomBytes(24).toString('hex'),
      outputPath: null,
      outputFilename: null,
      outputContentType: null,
      targetFormat: formatId,
      targetContainer: formatId.startsWith('mp3-') ? 'mp3' : 'mp4',
      outputSizeBytes: null,
      outputCodec: null,
      outputResolution: null,
      outputBitrateKbps: null,
      outputDurationSec: null,
      errorMessage: null,
      status: 'Validating',
      progressPct: 5,
      createdAtMs: now,
      updatedAtMs: now,
      expiresAtMs: now + limits.jobTtlMinutes * 60_000,
    };
    await fs.mkdir(job.jobDir, { recursive: true });
    const copiedInput = path.join(job.jobDir, `input${existing.inputExt || '.mp4'}`);
    await fs.copyFile(existing.inputPath, copiedInput);
    job.inputPath = copiedInput;
    jobStore.set(job.jobId, job);
  } else if (url) {
    const classified = classifyMediaUrl(url);
    if (!classified.valid || !classified.normalizedUrl) {
      throw new Error(classified.reason || 'Please provide a valid public media URL.');
    }
    if (classified.platform !== 'general') {
      throw new Error(
        `Direct stream downloading is not permitted for ${classified.platform} URLs. Export your own file via official tools and upload it instead.`
      );
    }
    if (limits.allowedDomains.length > 0 && classified.hostname) {
      const host = classified.hostname.toLowerCase();
      const allowed = limits.allowedDomains.some((d) => host === d || host.endsWith(`.${d}`));
      if (!allowed) {
        throw new Error(`Host "${host}" is outside the configured domain allowlist.`);
      }
    }

    const newJobId = crypto.randomUUID();
    job = {
      jobId: newJobId,
      userId: userId ?? null,
      sourceKind: 'url',
      sourceLabel: classified.normalizedUrl,
      sourceUrl: classified.normalizedUrl,
      status: 'Validating',
      progressPct: 2,
      downloadToken: crypto.randomBytes(24).toString('hex'),
      jobDir: path.join(MEDIA_JOBS_ROOT, newJobId),
      inputPath: null,
      inputExt: null,
      inspection: null,
      outputPath: null,
      outputFilename: null,
      outputContentType: null,
      targetFormat: formatId,
      targetContainer: formatId.startsWith('mp3-') ? 'mp3' : 'mp4',
      sourceSizeBytes: null,
      outputSizeBytes: null,
      outputCodec: null,
      outputResolution: null,
      outputBitrateKbps: null,
      outputDurationSec: null,
      errorMessage: null,
      createdAtMs: now,
      updatedAtMs: now,
      expiresAtMs: now + limits.jobTtlMinutes * 60_000,
    };
    jobStore.set(job.jobId, job);
  } else {
    throw new Error('Either jobId or url is required to start conversion.');
  }

  // Launch background conversion worker asynchronously
  void executeBackgroundConversion({
    job,
    formatId,
    limits,
    onFinishDbLog: onFinishDbLog ? (finished) => onFinishDbLog(toPublicJobRecord(finished)) : undefined,
  });

  return {
    job: toPublicJobRecord(job),
    downloadToken: job.downloadToken,
  };
}

export function getMediaJobStatus(jobId: string): MediaJobRecord | null {
  const job = jobStore.get(jobId);
  if (!job) return null;
  if (Date.now() > job.expiresAtMs && job.status !== 'Expired') {
    job.status = 'Expired';
    job.updatedAtMs = Date.now();
  }
  return toPublicJobRecord(job);
}

export async function authorizeAndResolveJobDownload(params: {
  jobId: string;
  token: string;
}): Promise<{
  filePath: string;
  contentType: string;
  filename: string;
  fileSizeBytes: number;
  container: 'mp4' | 'mp3';
  resolutionOrBitrate: string;
}> {
  const job = jobStore.get(params.jobId);
  if (!job) {
    throw Object.assign(new Error('Download job not found or already cleaned up.'), { statusCode: 404 });
  }
  if (!params.token || params.token !== job.downloadToken) {
    throw Object.assign(new Error('Invalid or missing download authorization token.'), { statusCode: 403 });
  }
  if (Date.now() > job.expiresAtMs || job.status === 'Expired') {
    job.status = 'Expired';
    throw Object.assign(new Error('This conversion job has expired. Please convert the file again.'), {
      statusCode: 410,
    });
  }
  if (job.status !== 'Completed' || !job.outputPath || !job.outputFilename) {
    throw Object.assign(new Error(`Download is not ready (status: ${job.status}).`), { statusCode: 409 });
  }

  const stat = await fs.stat(job.outputPath).catch(() => null);
  if (!stat || !stat.isFile()) {
    job.status = 'Expired';
    throw Object.assign(new Error('Converted file was removed from temporary storage.'), { statusCode: 410 });
  }

  return {
    filePath: job.outputPath,
    contentType: job.outputContentType || 'application/octet-stream',
    filename: job.outputFilename,
    fileSizeBytes: stat.size,
    container: job.targetContainer || 'mp4',
    resolutionOrBitrate: job.outputResolution || (job.outputBitrateKbps ? `${job.outputBitrateKbps}kbps` : 'source'),
  };
}

async function computeDirSizeAndCount(dirPath: string): Promise<{ bytes: number; files: number }> {
  let bytes = 0;
  let files = 0;
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        const sub = await computeDirSizeAndCount(full);
        bytes += sub.bytes;
        files += sub.files;
      } else if (entry.isFile()) {
        const st = await fs.stat(full).catch(() => null);
        if (st) {
          bytes += st.size;
          files += 1;
        }
      }
    }
  } catch {
    // Directory may not exist yet
  }
  return { bytes, files };
}

export async function cleanupMediaJobs(
  options: { forceAll?: boolean } = {}
): Promise<{
  removedJobs: number;
  freedBytes: number;
  remainingActiveJobs: number;
  storageUsedBytes: number;
  lastCleanupAt: string;
}> {
  const now = Date.now();
  let removedJobs = 0;
  let freedBytes = 0;

  for (const [id, job] of jobStore.entries()) {
    const isProcessing = job.status === 'Validating' || job.status === 'Processing';
    const isExpired = now > job.expiresAtMs || job.status === 'Expired';
    const isStaleFailed = job.status === 'Failed' && now - job.updatedAtMs > 5 * 60_000;

    if (options.forceAll ? !isProcessing : isExpired || isStaleFailed) {
      const sizeInfo = await computeDirSizeAndCount(job.jobDir);
      await fs.rm(job.jobDir, { recursive: true, force: true }).catch(() => {});
      job.status = 'Expired';
      job.outputPath = null;
      job.inputPath = null;
      job.updatedAtMs = now;
      if (isExpired || options.forceAll) {
        removedJobs += 1;
        freedBytes += sizeInfo.bytes;
      }
      if (now - job.updatedAtMs > 24 * 60 * 60_000) {
        jobStore.delete(id);
      }
    }
  }

  // Also sweep any orphaned subdirectories on disk not tracked in memory (keeping _incoming staging folder)
  try {
    const entries = await fs.readdir(MEDIA_JOBS_ROOT, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name === '_incoming') {
        const incomingDir = path.join(MEDIA_JOBS_ROOT, '_incoming');
        const stagedFiles = await fs.readdir(incomingDir, { withFileTypes: true }).catch(() => []);
        const maxAgeMs = options.forceAll ? 2_000 : 30 * 60_000;
        for (const staged of stagedFiles) {
          if (!staged.isFile()) continue;
          const stagedPath = path.join(incomingDir, staged.name);
          const st = await fs.stat(stagedPath).catch(() => null);
          if (st && now - st.mtimeMs >= maxAgeMs) {
            await fs.rm(stagedPath, { force: true }).catch(() => {});
            freedBytes += st.size;
          }
        }
        continue;
      }
      if (!jobStore.has(entry.name)) {
        const full = path.join(MEDIA_JOBS_ROOT, entry.name);
        const info = await computeDirSizeAndCount(full);
        await fs.rm(full, { recursive: true, force: true }).catch(() => {});
        removedJobs += 1;
        freedBytes += info.bytes;
      }
    }
  } catch {
    // Root may not exist yet
  }

  const remainingDisk = await computeDirSizeAndCount(MEDIA_JOBS_ROOT);
  const lastCleanupAt = new Date().toISOString();
  lastCleanupInfo = {
    at: lastCleanupAt,
    removed: removedJobs,
    freedBytes,
  };

  let remainingActiveJobs = 0;
  for (const job of jobStore.values()) {
    if (job.status === 'Validating' || job.status === 'Processing' || job.status === 'Uploaded') {
      remainingActiveJobs += 1;
    }
  }

  return {
    removedJobs,
    freedBytes,
    remainingActiveJobs,
    storageUsedBytes: remainingDisk.bytes,
    lastCleanupAt,
  };
}

export async function getLiveMediaEngineTelemetry(): Promise<{
  storageUsedBytes: number;
  tempFileCount: number;
  activeJobsCount: number;
  expiredJobsCount: number;
  lastCleanupAt: string | null;
  lastCleanupRemoved: number;
  lastCleanupFreedBytes: number;
  recentJobs: MediaJobRecord[];
}> {
  const disk = await computeDirSizeAndCount(MEDIA_JOBS_ROOT);
  const now = Date.now();
  let activeJobsCount = 0;
  let expiredJobsCount = 0;

  for (const job of jobStore.values()) {
    if (now > job.expiresAtMs && job.status !== 'Expired') {
      job.status = 'Expired';
    }
    if (job.status === 'Uploaded' || job.status === 'Validating' || job.status === 'Processing') {
      activeJobsCount += 1;
    } else if (job.status === 'Expired') {
      expiredJobsCount += 1;
    }
  }

  const recentJobs = Array.from(jobStore.values())
    .sort((a, b) => b.createdAtMs - a.createdAtMs)
    .slice(0, 25)
    .map(toPublicJobRecord);

  return {
    storageUsedBytes: disk.bytes,
    tempFileCount: disk.files,
    activeJobsCount,
    expiredJobsCount,
    lastCleanupAt: lastCleanupInfo.at,
    lastCleanupRemoved: lastCleanupInfo.removed,
    lastCleanupFreedBytes: lastCleanupInfo.freedBytes,
    recentJobs,
  };
}

// Synchronous direct media conversion (kept for backwards compatibility with POST /api/v1/media/download)
export async function processAuthorizedMediaDownload(
  params: {
    url: string;
    formatId: string;
  },
  limits: MediaLimitsConfig = parseMediaLimitsConfig()
): Promise<{
  buffer: Buffer;
  contentType: string;
  filename: string;
  container: 'mp4' | 'mp3';
  resolutionOrBitrate: string;
}> {
  const { url, formatId } = params;
  if (!ALLOWED_FORMAT_IDS.has(formatId)) {
    throw new Error('Unsupported or invalid media format selected.');
  }

  const classified = classifyMediaUrl(url);
  if (!classified.valid || !classified.normalizedUrl) {
    throw new Error(classified.reason || 'Please provide a valid public media URL.');
  }

  if (classified.platform !== 'general') {
    throw new Error(
      `Direct media stream downloading is disabled for ${classified.platform} URLs to comply with platform Terms of Service and DRM protections.`
    );
  }

  const allowedHostsOpt = limits.allowedDomains.length > 0 ? limits.allowedDomains : undefined;
  const upstream = await safeFetch(classified.normalizedUrl, {
    method: 'GET',
    timeoutMs: 30000,
    allowedHosts: allowedHostsOpt,
  });

  if (!upstream.ok) {
    throw new Error(`Unable to fetch authorized media source (HTTP ${upstream.status}).`);
  }

  const contentType = (upstream.headers.get('content-type') || '').toLowerCase();
  const isMediaHeader = contentType.startsWith('video/') || contentType.startsWith('audio/');
  if (!isMediaHeader && !classified.downloadable) {
    throw new Error('Target resource is not a supported video or audio stream.');
  }

  const sourceBytes = await readBoundedBytes(upstream, limits.maxUploadBytes);
  if (sourceBytes.byteLength === 0) {
    throw new Error('Upstream media returned an empty file.');
  }

  const ext = getExtFromUrlOrContentType(classified.normalizedUrl, contentType);
  const sig = validateMediaSignature(sourceBytes.subarray(0, 64), ext);
  if (!sig.valid) {
    throw new Error(sig.reason || 'Remote resource failed binary signature validation.');
  }

  const isAudioTarget = formatId.startsWith('mp3-');
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'mth-dl-'));
  const inputFile = path.join(tmpDir, `input${ext}`);
  const outputExt = isAudioTarget ? 'mp3' : 'mp4';
  const outputFile = path.join(tmpDir, `output.${outputExt}`);

  try {
    await fs.writeFile(inputFile, sourceBytes);

    if (formatId === 'mp4-source' && ext === '.mp4') {
      return {
        buffer: sourceBytes,
        contentType: 'video/mp4',
        filename: 'mediatoolshub-video-source.mp4',
        container: 'mp4',
        resolutionOrBitrate: 'source',
      };
    }

    if (isAudioTarget) {
      const audioTier = AUDIO_PRESETS.find((a) => a.formatId === formatId) || AUDIO_PRESETS[1];
      await execFileAsync(
        'ffmpeg',
        [
          '-y',
          '-i',
          inputFile,
          '-vn',
          '-codec:a',
          'libmp3lame',
          '-b:a',
          `${audioTier.bitrateKbps}k`,
          outputFile,
        ],
        { timeout: 60000 }
      );
      const outBuf = await fs.readFile(outputFile);
      return {
        buffer: outBuf,
        contentType: 'audio/mpeg',
        filename: `mediatoolshub-audio-${audioTier.bitrateKbps}kbps.mp3`,
        container: 'mp3',
        resolutionOrBitrate: `${audioTier.bitrateKbps}kbps`,
      };
    }

    const videoTier = VIDEO_PRESETS.find((v) => v.formatId === formatId);
    const args = ['-y', '-i', inputFile];
    if (videoTier) {
      args.push('-vf', `scale=-2:min(ih\\,${videoTier.height})`);
    }
    args.push(
      '-c:v',
      'libx264',
      '-preset',
      'veryfast',
      '-crf',
      '23',
      '-pix_fmt',
      'yuv420p',
      '-c:a',
      'aac',
      '-b:a',
      '128k',
      '-movflags',
      '+faststart',
      outputFile
    );

    await execFileAsync('ffmpeg', args, { timeout: 90000 });
    const outBuf = await fs.readFile(outputFile);
    const tag = videoTier ? `${videoTier.height}p` : 'source';
    return {
      buffer: outBuf,
      contentType: 'video/mp4',
      filename: `mediatoolshub-video-${tag}.mp4`,
      container: 'mp4',
      resolutionOrBitrate: tag,
    };
  } finally {
    await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
  }
}
