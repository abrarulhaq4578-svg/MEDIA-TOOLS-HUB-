import crypto from 'node:crypto';
import { GoogleGenAI, Type, type Schema } from '@google/genai';
import { getServerConfig } from '../config/env.ts';
import type {
  ScriptAiModelId,
  YtmAudienceCommunicationStrategy,
  YtmCalendarAuditReport,
  YtmChannelAnalyticsReport,
  YtmCoachDiagnosis,
  YtmCoachImprovementItem,
  YtmCoachLearningLesson,
  YtmCoachMetricSnapshot,
  YtmCoachOpportunity,
  YtmCommunityPostFormat,
  YtmCommunityPostPayload,
  YtmPlannerProjectRecord,
  YtmPlannerTaskRecord,
  YtmPriority,
  YtmPublishingStrategyPlan,
  YtmStrategyCalendarItem,
  YtmStrategyIntake,
} from '../../shared/types.ts';
import {
  buildModelThinkingConfig,
  extractReadableAiErrorMessage,
  getOrderedModelCandidates,
  isTransientModelOverloadError,
  markHydrogenTemporarilyUnavailable,
  ScriptAiError,
} from './scriptStudioAi.ts';

function getAiClient(): GoogleGenAI {
  const cfg = getServerConfig();
  if (!cfg.geminiApiKey) {
    throw new ScriptAiError(
      'GEMINI_API_KEY is not configured on the server. Add GEMINI_API_KEY in Secrets to enable AI generation.',
      500,
      'GEMINI_API_KEY_MISSING'
    );
  }
  return new GoogleGenAI({
    apiKey: cfg.geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function resolveModel(requested?: string | null): ScriptAiModelId {
  if (requested === 'gemini-3.1-flash-lite') return 'gemini-3.1-flash-lite';
  const cfg = getServerConfig();
  return cfg.scriptAiModel || 'gemini-4-hydrogen';
}

async function withAiTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => {
          reject(
            new ScriptAiError(
              `AI request timed out after ${Math.round(timeoutMs / 1000)}s. Please retry.`,
              500,
              'AI_TIMEOUT'
            )
          );
        }, timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function runStructuredJson<T>(params: {
  model?: string | null;
  systemInstruction: string;
  prompt: string;
  schema: Schema;
}): Promise<T> {
  const ai = getAiClient();
  const primaryModel = resolveModel(params.model);
  const candidates = getOrderedModelCandidates(primaryModel);
  const deadline = Date.now() + 45_000;

  let lastErr: unknown;
  for (let i = 0; i < candidates.length; i++) {
    const model = candidates[i];
    const remainingMs = deadline - Date.now();
    if (remainingMs <= 1500) break;
    const attemptTimeoutMs =
      i === 0 && candidates.length > 1
        ? Math.min(remainingMs, model === 'gemini-4-hydrogen' ? 16_000 : 25_000)
        : remainingMs;

    try {
      const response = await withAiTimeout(
        ai.models.generateContent({
          model,
          contents: params.prompt,
          config: {
            systemInstruction: params.systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: params.schema,
            ...buildModelThinkingConfig(model),
          },
        }),
        attemptTimeoutMs
      );
      const raw = (response.text || '')
        .trim()
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```$/, '');
      if (!raw) {
        throw new ScriptAiError('Empty AI response received.', 500, 'AI_INVALID_RESPONSE');
      }
      return JSON.parse(raw) as T;
    } catch (err: unknown) {
      lastErr = err;
      const msg = extractReadableAiErrorMessage(err);
      const lower = msg.toLowerCase();
      const isTimeout = err instanceof ScriptAiError && err.code === 'AI_TIMEOUT';
      const isQuota = lower.includes('429') || lower.includes('quota') || lower.includes('resource_exhausted');
      const isNotFound = lower.includes('not_found') || lower.includes('404');
      const shouldFallback = isTransientModelOverloadError(lower) || isTimeout || isQuota || isNotFound;

      if (model === 'gemini-4-hydrogen' && shouldFallback) {
        markHydrogenTemporarilyUnavailable(isQuota ? 10 * 60_000 : 3 * 60_000);
      }

      if (i + 1 < candidates.length && shouldFallback) {
        await new Promise((r) => setTimeout(r, 250));
        continue;
      }
      if (err instanceof ScriptAiError) throw err;
      if (isQuota) {
        throw new ScriptAiError(
          `Free-tier rate limit reached for ${model}. Retry shortly or switch to Gemini 3.1 Flash Lite.`,
          429,
          'AI_RATE_LIMITED'
        );
      }
      throw new ScriptAiError(msg, 500, 'AI_GENERATION_FAILED');
    }
  }
  if (lastErr instanceof ScriptAiError) throw lastErr;
  throw new ScriptAiError(extractReadableAiErrorMessage(lastErr), 500, 'AI_GENERATION_FAILED');
}

// ==============================================================================
// 1. AI STRATEGY ASSISTANT (Publishing Strategy + Communication Strategy + Calendar)
// ==============================================================================
export async function aiYtmGenerateContentStrategy(params: {
  intake: YtmStrategyIntake;
  channelDnaPrompt?: string;
  startDateKey: string;
  existingProjectsSummary: string;
  recentChannelPerformanceNote?: string;
}): Promise<{
  title: string;
  publishingStrategy: YtmPublishingStrategyPlan;
  communicationStrategy: YtmAudienceCommunicationStrategy;
  calendarItems: YtmStrategyCalendarItem[];
}> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING },
      publishingStrategy: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          longFormMonthlyTarget: { type: Type.STRING },
          shortsWeeklyTarget: { type: Type.STRING },
          communityPostsCadence: { type: Type.STRING },
          pollsAndQuizzesCadence: { type: Type.STRING },
          behindTheScenesAndPromoMix: { type: Type.STRING },
          commentEngagementRoutine: { type: Type.STRING },
          capacityRealismNote: { type: Type.STRING },
          contentPillarsMix: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                pillar: { type: Type.STRING },
                sharePercent: { type: Type.INTEGER },
                objective: { type: Type.STRING },
              },
              required: ['pillar', 'sharePercent', 'objective'],
            },
          },
        },
        required: [
          'summary',
          'longFormMonthlyTarget',
          'shortsWeeklyTarget',
          'communityPostsCadence',
          'pollsAndQuizzesCadence',
          'behindTheScenesAndPromoMix',
          'commentEngagementRoutine',
          'capacityRealismNote',
          'contentPillarsMix',
        ],
      },
      communicationStrategy: {
        type: Type.OBJECT,
        properties: {
          overview: { type: Type.STRING },
          weeklyEngagementSchedule: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                dayOfWeek: { type: Type.STRING },
                activity: { type: Type.STRING },
                timeMinutes: { type: Type.INTEGER },
              },
              required: ['dayOfWeek', 'activity', 'timeMinutes'],
            },
          },
          subscriberQuestionPrompts: { type: Type.ARRAY, items: { type: Type.STRING } },
          pollIdeas: { type: Type.ARRAY, items: { type: Type.STRING } },
          quizIdeas: { type: Type.ARRAY, items: { type: Type.STRING } },
          discussionPrompts: { type: Type.ARRAY, items: { type: Type.STRING } },
          feedbackCollectionRoutine: { type: Type.STRING },
          commentResponseSessions: { type: Type.STRING },
          launchAnnouncementFlow: { type: Type.STRING },
          postPublicationEngagementPlan: { type: Type.STRING },
        },
        required: [
          'overview',
          'weeklyEngagementSchedule',
          'subscriberQuestionPrompts',
          'pollIdeas',
          'quizIdeas',
          'discussionPrompts',
          'feedbackCollectionRoutine',
          'commentResponseSessions',
          'launchAnnouncementFlow',
          'postPublicationEngagementPlan',
        ],
      },
      calendarItems: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            date: { type: Type.STRING },
            time: { type: Type.STRING },
            platform: { type: Type.STRING },
            contentType: { type: Type.STRING },
            title: { type: Type.STRING },
            objective: { type: Type.STRING },
            productionDeadline: { type: Type.STRING },
            publishingDeadline: { type: Type.STRING },
            priority: { type: Type.STRING },
          },
          required: [
            'date',
            'platform',
            'contentType',
            'title',
            'objective',
            'productionDeadline',
            'publishingDeadline',
            'priority',
          ],
        },
      },
    },
    required: ['title', 'publishingStrategy', 'communicationStrategy', 'calendarItems'],
  };

  const prompt = `You are a Senior YouTube Content Strategist and Production Planner.
Create a realistic, sustainable 30-day Content Strategy & Calendar starting on ${params.startDateKey} tailored strictly to this creator's actual time budget, goals, and Channel DNA.

CRITICAL REALISM RULES:
- Do NOT prescribe arbitrary universal posting frequencies (like "post daily" if the creator only has ${params.intake.availableHoursPerWeek} hours/week).
- Tailor long-form count, Shorts count, community posts, polls, quizzes, behind-the-scenes, older video promos, and comment engagement sessions strictly to their available ${params.intake.availableHoursPerWeek} hours/week and stated goals.
- Generate 14 to 22 concrete calendar items spanning the next 4 weeks starting ${params.startDateKey} (YYYY-MM-DD dates strictly >= ${params.startDateKey}).
- Include realistic productionDeadline (1 to 3 days before publishingDeadline for videos) and publishingDeadline.
- Leave time empty ("") unless there is a clear rationale (e.g. launch window or engagement session).
- contentType must be one of: long_form_video, youtube_short, community_post, poll, quiz, engagement_session, promo_post, behind_the_scenes.
- priority must be one of: low, medium, high, urgent.

CREATOR STRATEGY INTAKE:
- Main Platform: ${params.intake.mainPlatform}
- Niche: ${params.intake.niche}
- Target Audience: ${params.intake.targetAudience}
- Content Formats: ${params.intake.contentFormats.join(', ') || 'Long-form YouTube, Shorts, Community Posts'}
- Publishing Goals: ${params.intake.publishingGoals}
- Available Production Time: ${params.intake.availableHoursPerWeek} hours/week
- Preferred Posting Frequency: ${params.intake.preferredFrequency}
- Monthly Content Target: ${params.intake.monthlyContentTarget}
- Audience Engagement Goals: ${params.intake.audienceEngagementGoals}
${params.intake.additionalConstraints ? `- Additional Constraints: ${params.intake.additionalConstraints}` : ''}

${params.channelDnaPrompt ? `${params.channelDnaPrompt}\n` : ''}
EXISTING PLANNER CONTEXT (avoid duplicating already-scheduled titles):
${params.existingProjectsSummary || 'No existing scheduled projects.'}
${params.recentChannelPerformanceNote ? `\nHISTORICAL PERFORMANCE CONTEXT:\n${params.recentChannelPerformanceNote}` : ''}`;

  const raw = await runStructuredJson<{
    title: string;
    publishingStrategy: YtmPublishingStrategyPlan;
    communicationStrategy: YtmAudienceCommunicationStrategy;
    calendarItems: Array<{
      date: string;
      time?: string;
      platform: string;
      contentType: string;
      title: string;
      objective: string;
      productionDeadline: string;
      publishingDeadline: string;
      priority: string;
    }>;
  }>({
    systemInstruction:
      'Produce realistic, creator-sustainable content strategies aligned with Channel DNA. Never fabricate channel metrics or force unsustainable posting frequencies.',
    prompt,
    schema,
  });

  const validTypes = new Set<YtmStrategyCalendarItem['contentType']>([
    'long_form_video',
    'youtube_short',
    'community_post',
    'poll',
    'quiz',
    'engagement_session',
    'promo_post',
    'behind_the_scenes',
  ]);
  const validPriorities = new Set<YtmPriority>(['low', 'medium', 'high', 'urgent']);

  const calendarItems: YtmStrategyCalendarItem[] = (raw.calendarItems || []).map((item, idx) => ({
    id: `strat_${crypto.randomBytes(4).toString('hex')}_${idx}`,
    date: /^\d{4}-\d{2}-\d{2}$/.test(item.date) ? item.date : params.startDateKey,
    time: item.time && item.time.trim() ? item.time.trim().slice(0, 16) : null,
    platform: (item.platform || params.intake.mainPlatform || 'YouTube').slice(0, 60),
    contentType: (validTypes.has(item.contentType as YtmStrategyCalendarItem['contentType'])
      ? item.contentType
      : 'long_form_video') as YtmStrategyCalendarItem['contentType'],
    title: (item.title || 'Untitled Content Item').slice(0, 180),
    objective: (item.objective || '').slice(0, 300),
    productionDeadline: /^\d{4}-\d{2}-\d{2}$/.test(item.productionDeadline)
      ? item.productionDeadline
      : /^\d{4}-\d{2}-\d{2}$/.test(item.date)
        ? item.date
        : params.startDateKey,
    publishingDeadline: /^\d{4}-\d{2}-\d{2}$/.test(item.publishingDeadline)
      ? item.publishingDeadline
      : /^\d{4}-\d{2}-\d{2}$/.test(item.date)
        ? item.date
        : params.startDateKey,
    status: 'pending_review',
    priority: (validPriorities.has(item.priority as YtmPriority)
      ? item.priority
      : 'medium') as YtmPriority,
  }));

  return {
    title: (raw.title || `${params.intake.niche || 'Channel'} 30-Day Strategy`).slice(0, 180),
    publishingStrategy: raw.publishingStrategy,
    communicationStrategy: raw.communicationStrategy,
    calendarItems,
  };
}

export async function aiYtmRegenerateStrategyDates(params: {
  intake: YtmStrategyIntake;
  channelDnaPrompt?: string;
  selectedDates: string[];
  existingItems: YtmStrategyCalendarItem[];
  note?: string;
}): Promise<YtmStrategyCalendarItem[]> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      items: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            date: { type: Type.STRING },
            time: { type: Type.STRING },
            platform: { type: Type.STRING },
            contentType: { type: Type.STRING },
            title: { type: Type.STRING },
            objective: { type: Type.STRING },
            productionDeadline: { type: Type.STRING },
            publishingDeadline: { type: Type.STRING },
            priority: { type: Type.STRING },
          },
          required: [
            'date',
            'platform',
            'contentType',
            'title',
            'objective',
            'productionDeadline',
            'publishingDeadline',
            'priority',
          ],
        },
      },
    },
    required: ['items'],
  };

  const prompt = `Regenerate fresh, distinct calendar items ONLY for these specific dates: ${params.selectedDates.join(', ')}.
Creator niche: ${params.intake.niche} | Audience: ${params.intake.targetAudience} | Goals: ${params.intake.publishingGoals}
${params.note ? `Creator adjustment note: ${params.note}` : ''}
${params.channelDnaPrompt ? `\n${params.channelDnaPrompt}` : ''}
Avoid repeating titles already on the calendar: ${params.existingItems.map((i) => i.title).slice(0, 15).join('; ')}`;

  const res = await runStructuredJson<{
    items: Array<{
      date: string;
      time?: string;
      platform: string;
      contentType: string;
      title: string;
      objective: string;
      productionDeadline: string;
      publishingDeadline: string;
      priority: string;
    }>;
  }>({
    systemInstruction: 'Return replacement calendar items ONLY for the requested dates.',
    prompt,
    schema,
  });

  const validTypes = new Set<YtmStrategyCalendarItem['contentType']>([
    'long_form_video',
    'youtube_short',
    'community_post',
    'poll',
    'quiz',
    'engagement_session',
    'promo_post',
    'behind_the_scenes',
  ]);
  const validPriorities = new Set<YtmPriority>(['low', 'medium', 'high', 'urgent']);

  return (res.items || []).map((item, idx) => {
    const fallbackDate = params.selectedDates[idx % params.selectedDates.length] || params.selectedDates[0];
    const resolvedDate = /^\d{4}-\d{2}-\d{2}$/.test(item.date) ? item.date : fallbackDate;
    return {
      id: `strat_${crypto.randomBytes(4).toString('hex')}_${idx}`,
      date: resolvedDate,
      time: item.time && item.time.trim() ? item.time.trim().slice(0, 16) : null,
      platform: (item.platform || params.intake.mainPlatform || 'YouTube').slice(0, 60),
      contentType: (validTypes.has(item.contentType as YtmStrategyCalendarItem['contentType'])
        ? item.contentType
        : 'long_form_video') as YtmStrategyCalendarItem['contentType'],
      title: (item.title || 'Refreshed Content Item').slice(0, 180),
      objective: (item.objective || '').slice(0, 300),
      productionDeadline: /^\d{4}-\d{2}-\d{2}$/.test(item.productionDeadline)
        ? item.productionDeadline
        : resolvedDate,
      publishingDeadline: /^\d{4}-\d{2}-\d{2}$/.test(item.publishingDeadline)
        ? item.publishingDeadline
        : resolvedDate,
      status: 'pending_review',
      priority: (validPriorities.has(item.priority as YtmPriority)
        ? item.priority
        : 'medium') as YtmPriority,
    };
  });
}

// ==============================================================================
// 2. CONTINUOUS CALENDAR ASSISTANCE (Deterministic Real-Data Audit + AI Advice)
// ==============================================================================
export function buildDeterministicCalendarAudit(params: {
  todayKey: string;
  projects: YtmPlannerProjectRecord[];
  tasks: YtmPlannerTaskRecord[];
  availableHoursPerWeek?: number;
}): YtmCalendarAuditReport {
  const suggestions: YtmCalendarAuditReport['suggestions'] = [];
  const todayMs = Date.parse(`${params.todayKey}T00:00:00Z`);

  const addDays = (baseKey: string, delta: number): string => {
    const d = new Date(`${baseKey}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + delta);
    return d.toISOString().slice(0, 10);
  };

  // 1. Missed deadlines (projects & tasks)
  let missedCount = 0;
  for (const p of params.projects) {
    if (p.status === 'Published') continue;
    const due = p.deadline?.slice(0, 10) || p.plannedDate?.slice(0, 10) || null;
    if (due && due < params.todayKey) {
      missedCount++;
      suggestions.push({
        id: `aud_proj_miss_${p.id}`,
        issueType: 'missed_deadline',
        severity: 'high',
        summary: `Project "${p.title}" missed its ${due} target date.`,
        targetType: 'project',
        targetId: p.id,
        targetTitle: p.title,
        currentDate: due,
        suggestedDate: addDays(params.todayKey, 3 + (missedCount % 4)),
        rationale:
          'Rescheduling past-due items to realistic upcoming slots prevents pipeline pile-up without losing the video idea.',
      });
    }
  }

  for (const t of params.tasks) {
    if (t.status === 'Completed') continue;
    const due = t.deadline?.slice(0, 10) || null;
    if (due && due < params.todayKey) {
      missedCount++;
      suggestions.push({
        id: `aud_task_miss_${t.id}`,
        issueType: 'missed_deadline',
        severity: 'high',
        summary: `Task "${t.taskName}" is overdue since ${due}.`,
        targetType: 'task',
        targetId: t.id,
        targetTitle: t.taskName,
        currentDate: due,
        suggestedDate: addDays(params.todayKey, 1 + (missedCount % 3)),
        rationale: 'Move overdue tasks to an achievable day this week or mark them completed.',
      });
    }
  }

  // 2. Overlapping deadlines on the same day
  const byDate = new Map<string, Array<{ type: 'project' | 'task'; id: number; title: string }>>();
  for (const p of params.projects) {
    if (p.status === 'Published') continue;
    const d = p.plannedDate?.slice(0, 10);
    if (d && d >= params.todayKey) {
      const list = byDate.get(d) || [];
      list.push({ type: 'project', id: p.id, title: p.title });
      byDate.set(d, list);
    }
  }
  let overlappingCount = 0;
  for (const [dateKey, items] of byDate.entries()) {
    if (items.length >= 2) {
      overlappingCount++;
      const second = items[1];
      suggestions.push({
        id: `aud_overlap_${dateKey}_${second.id}`,
        issueType: 'overlapping_deadlines',
        severity: 'medium',
        summary: `${items.length} video projects are scheduled on the same date (${dateKey}).`,
        targetType: 'project',
        targetId: second.id,
        targetTitle: second.title,
        currentDate: dateKey,
        suggestedDate: addDays(dateKey, 3),
        rationale:
          'Spacing out video launches by at least 3 days avoids cannibalizing impressions and reduces editing bottlenecks.',
      });
    }
  }

  // 3. Overloaded production weeks
  const byWeek = new Map<string, YtmPlannerProjectRecord[]>();
  for (const p of params.projects) {
    if (p.status === 'Published') continue;
    const d = p.plannedDate?.slice(0, 10) || p.deadline?.slice(0, 10);
    if (!d || d < params.todayKey) continue;
    const ms = Date.parse(`${d}T00:00:00Z`);
    const weekNum = Math.floor((ms - todayMs) / (7 * 86400000));
    if (weekNum >= 0 && weekNum < 6) {
      const key = `Week +${weekNum + 1}`;
      const list = byWeek.get(key) || [];
      list.push(p);
      byWeek.set(key, list);
    }
  }
  const weeklyCap = params.availableHoursPerWeek && params.availableHoursPerWeek <= 6 ? 2 : 3;
  let overloadedWeeksCount = 0;
  for (const [wk, items] of byWeek.entries()) {
    if (items.length > weeklyCap) {
      overloadedWeeksCount++;
      const overflowItem = items[items.length - 1];
      const origDate = overflowItem.plannedDate?.slice(0, 10) || params.todayKey;
      suggestions.push({
        id: `aud_overload_${wk}_${overflowItem.id}`,
        issueType: 'overloaded_week',
        severity: 'medium',
        summary: `${wk} has ${items.length} active videos scheduled (recommended cap: ${weeklyCap}/week).`,
        targetType: 'project',
        targetId: overflowItem.id,
        targetTitle: overflowItem.title,
        currentDate: origDate,
        suggestedDate: addDays(origDate, 7),
        rationale: `Shifting "${overflowItem.title}" to the following week protects quality and prevents creator burnout.`,
      });
    }
  }

  // 4. Publishing gaps (>10 days without a scheduled project in the next 30 days)
  const upcomingDates = params.projects
    .filter((p) => p.status !== 'Published' && p.plannedDate && p.plannedDate.slice(0, 10) >= params.todayKey)
    .map((p) => p.plannedDate!.slice(0, 10))
    .sort();
  let gapsCount = 0;
  if (upcomingDates.length === 0) {
    gapsCount = 1;
    suggestions.push({
      id: `aud_gap_empty_${params.todayKey}`,
      issueType: 'publishing_gap',
      severity: 'medium',
      summary: 'No upcoming videos are scheduled on the calendar yet.',
      targetType: 'gap',
      targetId: null,
      targetTitle: 'Schedule next core video or community check-in',
      currentDate: null,
      suggestedDate: addDays(params.todayKey, 5),
      rationale:
        'Generate and approve a realistic strategy calendar or schedule at least one upcoming anchor video.',
    });
  } else {
    let prevMs = todayMs;
    for (const d of upcomingDates) {
      const curMs = Date.parse(`${d}T00:00:00Z`);
      const diffDays = Math.round((curMs - prevMs) / 86400000);
      if (diffDays > 10) {
        gapsCount++;
        const midKey = new Date(prevMs + Math.floor(diffDays / 2) * 86400000).toISOString().slice(0, 10);
        suggestions.push({
          id: `aud_gap_${midKey}`,
          issueType: 'publishing_gap',
          severity: 'low',
          summary: `${diffDays}-day publishing gap detected before ${d}.`,
          targetType: 'gap',
          targetId: null,
          targetTitle: 'Fill gap with a Short, Community Poll, or Quiz',
          currentDate: null,
          suggestedDate: midKey,
          rationale:
            'A low-effort Community Post or Short around this date keeps subscribers warm without heavy filming.',
        });
      }
      prevMs = curMs;
    }
  }

  const totalIssues = missedCount + overloadedWeeksCount + gapsCount + overlappingCount;
  const healthSummary =
    totalIssues === 0
      ? 'Your current Content Planner schedule is balanced with no overdue items, overlapping launch days, or overloaded weeks.'
      : `Detected ${missedCount} missed deadline(s), ${overlappingCount} overlapping launch date(s), ${overloadedWeeksCount} overloaded week(s), and ${gapsCount} publishing gap(s). Review and approve any suggested date changes below.`;

  return {
    auditedAt: new Date().toISOString(),
    healthSummary,
    missedDeadlinesCount: missedCount,
    overloadedWeeksCount,
    publishingGapsCount: gapsCount,
    overlappingDeadlinesCount: overlappingCount,
    suggestions: suggestions.slice(0, 12),
  };
}

// ==============================================================================
// 3. STAGE 4 COMMUNITY POST GENERATOR (ALL 5 FORMATS)
// ==============================================================================
export async function aiYtmGenerateCommunityPost(params: {
  formatType: YtmCommunityPostFormat;
  topic: string;
  projectTitle?: string;
  projectTopicSummary?: string;
  channelDnaPrompt?: string;
  instruction?: string;
}): Promise<{ title: string; payload: YtmCommunityPostPayload }> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      title: { type: Type.STRING },
      question: { type: Type.STRING },
      options: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            label: { type: Type.STRING },
            imagePrompt: { type: Type.STRING },
          },
          required: ['label'],
        },
      },
      correctOptionIndex: { type: Type.INTEGER },
      explanation: { type: Type.STRING },
      caption: { type: Type.STRING },
      bodyText: { type: Type.STRING },
      callToAction: { type: Type.STRING },
      imagePrompt: { type: Type.STRING },
    },
    required: ['title'],
  };

  const formatSpecs: Record<YtmCommunityPostFormat, string> = {
    quiz: 'FORMAT: YOUTUBE QUIZ. Must include: question (clear engaging quiz question), options (4 concise answer choices), correctOptionIndex (0..3), explanation (short clear explanation revealed after voting), optional caption, and optional imagePrompt.',
    text_poll:
      'FORMAT: YOUTUBE TEXT POLL. Must include: question (clear poll question), options (3 to 4 crisp text choices under 65 chars each), and optional introductory caption + callToAction.',
    image_poll:
      'FORMAT: YOUTUBE IMAGE POLL. Must include: question (visual poll question), options (2 to 4 options where EACH option has both a short label AND a concrete visual imagePrompt describing the distinct visual for that option), plus optional caption.',
    image_post:
      'FORMAT: YOUTUBE IMAGE POST. Must include: imagePrompt (detailed high-contrast visual concept for the post image), caption (engaging headline/hook), bodyText (supporting story or value), and callToAction.',
    simple_text:
      'FORMAT: YOUTUBE SIMPLE TEXT POST. Must include: bodyText (authentic community message, update, or discussion prompt), question or discussion prompt in caption, and optional callToAction.',
  };

  const prompt = `Create a high-engagement YouTube Community Post strictly matching the requested format and Channel DNA.
${formatSpecs[params.formatType]}

Topic / Angle: ${params.topic}
${params.projectTitle ? `Linked Video Project Title: ${params.projectTitle}` : ''}
${params.projectTopicSummary ? `Video Context: ${params.projectTopicSummary}` : ''}
${params.instruction ? `Creator Direction: ${params.instruction}` : ''}
${params.channelDnaPrompt ? `\n${params.channelDnaPrompt}` : ''}

Keep copy natural, concise, and aligned with YouTube Community tab character ergonomics (no robotic filler or hashtags overload).`;

  const raw = await runStructuredJson<{
    title: string;
    question?: string;
    options?: Array<{ label: string; imagePrompt?: string }>;
    correctOptionIndex?: number;
    explanation?: string;
    caption?: string;
    bodyText?: string;
    callToAction?: string;
    imagePrompt?: string;
  }>({
    systemInstruction:
      'Return clean, ready-to-publish YouTube Community Post copy matching the exact format requested and Channel DNA.',
    prompt,
    schema,
  });

  const normalizedOptions = Array.isArray(raw.options)
    ? raw.options.slice(0, 4).map((opt, idx) => ({
        id: `opt_${idx + 1}`,
        label: (opt.label || `Option ${idx + 1}`).slice(0, 120),
        imagePrompt: opt.imagePrompt ? opt.imagePrompt.slice(0, 400) : undefined,
        imageUrl: null,
      }))
    : undefined;

  const payload: YtmCommunityPostPayload = {
    question: raw.question || undefined,
    options: normalizedOptions,
    correctOptionIndex:
      params.formatType === 'quiz' && typeof raw.correctOptionIndex === 'number'
        ? Math.max(0, Math.min((normalizedOptions?.length || 4) - 1, raw.correctOptionIndex))
        : undefined,
    explanation: raw.explanation || undefined,
    caption: raw.caption || undefined,
    bodyText: raw.bodyText || undefined,
    callToAction: raw.callToAction || undefined,
    imagePrompt: raw.imagePrompt || undefined,
    imageUrl: null,
  };

  return {
    title: (raw.title || params.topic || 'Community Post Draft').slice(0, 160),
    payload,
  };
}

// ==============================================================================
// 4. CREATOR PERFORMANCE COACH (REAL DATA ONLY — NEVER FABRICATES METRICS)
// ==============================================================================
export async function aiYtmRunPerformanceCoach(params: {
  channelTitle: string;
  currentReport: YtmChannelAnalyticsReport;
  previousReport: YtmChannelAnalyticsReport | null;
  metricsSummary: YtmCoachMetricSnapshot;
  channelDnaPrompt?: string;
  externalCompetitorSummary?: string;
  recentPublishingCadenceNote: string;
}): Promise<{
  diagnosis: YtmCoachDiagnosis;
  improvements: YtmCoachImprovementItem[];
  opportunities: YtmCoachOpportunity[];
  learningLessons: YtmCoachLearningLesson[];
  recommendedActions: Array<{
    horizon: 'daily' | 'weekly' | 'monthly' | 'experiment';
    title: string;
    rationale: string;
    actionSteps: string;
    expectedOutcome: string;
    metricToMeasure: string;
    priority: YtmPriority;
  }>;
}> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      diagnosis: {
        type: Type.OBJECT,
        properties: {
          headline: { type: Type.STRING },
          overallStatus: { type: Type.STRING },
          whatsWorking: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: { point: { type: Type.STRING }, evidence: { type: Type.STRING } },
              required: ['point', 'evidence'],
            },
          },
          notImproving: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: { point: { type: Type.STRING }, evidence: { type: Type.STRING } },
              required: ['point', 'evidence'],
            },
          },
          underperformingVideos: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                videoTitle: { type: Type.STRING },
                observation: { type: Type.STRING },
                likelyReason: { type: Type.STRING },
              },
              required: ['videoTitle', 'observation', 'likelyReason'],
            },
          },
          strongestTopics: { type: Type.ARRAY, items: { type: Type.STRING } },
          decliningTopics: { type: Type.ARRAY, items: { type: Type.STRING } },
          publishingHabitAssessment: { type: Type.STRING },
          periodComparisonSummary: { type: Type.STRING },
        },
        required: [
          'headline',
          'overallStatus',
          'whatsWorking',
          'notImproving',
          'underperformingVideos',
          'strongestTopics',
          'decliningTopics',
          'publishingHabitAssessment',
          'periodComparisonSummary',
        ],
      },
      improvements: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            area: { type: Type.STRING },
            whatHappened: { type: Type.STRING },
            whyItMatters: { type: Type.STRING },
            evidenceFromChannel: { type: Type.STRING },
            possibleCause: { type: Type.STRING },
            whatToImprove: { type: Type.STRING },
            howToImprove: { type: Type.STRING },
            nextAction: { type: Type.STRING },
            howToMeasure: { type: Type.STRING },
          },
          required: [
            'area',
            'whatHappened',
            'whyItMatters',
            'evidenceFromChannel',
            'possibleCause',
            'whatToImprove',
            'howToImprove',
            'nextAction',
            'howToMeasure',
          ],
        },
      },
      opportunities: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING },
            evidenceSource: { type: Type.STRING },
            title: { type: Type.STRING },
            explanation: { type: Type.STRING },
            suggestedVideoAngle: { type: Type.STRING },
            expectedImpact: { type: Type.STRING },
          },
          required: [
            'category',
            'evidenceSource',
            'title',
            'explanation',
            'suggestedVideoAngle',
            'expectedImpact',
          ],
        },
      },
      learningLessons: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            topic: { type: Type.STRING },
            plainEnglishExplanation: { type: Type.STRING },
            howItShowsUpOnYourChannel: { type: Type.STRING },
            beginnerChecklist: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: [
            'topic',
            'plainEnglishExplanation',
            'howItShowsUpOnYourChannel',
            'beginnerChecklist',
          ],
        },
      },
      recommendedActions: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            horizon: { type: Type.STRING },
            title: { type: Type.STRING },
            rationale: { type: Type.STRING },
            actionSteps: { type: Type.STRING },
            expectedOutcome: { type: Type.STRING },
            metricToMeasure: { type: Type.STRING },
            priority: { type: Type.STRING },
          },
          required: [
            'horizon',
            'title',
            'rationale',
            'actionSteps',
            'expectedOutcome',
            'metricToMeasure',
            'priority',
          ],
        },
      },
    },
    required: ['diagnosis', 'improvements', 'opportunities', 'learningLessons', 'recommendedActions'],
  };

  const prompt = `You are a supportive, plain-English YouTube Creator Performance Coach guiding a real creator based ONLY on their verified YouTube Analytics API v2 / Data API v3 performance data.

STRICT HONESTY & EVIDENCE RULES:
- Cite ONLY metrics present in the data below.
- NEVER invent CTR, Impressions, Returning Viewers, or Revenue numbers if they are marked unavailable.
- Clearly distinguish own channel observations ("own_channel_data") from external competitor research ("external_competitor_intelligence").
- Write in clear, beginner-friendly teaching language — explain WHY something matters and HOW to fix it step by step.

CHANNEL: ${params.channelTitle}
DATA SOURCE: ${params.currentReport.source}
CURRENT PERIOD (${params.metricsSummary.currentPeriod.start} to ${params.metricsSummary.currentPeriod.end}):
- Views: ${params.metricsSummary.views ?? 'Unavailable'} (Prior period: ${params.metricsSummary.previousViews ?? 'Unavailable'})
- Watch Time (minutes): ${params.metricsSummary.watchTimeMinutes ?? 'Unavailable'} (Prior period: ${params.metricsSummary.previousWatchTimeMinutes ?? 'Unavailable'})
- Average View Duration (seconds): ${params.metricsSummary.avgViewDurationSec ?? 'Unavailable'} (Prior period: ${params.metricsSummary.previousAvgViewDurationSec ?? 'Unavailable'})
- Net Subscribers: ${params.metricsSummary.subscribersNet ?? 'Unavailable'} (Prior period: ${params.metricsSummary.previousSubscribersNet ?? 'Unavailable'})
- Likes: ${params.metricsSummary.likes ?? 'Unavailable'} | Comments: ${params.metricsSummary.comments ?? 'Unavailable'}
- Unavailable Metrics Disclosure: ${params.metricsSummary.unavailableMetricsDisclosure}

PUBLISHING CADENCE & WORKSPACE CONTEXT:
${params.recentPublishingCadenceNote}

TOP / RECENT VIDEOS OBSERVED:
${
  params.currentReport.topVideos
    .slice(0, 12)
    .map(
      (v, i) =>
        `${i + 1}. "${v.title}" — ${v.views} views, ${v.estimatedMinutesWatched} min watch time, ${v.averageViewDurationSec}s avg view duration`
    )
    .join('\n') || 'No individual video metrics returned in this date range.'
}

TRAFFIC SOURCES:
${
  params.currentReport.trafficSources
    .slice(0, 6)
    .map((t) => `- ${t.sourceType}: ${t.views} views (${t.estimatedMinutesWatched} min)`)
    .join('\n') || 'Traffic source breakdown unavailable for this period.'
}

${params.channelDnaPrompt ? `\n${params.channelDnaPrompt}\n` : ''}
${
  params.externalCompetitorSummary
    ? `\nEXTERNAL COMPETITOR INTELLIGENCE (label opportunities using this as "external_competitor_intelligence" or "combined"):\n${params.externalCompetitorSummary}`
    : '\nNo external Competitor Intelligence saved yet — base opportunities strictly on own_channel_data.'
}

Generate:
- Diagnosis (overallStatus: growing | steady | needs_attention)
- 3 to 5 beginner-friendly What to Improve items (covering all 8 teaching fields)
- 4 to 6 Growth Opportunities (category: series_candidate | expandable_topic | weak_area_fix | content_gap | audience_question | consistency; evidenceSource: own_channel_data | external_competitor_intelligence | combined)
- 3 to 4 Learning Center lessons explaining real YouTube mechanics tied to what shows up on this channel
- 5 to 7 Recommended Actions spanning horizons: daily, weekly, monthly, experiment (with concrete actionSteps & metricToMeasure).`;

  const raw = await runStructuredJson<{
    diagnosis: YtmCoachDiagnosis;
    improvements: Array<Omit<YtmCoachImprovementItem, 'id'>>;
    opportunities: Array<Omit<YtmCoachOpportunity, 'id'>>;
    learningLessons: Array<Omit<YtmCoachLearningLesson, 'id'>>;
    recommendedActions: Array<{
      horizon: string;
      title: string;
      rationale: string;
      actionSteps: string;
      expectedOutcome: string;
      metricToMeasure: string;
      priority: string;
    }>;
  }>({
    systemInstruction:
      'Be an honest, clear, actionable Creator Performance Coach. Never fabricate unavailable metrics. Always separate own-channel facts from external competitor insights.',
    prompt,
    schema,
  });

  const validOverall = new Set(['growing', 'steady', 'needs_attention']);
  const validCategories = new Set<YtmCoachOpportunity['category']>([
    'series_candidate',
    'expandable_topic',
    'weak_area_fix',
    'content_gap',
    'audience_question',
    'consistency',
  ]);
  const validSources = new Set<YtmCoachOpportunity['evidenceSource']>([
    'own_channel_data',
    'external_competitor_intelligence',
    'combined',
  ]);
  const validHorizons = new Set(['daily', 'weekly', 'monthly', 'experiment']);
  const validPriorities = new Set<YtmPriority>(['low', 'medium', 'high', 'urgent']);

  return {
    diagnosis: {
      ...raw.diagnosis,
      overallStatus: (validOverall.has(raw.diagnosis?.overallStatus)
        ? raw.diagnosis.overallStatus
        : 'steady') as YtmCoachDiagnosis['overallStatus'],
      whatsWorking: raw.diagnosis?.whatsWorking || [],
      notImproving: raw.diagnosis?.notImproving || [],
      underperformingVideos: raw.diagnosis?.underperformingVideos || [],
      strongestTopics: raw.diagnosis?.strongestTopics || [],
      decliningTopics: raw.diagnosis?.decliningTopics || [],
    },
    improvements: (raw.improvements || []).map((item, idx) => ({
      ...item,
      id: `imp_${idx + 1}_${crypto.randomBytes(3).toString('hex')}`,
    })),
    opportunities: (raw.opportunities || []).map((item, idx) => ({
      ...item,
      id: `opp_${idx + 1}_${crypto.randomBytes(3).toString('hex')}`,
      category: (validCategories.has(item.category as YtmCoachOpportunity['category'])
        ? item.category
        : 'expandable_topic') as YtmCoachOpportunity['category'],
      evidenceSource: (validSources.has(item.evidenceSource as YtmCoachOpportunity['evidenceSource'])
        ? item.evidenceSource
        : 'own_channel_data') as YtmCoachOpportunity['evidenceSource'],
    })),
    learningLessons: (raw.learningLessons || []).map((item, idx) => ({
      ...item,
      id: `lesson_${idx + 1}_${crypto.randomBytes(3).toString('hex')}`,
    })),
    recommendedActions: (raw.recommendedActions || []).slice(0, 8).map((a) => ({
      horizon: (validHorizons.has(a.horizon) ? a.horizon : 'weekly') as
        | 'daily'
        | 'weekly'
        | 'monthly'
        | 'experiment',
      title: (a.title || 'Channel Improvement Action').slice(0, 180),
      rationale: a.rationale || '',
      actionSteps: a.actionSteps || '',
      expectedOutcome: a.expectedOutcome || '',
      metricToMeasure: a.metricToMeasure || '',
      priority: (validPriorities.has(a.priority as YtmPriority) ? a.priority : 'medium') as YtmPriority,
    })),
  };
}
