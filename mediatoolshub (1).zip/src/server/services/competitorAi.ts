import { GoogleGenAI, Type, type Schema } from '@google/genai';
import { formatCompactNumber, formatSecondsAsClock } from '../../shared/competitorHelpers.ts';
import type {
  ChannelDeepDiveAnalysis,
  CompetitorChannelCollection,
  CrossCompetitorSynthesis,
  ScriptAiModelId,
} from '../../shared/types.ts';
import { getServerConfig } from '../config/env.ts';
import {
  buildModelThinkingConfig,
  extractReadableAiErrorMessage,
  getOrderedModelCandidates,
  isTransientModelOverloadError,
  markHydrogenTemporarilyUnavailable,
  ScriptAiError,
} from './scriptStudioAi.ts';

const AI_TIMEOUT_MS = 58_000;

const COMPETITOR_ANALYST_SYSTEM_INSTRUCTION = `You are a senior YouTube competitive intelligence analyst, audience psychologist, packaging strategist, and storytelling architect inside MediaToolsHub.

Strict Evidence & Epistemic Honesty Rules:
1. NEVER fabricate view counts, subscriber counts, CTR, retention curves, watch time, or transcript quotes. Only cite quantitative figures provided in the verified YouTube Data API v3 input.
2. NEVER guess hidden technical equipment or software (such as Adobe Premiere, DaVinci Resolve, Sony FX3, Shure SM7B, ElevenLabs) unless explicitly stated in a channel/video description provided to you. Place such unknowns clearly inside "unknownTechnicalDetails".
3. NEVER say the YouTube algorithm "promoted" or "boosted" a video as a proven causal fact. Use accurate analytical framing ("performed significantly above channel median", "correlates with high curiosity framing").
4. If public transcripts were NOT available (transcriptsSampledCount === 0), state that limitation transparently in Module 7 Hook & Storytelling and do NOT pretend to quote spoken lines.
5. Output actionable, beginner-friendly yet deep strategic intelligence designed strictly for creating ORIGINAL content—never copying competitor branding, scripts, or copyrighted expression.`;

function getGeminiClient(): GoogleGenAI {
  const { geminiApiKey } = getServerConfig();
  if (!geminiApiKey) {
    throw new ScriptAiError(
      'Server AI analysis is not configured yet. Please add GEMINI_API_KEY in Settings > Secrets.',
      500,
      'GEMINI_API_KEY_MISSING'
    );
  }
  return new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function resolveModel(requested?: string | null): ScriptAiModelId {
  if (requested === 'gemini-3.1-flash-lite') return 'gemini-3.1-flash-lite';
  const cfg = getServerConfig();
  return cfg.scriptAiModel || 'gemini-4-hydrogen';
}

function extractCleanJsonString(raw: string): string {
  const trimmed = raw.trim();
  if (trimmed.startsWith('```')) {
    return trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  }
  return trimmed;
}

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => {
          reject(
            new ScriptAiError(
              `${label} timed out after ${Math.round(timeoutMs / 1000)}s. Your collected channel data is preserved — retry or switch to Gemini 3.1 Flash Lite.`,
              500,
              'AI_TIMEOUT'
            )
          );
        }, timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function generateCompetitorJson<T>(params: {
  model: ScriptAiModelId;
  prompt: string;
  schema: Schema;
  label: string;
}): Promise<T> {
  const ai = getGeminiClient();
  const modelCandidates: ScriptAiModelId[] = getOrderedModelCandidates(params.model);
  const deadline = Date.now() + AI_TIMEOUT_MS;
  let lastErr: unknown;

  for (let attempt = 0; attempt < modelCandidates.length; attempt++) {
    const activeModel = modelCandidates[attempt];
    const remainingMs = deadline - Date.now();
    if (remainingMs <= 1500) {
      throw new ScriptAiError(
        `${params.label} timed out. Preserved progress can be retried cleanly.`,
        500,
        'AI_TIMEOUT'
      );
    }

    const attemptTimeoutMs =
      attempt === 0 && modelCandidates.length > 1
        ? Math.min(remainingMs, activeModel === 'gemini-4-hydrogen' ? 18_000 : 28_000)
        : remainingMs;

    try {
      const response = await withTimeout(
        ai.models.generateContent({
          model: activeModel,
          contents: params.prompt,
          config: {
            systemInstruction: COMPETITOR_ANALYST_SYSTEM_INSTRUCTION,
            responseMimeType: 'application/json',
            responseSchema: params.schema,
            ...buildModelThinkingConfig(activeModel),
          },
        }),
        attemptTimeoutMs,
        params.label
      );

      const raw = extractCleanJsonString(response.text ?? '');
      if (!raw) {
        throw new ScriptAiError(
          'The AI model returned an empty response. Please retry.',
          500,
          'AI_INVALID_RESPONSE'
        );
      }
      return JSON.parse(raw) as T;
    } catch (err) {
      lastErr = err;
      const readableMsg = extractReadableAiErrorMessage(err);
      const lower = readableMsg.toLowerCase();

      if (
        lower.includes('api_key_invalid') ||
        lower.includes('permission_denied') ||
        lower.includes('api key not valid')
      ) {
        throw new ScriptAiError(
          'The server GEMINI_API_KEY was rejected or lacks permission. Please verify it in Settings > Secrets.',
          500,
          'GEMINI_AUTH_ERROR'
        );
      }

      const hasFallback = attempt + 1 < modelCandidates.length;
      const isTimeout = err instanceof ScriptAiError && err.code === 'AI_TIMEOUT';
      const isNotFound = lower.includes('not_found') || lower.includes('404');
      const isQuota = lower.includes('quota') || lower.includes('resource_exhausted') || lower.includes('429');
      const shouldFallback = isTransientModelOverloadError(lower) || isTimeout || isNotFound || isQuota;

      if (activeModel === 'gemini-4-hydrogen' && shouldFallback) {
        markHydrogenTemporarilyUnavailable(isQuota ? 10 * 60_000 : 3 * 60_000);
      }

      if (hasFallback && shouldFallback) {
        await new Promise((r) => setTimeout(r, 250));
        continue;
      }

      if (isQuota) {
        throw new ScriptAiError(
          `Free-tier quota limit reached for ${activeModel}. Click "Switch to Gemini 3.1 Flash Lite & Retry" or wait a moment.`,
          429,
          'GEMINI_QUOTA_EXCEEDED'
        );
      }
      if (isNotFound) {
        throw new ScriptAiError(
          `Model "${activeModel}" is currently unavailable. Try switching AI model.`,
          400,
          'GEMINI_MODEL_UNAVAILABLE'
        );
      }
      if (err instanceof ScriptAiError) {
        throw err;
      }
      throw new ScriptAiError(`Competitor AI analysis failed: ${readableMsg}`, 500, 'AI_GENERATION_FAILED');
    }
  }

  throw new ScriptAiError(
    `Competitor AI analysis failed: ${extractReadableAiErrorMessage(lastErr)}`,
    500,
    'AI_GENERATION_FAILED'
  );
}

function buildChannelEvidenceSummary(col: CompetitorChannelCollection): string {
  const { profile, videos, metrics } = col;
  const sortedByOutlier = [...videos].sort(
    (a, b) => (b.outlierRatio ?? 0) - (a.outlierRatio ?? 0)
  );
  const topVideos = sortedByOutlier.slice(0, 12);
  const recentVideos = [...videos]
    .sort((a, b) => (b.publishedAt || '').localeCompare(a.publishedAt || ''))
    .slice(0, 10);

  const serializeVideo = (v: typeof videos[number]) => ({
    videoId: v.videoId,
    title: v.title,
    publishedAt: v.publishedAt,
    duration: v.durationLabel,
    formatType: v.formatType,
    views: v.viewCount,
    outlierRatio: v.outlierRatio,
    outlierClassification: v.outlierClassification,
    descriptionSnippet: v.description.slice(0, 260),
    tagsSample: v.tags.slice(0, 8),
    transcriptExcerpt: v.transcriptExcerpt ? v.transcriptExcerpt.slice(0, 420) : null,
  });

  return JSON.stringify(
    {
      channelProfile: {
        channelId: profile.channelId,
        title: profile.title,
        handle: profile.handle,
        country: profile.country,
        publishedAt: profile.publishedAt,
        subscribers: profile.hiddenSubscriberCount
          ? 'Hidden by creator'
          : profile.subscriberCount,
        totalChannelViews: profile.viewCount,
        totalChannelVideos: profile.videoCount,
        description: profile.description.slice(0, 800),
      },
      calculatedMetrics: {
        sampleSize: metrics.sampleSize,
        longFormCount: metrics.longFormCount,
        shortsCount: metrics.shortsCount,
        medianViewsOverall: metrics.medianViewsOverall,
        medianViewsLongForm: metrics.medianViewsLongForm,
        medianViewsShorts: metrics.medianViewsShorts,
        avgDurationLongForm: formatSecondsAsClock(metrics.avgDurationSecLongForm),
        avgDurationShorts: formatSecondsAsClock(metrics.avgDurationSecShorts),
        uploadsPerMonthEstimate: metrics.uploadsPerMonthEstimate,
        avgTitleLengthChars: metrics.avgTitleLength,
        titleQuestionPercent: metrics.titleQuestionPercent,
        titleNumberPercent: metrics.titleNumberPercent,
        topOpeningWords: metrics.topOpeningWords,
        topKeywords: metrics.topKeywords,
        strongOrExceptionalOutliersCount: metrics.strongOrExceptionalOutliersCount,
        transcriptsSampledCount: metrics.transcriptsSampledCount,
        retrievedAt: metrics.retrievedAt,
      },
      topOutlierVideos: topVideos.map(serializeVideo),
      recentSampleTitles: recentVideos.map((v) => ({
        title: v.title,
        views: v.viewCount,
        outlierRatio: v.outlierRatio,
        duration: v.durationLabel,
        formatType: v.formatType,
      })),
    },
    null,
    2
  );
}

const SINGLE_CHANNEL_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    module1ChannelDna: {
      type: Type.OBJECT,
      properties: {
        primaryNiche: { type: Type.STRING },
        subNiches: { type: Type.ARRAY, items: { type: Type.STRING } },
        microNiches: { type: Type.ARRAY, items: { type: Type.STRING } },
        coreCategories: { type: Type.ARRAY, items: { type: Type.STRING } },
        targetAudience: { type: Type.STRING },
        audienceProblemsAndDesires: { type: Type.ARRAY, items: { type: Type.STRING } },
        channelPositioning: { type: Type.STRING },
        valuePropositionAndPromise: { type: Type.STRING },
        uniqueCompetitiveAdvantage: { type: Type.STRING },
        creatorPersonalityAndTone: { type: Type.STRING },
      },
      required: [
        'primaryNiche',
        'subNiches',
        'microNiches',
        'coreCategories',
        'targetAudience',
        'audienceProblemsAndDesires',
        'channelPositioning',
        'valuePropositionAndPromise',
        'uniqueCompetitiveAdvantage',
        'creatorPersonalityAndTone',
      ],
    },
    module2ViralTopics: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          videoId: { type: Type.STRING },
          title: { type: Type.STRING },
          mainTopic: { type: Type.STRING },
          whyItMayHaveWorked: { type: Type.STRING },
          psychologicalTrigger: { type: Type.STRING },
          repeatableAngle: { type: Type.STRING },
        },
        required: [
          'videoId',
          'title',
          'mainTopic',
          'whyItMayHaveWorked',
          'psychologicalTrigger',
          'repeatableAngle',
        ],
      },
    },
    module3TitleIntelligence: {
      type: Type.OBJECT,
      properties: {
        observedTitleHabitsSummary: { type: Type.STRING },
        openingPatternNotes: { type: Type.ARRAY, items: { type: Type.STRING } },
        powerVerbsAndModifiers: { type: Type.ARRAY, items: { type: Type.STRING } },
        formulas: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              formulaName: { type: Type.STRING },
              template: { type: Type.STRING },
              competitorExample: { type: Type.STRING },
              psychologicalMechanism: { type: Type.STRING },
              contentCategory: { type: Type.STRING },
              originalAdaptation: { type: Type.STRING },
            },
            required: [
              'formulaName',
              'template',
              'competitorExample',
              'psychologicalMechanism',
              'contentCategory',
              'originalAdaptation',
            ],
          },
        },
        titleFormatBlueprint: { type: Type.STRING },
      },
      required: [
        'observedTitleHabitsSummary',
        'openingPatternNotes',
        'powerVerbsAndModifiers',
        'formulas',
        'titleFormatBlueprint',
      ],
    },
    module4ThumbnailIntelligence: {
      type: Type.OBJECT,
      properties: {
        observableVisualPatterns: { type: Type.ARRAY, items: { type: Type.STRING } },
        recurringStyles: { type: Type.ARRAY, items: { type: Type.STRING } },
        compositionAndTypography: { type: Type.STRING },
        colorAndContrastNotes: { type: Type.STRING },
        visualStorytellingMechanism: { type: Type.STRING },
        originalVisualOpportunities: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'observableVisualPatterns',
        'recurringStyles',
        'compositionAndTypography',
        'colorAndContrastNotes',
        'visualStorytellingMechanism',
        'originalVisualOpportunities',
      ],
    },
    module5VideoFormatIntelligence: {
      type: Type.OBJECT,
      properties: {
        observableFormatBreakdown: { type: Type.STRING },
        pacingAndStructuralObservations: { type: Type.STRING },
        narrationAndPresentationStyle: { type: Type.STRING },
        evidenceLimitationNote: { type: Type.STRING },
      },
      required: [
        'observableFormatBreakdown',
        'pacingAndStructuralObservations',
        'narrationAndPresentationStyle',
        'evidenceLimitationNote',
      ],
    },
    module6ContentStrategy: {
      type: Type.OBJECT,
      properties: {
        contentPillars: { type: Type.ARRAY, items: { type: Type.STRING } },
        topicClusters: { type: Type.ARRAY, items: { type: Type.STRING } },
        seriesFormats: { type: Type.ARRAY, items: { type: Type.STRING } },
        evergreenVsTrendMix: { type: Type.STRING },
        cadenceAndConsistencyAssessment: { type: Type.STRING },
        shortsVsLongFormRelationship: { type: Type.STRING },
        competitivePositioningSummary: { type: Type.STRING },
      },
      required: [
        'contentPillars',
        'topicClusters',
        'seriesFormats',
        'evergreenVsTrendMix',
        'cadenceAndConsistencyAssessment',
        'shortsVsLongFormRelationship',
        'competitivePositioningSummary',
      ],
    },
    module7HookAndStorytelling: {
      type: Type.OBJECT,
      properties: {
        transcriptEvidenceStatus: { type: Type.STRING },
        limitationNotice: { type: Type.STRING },
        openingHookPattern: { type: Type.STRING },
        contextAndCuriosityGap: { type: Type.STRING },
        commonBeliefOrContrast: { type: Type.STRING },
        proofAndPromiseHandling: { type: Type.STRING },
        openLoopsAndTransitions: { type: Type.STRING },
        payoffAndCtaStyle: { type: Type.STRING },
        reusableHookBlueprints: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: [
        'transcriptEvidenceStatus',
        'limitationNotice',
        'openingHookPattern',
        'contextAndCuriosityGap',
        'commonBeliefOrContrast',
        'proofAndPromiseHandling',
        'openLoopsAndTransitions',
        'payoffAndCtaStyle',
        'reusableHookBlueprints',
      ],
    },
    module8ProductionDna: {
      type: Type.OBJECT,
      properties: {
        observableProductionTraits: { type: Type.ARRAY, items: { type: Type.STRING } },
        unknownTechnicalDetails: { type: Type.ARRAY, items: { type: Type.STRING } },
        replicationGuidanceNote: { type: Type.STRING },
      },
      required: [
        'observableProductionTraits',
        'unknownTechnicalDetails',
        'replicationGuidanceNote',
      ],
    },
    module9MasterBlueprint: {
      type: Type.OBJECT,
      properties: {
        nichePrompt: { type: Type.STRING },
        positioningStatement: { type: Type.STRING },
        audienceProfile: { type: Type.STRING },
        channelPromise: { type: Type.STRING },
        contentPillars: { type: Type.ARRAY, items: { type: Type.STRING } },
        titleDnaRules: { type: Type.ARRAY, items: { type: Type.STRING } },
        thumbnailDnaRules: { type: Type.ARRAY, items: { type: Type.STRING } },
        formatDnaRules: { type: Type.ARRAY, items: { type: Type.STRING } },
        storytellingDnaRules: { type: Type.ARRAY, items: { type: Type.STRING } },
        publishingStrategy: { type: Type.STRING },
        productionDnaGuidelines: { type: Type.ARRAY, items: { type: Type.STRING } },
        differentiationStrategy: { type: Type.STRING },
        masterChannelPrompt: { type: Type.STRING },
      },
      required: [
        'nichePrompt',
        'positioningStatement',
        'audienceProfile',
        'channelPromise',
        'contentPillars',
        'titleDnaRules',
        'thumbnailDnaRules',
        'formatDnaRules',
        'storytellingDnaRules',
        'publishingStrategy',
        'productionDnaGuidelines',
        'differentiationStrategy',
        'masterChannelPrompt',
      ],
    },
  },
  required: [
    'module1ChannelDna',
    'module2ViralTopics',
    'module3TitleIntelligence',
    'module4ThumbnailIntelligence',
    'module5VideoFormatIntelligence',
    'module6ContentStrategy',
    'module7HookAndStorytelling',
    'module8ProductionDna',
    'module9MasterBlueprint',
  ],
};

export async function aiAnalyzeSingleChannel(
  collection: CompetitorChannelCollection,
  requestedModel?: string | null
): Promise<ChannelDeepDiveAnalysis> {
  const model = resolveModel(requestedModel);
  const evidenceJson = buildChannelEvidenceSummary(collection);

  const prompt = `Analyze this single YouTube competitor channel deeply across Modules 1 through 9.
Ground EVERY quantitative observation in the verified data below. For Module 7, transcriptsSampledCount is ${collection.metrics.transcriptsSampledCount}. ${
    collection.metrics.transcriptsSampledCount === 0
      ? 'Because NO public closed captions were exposed, set transcriptEvidenceStatus to "no_public_transcripts" and explicitly state in limitationNotice that spoken hook lines could not be verified directly.'
      : 'Use the brief structural transcriptExcerpt snippets only to infer opening hook & storytelling structure (do NOT quote long passages); set transcriptEvidenceStatus to "transcript_sampled".'
  }
In Module 3 formulas, provide 5 to 7 reusable structural formulas grounded in actual titles from the sample ("competitorExample" MUST be a real title from topOutlierVideos or recentSampleTitles), paired with an original adaptation ("originalAdaptation").
In Module 8 Production DNA, strictly place editing software, exact camera, microphone, or AI voice tools inside unknownTechnicalDetails unless explicitly stated in a video/channel description.

VERIFIED CHANNEL DATA:
${evidenceJson}`;

  type RawSingleResponse = Omit<
    ChannelDeepDiveAnalysis,
    'channelId' | 'channelTitle' | 'analyzedAt' | 'modelUsed'
  >;

  const result = await generateCompetitorJson<RawSingleResponse>({
    model,
    prompt,
    schema: SINGLE_CHANNEL_SCHEMA,
    label: `Channel Deep-Dive (${collection.profile.title})`,
  });

  return {
    channelId: collection.profile.channelId,
    channelTitle: collection.profile.title,
    analyzedAt: new Date().toISOString(),
    modelUsed: model,
    ...result,
    module7HookAndStorytelling: {
      ...result.module7HookAndStorytelling,
      transcriptEvidenceStatus:
        collection.metrics.transcriptsSampledCount > 0
          ? 'transcript_sampled'
          : 'no_public_transcripts',
    },
  };
}

const SYNTHESIS_SCHEMA: Schema = {
  type: Type.OBJECT,
  properties: {
    executiveSummary: { type: Type.STRING },
    nicheLandscapeComparison: { type: Type.STRING },
    crossChannelPatterns: { type: Type.ARRAY, items: { type: Type.STRING } },
    strategicDifferences: { type: Type.ARRAY, items: { type: Type.STRING } },
    module10ContentGaps: {
      type: Type.OBJECT,
      properties: {
        underservedTopics: { type: Type.ARRAY, items: { type: Type.STRING } },
        overcrowdedAnglesToAvoid: { type: Type.ARRAY, items: { type: Type.STRING } },
        whiteSpaceOpportunitiesSummary: { type: Type.STRING },
        videoOpportunities: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              topic: { type: Type.STRING },
              targetViewer: { type: Type.STRING },
              viewerProblem: { type: Type.STRING },
              uniqueAngle: { type: Type.STRING },
              whyOpportunityExists: { type: Type.STRING },
              suggestedTitle: { type: Type.STRING },
              thumbnailConcept: { type: Type.STRING },
              recommendedFormat: { type: Type.STRING },
              recommendedDurationMinutes: { type: Type.NUMBER },
              competitorContext: { type: Type.STRING },
            },
            required: [
              'id',
              'topic',
              'targetViewer',
              'viewerProblem',
              'uniqueAngle',
              'whyOpportunityExists',
              'suggestedTitle',
              'thumbnailConcept',
              'recommendedFormat',
              'recommendedDurationMinutes',
              'competitorContext',
            ],
          },
        },
      },
      required: [
        'underservedTopics',
        'overcrowdedAnglesToAvoid',
        'whiteSpaceOpportunitiesSummary',
        'videoOpportunities',
      ],
    },
    module11GrowthStrategy: {
      type: Type.OBJECT,
      properties: {
        ownChannelSummary: { type: Type.STRING },
        competitiveEdgeDiagnosis: { type: Type.STRING },
        growthBlueprint10Points: { type: Type.ARRAY, items: { type: Type.STRING } },
        thirtyDayContentPlan: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              dayRange: { type: Type.STRING },
              focus: { type: Type.STRING },
              actionableDeliverable: { type: Type.STRING },
              targetTopicOrFormat: { type: Type.STRING },
            },
            required: [
              'dayRange',
              'focus',
              'actionableDeliverable',
              'targetTopicOrFormat',
            ],
          },
        },
      },
      required: [
        'ownChannelSummary',
        'competitiveEdgeDiagnosis',
        'growthBlueprint10Points',
        'thirtyDayContentPlan',
      ],
    },
    report19Sections: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          number: { type: Type.STRING },
          title: { type: Type.STRING },
          epistemicLabel: { type: Type.STRING },
          summary: { type: Type.STRING },
          bulletPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['number', 'title', 'epistemicLabel', 'summary', 'bulletPoints'],
      },
    },
  },
  required: [
    'executiveSummary',
    'nicheLandscapeComparison',
    'crossChannelPatterns',
    'strategicDifferences',
    'module10ContentGaps',
    'module11GrowthStrategy',
    'report19Sections',
  ],
};

export async function aiSynthesizeCrossCompetitorReport(params: {
  collections: CompetitorChannelCollection[];
  channelAnalyses: ChannelDeepDiveAnalysis[];
  ownChannelCollection?: CompetitorChannelCollection | null;
  requestedModel?: string | null;
}): Promise<CrossCompetitorSynthesis> {
  const model = resolveModel(params.requestedModel);

  const channelSummaries = params.collections.map((col) => {
    const analysis = params.channelAnalyses.find((a) => a.channelId === col.profile.channelId);
    return {
      title: col.profile.title,
      channelId: col.profile.channelId,
      subscribers: col.profile.hiddenSubscriberCount
        ? 'Hidden'
        : formatCompactNumber(col.profile.subscriberCount),
      sampleSize: col.metrics.sampleSize,
      medianViewsOverall: col.metrics.medianViewsOverall,
      longFormCount: col.metrics.longFormCount,
      shortsCount: col.metrics.shortsCount,
      uploadsPerMonthEstimate: col.metrics.uploadsPerMonthEstimate,
      avgDurationLongForm: formatSecondsAsClock(col.metrics.avgDurationSecLongForm),
      strongOutliersCount: col.metrics.strongOrExceptionalOutliersCount,
      topOutlierTitles: [...col.videos]
        .sort((a, b) => (b.outlierRatio ?? 0) - (a.outlierRatio ?? 0))
        .slice(0, 4)
        .map((v) => `${v.title} (${v.outlierRatio ?? 'N/A'}x)`),
      dnaSummary: analysis
        ? {
            primaryNiche: analysis.module1ChannelDna.primaryNiche,
            positioning: analysis.module1ChannelDna.channelPositioning,
            pillars: analysis.module6ContentStrategy.contentPillars,
            titleFormulas: analysis.module3TitleIntelligence.formulas.map((f) => f.template),
            masterPrompt: analysis.module9MasterBlueprint.masterChannelPrompt,
          }
        : null,
    };
  });

  const ownSummary = params.ownChannelCollection
    ? {
        title: params.ownChannelCollection.profile.title,
        subscribers: params.ownChannelCollection.profile.hiddenSubscriberCount
          ? 'Hidden'
          : params.ownChannelCollection.profile.subscriberCount,
        medianViewsOverall: params.ownChannelCollection.metrics.medianViewsOverall,
        longFormCount: params.ownChannelCollection.metrics.longFormCount,
        shortsCount: params.ownChannelCollection.metrics.shortsCount,
        uploadsPerMonthEstimate: params.ownChannelCollection.metrics.uploadsPerMonthEstimate,
        recentTitles: params.ownChannelCollection.videos.slice(0, 8).map((v) => v.title),
      }
    : null;

  const prompt = `Synthesize a comprehensive cross-competitor intelligence report across ${params.collections.length} analyzed competitor YouTube channels${ownSummary ? ` AND compare them against the user's own channel (${ownSummary.title})` : ''}.

Requirements:
1. Module 10 Content Gaps: Provide EXACTLY 10 original videoOpportunities (numbered id "opp-1" .. "opp-10") designed to beat competitors through clarity, depth, fresher framing, or underserved viewer needs (NOT copying competitors). Include realistic recommendedDurationMinutes (e.g. 10, 14, 1, 18).
2. Module 11 Personalized Growth Strategy: Provide a crisp 10-point growthBlueprint10Points array AND a 4-week / 30-day thirtyDayContentPlan (at least 6 concrete dayRange milestones covering Days 1-30). ${ownSummary ? 'Explicitly benchmark the user channel stats & topics against these competitors.' : 'Tailor the blueprint cleanly for a creator entering or competing in this niche.'}
3. report19Sections: Generate ALL 19 numbered sections in exact order ("01" to "19"):
   01. Executive Summary (inferred)
   02. Competitor Overview (observed)
   03. Niche & Audience Breakdown (inferred)
   04. Viral Topics & Outlier Analysis (calculated)
   05. Complete Title Intelligence (calculated)
   06. Thumbnail Intelligence (observed)
   07. Video Format Intelligence (calculated)
   08. Content Strategy (inferred)
   09. Hook & Storytelling Framework (inferred)
   10. Production Style Analysis (observed)
   11. Competitor Comparison Dashboard (calculated)
   12. Niche Prompt (inferred)
   13. Title Prompts & Templates (inferred)
   14. Thumbnail Design Guidelines (inferred)
   15. Video Format Blueprint (inferred)
   16. Master Channel Blueprint Prompt (inferred)
   17. Content Gap Finder (inferred)
   18. 10 Original Video Opportunities (inferred)
   19. Personalized Growth Strategy & 30-Day Content Plan (inferred)

COMPETITOR SUMMARIES:
${JSON.stringify(channelSummaries, null, 2)}

USER OWN CHANNEL (${ownSummary ? 'PROVIDED' : 'NOT PROVIDED'}):
${ownSummary ? JSON.stringify(ownSummary, null, 2) : 'None provided'}`;

  type RawSynthesisResponse = Omit<CrossCompetitorSynthesis, 'synthesizedAt' | 'modelUsed'> & {
    module11GrowthStrategy: Omit<
      CrossCompetitorSynthesis['module11GrowthStrategy'],
      'hasOwnChannelComparison'
    >;
  };

  const result = await generateCompetitorJson<RawSynthesisResponse>({
    model,
    prompt,
    schema: SYNTHESIS_SCHEMA,
    label: 'Cross-Competitor Report Synthesis',
  });

  const normalizedSections = (result.report19Sections || []).map((sec, idx) => ({
    ...sec,
    number: String(idx + 1).padStart(2, '0'),
    epistemicLabel: (['observed', 'calculated', 'inferred', 'unknown'].includes(sec.epistemicLabel)
      ? sec.epistemicLabel
      : 'inferred') as 'observed' | 'calculated' | 'inferred' | 'unknown',
  }));

  return {
    synthesizedAt: new Date().toISOString(),
    modelUsed: model,
    executiveSummary: result.executiveSummary,
    nicheLandscapeComparison: result.nicheLandscapeComparison,
    crossChannelPatterns: result.crossChannelPatterns || [],
    strategicDifferences: result.strategicDifferences || [],
    module10ContentGaps: {
      ...result.module10ContentGaps,
      videoOpportunities: (result.module10ContentGaps?.videoOpportunities || []).map((opp, i) => ({
        ...opp,
        id: opp.id || `opp-${i + 1}`,
        recommendedDurationMinutes: Math.max(1, Math.min(90, Math.round(opp.recommendedDurationMinutes || 10))),
      })),
    },
    module11GrowthStrategy: {
      ...result.module11GrowthStrategy,
      hasOwnChannelComparison: Boolean(ownSummary),
    },
    report19Sections: normalizedSections,
  };
}
