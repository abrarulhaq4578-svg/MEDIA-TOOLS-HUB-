import fs from 'node:fs/promises';
import type express from 'express';
import { and, desc, eq } from 'drizzle-orm';
import { OAuth2Client, type Credentials } from 'google-auth-library';
import { db } from '../../db/index.ts';
import {
  ytmAnalyticsSnapshots,
  ytmConnectedAccounts,
  ytmOAuthTokens,
} from '../../db/schema.ts';
import {
  CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI,
  getGoogleOAuthConfig,
  getServerConfig,
  getYtmOAuthConfigStatus,
  isPlaceholderSentinel,
} from '../config/env.ts';
import type {
  YtmChannelAnalyticsReport,
  YtmConnectedChannelRecord,
  YtmOAuthConfigValidation,
  YtmOAuthCredentialDiagnostics,
} from '../../shared/types.ts';
import {
  validateGoogleOAuthAuthorizationUrl,
  YTM_OAUTH_CALLBACK_PATH,
} from '../../shared/ytmHelpers.ts';
import { decryptOAuthTokens, encryptOAuthTokens } from './ytmCrypto.ts';

export const YOUTUBE_OAUTH_SCOPES = [
  'https://www.googleapis.com/auth/youtube.readonly',
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/yt-analytics.readonly',
  'https://www.googleapis.com/auth/yt-analytics-monetary.readonly',
  'https://www.googleapis.com/auth/youtube.force-ssl',
];

export class YtmOAuthError extends Error {
  statusCode: number;
  code: string;
  diagnostics?: YtmOAuthCredentialDiagnostics;

  constructor(
    message: string,
    statusCode = 400,
    code = 'OAUTH_ERROR',
    diagnostics?: YtmOAuthCredentialDiagnostics
  ) {
    super(message);
    this.name = 'YtmOAuthError';
    this.statusCode = statusCode;
    this.code = code;
    this.diagnostics = diagnostics;
  }
}

export interface GoogleOAuthUrlDiagnostics {
  hostname: string;
  pathname: string;
  queryParamNames: string[];
  source: YtmOAuthCredentialDiagnostics['source'];
  dotenvFilePresent: boolean;
  frontendEnvOverridePresent: boolean;
  clientIdPresent: boolean;
  clientIdLength: number;
  rawClientIdLength: number;
  rawClientIdHasWhitespace: boolean;
  rawClientIdHasQuotes: boolean;
  clientIdEndsWithAppsDomain: boolean;
  clientIdFormatValid: boolean;
  clientIdMatchesConfiguredParam: boolean;
  clientSecretPresent: boolean;
  clientSecretLength: number;
  clientSecretFormatValid: boolean;
  oauthClientInitialized: boolean;
  authorizationUrlReady: boolean;
  redirectUri: string;
  redirectUriMatchesConfigured: boolean;
}

export function createGoogleOAuth2Client(params: {
  clientId?: string | null;
  clientSecret?: string | null;
  redirectUri?: string | null;
}): OAuth2Client {
  return new OAuth2Client({
    clientId: params.clientId || undefined,
    clientSecret: params.clientSecret || undefined,
    redirectUri: params.redirectUri || undefined,
  });
}

export function normalizeOAuthRedirectUri(rawUri: string): string | null {
  try {
    const parsed = new URL(rawUri.trim());
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
    const cleanPath = parsed.pathname.replace(/\/+$/, '');
    if (!cleanPath || cleanPath === '') {
      parsed.pathname = YTM_OAUTH_CALLBACK_PATH;
    } else {
      parsed.pathname = cleanPath;
    }
    parsed.search = '';
    parsed.hash = '';
    return parsed.toString();
  } catch {
    return null;
  }
}

export function resolveOAuthRedirectUri(
  req?: Pick<express.Request, 'get'>,
  env: NodeJS.ProcessEnv = process.env
): string {
  const cfg = getServerConfig(env);
  if (cfg.googleRedirectUri) {
    const normalized = normalizeOAuthRedirectUri(cfg.googleRedirectUri);
    if (normalized) {
      return normalized;
    }
  }
  const appUrl = env.APP_URL?.trim();
  if (appUrl && !isPlaceholderSentinel(appUrl)) {
    const normalized = normalizeOAuthRedirectUri(
      `${appUrl.replace(/\/+$/, '')}${YTM_OAUTH_CALLBACK_PATH}`
    );
    if (normalized) return normalized;
  }

  // Only allow request Host header derivation in local development for explicit loopback hosts.
  // Never blindly trust arbitrary x-forwarded-host / x-forwarded-proto headers for OAuth redirects.
  if (env.NODE_ENV !== 'production' && req) {
    const rawHost = (req.get('host') || '').split(',')[0].trim();
    if (/^(localhost|127\.0\.0\.1)(:\d{2,5})?$/i.test(rawHost)) {
      return `http://${rawHost}${YTM_OAUTH_CALLBACK_PATH}`;
    }
  }

  return CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI;
}

export function buildValidatedGoogleOAuthAuthorizationUrl(params: {
  redirectUri: string;
  state: string;
  env?: NodeJS.ProcessEnv;
}): {
  authorizationUrl: string;
  diagnostics: GoogleOAuthUrlDiagnostics;
  credentialDiagnostics: YtmOAuthCredentialDiagnostics;
} {
  const env = params.env || process.env;
  const normalizedRedirect = normalizeOAuthRedirectUri(params.redirectUri);
  const oauthConfig = getGoogleOAuthConfig(env, normalizedRedirect || params.redirectUri);
  const credentialDiagnostics = oauthConfig.diagnostics;

  if (!oauthConfig.clientId || !oauthConfig.clientSecret) {
    throw new YtmOAuthError(
      credentialDiagnostics.clientIdIsPlaceholderLiteral ||
        credentialDiagnostics.clientSecretIsPlaceholderLiteral
        ? 'Google OAuth environment variables still contain placeholder sentinel values instead of real OAuth credentials.'
        : 'Google OAuth is not configured on the server. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.',
      400,
      'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      credentialDiagnostics
    );
  }

  if (!credentialDiagnostics.clientIdFormatValid) {
    throw new YtmOAuthError(
      credentialDiagnostics.clientIdIssueMessage,
      400,
      'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      credentialDiagnostics
    );
  }

  if (!credentialDiagnostics.clientSecretFormatValid) {
    throw new YtmOAuthError(
      credentialDiagnostics.clientSecretIssueMessage,
      400,
      'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      credentialDiagnostics
    );
  }

  if (!normalizedRedirect) {
    throw new YtmOAuthError(
      'Configured OAuth redirect_uri is invalid.',
      400,
      'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      credentialDiagnostics
    );
  }

  const oauth2Client = createGoogleOAuth2Client({
    clientId: oauthConfig.clientId,
    clientSecret: oauthConfig.clientSecret,
    redirectUri: normalizedRedirect,
  });

  const rawGeneratedUrl = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    include_granted_scopes: true,
    prompt: 'consent',
    scope: YOUTUBE_OAUTH_SCOPES,
    state: params.state,
    redirect_uri: normalizedRedirect,
  });

  const authorizationUrl = validateGoogleOAuthAuthorizationUrl(rawGeneratedUrl);
  const parsed = new URL(authorizationUrl);

  const cfg = getServerConfig(env);
  const appUrl = env.APP_URL?.trim();
  const expectedAppCallback =
    appUrl && !isPlaceholderSentinel(appUrl)
      ? normalizeOAuthRedirectUri(`${appUrl.replace(/\/+$/, '')}${YTM_OAUTH_CALLBACK_PATH}`)
      : null;
  const configuredOverride = cfg.googleRedirectUri
    ? normalizeOAuthRedirectUri(cfg.googleRedirectUri)
    : null;

  const clientIdMatchesConfiguredParam = parsed.searchParams.get('client_id') === oauthConfig.clientId;

  credentialDiagnostics.oauthClientInitialized = true;
  credentialDiagnostics.authorizationUrlReady = true;

  const diagnostics: GoogleOAuthUrlDiagnostics = {
    hostname: parsed.hostname,
    pathname: parsed.pathname,
    queryParamNames: Array.from(parsed.searchParams.keys()),
    source: credentialDiagnostics.source,
    dotenvFilePresent: credentialDiagnostics.dotenvFilePresent,
    frontendEnvOverridePresent: credentialDiagnostics.frontendEnvOverridePresent,
    clientIdPresent: credentialDiagnostics.clientIdPresent,
    clientIdLength: credentialDiagnostics.clientIdLength,
    rawClientIdLength: credentialDiagnostics.rawClientIdLength ?? credentialDiagnostics.clientIdLength,
    rawClientIdHasWhitespace: Boolean(credentialDiagnostics.rawClientIdHasWhitespace ?? credentialDiagnostics.clientIdHasWhitespace),
    rawClientIdHasQuotes: Boolean(credentialDiagnostics.rawClientIdHasQuotes ?? credentialDiagnostics.clientIdHasQuotes),
    clientIdEndsWithAppsDomain: credentialDiagnostics.clientIdEndsWithAppsDomain,
    clientIdFormatValid: credentialDiagnostics.clientIdFormatValid,
    clientIdMatchesConfiguredParam,
    clientSecretPresent: credentialDiagnostics.clientSecretPresent,
    clientSecretLength: credentialDiagnostics.clientSecretLength,
    clientSecretFormatValid: credentialDiagnostics.clientSecretFormatValid,
    oauthClientInitialized: true,
    authorizationUrlReady: true,
    redirectUri: normalizedRedirect,
    redirectUriMatchesConfigured: configuredOverride
      ? configuredOverride === normalizedRedirect
      : expectedAppCallback
        ? expectedAppCallback === normalizedRedirect
        : true,
  };

  console.info('[YTM OAuth] Authorization URL generated:', JSON.stringify(diagnostics));

  return {
    authorizationUrl,
    diagnostics,
    credentialDiagnostics,
  };
}

export async function verifyGoogleOAuthClientWithGoogle(
  authorizationUrl: string
): Promise<{
  status:
    | 'valid_client_recognized'
    | 'invalid_client'
    | 'redirect_uri_mismatch'
    | 'unreachable';
  message: string;
}> {
  try {
    const res = await fetch(authorizationUrl, {
      method: 'GET',
      redirect: 'follow',
      signal: AbortSignal.timeout(4000),
    });
    const finalUrl = res.url || '';
    const body = await res.text();
    const combined = `${finalUrl}\n${body}`;

    if (/invalid_client|deleted_client|The OAuth client was not found/i.test(combined)) {
      return {
        status: 'invalid_client',
        message:
          'Google returned 401 invalid_client (The OAuth client was not found). Check that GOOGLE_CLIENT_ID in your server environment is an active Web application OAuth 2.0 Client ID from your Google Cloud project and redeploy/restart the server.',
      };
    }

    if (/redirect_uri_mismatch/i.test(combined)) {
      return {
        status: 'redirect_uri_mismatch',
        message:
          'Google recognized the Client ID, but returned redirect_uri_mismatch. Verify Authorized redirect URIs in Google Cloud Console includes the exact callback URL.',
      };
    }

    return {
      status: 'valid_client_recognized',
      message:
        'Google OAuth endpoint recognized the configured Client ID and accepted the redirect URI.',
    };
  } catch {
    return {
      status: 'unreachable',
      message: 'Unable to reach Google OAuth endpoint for preflight verification.',
    };
  }
}

export async function buildYtmOAuthConfigValidation(params: {
  redirectUri: string;
  env?: NodeJS.ProcessEnv;
  probeGoogleEndpoint?: boolean;
}): Promise<YtmOAuthConfigValidation> {
  const env = params.env || process.env;
  const oauthStatus = getYtmOAuthConfigStatus(env);
  const normalizedRedirect = normalizeOAuthRedirectUri(params.redirectUri);
  const redirectUriValid = Boolean(normalizedRedirect);
  const oauthConfig = getGoogleOAuthConfig(env, normalizedRedirect || params.redirectUri);
  const issues = [...oauthConfig.diagnostics.issues];
  if (!redirectUriValid && !issues.includes('invalid_redirect_uri')) {
    issues.push('invalid_redirect_uri');
  }
  const diag: YtmOAuthCredentialDiagnostics = {
    ...oauthConfig.diagnostics,
    redirectUri: normalizedRedirect || params.redirectUri,
    redirectUriValid,
    issues,
    oauthClientInitialized: false,
    authorizationUrlReady: false,
  };

  if (!oauthStatus.configured) {
    diag.oauthConfigured = false;
    return {
      valid: false,
      oauthConfigured: false,
      clientIdPresent: diag.clientIdPresent,
      clientIdFormatValid: diag.clientIdFormatValid,
      clientSecretPresent: diag.clientSecretPresent,
      clientSecretFormatValid: diag.clientSecretFormatValid,
      oauthClientInitialized: false,
      redirectUriValid,
      authorizationUrlReady: false,
      issues: diag.issues,
      code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      message: 'Google OAuth client credentials are not configured on the server yet.',
      details:
        diag.clientIdIsPlaceholderLiteral || diag.clientSecretIsPlaceholderLiteral
          ? `Server process.env currently has placeholder sentinel values for ${oauthStatus.missingVars.join(', ')}. Set real Google Cloud Web OAuth credentials in your runtime environment.`
          : `Missing required environment variable(s): ${oauthStatus.missingVars.join(', ')}.`,
      missingVars: oauthStatus.missingVars,
      redirectUri: normalizedRedirect || params.redirectUri,
      hasClientId: oauthStatus.hasClientId,
      hasClientSecret: oauthStatus.hasClientSecret,
      hasEncryptionKey: oauthStatus.hasEncryptionKey,
      diagnostics: diag,
    };
  }

  if (!diag.clientIdFormatValid || !diag.clientSecretFormatValid || !redirectUriValid) {
    diag.oauthConfigured = false;
    const details = !diag.clientIdFormatValid
      ? diag.clientIdIssueMessage
      : !diag.clientSecretFormatValid
        ? diag.clientSecretIssueMessage
        : 'Resolved OAuth redirect URI is invalid.';
    return {
      valid: false,
      oauthConfigured: false,
      clientIdPresent: diag.clientIdPresent,
      clientIdFormatValid: diag.clientIdFormatValid,
      clientSecretPresent: diag.clientSecretPresent,
      clientSecretFormatValid: diag.clientSecretFormatValid,
      oauthClientInitialized: false,
      redirectUriValid,
      authorizationUrlReady: false,
      issues: diag.issues,
      code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      message: 'Configured Google OAuth credentials failed structural validation.',
      details,
      missingVars: [],
      redirectUri: normalizedRedirect || params.redirectUri,
      hasClientId: oauthStatus.hasClientId,
      hasClientSecret: oauthStatus.hasClientSecret,
      hasEncryptionKey: oauthStatus.hasEncryptionKey,
      diagnostics: diag,
    };
  }

  let probeAuthUrl = '';
  try {
    const built = buildValidatedGoogleOAuthAuthorizationUrl({
      redirectUri: normalizedRedirect || params.redirectUri,
      state: 'diag_preflight_probe',
      env,
    });
    probeAuthUrl = built.authorizationUrl;
    diag.oauthClientInitialized = true;
    diag.authorizationUrlReady = true;
  } catch (err) {
    diag.oauthConfigured = false;
    if (!diag.issues.includes('oauth_client_init_failed')) {
      diag.issues.push('oauth_client_init_failed');
    }
    return {
      valid: false,
      oauthConfigured: false,
      clientIdPresent: diag.clientIdPresent,
      clientIdFormatValid: diag.clientIdFormatValid,
      clientSecretPresent: diag.clientSecretPresent,
      clientSecretFormatValid: diag.clientSecretFormatValid,
      oauthClientInitialized: false,
      redirectUriValid,
      authorizationUrlReady: false,
      issues: diag.issues,
      code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
      message: 'Unable to initialize Google OAuth2Client authorization URL.',
      details: err instanceof Error ? err.message : 'OAuth validation error.',
      missingVars: [],
      redirectUri: normalizedRedirect || params.redirectUri,
      hasClientId: oauthStatus.hasClientId,
      hasClientSecret: oauthStatus.hasClientSecret,
      hasEncryptionKey: oauthStatus.hasEncryptionKey,
      diagnostics: diag,
    };
  }

  if (params.probeGoogleEndpoint) {
    const probe = await verifyGoogleOAuthClientWithGoogle(probeAuthUrl);
    diag.googleEndpointCheck = probe.status;
    diag.googleEndpointMessage = probe.message;

    if (probe.status === 'invalid_client') {
      diag.oauthConfigured = false;
      if (!diag.issues.includes('google_invalid_client')) {
        diag.issues.push('google_invalid_client');
      }
      return {
        valid: false,
        oauthConfigured: false,
        clientIdPresent: diag.clientIdPresent,
        clientIdFormatValid: diag.clientIdFormatValid,
        clientSecretPresent: diag.clientSecretPresent,
        clientSecretFormatValid: diag.clientSecretFormatValid,
        oauthClientInitialized: diag.oauthClientInitialized,
        redirectUriValid,
        authorizationUrlReady: false,
        issues: diag.issues,
        code: 'OAUTH_INVALID_CLIENT',
        message: 'Google OAuth returned 401 invalid_client (The OAuth client was not found).',
        details: probe.message,
        missingVars: [],
        redirectUri: normalizedRedirect || params.redirectUri,
        hasClientId: oauthStatus.hasClientId,
        hasClientSecret: oauthStatus.hasClientSecret,
        hasEncryptionKey: oauthStatus.hasEncryptionKey,
        diagnostics: diag,
      };
    }

    if (probe.status === 'redirect_uri_mismatch') {
      diag.oauthConfigured = false;
      if (!diag.issues.includes('redirect_uri_mismatch')) {
        diag.issues.push('redirect_uri_mismatch');
      }
      return {
        valid: false,
        oauthConfigured: false,
        clientIdPresent: diag.clientIdPresent,
        clientIdFormatValid: diag.clientIdFormatValid,
        clientSecretPresent: diag.clientSecretPresent,
        clientSecretFormatValid: diag.clientSecretFormatValid,
        oauthClientInitialized: diag.oauthClientInitialized,
        redirectUriValid,
        authorizationUrlReady: false,
        issues: diag.issues,
        code: 'GOOGLE_OAUTH_CONFIGURATION_INVALID',
        message: 'Google OAuth reported redirect_uri_mismatch.',
        details: probe.message,
        missingVars: [],
        redirectUri: normalizedRedirect || params.redirectUri,
        hasClientId: oauthStatus.hasClientId,
        hasClientSecret: oauthStatus.hasClientSecret,
        hasEncryptionKey: oauthStatus.hasEncryptionKey,
        diagnostics: diag,
      };
    }
  }

  diag.oauthConfigured = true;
  return {
    valid: true,
    oauthConfigured: true,
    clientIdPresent: diag.clientIdPresent,
    clientIdFormatValid: diag.clientIdFormatValid,
    clientSecretPresent: diag.clientSecretPresent,
    clientSecretFormatValid: diag.clientSecretFormatValid,
    oauthClientInitialized: diag.oauthClientInitialized,
    redirectUriValid,
    authorizationUrlReady: diag.authorizationUrlReady,
    issues: diag.issues,
    code: null,
    message: 'Google OAuth 2.0 credentials are configured and formatted cleanly.',
    details: 'Server environment holds valid Web application OAuth credentials.',
    missingVars: [],
    redirectUri: normalizedRedirect || params.redirectUri,
    hasClientId: oauthStatus.hasClientId,
    hasClientSecret: oauthStatus.hasClientSecret,
    hasEncryptionKey: oauthStatus.hasEncryptionKey,
    diagnostics: diag,
  };
}

export function buildGoogleOAuthUrl(params: {
  redirectUri: string;
  state: string;
}): string {
  return buildValidatedGoogleOAuthAuthorizationUrl(params).authorizationUrl;
}

export function hydrateConnectedChannel(
  row: typeof ytmConnectedAccounts.$inferSelect
): YtmConnectedChannelRecord {
  let scopes: string[] = [];
  try {
    scopes = JSON.parse(row.scopesJson) as string[];
  } catch {
    scopes = [];
  }
  return {
    id: row.id,
    workspaceId: row.workspaceId,
    provider: row.provider,
    channelId: row.channelId,
    channelTitle: row.channelTitle,
    channelHandle: row.channelHandle || null,
    thumbnailUrl: row.thumbnailUrl || null,
    subscriberCount: row.subscriberCount ?? null,
    videoCount: row.videoCount ?? null,
    viewCount: row.viewCount ?? null,
    scopes,
    connectionStatus: row.connectionStatus,
    lastSyncedAt: row.lastSyncedAt.toISOString(),
  };
}

export async function getWorkspaceConnectedChannel(
  workspaceId: number
): Promise<YtmConnectedChannelRecord | null> {
  const rows = await db
    .select()
    .from(ytmConnectedAccounts)
    .where(
      and(
        eq(ytmConnectedAccounts.workspaceId, workspaceId),
        eq(ytmConnectedAccounts.connectionStatus, 'connected')
      )
    )
    .orderBy(desc(ytmConnectedAccounts.updatedAt))
    .limit(1);

  return rows[0] ? hydrateConnectedChannel(rows[0]) : null;
}

export async function exchangeCodeAndStoreYouTubeChannel(params: {
  code: string;
  redirectUri: string;
  workspaceId: number;
  userId: number;
}): Promise<YtmConnectedChannelRecord> {
  const cfg = getServerConfig();
  if (!cfg.googleClientId || !cfg.googleClientSecret) {
    throw new YtmOAuthError(
      'Google OAuth credentials are missing on the server.',
      422,
      'OAUTH_NOT_CONFIGURED'
    );
  }

  const oauth2Client = createGoogleOAuth2Client({
    clientId: cfg.googleClientId,
    clientSecret: cfg.googleClientSecret,
    redirectUri: params.redirectUri,
  });

  let tokenData: Credentials;
  try {
    const tokenRes = await oauth2Client.getToken({
      code: params.code,
      redirect_uri: params.redirectUri,
    });
    tokenData = tokenRes.tokens;
  } catch (err: unknown) {
    const gaxiosData = (
      err as { response?: { data?: { error?: string; error_description?: string } } }
    )?.response?.data;
    const message =
      gaxiosData?.error_description ||
      gaxiosData?.error ||
      (err instanceof Error ? err.message : 'Failed to exchange Google OAuth authorization code.');
    throw new YtmOAuthError(message, 400, 'TOKEN_EXCHANGE_FAILED');
  }

  if (!tokenData.access_token) {
    throw new YtmOAuthError(
      'Google OAuth token exchange did not return an access_token.',
      400,
      'TOKEN_EXCHANGE_FAILED'
    );
  }

  // Fetch authenticated user's own YouTube channel profile
  const chRes = await fetch(
    'https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true',
    {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    }
  );
  const chJson = (await chRes.json().catch(() => ({}))) as {
    items?: Array<{
      id: string;
      snippet?: {
        title?: string;
        customUrl?: string;
        thumbnails?: { high?: { url?: string }; default?: { url?: string } };
      };
      statistics?: {
        subscriberCount?: string;
        videoCount?: string;
        viewCount?: string;
      };
    }>;
    error?: { message?: string };
  };

  if (!chRes.ok) {
    throw new YtmOAuthError(
      chJson.error?.message || 'Unable to read YouTube channel profile for the authorized Google account.',
      400,
      'YOUTUBE_PROFILE_FETCH_FAILED'
    );
  }

  const ch = chJson.items?.[0];
  if (!ch) {
    throw new YtmOAuthError(
      'This Google account does not have an active YouTube channel. Create or select a YouTube channel in YouTube Studio first.',
      404,
      'NO_YOUTUBE_CHANNEL'
    );
  }

  // Preserve any existing refresh_token for this workspace+channel if Google omitted refresh_token on re-auth
  let preservedRefreshToken: string | undefined = tokenData.refresh_token || undefined;
  if (!preservedRefreshToken) {
    try {
      const priorAccounts = await db
        .select()
        .from(ytmConnectedAccounts)
        .where(
          and(
            eq(ytmConnectedAccounts.workspaceId, params.workspaceId),
            eq(ytmConnectedAccounts.channelId, ch.id)
          )
        )
        .orderBy(desc(ytmConnectedAccounts.updatedAt))
        .limit(5);

      for (const acc of priorAccounts) {
        const tokRows = await db
          .select()
          .from(ytmOAuthTokens)
          .where(eq(ytmOAuthTokens.connectedAccountId, acc.id))
          .limit(1);
        if (tokRows[0]) {
          const dec = decryptOAuthTokens(tokRows[0]);
          if (dec.refreshToken) {
            preservedRefreshToken = dec.refreshToken;
            break;
          }
        }
      }
    } catch {
      // Non-fatal fallback; keep undefined if prior token cannot be decrypted
    }
  }

  const scopes = (tokenData.scope || '').split(/\s+/).filter(Boolean);
  const expiryDate =
    tokenData.expiry_date && Number.isFinite(tokenData.expiry_date)
      ? new Date(tokenData.expiry_date)
      : new Date(Date.now() + 3500 * 1000);
  const encrypted = encryptOAuthTokens(tokenData.access_token, preservedRefreshToken);

  // Deactivate previous connections in this workspace so one active primary channel is tracked
  await db
    .update(ytmConnectedAccounts)
    .set({ connectionStatus: 'disconnected', updatedAt: new Date() })
    .where(eq(ytmConnectedAccounts.workspaceId, params.workspaceId));

  const inserted = await db
    .insert(ytmConnectedAccounts)
    .values({
      workspaceId: params.workspaceId,
      userId: params.userId,
      provider: 'google_youtube',
      channelId: ch.id,
      channelTitle: ch.snippet?.title || 'Connected YouTube Channel',
      channelHandle: ch.snippet?.customUrl || null,
      thumbnailUrl:
        ch.snippet?.thumbnails?.high?.url || ch.snippet?.thumbnails?.default?.url || null,
      subscriberCount: ch.statistics?.subscriberCount
        ? Number.parseInt(ch.statistics.subscriberCount, 10)
        : null,
      videoCount: ch.statistics?.videoCount
        ? Number.parseInt(ch.statistics.videoCount, 10)
        : null,
      viewCount: ch.statistics?.viewCount || null,
      scopesJson: JSON.stringify(scopes),
      connectionStatus: 'connected',
      lastSyncedAt: new Date(),
    })
    .returning();

  await db.insert(ytmOAuthTokens).values({
    connectedAccountId: inserted[0].id,
    encryptedAccessToken: encrypted.encryptedAccessToken,
    encryptedRefreshToken: encrypted.encryptedRefreshToken,
    iv: encrypted.iv,
    authTag: encrypted.authTag,
    expiryDate,
    tokenType: tokenData.token_type || 'Bearer',
  });

  return hydrateConnectedChannel(inserted[0]);
}

export async function getValidWorkspaceAccessToken(workspaceId: number): Promise<{
  accessToken: string;
  channel: YtmConnectedChannelRecord;
}> {
  const oauthStatus = getYtmOAuthConfigStatus();
  if (!oauthStatus.configured) {
    throw new YtmOAuthError(
      'Google OAuth is not configured on the server.',
      422,
      'OAUTH_NOT_CONFIGURED'
    );
  }

  const accounts = await db
    .select()
    .from(ytmConnectedAccounts)
    .where(
      and(
        eq(ytmConnectedAccounts.workspaceId, workspaceId),
        eq(ytmConnectedAccounts.connectionStatus, 'connected')
      )
    )
    .orderBy(desc(ytmConnectedAccounts.updatedAt))
    .limit(1);

  if (!accounts[0]) {
    throw new YtmOAuthError(
      'No YouTube channel is connected to this workspace. Connect your channel first.',
      400,
      'CHANNEL_NOT_CONNECTED'
    );
  }

  const tokenRows = await db
    .select()
    .from(ytmOAuthTokens)
    .where(eq(ytmOAuthTokens.connectedAccountId, accounts[0].id))
    .limit(1);

  if (!tokenRows[0]) {
    throw new YtmOAuthError(
      'Stored OAuth token record is missing. Reconnect your YouTube channel.',
      401,
      'TOKEN_MISSING'
    );
  }

  const decrypted = decryptOAuthTokens(tokenRows[0]);
  const isExpired =
    !tokenRows[0].expiryDate || tokenRows[0].expiryDate.getTime() < Date.now() + 90_000;

  if (!isExpired && decrypted.accessToken) {
    return {
      accessToken: decrypted.accessToken,
      channel: hydrateConnectedChannel(accounts[0]),
    };
  }

  if (!decrypted.refreshToken) {
    throw new YtmOAuthError(
      'OAuth session expired and no refresh token is available. Please reconnect your YouTube channel.',
      401,
      'TOKEN_EXPIRED'
    );
  }

  const cfg = getServerConfig();
  const oauth2Client = createGoogleOAuth2Client({
    clientId: cfg.googleClientId!,
    clientSecret: cfg.googleClientSecret!,
    redirectUri: cfg.googleRedirectUri || undefined,
  });
  oauth2Client.setCredentials({
    access_token: decrypted.accessToken || undefined,
    refresh_token: decrypted.refreshToken,
  });

  let refreshedCreds: Credentials;
  try {
    const refreshRes = await oauth2Client.refreshAccessToken();
    refreshedCreds = refreshRes.credentials;
  } catch (err: unknown) {
    await db
      .update(ytmConnectedAccounts)
      .set({ connectionStatus: 'reconnect_required', updatedAt: new Date() })
      .where(eq(ytmConnectedAccounts.id, accounts[0].id));
    throw new YtmOAuthError(
      err instanceof Error
        ? err.message
        : 'Unable to refresh YouTube access token. Please reconnect your channel.',
      401,
      'TOKEN_REFRESH_FAILED'
    );
  }

  if (!refreshedCreds.access_token) {
    await db
      .update(ytmConnectedAccounts)
      .set({ connectionStatus: 'reconnect_required', updatedAt: new Date() })
      .where(eq(ytmConnectedAccounts.id, accounts[0].id));
    throw new YtmOAuthError(
      'Unable to refresh YouTube access token. Please reconnect your channel.',
      401,
      'TOKEN_REFRESH_FAILED'
    );
  }

  const nextRefreshToken = refreshedCreds.refresh_token || decrypted.refreshToken;
  const reEncrypted = encryptOAuthTokens(refreshedCreds.access_token, nextRefreshToken);
  const newExpiry =
    refreshedCreds.expiry_date && Number.isFinite(refreshedCreds.expiry_date)
      ? new Date(refreshedCreds.expiry_date)
      : new Date(Date.now() + 3500 * 1000);
  await db
    .update(ytmOAuthTokens)
    .set({
      encryptedAccessToken: reEncrypted.encryptedAccessToken,
      encryptedRefreshToken: reEncrypted.encryptedRefreshToken,
      iv: reEncrypted.iv,
      authTag: reEncrypted.authTag,
      expiryDate: newExpiry,
      updatedAt: new Date(),
    })
    .where(eq(ytmOAuthTokens.id, tokenRows[0].id));

  return {
    accessToken: refreshedCreds.access_token,
    channel: hydrateConnectedChannel(accounts[0]),
  };
}

export async function disconnectWorkspaceChannel(workspaceId: number): Promise<void> {
  const cfg = getServerConfig();
  const accounts = await db
    .select()
    .from(ytmConnectedAccounts)
    .where(
      and(
        eq(ytmConnectedAccounts.workspaceId, workspaceId),
        eq(ytmConnectedAccounts.connectionStatus, 'connected')
      )
    );

  for (const acc of accounts) {
    try {
      const tokenRows = await db
        .select()
        .from(ytmOAuthTokens)
        .where(eq(ytmOAuthTokens.connectedAccountId, acc.id))
        .limit(1);
      if (tokenRows[0]) {
        const dec = decryptOAuthTokens(tokenRows[0]);
        const revokeToken = dec.refreshToken || dec.accessToken;
        if (revokeToken) {
          const oauth2Client = createGoogleOAuth2Client({
            clientId: cfg.googleClientId,
            clientSecret: cfg.googleClientSecret,
          });
          await oauth2Client.revokeToken(revokeToken).catch(() => {});
        }
        await db.delete(ytmOAuthTokens).where(eq(ytmOAuthTokens.id, tokenRows[0].id));
      }
    } catch {
      // Proceed to disconnect DB row cleanly
    }

    await db
      .update(ytmConnectedAccounts)
      .set({ connectionStatus: 'disconnected', updatedAt: new Date() })
      .where(eq(ytmConnectedAccounts.id, acc.id));
  }
}

export async function fetchAuthorizedChannelVideos(workspaceId: number): Promise<
  Array<{
    videoId: string;
    title: string;
    publishedAt: string;
    thumbnailUrl: string | null;
    privacyStatus: string;
    viewCount: number | null;
    likeCount: number | null;
    commentCount: number | null;
    videoUrl: string;
  }>
> {
  const { accessToken } = await getValidWorkspaceAccessToken(workspaceId);
  const chRes = await fetch(
    'https://www.googleapis.com/youtube/v3/channels?part=contentDetails&mine=true',
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  const chJson = (await chRes.json()) as {
    items?: Array<{ contentDetails?: { relatedPlaylists?: { uploads?: string } } }>;
  };
  const uploadsId = chJson.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  if (!uploadsId) return [];

  const plRes = await fetch(
    `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,status&playlistId=${encodeURIComponent(
      uploadsId
    )}&maxResults=25`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  const plJson = (await plRes.json()) as {
    items?: Array<{
      snippet?: {
        resourceId?: { videoId?: string };
        title?: string;
        publishedAt?: string;
        thumbnails?: { medium?: { url?: string }; default?: { url?: string } };
      };
      status?: { privacyStatus?: string };
    }>;
  };
  const ids = (plJson.items || [])
    .map((item) => item.snippet?.resourceId?.videoId)
    .filter((id): id is string => Boolean(id));
  if (ids.length === 0) return [];

  const vRes = await fetch(
    `https://www.googleapis.com/youtube/v3/videos?part=snippet,statistics,status&id=${ids.join(',')}`,
    { headers: { Authorization: `Bearer ${accessToken}` } }
  );
  const vJson = (await vRes.json()) as {
    items?: Array<{
      id: string;
      snippet?: {
        title?: string;
        publishedAt?: string;
        thumbnails?: { medium?: { url?: string } };
      };
      status?: { privacyStatus?: string };
      statistics?: { viewCount?: string; likeCount?: string; commentCount?: string };
    }>;
  };

  return (vJson.items || []).map((v) => ({
    videoId: v.id,
    title: v.snippet?.title || 'Untitled Video',
    publishedAt: v.snippet?.publishedAt || '',
    thumbnailUrl: v.snippet?.thumbnails?.medium?.url || null,
    privacyStatus: v.status?.privacyStatus || 'unknown',
    viewCount: v.statistics?.viewCount ? Number.parseInt(v.statistics.viewCount, 10) : null,
    likeCount: v.statistics?.likeCount ? Number.parseInt(v.statistics.likeCount, 10) : null,
    commentCount: v.statistics?.commentCount ? Number.parseInt(v.statistics.commentCount, 10) : null,
    videoUrl: `https://www.youtube.com/watch?v=${v.id}`,
  }));
}

export async function fetchAuthorizedChannelAnalytics(params: {
  workspaceId: number;
  startDate: string;
  endDate: string;
}): Promise<YtmChannelAnalyticsReport> {
  const { accessToken, channel } = await getValidWorkspaceAccessToken(params.workspaceId);

  const summaryUrl = new URL('https://youtubeanalytics.googleapis.com/v2/reports');
  summaryUrl.searchParams.set('ids', 'channel==MINE');
  summaryUrl.searchParams.set('startDate', params.startDate);
  summaryUrl.searchParams.set('endDate', params.endDate);
  summaryUrl.searchParams.set(
    'metrics',
    'views,estimatedMinutesWatched,averageViewDuration,subscribersGained,subscribersLost,likes,comments'
  );
  summaryUrl.searchParams.set('dimensions', 'day');
  summaryUrl.searchParams.set('sort', 'day');

  const trafficUrl = new URL('https://youtubeanalytics.googleapis.com/v2/reports');
  trafficUrl.searchParams.set('ids', 'channel==MINE');
  trafficUrl.searchParams.set('startDate', params.startDate);
  trafficUrl.searchParams.set('endDate', params.endDate);
  trafficUrl.searchParams.set('metrics', 'views,estimatedMinutesWatched');
  trafficUrl.searchParams.set('dimensions', 'insightTrafficSourceType');
  trafficUrl.searchParams.set('sort', '-views');

  const topVidUrl = new URL('https://youtubeanalytics.googleapis.com/v2/reports');
  topVidUrl.searchParams.set('ids', 'channel==MINE');
  topVidUrl.searchParams.set('startDate', params.startDate);
  topVidUrl.searchParams.set('endDate', params.endDate);
  topVidUrl.searchParams.set('metrics', 'views,estimatedMinutesWatched,averageViewDuration');
  topVidUrl.searchParams.set('dimensions', 'video');
  topVidUrl.searchParams.set('sort', '-views');
  topVidUrl.searchParams.set('maxResults', '10');

  const [sumRes, trafRes, vidRes] = await Promise.all([
    fetch(summaryUrl, { headers: { Authorization: `Bearer ${accessToken}` } }),
    fetch(trafficUrl, { headers: { Authorization: `Bearer ${accessToken}` } }),
    fetch(topVidUrl, { headers: { Authorization: `Bearer ${accessToken}` } }),
  ]);

  if (!sumRes.ok) {
    const errJson = (await sumRes.json().catch(() => ({}))) as { error?: { message?: string } };
    throw new YtmOAuthError(
      errJson.error?.message ||
        'YouTube Analytics API v2 rejected this query. Ensure YouTube Analytics API is enabled and scope yt-analytics.readonly was granted.',
      sumRes.status >= 400 ? sumRes.status : 502,
      'YOUTUBE_ANALYTICS_FAILED'
    );
  }

  type ReportBody = { rows?: Array<Array<string | number>> };
  const sumJson = (await sumRes.json()) as ReportBody;
  const trafJson = trafRes.ok ? ((await trafRes.json()) as ReportBody) : { rows: [] };
  const vidJson = vidRes.ok ? ((await vidRes.json()) as ReportBody) : { rows: [] };

  let totalViews = 0;
  let totalMinutes = 0;
  let avgDurSum = 0;
  let subsGained = 0;
  let subsLost = 0;
  let totalLikes = 0;
  let totalComments = 0;

  const dailySeries = (sumJson.rows || []).map((row) => {
    const views = Number(row[1] || 0);
    const mins = Number(row[2] || 0);
    const avgDur = Number(row[3] || 0);
    const gained = Number(row[4] || 0);
    const lost = Number(row[5] || 0);
    const likes = Number(row[6] || 0);
    const comments = Number(row[7] || 0);

    totalViews += views;
    totalMinutes += mins;
    avgDurSum += avgDur;
    subsGained += gained;
    subsLost += lost;
    totalLikes += likes;
    totalComments += comments;

    return {
      date: String(row[0]),
      views,
      estimatedMinutesWatched: mins,
      subscribersGained: gained,
    };
  });

  const dayCount = Math.max(1, dailySeries.length);
  const topIds = (vidJson.rows || []).map((r) => String(r[0])).filter(Boolean);
  const videoTitleMap = new Map<string, { title: string; publishedAt?: string; thumb?: string }>();
  if (topIds.length > 0) {
    const metaRes = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=snippet&id=${topIds.join(',')}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    if (metaRes.ok) {
      const metaJson = (await metaRes.json()) as {
        items?: Array<{
          id: string;
          snippet?: {
            title?: string;
            publishedAt?: string;
            thumbnails?: { medium?: { url?: string } };
          };
        }>;
      };
      for (const item of metaJson.items || []) {
        videoTitleMap.set(item.id, {
          title: item.snippet?.title || item.id,
          publishedAt: item.snippet?.publishedAt,
          thumb: item.snippet?.thumbnails?.medium?.url,
        });
      }
    }
  }

  const report: YtmChannelAnalyticsReport = {
    channelId: channel.channelId,
    channelTitle: channel.channelTitle,
    dateRangeStart: params.startDate,
    dateRangeEnd: params.endDate,
    source: 'youtube_analytics_api_v2',
    totals: {
      views: totalViews,
      estimatedMinutesWatched: totalMinutes,
      averageViewDurationSec: dailySeries.length > 0 ? Math.round(avgDurSum / dayCount) : 0,
      subscribersGained: subsGained,
      subscribersLost: subsLost,
      likes: totalLikes,
      comments: totalComments,
      // Impressions & CTR are not reliably exposed via standard YouTube Analytics API v2 channel==MINE queries
      impressions: null,
      impressionsCtr: null,
    },
    unavailableMetricsNote:
      'Impressions and Thumbnail CTR are shown as unavailable because YouTube Analytics API v2 does not provide full YouTube Studio Reach metrics for standard API queries.',
    dailySeries,
    trafficSources: (trafJson.rows || []).map((r) => ({
      sourceType: String(r[0]),
      views: Number(r[1] || 0),
      estimatedMinutesWatched: Number(r[2] || 0),
    })),
    topVideos: (vidJson.rows || []).map((r) => {
      const vidId = String(r[0]);
      const meta = videoTitleMap.get(vidId);
      return {
        videoId: vidId,
        title: meta?.title || vidId,
        views: Number(r[1] || 0),
        estimatedMinutesWatched: Number(r[2] || 0),
        averageViewDurationSec: Number(r[3] || 0),
        publishedAt: meta?.publishedAt,
        thumbnailUrl: meta?.thumb,
      };
    }),
    retrievedAt: new Date().toISOString(),
  };

  await db.insert(ytmAnalyticsSnapshots).values({
    workspaceId: params.workspaceId,
    channelId: channel.channelId,
    dateRangeStart: params.startDate,
    dateRangeEnd: params.endDate,
    metricsJson: JSON.stringify(report),
  });

  return report;
}

export async function fetchAuthorizedMonetaryRevenue(params: {
  workspaceId: number;
  startDate: string;
  endDate: string;
}): Promise<{
  available: boolean;
  estimatedRevenue: number | null;
  currency: string;
  note: string;
}> {
  const { accessToken } = await getValidWorkspaceAccessToken(params.workspaceId);
  const url = new URL('https://youtubeanalytics.googleapis.com/v2/reports');
  url.searchParams.set('ids', 'channel==MINE');
  url.searchParams.set('startDate', params.startDate);
  url.searchParams.set('endDate', params.endDate);
  url.searchParams.set('metrics', 'estimatedRevenue,estimatedAdRevenue');

  const res = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
  if (!res.ok) {
    return {
      available: false,
      estimatedRevenue: null,
      currency: 'USD',
      note: 'Monetary YouTube Analytics API data is unavailable for this channel (channel may not be in YPP or monetary scope was declined).',
    };
  }
  const data = (await res.json()) as { rows?: Array<Array<number>> };
  const val = data.rows?.[0]?.[0] ?? null;
  return {
    available: val !== null,
    estimatedRevenue: val,
    currency: 'USD',
    note:
      val !== null
        ? 'Retrieved directly from YouTube Analytics Monetary API.'
        : 'No monetary rows returned for selected period.',
  };
}

export async function fetchAuthorizedComments(
  workspaceId: number,
  videoId?: string
): Promise<
  Array<{
    externalCommentId: string;
    videoId: string;
    authorName: string;
    content: string;
    publishedAt: string;
  }>
> {
  const { accessToken, channel } = await getValidWorkspaceAccessToken(workspaceId);
  const url = new URL('https://www.googleapis.com/youtube/v3/commentThreads');
  url.searchParams.set('part', 'snippet');
  url.searchParams.set('maxResults', '25');
  url.searchParams.set('order', 'time');
  if (videoId) {
    url.searchParams.set('videoId', videoId);
  } else {
    url.searchParams.set('allThreadsRelatedToChannelId', channel.channelId);
  }

  const res = await fetch(url, { headers: { Authorization: `Bearer ${accessToken}` } });
  const json = (await res.json().catch(() => ({}))) as {
    items?: Array<{
      id: string;
      snippet?: {
        videoId?: string;
        topLevelComment?: {
          id?: string;
          snippet?: {
            authorDisplayName?: string;
            textOriginal?: string;
            publishedAt?: string;
          };
        };
      };
    }>;
    error?: { message?: string };
  };

  if (!res.ok) {
    throw new YtmOAuthError(
      json.error?.message || 'Unable to retrieve channel comments from YouTube Data API.',
      res.status >= 400 ? res.status : 502,
      'COMMENTS_FETCH_FAILED'
    );
  }

  return (json.items || []).map((item) => ({
    externalCommentId: item.snippet?.topLevelComment?.id || item.id,
    videoId: item.snippet?.videoId || '',
    authorName: item.snippet?.topLevelComment?.snippet?.authorDisplayName || 'Viewer',
    content: item.snippet?.topLevelComment?.snippet?.textOriginal || '',
    publishedAt: item.snippet?.topLevelComment?.snippet?.publishedAt || '',
  }));
}

export async function postAuthorizedCommentReply(params: {
  workspaceId: number;
  parentCommentId: string;
  replyText: string;
}): Promise<{ commentId: string }> {
  const { accessToken } = await getValidWorkspaceAccessToken(params.workspaceId);
  const res = await fetch('https://www.googleapis.com/youtube/v3/comments?part=snippet', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      snippet: {
        parentId: params.parentCommentId,
        textOriginal: params.replyText,
      },
    }),
  });
  const json = (await res.json().catch(() => ({}))) as {
    id?: string;
    error?: { message?: string };
  };
  if (!res.ok || !json.id) {
    throw new YtmOAuthError(
      json.error?.message || 'Failed to post reply via YouTube Data API.',
      res.status >= 400 ? res.status : 502,
      'COMMENT_REPLY_FAILED'
    );
  }
  return { commentId: json.id };
}

export async function executeResumableYouTubeUpload(params: {
  workspaceId: number;
  filePath: string;
  mimeType: string;
  title: string;
  description: string;
  tags: string[];
  categoryId: string;
  privacyStatus: 'public' | 'unlisted' | 'private';
  publishAt?: string | null;
  onProgress?: (percent: number) => Promise<void> | void;
}): Promise<{ videoId: string; videoUrl: string }> {
  const { accessToken } = await getValidWorkspaceAccessToken(params.workspaceId);
  const stat = await fs.stat(params.filePath);

  const metadata = {
    snippet: {
      title: params.title.slice(0, 100),
      description: params.description.slice(0, 5000),
      tags: params.tags.slice(0, 30),
      categoryId: params.categoryId || '22',
    },
    status: {
      privacyStatus: params.privacyStatus,
      ...(params.privacyStatus === 'private' && params.publishAt
        ? { publishAt: params.publishAt }
        : {}),
      selfDeclaredMadeForKids: false,
    },
  };

  if (params.onProgress) await params.onProgress(10);

  const initRes = await fetch(
    'https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status',
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json; charset=UTF-8',
        'X-Upload-Content-Length': String(stat.size),
        'X-Upload-Content-Type': params.mimeType || 'video/mp4',
      },
      body: JSON.stringify(metadata),
    }
  );

  if (!initRes.ok) {
    const errJson = (await initRes.json().catch(() => ({}))) as { error?: { message?: string } };
    throw new YtmOAuthError(
      errJson.error?.message || 'YouTube resumable upload initialization failed.',
      initRes.status >= 400 ? initRes.status : 502,
      'UPLOAD_INIT_FAILED'
    );
  }

  const uploadLocation = initRes.headers.get('location');
  if (!uploadLocation) {
    throw new YtmOAuthError(
      'Google Upload API did not return a resumable session Location URI.',
      502,
      'UPLOAD_LOCATION_MISSING'
    );
  }

  if (params.onProgress) await params.onProgress(35);
  const fileBuffer = await fs.readFile(params.filePath);
  if (params.onProgress) await params.onProgress(65);

  const putRes = await fetch(uploadLocation, {
    method: 'PUT',
    headers: {
      'Content-Length': String(fileBuffer.byteLength),
      'Content-Type': params.mimeType || 'video/mp4',
    },
    body: fileBuffer,
  });

  const putJson = (await putRes.json().catch(() => ({}))) as {
    id?: string;
    error?: { message?: string };
  };

  if (!putRes.ok || !putJson.id) {
    throw new YtmOAuthError(
      putJson.error?.message || 'Video binary upload to YouTube failed.',
      putRes.status >= 400 ? putRes.status : 502,
      'UPLOAD_TRANSFER_FAILED'
    );
  }

  if (params.onProgress) await params.onProgress(100);
  return {
    videoId: putJson.id,
    videoUrl: `https://www.youtube.com/watch?v=${putJson.id}`,
  };
}
