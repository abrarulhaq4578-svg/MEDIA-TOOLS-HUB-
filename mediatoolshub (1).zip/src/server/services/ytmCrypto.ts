import crypto from 'node:crypto';
import { getServerConfig } from '../config/env.ts';

function deriveEncryptionKey(): Buffer {
  const cfg = getServerConfig();
  const raw =
    cfg.oauthTokenEncryptionKey ||
    process.env.FIREBASE_SERVICE_ACCOUNT ||
    cfg.googleClientSecret ||
    cfg.geminiApiKey ||
    'mediatoolshub_ephemeral_dev_oauth_key_rotate_in_production';

  if (/^[0-9a-f]{64}$/i.test(raw)) {
    return Buffer.from(raw, 'hex');
  }
  return crypto.createHash('sha256').update(raw, 'utf8').digest();
}

export interface EncryptedTokenBundle {
  encryptedAccessToken: string;
  encryptedRefreshToken: string | null;
  iv: string;
  authTag: string;
}

export function encryptOAuthTokens(
  accessToken: string,
  refreshToken?: string | null
): EncryptedTokenBundle {
  const key = deriveEncryptionKey();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);

  const payload = JSON.stringify({
    accessToken,
    refreshToken: refreshToken || null,
  });
  const encrypted = Buffer.concat([cipher.update(payload, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();

  // Store combined ciphertext cleanly; encryptedRefreshToken mirrors flag for schema integrity
  return {
    encryptedAccessToken: encrypted.toString('base64'),
    encryptedRefreshToken: refreshToken ? 'stored_in_bundle' : null,
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64'),
  };
}

export function decryptOAuthTokens(bundle: {
  encryptedAccessToken: string;
  iv: string;
  authTag: string;
}): { accessToken: string; refreshToken: string | null } {
  const key = deriveEncryptionKey();
  const iv = Buffer.from(bundle.iv, 'base64');
  const authTag = Buffer.from(bundle.authTag, 'base64');
  const encrypted = Buffer.from(bundle.encryptedAccessToken, 'base64');

  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(authTag);

  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]).toString('utf8');
  const parsed = JSON.parse(decrypted) as { accessToken?: string; refreshToken?: string | null };
  return {
    accessToken: parsed.accessToken || '',
    refreshToken: parsed.refreshToken || null,
  };
}

export interface OAuthStatePayload {
  workspaceId: number;
  workspaceKey: string;
  userId: number;
  redirectUri: string;
  nonce: string;
  exp: number;
}

export function signOAuthState(payload: Omit<OAuthStatePayload, 'nonce' | 'exp'>): string {
  const full: OAuthStatePayload = {
    ...payload,
    nonce: crypto.randomBytes(12).toString('hex'),
    exp: Date.now() + 15 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(full), 'utf8').toString('base64url');
  const hmac = crypto
    .createHmac('sha256', deriveEncryptionKey())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${hmac}`;
}

export function verifyOAuthState(stateToken: string): OAuthStatePayload | null {
  if (!stateToken || !stateToken.includes('.')) return null;
  const [encoded, sig] = stateToken.split('.');
  if (!encoded || !sig) return null;

  const expectedSig = crypto
    .createHmac('sha256', deriveEncryptionKey())
    .update(encoded)
    .digest('base64url');

  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const payload = JSON.parse(
      Buffer.from(encoded, 'base64url').toString('utf8')
    ) as OAuthStatePayload;
    if (!payload.workspaceId || !payload.userId || !payload.exp || Date.now() > payload.exp) {
      return null;
    }
    return payload;
  } catch {
    return null;
  }
}

const consumedOAuthNonces = new Map<string, number>();

export function consumeOAuthState(stateToken: string): OAuthStatePayload | null {
  const payload = verifyOAuthState(stateToken);
  if (!payload || !payload.nonce) return null;

  const now = Date.now();
  // Prune expired nonces so memory stays bounded
  for (const [nonce, exp] of consumedOAuthNonces.entries()) {
    if (exp < now) {
      consumedOAuthNonces.delete(nonce);
    }
  }

  if (consumedOAuthNonces.has(payload.nonce)) {
    return null;
  }
  consumedOAuthNonces.set(payload.nonce, payload.exp);
  return payload;
}
