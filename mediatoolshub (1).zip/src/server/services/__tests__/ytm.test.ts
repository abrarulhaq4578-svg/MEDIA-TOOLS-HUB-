import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  classifyDistributionState,
  GOOGLE_OAUTH_AUTHORIZATION_ENDPOINT,
  hasYtmPermission,
  normalizeYtmRole,
  validateGoogleOAuthAuthorizationUrl,
  YTM_COMMUNITY_POST_FORMATS,
  YTM_DEFAULT_PIPELINE_STATUSES,
  YTM_DEFAULT_PRODUCTION_CHECKLIST,
  YTM_INSPIRATION_CATEGORIES,
  YTM_OAUTH_CALLBACK_PATH,
  YTM_SIDEBAR_SECTIONS,
  YTM_WORKFLOW_STAGES,
} from '../../../shared/ytmHelpers.ts';
import {
  CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI,
  getGoogleOAuthConfig,
  getGoogleOAuthCredentialDiagnostics,
  getServerConfig,
  getYtmOAuthConfigStatus,
} from '../../config/env.ts';
import {
  buildInspirationDedupeKey,
  defaultChannelDna,
  formatChannelDnaForPrompt,
  normalizeYouTubeUrlForDedupe,
  parsePlannerChecklist,
} from '../ytmChannelDnaService.ts';
import {
  consumeOAuthState,
  decryptOAuthTokens,
  encryptOAuthTokens,
  signOAuthState,
  verifyOAuthState,
} from '../ytmCrypto.ts';
import {
  buildValidatedGoogleOAuthAuthorizationUrl,
  buildYtmOAuthConfigValidation,
  normalizeOAuthRedirectUri,
  resolveOAuthRedirectUri,
  YOUTUBE_OAUTH_SCOPES,
} from '../ytmOAuthService.ts';
import { buildDeterministicCalendarAudit } from '../ytmOsAiService.ts';

describe('YouTube Management Crypto & OAuth State', () => {
  it('encrypts and decrypts OAuth access + refresh tokens via AES-256-GCM round-trip', () => {
    const bundle = encryptOAuthTokens('ya29.access-token-sample', '1//refresh-token-sample');
    expect(bundle.encryptedAccessToken).toBeTruthy();
    expect(bundle.encryptedRefreshToken).toBe('stored_in_bundle');
    expect(bundle.iv).toBeTruthy();
    expect(bundle.authTag).toBeTruthy();
    expect(bundle.encryptedAccessToken).not.toContain('ya29.access-token-sample');

    const decoded = decryptOAuthTokens(bundle);
    expect(decoded.accessToken).toBe('ya29.access-token-sample');
    expect(decoded.refreshToken).toBe('1//refresh-token-sample');
  });

  it('signs and verifies OAuth CSRF state and rejects tampered state', () => {
    const token = signOAuthState({
      workspaceId: 42,
      workspaceKey: 'ytm_ws_test123',
      userId: 7,
      redirectUri: 'https://example.com/api/v1/ytm/auth/google/callback',
    });

    const verified = verifyOAuthState(token);
    expect(verified).not.toBeNull();
    expect(verified?.workspaceId).toBe(42);
    expect(verified?.workspaceKey).toBe('ytm_ws_test123');
    expect(verified?.userId).toBe(7);

    const [encoded, sig] = token.split('.');
    const tampered = `${encoded}.${sig.slice(0, -2)}xx`;
    expect(verifyOAuthState(tampered)).toBeNull();
    expect(verifyOAuthState('malformed')).toBeNull();

    // Single-use replay protection via consumeOAuthState
    const firstConsume = consumeOAuthState(token);
    expect(firstConsume).not.toBeNull();
    expect(firstConsume?.workspaceId).toBe(42);
    expect(consumeOAuthState(token)).toBeNull();
  });

  it('builds a valid Google OAuth v2 authorization URL with exact endpoint and single-encoded params', () => {
    const configuredCallback =
      'https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app/api/v1/ytm/auth/google/callback';
    const { authorizationUrl, diagnostics } = buildValidatedGoogleOAuthAuthorizationUrl({
      redirectUri: configuredCallback,
      state: 'csrf_state_token_abc123',
      env: {
        GOOGLE_CLIENT_ID: '1234567890-testclient.apps.googleusercontent.com',
        GOOGLE_CLIENT_SECRET: 'test-secret-value',
        GOOGLE_REDIRECT_URI: configuredCallback,
      } as NodeJS.ProcessEnv,
    });

    expect(authorizationUrl.startsWith(`${GOOGLE_OAUTH_AUTHORIZATION_ENDPOINT}?`)).toBe(true);

    const parsed = new URL(authorizationUrl);
    expect(parsed.protocol).toBe('https:');
    expect(parsed.hostname).toBe('accounts.google.com');
    expect(parsed.pathname).toBe('/o/oauth2/v2/auth');
    expect(parsed.searchParams.get('client_id')).toBe(
      '1234567890-testclient.apps.googleusercontent.com'
    );
    expect(parsed.searchParams.get('redirect_uri')).toBe(configuredCallback);
    expect(parsed.searchParams.get('response_type')).toBe('code');
    expect(parsed.searchParams.get('scope')).toBe(YOUTUBE_OAUTH_SCOPES.join(' '));
    expect(parsed.searchParams.get('access_type')).toBe('offline');
    expect(parsed.searchParams.get('include_granted_scopes')).toBe('true');
    expect(parsed.searchParams.get('prompt')).toBe('consent');
    expect(parsed.searchParams.get('state')).toBe('csrf_state_token_abc123');

    // Ensure no double-encoding (e.g. %253A)
    expect(authorizationUrl).not.toContain('%253A');
    expect(authorizationUrl).not.toContain('%252F');

    expect(diagnostics.hostname).toBe('accounts.google.com');
    expect(diagnostics.pathname).toBe('/o/oauth2/v2/auth');
    expect(diagnostics.clientIdPresent).toBe(true);
    expect(diagnostics.redirectUri).toBe(configuredCallback);
    expect(diagnostics.clientIdEndsWithAppsDomain).toBe(true);
    expect(diagnostics.oauthClientInitialized).toBe(true);
    expect(diagnostics.authorizationUrlReady).toBe(true);
    expect(diagnostics.queryParamNames.sort()).toEqual([
      'access_type',
      'client_id',
      'include_granted_scopes',
      'prompt',
      'redirect_uri',
      'response_type',
      'scope',
      'state',
    ]);
  });

  it('normalizes redirect URIs and rejects invalid Google OAuth authorization URLs', () => {
    expect(
      normalizeOAuthRedirectUri(
        'https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app/'
      )
    ).toBe(
      `https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app${YTM_OAUTH_CALLBACK_PATH}`
    );

    expect(
      normalizeOAuthRedirectUri(
        'https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app/api/v1/ytm/auth/google/callback/'
      )
    ).toBe(
      `https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app${YTM_OAUTH_CALLBACK_PATH}`
    );

    expect(() =>
      validateGoogleOAuthAuthorizationUrl(
        'https://oauth2.googleapis.com/token?client_id=a&redirect_uri=https://x.com&response_type=code&scope=s&state=st'
      )
    ).toThrow(/accounts\.google\.com/);

    expect(() =>
      validateGoogleOAuthAuthorizationUrl(
        'https://accounts.google.com/o/oauth2/v2?client_id=a&redirect_uri=https://x.com&response_type=code&scope=s&state=st'
      )
    ).toThrow(/\/o\/oauth2\/v2\/auth/);

    expect(() =>
      validateGoogleOAuthAuthorizationUrl(
        'http://accounts.google.com/o/oauth2/v2/auth?client_id=a&redirect_uri=https://x.com&response_type=code&scope=s&state=st'
      )
    ).toThrow(/HTTPS/);

    expect(() =>
      validateGoogleOAuthAuthorizationUrl(
        'https://accounts.google.com/o/oauth2/v2/auth?client_id=a&redirect_uri=https://x.com&response_type=code&scope=s'
      )
    ).toThrow(/state/);
  });
});

describe('YouTube Management RBAC & Pipeline Helpers', () => {
  it('defines exact 10 ordered sidebar sections including Creator Performance Coach', () => {
    expect(YTM_SIDEBAR_SECTIONS.map((s) => s.id)).toEqual([
      'dashboard',
      'competitors',
      'planner',
      'workflow',
      'analytics',
      'coach',
      'earn',
      'community',
      'team',
      'others',
    ]);
    expect(YTM_SIDEBAR_SECTIONS.map((s) => s.order)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    expect(YTM_SIDEBAR_SECTIONS[5]?.label).toBe('Creator Performance Coach');
    expect(YTM_DEFAULT_PIPELINE_STATUSES).toEqual([
      'Idea',
      'Selected',
      'Researching',
      'Scripting',
      'Production',
      'Ready to Publish',
      'Published',
    ]);
    expect(YTM_INSPIRATION_CATEGORIES).toHaveLength(8);
    expect(YTM_DEFAULT_PRODUCTION_CHECKLIST.length).toBeGreaterThanOrEqual(5);
  });

  it('enforces strict role permissions across all 8 workspace roles', () => {
    expect(hasYtmPermission('owner', 'oauth:manage')).toBe(true);
    expect(hasYtmPermission('admin', 'team:manage')).toBe(true);
    expect(hasYtmPermission('manager', 'workflow:approve')).toBe(true);
    expect(hasYtmPermission('manager', 'oauth:manage')).toBe(false);

    expect(hasYtmPermission('editor', 'workflow:write')).toBe(true);
    expect(hasYtmPermission('editor', 'publish:youtube')).toBe(false);
    expect(hasYtmPermission('editor', 'earn:read')).toBe(false);

    expect(hasYtmPermission('thumbnail_designer', 'workflow:write')).toBe(true);
    expect(hasYtmPermission('thumbnail_designer', 'analytics:read')).toBe(false);

    expect(hasYtmPermission('script_writer', 'planner:write')).toBe(true);
    expect(hasYtmPermission('script_writer', 'team:manage')).toBe(false);

    expect(hasYtmPermission('analyst', 'analytics:read')).toBe(true);
    expect(hasYtmPermission('analyst', 'earn:read')).toBe(true);
    expect(hasYtmPermission('analyst', 'earn:write')).toBe(false);

    expect(hasYtmPermission('viewer', 'workspace:read')).toBe(true);
    expect(hasYtmPermission('viewer', 'planner:write')).toBe(false);
    expect(normalizeYtmRole('unknown_role')).toBe('viewer');
  });

  it('never fakes published_api distribution state without verified API publish', () => {
    expect(
      classifyDistributionState({
        platform: 'instagram',
        apiPublishSucceeded: false,
        markedManuallyPublished: false,
      })
    ).toBe('draft');

    expect(
      classifyDistributionState({
        platform: 'instagram',
        apiPublishSucceeded: false,
        markedManuallyPublished: true,
      })
    ).toBe('manually_published');

    expect(
      classifyDistributionState({
        platform: 'youtube_shorts',
        apiPublishSucceeded: true,
        markedManuallyPublished: false,
      })
    ).toBe('published_api');
  });

  it('reports OAuth configuration gaps accurately without throwing', () => {
    const missing = getYtmOAuthConfigStatus({} as NodeJS.ProcessEnv);
    expect(missing.configured).toBe(false);
    expect(missing.missingVars).toEqual(['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET']);

    const present = getYtmOAuthConfigStatus({
      GOOGLE_CLIENT_ID: 'client-id',
      GOOGLE_CLIENT_SECRET: 'client-secret',
    } as NodeJS.ProcessEnv);
    expect(present.configured).toBe(true);
    expect(present.missingVars).toEqual([]);
  });

  it('validates GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET formats and detects common misconfigurations without exposing secrets', () => {
    const cleanedCfg = getServerConfig({
      GOOGLE_CLIENT_ID: ' "GOOGLE_CLIENT_ID=1234567890-abc123.apps.googleusercontent.com" \n',
      GOOGLE_CLIENT_SECRET: " 'GOCSPX-test_secret_value_12345' ",
    } as NodeJS.ProcessEnv);
    expect(cleanedCfg.googleClientId).toBe('1234567890-abc123.apps.googleusercontent.com');
    expect(cleanedCfg.googleClientSecret).toBe('GOCSPX-test_secret_value_12345');

    const validDiag = getGoogleOAuthCredentialDiagnostics({
      GOOGLE_CLIENT_ID: '1234567890-abc123.apps.googleusercontent.com',
      GOOGLE_CLIENT_SECRET: 'GOCSPX-test_secret_value_12345',
    } as NodeJS.ProcessEnv);
    expect(validDiag.clientIdFormatValid).toBe(true);
    expect(validDiag.clientSecretFormatValid).toBe(true);
    expect(validDiag.clientIdEndsWithAppsDomain).toBe(true);
    expect(validDiag.clientIdIsPlaceholderLiteral).toBe(false);
    expect(validDiag.clientIdHasWhitespace).toBe(false);
    expect(validDiag.clientIdHasQuotes).toBe(false);
    expect(validDiag.rawClientIdLength).toBe(44);
    expect(validDiag.clientIdIssueCode).toBe('ok');
    expect(validDiag.clientSecretIssueCode).toBe('ok');
    expect(validDiag.source).toBe('server_env');
    expect(validDiag.frontendEnvOverridePresent).toBe(false);

    const placeholderDiag = getGoogleOAuthCredentialDiagnostics({
      GOOGLE_CLIENT_ID: 'true',
      GOOGLE_CLIENT_SECRET: 'test',
    } as NodeJS.ProcessEnv);
    expect(placeholderDiag.rawClientIdLength).toBe(4);
    expect(placeholderDiag.clientIdIsPlaceholderLiteral).toBe(true);
    expect(placeholderDiag.clientSecretIsPlaceholderLiteral).toBe(true);
    expect(placeholderDiag.clientIdEndsWithAppsDomain).toBe(false);

    const swapped = getGoogleOAuthCredentialDiagnostics({
      GOOGLE_CLIENT_ID: 'GOCSPX-test_secret_value_12345',
      GOOGLE_CLIENT_SECRET: '1234567890-abc123.apps.googleusercontent.com',
    } as NodeJS.ProcessEnv);
    expect(swapped.clientIdFormatValid).toBe(false);
    expect(swapped.clientIdIssueCode).toBe('swapped_with_secret');
    expect(swapped.clientSecretFormatValid).toBe(false);
    expect(swapped.clientSecretIssueCode).toBe('swapped_with_client_id');

    const apiKeyMistake = getGoogleOAuthCredentialDiagnostics({
      GOOGLE_CLIENT_ID: 'AIzaSyTestFakeKey1234567890',
      GOOGLE_CLIENT_SECRET: 'custom-short-secret',
    } as NodeJS.ProcessEnv);
    expect(apiKeyMistake.clientIdIssueCode).toBe('api_key_instead_of_client_id');
    expect(apiKeyMistake.issues).toContain('api_key_instead_of_client_id');
    expect(apiKeyMistake.clientSecretFormatValid).toBe(true);
    expect(apiKeyMistake.clientSecretIssueCode).toBe('ok');

    // Preserves internal characters while stripping CR/LF, outer spaces, and outer quotes; flags internal spaces
    const normalizedCfg = getGoogleOAuthConfig({
      GOOGLE_CLIENT_ID: '\r\n "400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com"\r\n ',
      GOOGLE_CLIENT_SECRET: "\n 'GOCSPX-abc_123-XYZ_987654'\r\n",
    } as NodeJS.ProcessEnv);
    expect(normalizedCfg.clientId).toBe(
      '400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com'
    );
    expect(normalizedCfg.clientSecret).toBe('GOCSPX-abc_123-XYZ_987654');
    expect(normalizedCfg.diagnostics.clientIdFormatValid).toBe(true);
    expect(normalizedCfg.diagnostics.clientSecretFormatValid).toBe(true);
    expect(normalizedCfg.diagnostics.issues).toEqual([]);

    const internalSpaceSecret = getGoogleOAuthConfig({
      GOOGLE_CLIENT_ID: '400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com',
      GOOGLE_CLIENT_SECRET: 'GOCSPX-bad secret with spaces',
    } as NodeJS.ProcessEnv);
    expect(internalSpaceSecret.clientSecret).toBe('GOCSPX-bad secret with spaces');
    expect(internalSpaceSecret.diagnostics.clientSecretFormatValid).toBe(false);
    expect(internalSpaceSecret.diagnostics.clientSecretIssueCode).toBe('invalid_format');
    expect(internalSpaceSecret.diagnostics.issues).toContain('invalid_format');
  });

  it('refuses untrusted forwarded Host headers when resolving OAuth redirect URI', () => {
    const spoofedReq = {
      get: (headerName: string) => {
        if (headerName.toLowerCase() === 'host') return 'evil.attacker.example';
        return undefined;
      },
    };
    const resolvedProd = resolveOAuthRedirectUri(spoofedReq as never, {
      NODE_ENV: 'production',
    } as NodeJS.ProcessEnv);
    expect(resolvedProd).toBe(CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI);

    const resolvedDevSpoof = resolveOAuthRedirectUri(spoofedReq as never, {
      NODE_ENV: 'development',
    } as NodeJS.ProcessEnv);
    expect(resolvedDevSpoof).toBe(CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI);

    const localhostReq = {
      get: (headerName: string) => (headerName.toLowerCase() === 'host' ? 'localhost:3000' : undefined),
    };
    const resolvedLocal = resolveOAuthRedirectUri(localhostReq as never, {
      NODE_ENV: 'development',
    } as NodeJS.ProcessEnv);
    expect(resolvedLocal).toBe(`http://localhost:3000${YTM_OAUTH_CALLBACK_PATH}`);
  });

  it('builds complete OAuth health validation via OAuth2Client without throwing on placeholders', async () => {
    const callbackUri =
      'https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app/api/v1/ytm/auth/google/callback';

    const ready = await buildYtmOAuthConfigValidation({
      redirectUri: callbackUri,
      probeGoogleEndpoint: false,
      env: {
        GOOGLE_CLIENT_ID: '400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com',
        GOOGLE_CLIENT_SECRET: 'valid-secret-without-fixed-prefix',
        GOOGLE_REDIRECT_URI: callbackUri,
      } as NodeJS.ProcessEnv,
    });
    expect(ready.valid).toBe(true);
    expect(ready.oauthConfigured).toBe(true);
    expect(ready.clientIdPresent).toBe(true);
    expect(ready.clientIdFormatValid).toBe(true);
    expect(ready.clientSecretPresent).toBe(true);
    expect(ready.oauthClientInitialized).toBe(true);
    expect(ready.redirectUriValid).toBe(true);
    expect(ready.authorizationUrlReady).toBe(true);

    const placeholder = await buildYtmOAuthConfigValidation({
      redirectUri: callbackUri,
      probeGoogleEndpoint: false,
      env: {
        GOOGLE_CLIENT_ID: 'true',
        GOOGLE_CLIENT_SECRET: 'null',
        GOOGLE_REDIRECT_URI: 'none',
      } as NodeJS.ProcessEnv,
    });
    expect(placeholder.valid).toBe(false);
    expect(placeholder.oauthConfigured).toBe(false);
    expect(placeholder.clientIdPresent).toBe(false);
    expect(placeholder.clientSecretPresent).toBe(false);
    expect(placeholder.oauthClientInitialized).toBe(false);
    expect(placeholder.authorizationUrlReady).toBe(false);
    expect(placeholder.diagnostics?.clientIdIsPlaceholderLiteral).toBe(true);
    expect(placeholder.diagnostics?.clientSecretIsPlaceholderLiteral).toBe(true);

    const repeatedSentinel = await buildYtmOAuthConfigValidation({
      redirectUri: callbackUri,
      probeGoogleEndpoint: false,
      env: {
        GOOGLE_CLIENT_ID: 'zzzz',
        GOOGLE_CLIENT_SECRET: 'zzzz',
        GOOGLE_REDIRECT_URI: 'zzzz',
        OAUTH_TOKEN_ENCRYPTION_KEY: 'zzzz',
      } as NodeJS.ProcessEnv,
    });
    expect(repeatedSentinel.valid).toBe(false);
    expect(repeatedSentinel.oauthConfigured).toBe(false);
    expect(repeatedSentinel.clientIdPresent).toBe(false);
    expect(repeatedSentinel.clientSecretPresent).toBe(false);
    expect(repeatedSentinel.diagnostics?.clientIdIsPlaceholderLiteral).toBe(true);
    expect(repeatedSentinel.diagnostics?.clientSecretIsPlaceholderLiteral).toBe(true);
    expect(repeatedSentinel.diagnostics?.clientIdIssueCode).toBe('placeholder_literal');
    expect(repeatedSentinel.diagnostics?.clientSecretIssueCode).toBe('placeholder_literal');
  });

  it('loads GOOGLE_CLIENT_SECRET and OAUTH_TOKEN_ENCRYPTION_KEY from Secret Manager mounted files when env var is absent or sentinel', () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mth-sm-test-'));
    const secretFile = path.join(tmpDir, 'GOOGLE_CLIENT_SECRET');
    const encFile = path.join(tmpDir, 'OAUTH_TOKEN_ENCRYPTION_KEY');
    try {
      fs.writeFileSync(secretFile, 'mounted-rotated-secret-value\n', 'utf8');
      fs.writeFileSync(encFile, '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef\n', 'utf8');

      const testEnv = {
        GOOGLE_CLIENT_ID: '400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com',
        GOOGLE_CLIENT_SECRET: 'null',
        GOOGLE_CLIENT_SECRET_FILE: secretFile,
        OAUTH_TOKEN_ENCRYPTION_KEY_FILE: encFile,
      } as NodeJS.ProcessEnv;

      const cfg = getServerConfig(testEnv);
      expect(cfg.googleClientSecret).toBe('mounted-rotated-secret-value');
      expect(cfg.oauthTokenEncryptionKey).toBe(
        '0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef'
      );

      const diag = getGoogleOAuthCredentialDiagnostics(testEnv);
      expect(diag.configured).toBe(true);
      expect(diag.source).toBe('secret_manager_mount');
      expect(diag.secretMountDetected).toBe(true);
      expect(diag.clientSecretPresent).toBe(true);
      expect(diag.clientSecretFormatValid).toBe(true);
      expect(diag.clientIdFormatValid).toBe(true);
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });
});

describe('Channel DNA, Saved Inspiration Deduplication & Smart Planner Helpers', () => {
  it('formats distinct Channel DNA profiles cleanly with words-to-use and words-to-avoid constraints', () => {
    const techProfile = {
      id: 1,
      workspaceId: 10,
      userId: 5,
      youtubeChannelId: null,
      channelName: 'Signal Craft Labs',
      channelHandle: '@signalcraft',
      description: 'Deep hardware teardown channel',
      niche: 'Consumer Tech',
      subNiche: 'Audio Engineering',
      isDefault: true,
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z',
      dna: {
        ...defaultChannelDna(),
        targetAudience: 'Studio engineers and audiophiles',
        preferredLanguage: 'English',
        toneOfVoice: 'Calm, empirical, measurement-first',
        wordsToUse: ['measured', 'signal path'],
        wordsToAvoid: ['INSANE', 'GAME CHANGER'],
        uniquePositioning: 'Lab-tested audio gear with zero sponsor bias',
      },
    };

    const cookingProfile = {
      ...techProfile,
      id: 2,
      channelName: 'Weeknight Wok',
      niche: 'Food & Cooking',
      subNiche: '15-Minute Asian Recipes',
      dna: {
        ...defaultChannelDna(),
        targetAudience: 'Busy home cooks',
        toneOfVoice: 'Warm, punchy, sensory',
        wordsToUse: ['wok hei', 'weeknight'],
        wordsToAvoid: ['molecular gastronomy'],
      },
    };

    const techPrompt = formatChannelDnaForPrompt(techProfile);
    const cookingPrompt = formatChannelDnaForPrompt(cookingProfile);

    expect(techPrompt).toContain('Signal Craft Labs');
    expect(techPrompt).toContain('Audio Engineering');
    expect(techPrompt).toContain('INSANE, GAME CHANGER');
    expect(techPrompt).toContain('Lab-tested audio gear');
    expect(cookingPrompt).toContain('Weeknight Wok');
    expect(cookingPrompt).not.toContain('Signal Craft Labs');
    expect(formatChannelDnaForPrompt(null)).toBe('');
  });

  it('normalizes YouTube URLs across watch, short, and youtu.be formats to prevent duplicate inspiration saves', () => {
    const watchUrl = 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=42s';
    const shortLink = 'https://youtu.be/dQw4w9WgXcQ?si=abcdef';
    const shortsUrl = 'https://youtube.com/shorts/dQw4w9WgXcQ';

    expect(normalizeYouTubeUrlForDedupe(watchUrl)).toBe('yt:dqw4w9wgxcq');
    expect(normalizeYouTubeUrlForDedupe(shortLink)).toBe('yt:dqw4w9wgxcq');
    expect(normalizeYouTubeUrlForDedupe(shortsUrl)).toBe('yt:dqw4w9wgxcq');

    const keyA = buildInspirationDedupeKey({
      channelProfileId: 7,
      originalVideoUrl: watchUrl,
      originalVideoTitle: 'Original Video Title',
      inspirationCategory: 'video_topic',
    });
    const keyB = buildInspirationDedupeKey({
      channelProfileId: 7,
      originalVideoUrl: shortLink,
      originalVideoTitle: 'Original Video Title',
      inspirationCategory: 'video_topic',
    });
    const keyDifferentCategory = buildInspirationDedupeKey({
      channelProfileId: 7,
      originalVideoUrl: watchUrl,
      originalVideoTitle: 'Original Video Title',
      inspirationCategory: 'thumbnail_concept',
    });
    const keyDifferentChannel = buildInspirationDedupeKey({
      channelProfileId: 8,
      originalVideoUrl: watchUrl,
      originalVideoTitle: 'Original Video Title',
      inspirationCategory: 'video_topic',
    });

    expect(keyA).toBe(keyB);
    expect(keyA).not.toBe(keyDifferentCategory);
    expect(keyA).not.toBe(keyDifferentChannel);
  });

  it('parses planner production checklists safely and falls back to default checklist when empty', () => {
    const fallback = parsePlannerChecklist(null);
    expect(fallback.length).toBe(YTM_DEFAULT_PRODUCTION_CHECKLIST.length);
    expect(fallback.every((item) => item.done === false)).toBe(true);

    const parsed = parsePlannerChecklist(
      JSON.stringify([
        { id: 'research', label: 'Research done', done: true },
        { id: 'script', label: 'Script drafted', done: false },
      ])
    );
    expect(parsed).toEqual([
      { id: 'research', label: 'Research done', done: true },
      { id: 'script', label: 'Script drafted', done: false },
    ]);
  });
});

describe('YouTube Management OS — Channel DNA, AI Strategy Calendar Audit & Stage 4 Community Posts', () => {
  it('injects all extended Channel DNA attributes into AI prompts', () => {
    const profile = {
      id: 99,
      workspaceId: 12,
      userId: 3,
      youtubeChannelId: null,
      channelName: 'Creator Ops Lab',
      channelHandle: '@creatoropslab',
      description: 'Systems for independent YouTube educators',
      niche: 'Creator Economy',
      subNiche: 'Educational Video Systems',
      isDefault: true,
      createdAt: '2026-01-01T00:00:00.000Z',
      updatedAt: '2026-01-01T00:00:00.000Z',
      dna: {
        ...defaultChannelDna(),
        targetAudience: 'Solo educators scaling past 10k subscribers',
        audienceProblems: ['Burnout from chaotic uploads', 'Flat 30-second retention'],
        preferredFormats: ['Deep-dive teardowns', 'Weekly Shorts recaps'],
        brandVoice: 'Direct, evidence-backed mentor',
        publishingPreferences: '1 long-form every Tuesday, 2 Shorts Thu/Sat',
        contentRules: 'Never invent statistics; show real retention graphs',
        creativeGuidelines: 'High-contrast 2-word thumbnails, warm slate accents',
      },
    };

    const prompt = formatChannelDnaForPrompt(profile);
    expect(prompt).toContain('Burnout from chaotic uploads');
    expect(prompt).toContain('Deep-dive teardowns');
    expect(prompt).toContain('Direct, evidence-backed mentor');
    expect(prompt).toContain('1 long-form every Tuesday');
    expect(prompt).toContain('Never invent statistics');
    expect(prompt).toContain('High-contrast 2-word thumbnails');
  });

  it('exposes all 5 YouTube Community Post formats and Stage 4 dual-mode metadata', () => {
    expect(YTM_COMMUNITY_POST_FORMATS.map((f) => f.id)).toEqual([
      'quiz',
      'text_poll',
      'image_poll',
      'image_post',
      'simple_text',
    ]);
    const stage4 = YTM_WORKFLOW_STAGES.find((s) => s.stage === 4);
    expect(stage4?.label).toContain('Thumbnail');
    expect(stage4?.label).toContain('Post');
  });

  it('audits real planner projects and tasks for missed deadlines, date overlaps, overloaded weeks, and gaps', () => {
    const baseProject = {
      workspaceId: 1,
      assigneeUserId: null,
      topic: 'Channel systems',
      description: '',
      notes: '',
      targetAudience: 'Creators',
      category: 'Education',
      status: 'Scripting',
      priority: 'medium' as const,
      recurrenceRule: 'none' as const,
      workflowProjectId: null,
      channelProfileId: null,
      savedInspirationId: null,
      adaptedIdeaId: null,
      inspirationSourceLabel: '',
      inspirationSourceUrl: '',
      adaptedAngle: '',
      productionChecklist: [],
      createdAt: '2026-05-01T00:00:00.000Z',
      updatedAt: '2026-05-01T00:00:00.000Z',
    };

    const audit = buildDeterministicCalendarAudit({
      todayKey: '2026-05-10',
      availableHoursPerWeek: 8,
      projects: [
        {
          ...baseProject,
          id: 1,
          title: 'Overdue Video',
          plannedDate: '2026-05-04',
          deadline: '2026-05-04',
        },
        {
          ...baseProject,
          id: 2,
          title: 'Overlap A',
          plannedDate: '2026-05-12',
          deadline: '2026-05-12',
        },
        {
          ...baseProject,
          id: 3,
          title: 'Overlap B',
          plannedDate: '2026-05-12',
          deadline: '2026-05-12',
        },
        {
          ...baseProject,
          id: 4,
          title: 'Overload C',
          plannedDate: '2026-05-13',
          deadline: '2026-05-13',
        },
        {
          ...baseProject,
          id: 5,
          title: 'Overload D',
          plannedDate: '2026-05-14',
          deadline: '2026-05-14',
        },
        {
          ...baseProject,
          id: 6,
          title: 'Far Future After Gap',
          plannedDate: '2026-06-05',
          deadline: '2026-06-05',
        },
      ],
      tasks: [
        {
          id: 101,
          workspaceId: 1,
          plannerProjectId: 1,
          assigneeUserId: null,
          taskName: 'Record A-roll',
          workspaceSection: 'workflow',
          scheduledAt: '2026-05-05',
          deadline: '2026-05-06',
          priority: 'high',
          status: 'In Progress',
          aiSuggested: false,
          createdAt: '2026-05-01T00:00:00.000Z',
          updatedAt: '2026-05-01T00:00:00.000Z',
        },
      ],
    });

    const issueTypes = new Set(audit.suggestions.map((s) => s.issueType));
    expect(audit.missedDeadlinesCount).toBe(2);
    expect(audit.overlappingDeadlinesCount).toBeGreaterThanOrEqual(1);
    expect(audit.overloadedWeeksCount).toBeGreaterThanOrEqual(1);
    expect(audit.publishingGapsCount).toBeGreaterThanOrEqual(1);
    expect(issueTypes.has('missed_deadline')).toBe(true);
    expect(issueTypes.has('overlapping_deadlines')).toBe(true);
    expect(issueTypes.has('overloaded_week')).toBe(true);
    expect(issueTypes.has('publishing_gap')).toBe(true);
    expect(audit.healthSummary.length).toBeGreaterThan(10);
  });
});


