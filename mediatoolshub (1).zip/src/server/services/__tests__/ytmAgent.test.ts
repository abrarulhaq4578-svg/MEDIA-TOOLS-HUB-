import { describe, expect, it } from 'vitest';
import {
  evaluateToolAuthorization,
  getAgentToolsMetadata,
  getFunctionDeclarationsForMode,
  YTM_AGENT_TOOL_MAP,
  YTM_AGENT_TOOLS,
} from '../ytmAgentTools.ts';

describe('YouTube OS AI Agent Tool Registry & Safety Matrix', () => {
  it('registers unique, schema-complete YouTube OS tools across read, write, and sensitive categories', () => {
    expect(YTM_AGENT_TOOLS.length).toBeGreaterThanOrEqual(18);
    const names = new Set(YTM_AGENT_TOOLS.map((t) => t.name));
    expect(names.size).toBe(YTM_AGENT_TOOLS.length);

    for (const tool of YTM_AGENT_TOOLS) {
      expect(tool.declaration.name).toBe(tool.name);
      expect(tool.description.length).toBeGreaterThan(10);
      expect(['read', 'write', 'sensitive']).toContain(tool.actionCategory);
      if (tool.actionCategory === 'sensitive') {
        expect(tool.alwaysRequiresApproval).toBe(true);
      }
    }

    const meta = getAgentToolsMetadata();
    expect(meta.length).toBe(YTM_AGENT_TOOLS.length);
  });

  it('exposes ONLY read-only function declarations to Gemini when in chat mode', () => {
    const chatDecls = getFunctionDeclarationsForMode('chat');
    const autopilotDecls = getFunctionDeclarationsForMode('autopilot');
    expect(chatDecls.length).toBeGreaterThan(0);
    expect(chatDecls.length).toBeLessThan(autopilotDecls.length);

    for (const decl of chatDecls) {
      const def = YTM_AGENT_TOOL_MAP.get(decl.name || '');
      expect(def?.actionCategory).toBe('read');
    }
  });

  it('enforces chat (read-only), assist (confirm writes), and autopilot (confirm sensitive) rules', () => {
    const readTool = YTM_AGENT_TOOL_MAP.get('get_channel_dna')!;
    const writeTool = YTM_AGENT_TOOL_MAP.get('create_workflow_project')!;
    const sensitiveTool = YTM_AGENT_TOOL_MAP.get('delete_planner_item')!;

    // Chat mode
    expect(
      evaluateToolAuthorization({
        tool: readTool,
        mode: 'chat',
        role: 'owner',
        approvalRequiredActions: [],
      })
    ).toEqual({ allowed: true, requiresApproval: false });

    const chatWrite = evaluateToolAuthorization({
      tool: writeTool,
      mode: 'chat',
      role: 'owner',
      approvalRequiredActions: [],
    });
    expect(chatWrite.allowed).toBe(false);

    // Assist mode: read auto-runs, write requires approval, sensitive requires approval
    expect(
      evaluateToolAuthorization({
        tool: readTool,
        mode: 'assist',
        role: 'owner',
        approvalRequiredActions: [],
      })
    ).toEqual({ allowed: true, requiresApproval: false });

    const assistWrite = evaluateToolAuthorization({
      tool: writeTool,
      mode: 'assist',
      role: 'owner',
      approvalRequiredActions: [],
    });
    expect(assistWrite.allowed).toBe(true);
    expect(assistWrite.requiresApproval).toBe(true);

    // Autopilot mode: write auto-runs unless user opted in to approval; sensitive ALWAYS requires approval
    expect(
      evaluateToolAuthorization({
        tool: writeTool,
        mode: 'autopilot',
        role: 'owner',
        approvalRequiredActions: [],
      })
    ).toEqual({ allowed: true, requiresApproval: false });

    const autopilotCustomConfirm = evaluateToolAuthorization({
      tool: writeTool,
      mode: 'autopilot',
      role: 'owner',
      approvalRequiredActions: ['create_workflow_project'],
    });
    expect(autopilotCustomConfirm.allowed).toBe(true);
    expect(autopilotCustomConfirm.requiresApproval).toBe(true);

    const autopilotSensitive = evaluateToolAuthorization({
      tool: sensitiveTool,
      mode: 'autopilot',
      role: 'owner',
      approvalRequiredActions: [],
    });
    expect(autopilotSensitive.allowed).toBe(true);
    expect(autopilotSensitive.requiresApproval).toBe(true);
  });

  it('enforces workspace RBAC permissions even in autopilot mode', () => {
    const writeTool = YTM_AGENT_TOOL_MAP.get('create_workflow_project')!;
    const viewerDecision = evaluateToolAuthorization({
      tool: writeTool,
      mode: 'autopilot',
      role: 'viewer',
      approvalRequiredActions: [],
    });
    expect(viewerDecision.allowed).toBe(false);
    expect(viewerDecision.reason).toContain('viewer');
  });
});
