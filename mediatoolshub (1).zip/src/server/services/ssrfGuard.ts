import dns from 'node:dns/promises';
import net from 'node:net';

const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  'localhost.localdomain',
  'metadata.google.internal',
  'metadata',
  '169.254.169.254',
]);

export function isPrivateOrReservedIp(ip: string): boolean {
  const normalized = ip.trim().toLowerCase();

  if (normalized.startsWith('::ffff:')) {
    return isPrivateOrReservedIp(normalized.slice(7));
  }

  const version = net.isIP(normalized);
  if (version === 4) {
    const parts = normalized.split('.').map((n) => Number.parseInt(n, 10));
    if (parts.length !== 4 || parts.some((n) => Number.isNaN(n) || n < 0 || n > 255)) {
      return true;
    }
    const [a, b] = parts;
    if (a === 0) return true; // 0.0.0.0/8
    if (a === 10) return true; // 10.0.0.0/8
    if (a === 100 && b >= 64 && b <= 127) return true; // 100.64.0.0/10 CGNAT
    if (a === 127) return true; // 127.0.0.0/8 loopback
    if (a === 169 && b === 254) return true; // 169.254.0.0/16 link-local & cloud metadata
    if (a === 172 && b >= 16 && b <= 31) return true; // 172.16.0.0/12
    if (a === 192 && b === 0) return true; // 192.0.0.0/24
    if (a === 192 && b === 168) return true; // 192.168.0.0/16
    if (a === 198 && (b === 18 || b === 19)) return true; // 198.18.0.0/15 benchmark
    if (a >= 224) return true; // Multicast & reserved
    return false;
  }

  if (version === 6) {
    if (normalized === '::' || normalized === '::1') return true;
    if (normalized.startsWith('fc') || normalized.startsWith('fd')) return true; // fc00::/7 ULA
    if (
      normalized.startsWith('fe8') ||
      normalized.startsWith('fe9') ||
      normalized.startsWith('fea') ||
      normalized.startsWith('feb')
    ) {
      return true; // fe80::/10 link-local
    }
    if (normalized.startsWith('ff')) return true; // multicast
    return false;
  }

  return true;
}

export interface SsrfCheckResult {
  safe: boolean;
  url?: URL;
  reason?: string;
}

export function validateUrlSyntaxOnly(rawUrl: string): SsrfCheckResult {
  const trimmed = rawUrl.trim();
  if (!trimmed || trimmed.length > 2048) {
    return { safe: false, reason: 'URL must be between 1 and 2048 characters.' };
  }

  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return { safe: false, reason: 'Invalid URL format. Include https:// or http://.' };
  }

  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return { safe: false, reason: 'Only HTTP and HTTPS protocols are permitted.' };
  }

  if (parsed.username || parsed.password) {
    return { safe: false, reason: 'Embedded URL credentials are not permitted.' };
  }

  const host = parsed.hostname.toLowerCase();
  if (
    BLOCKED_HOSTNAMES.has(host) ||
    host.endsWith('.local') ||
    host.endsWith('.internal') ||
    host.endsWith('.localhost')
  ) {
    return { safe: false, reason: 'Internal or reserved hostnames are blocked.' };
  }

  if (net.isIP(host) && isPrivateOrReservedIp(host)) {
    return { safe: false, reason: 'Private, loopback, or metadata IP addresses are blocked.' };
  }

  return { safe: true, url: parsed };
}

export async function validatePublicUrl(rawUrl: string): Promise<SsrfCheckResult> {
  const syntax = validateUrlSyntaxOnly(rawUrl);
  if (!syntax.safe || !syntax.url) {
    return syntax;
  }

  const host = syntax.url.hostname.toLowerCase();
  if (net.isIP(host)) {
    if (isPrivateOrReservedIp(host)) {
      return { safe: false, reason: 'Private or reserved IP addresses are blocked.' };
    }
    return syntax;
  }

  try {
    const records = await dns.lookup(host, { all: true });
    if (!records.length) {
      return { safe: false, reason: 'Hostname could not be resolved.' };
    }
    for (const rec of records) {
      if (isPrivateOrReservedIp(rec.address)) {
        return {
          safe: false,
          reason: 'Resolved destination IP belongs to a restricted network range.',
        };
      }
    }
    return syntax;
  } catch {
    return { safe: false, reason: 'Unable to resolve public hostname.' };
  }
}

export async function safeFetch(
  targetUrl: string,
  options: {
    method?: 'GET' | 'HEAD';
    headers?: Record<string, string>;
    timeoutMs?: number;
    maxRedirects?: number;
    allowedHosts?: string[];
  } = {}
): Promise<Response> {
  const maxRedirects = options.maxRedirects ?? 3;
  const timeoutMs = options.timeoutMs ?? 8000;
  let currentUrl = targetUrl;

  for (let hop = 0; hop <= maxRedirects; hop += 1) {
    const check = await validatePublicUrl(currentUrl);
    if (!check.safe || !check.url) {
      throw new Error(check.reason || 'URL blocked by SSRF security policy.');
    }

    if (options.allowedHosts && options.allowedHosts.length > 0) {
      const host = check.url.hostname.toLowerCase();
      const permitted = options.allowedHosts.some(
        (allowed) => host === allowed || host.endsWith(`.${allowed}`)
      );
      if (!permitted) {
        throw new Error(`Destination host ${host} is outside the endpoint allowlist.`);
      }
    }

    const response = await fetch(check.url.toString(), {
      method: options.method ?? 'GET',
      headers: {
        'User-Agent': 'MediaToolsHub-MetadataBot/1.0 (+https://mediatoolshub.app)',
        ...options.headers,
      },
      redirect: 'manual',
      signal: AbortSignal.timeout(timeoutMs),
    });

    if (
      response.status >= 300 &&
      response.status < 400 &&
      response.headers.get('location')
    ) {
      const location = response.headers.get('location')!;
      currentUrl = new URL(location, check.url).toString();
      continue;
    }

    return response;
  }

  throw new Error('Maximum HTTP redirect limit exceeded.');
}
