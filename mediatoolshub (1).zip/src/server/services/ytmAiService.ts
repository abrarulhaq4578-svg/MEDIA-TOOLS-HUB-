import crypto from 'node:crypto';
import { GoogleGenAI, Type, type Schema } from '@google/genai';
import { getServerConfig } from '../config/env.ts';
import type {
  ScriptAiModelId,
  YtmAiRecommendation,
  YtmChannelAnalyticsReport,
  YtmDistributionPlatform,
  YtmPlannerProjectRecord,
  YtmPlannerTaskRecord,
  YtmTitleOption,
  YtmWorkflowStage2Topic,
  YtmWorkflowStage4Thumbnail,
  YtmWorkflowStage5Seo,
} from '../../shared/types.ts';
import {
  buildModelThinkingConfig,
  extractReadableAiErrorMessage,
  getOrderedModelCandidates,
  isTransientModelOverloadError,
  markHydrogenTemporarilyUnavailable,
  ScriptAiError,
} from './scriptStudioAi.ts';

function getAiClient(): GoogleGenAI {
  const cfg = getServerConfig();
  if (!cfg.geminiApiKey) {
    throw new ScriptAiError(
      'GEMINI_API_KEY is not configured on the server. Add GEMINI_API_KEY in Secrets to enable AI generation.',
      500,
      'GEMINI_API_KEY_MISSING'
    );
  }
  return new GoogleGenAI({
    apiKey: cfg.geminiApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function resolveFreeTierModel(requested?: string | null): ScriptAiModelId {
  if (requested === 'gemini-3.1-flash-lite') return 'gemini-3.1-flash-lite';
  const cfg = getServerConfig();
  return cfg.scriptAiModel || 'gemini-4-hydrogen';
}

async function withAiTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => {
          reject(
            new ScriptAiError(
              `AI request timed out after ${Math.round(timeoutMs / 1000)}s. Please retry.`,
              500,
              'AI_TIMEOUT'
            )
          );
        }, timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function runStructuredPrompt<T>(params: {
  model?: string | null;
  systemInstruction: string;
  prompt: string;
  schema: Schema;
}): Promise<T> {
  const ai = getAiClient();
  const primaryModel = resolveFreeTierModel(params.model);
  const candidates = getOrderedModelCandidates(primaryModel);
  const deadline = Date.now() + 42_000;

  let lastErr: unknown;
  for (let i = 0; i < candidates.length; i++) {
    const model = candidates[i];
    const remainingMs = deadline - Date.now();
    if (remainingMs <= 1500) break;
    const attemptTimeoutMs =
      i === 0 && candidates.length > 1
        ? Math.min(remainingMs, model === 'gemini-4-hydrogen' ? 16_000 : 24_000)
        : remainingMs;

    try {
      const response = await withAiTimeout(
        ai.models.generateContent({
          model,
          contents: params.prompt,
          config: {
            systemInstruction: params.systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: params.schema,
            ...buildModelThinkingConfig(model),
          },
        }),
        attemptTimeoutMs
      );
      const text = (response.text || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
      if (!text) {
        throw new ScriptAiError('Empty AI response received.', 500, 'AI_INVALID_RESPONSE');
      }
      return JSON.parse(text) as T;
    } catch (err: unknown) {
      lastErr = err;
      const msg = extractReadableAiErrorMessage(err);
      const lower = msg.toLowerCase();
      const isTimeout = err instanceof ScriptAiError && err.code === 'AI_TIMEOUT';
      const isQuota = lower.includes('429') || lower.includes('quota') || lower.includes('resource_exhausted');
      const isNotFound = lower.includes('not_found') || lower.includes('404');
      const shouldFallback = isTransientModelOverloadError(lower) || isTimeout || isQuota || isNotFound;

      if (model === 'gemini-4-hydrogen' && shouldFallback) {
        markHydrogenTemporarilyUnavailable(isQuota ? 10 * 60_000 : 3 * 60_000);
      }

      if (i + 1 < candidates.length && shouldFallback) {
        await new Promise((r) => setTimeout(r, 250));
        continue;
      }
      if (err instanceof ScriptAiError) throw err;
      if (isQuota) {
        throw new ScriptAiError(
          `Free-tier rate limit reached for ${model}. Retry shortly or switch to Gemini 3.1 Flash Lite.`,
          429,
          'AI_RATE_LIMITED'
        );
      }
      throw new ScriptAiError(msg, 500, 'AI_GENERATION_FAILED');
    }
  }
  if (lastErr instanceof ScriptAiError) throw lastErr;
  throw new ScriptAiError(extractReadableAiErrorMessage(lastErr), 500, 'AI_GENERATION_FAILED');
}

export async function aiYtmDailyRecommendations(params: {
  channelTitle: string | null;
  channelGoal: string;
  channelDnaPrompt?: string;
  todaysTasks: YtmPlannerTaskRecord[];
  overdueTasks: YtmPlannerTaskRecord[];
  activeProjects: YtmPlannerProjectRecord[];
}): Promise<YtmAiRecommendation[]> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      recommendations: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            rationale: { type: Type.STRING },
            suggestedAction: { type: Type.STRING },
            suggestedWorkspaceSection: { type: Type.STRING },
            suggestedPriority: { type: Type.STRING },
          },
          required: [
            'title',
            'rationale',
            'suggestedAction',
            'suggestedWorkspaceSection',
            'suggestedPriority',
          ],
        },
      },
    },
    required: ['recommendations'],
  };

  const prompt = `You are a practical YouTube Creator Operations Advisor. Suggest 3 concrete, non-generic daily actions based on the creator's REAL workspace state below.
Channel: ${params.channelTitle || 'Not connected yet'}
Channel Goal: ${params.channelGoal}
${params.channelDnaPrompt ? `\n${params.channelDnaPrompt}\n` : ''}
Today's Scheduled Tasks (${params.todaysTasks.length}): ${params.todaysTasks.map((t) => `${t.taskName} [${t.status}]`).join('; ') || 'None'}
Overdue Tasks (${params.overdueTasks.length}): ${params.overdueTasks.map((t) => t.taskName).join('; ') || 'None'}
Active Video Projects (${params.activeProjects.length}): ${params.activeProjects.slice(0, 6).map((p) => `${p.title} (${p.status})`).join('; ') || 'None'}

Note: Suggest actionable steps (e.g., planner, workflow, competitors, analytics, community, earn). Do NOT assume fake metrics.`;

  const res = await runStructuredPrompt<{
    recommendations: Array<{
      title: string;
      rationale: string;
      suggestedAction: string;
      suggestedWorkspaceSection: string;
      suggestedPriority: string;
    }>;
  }>({
    systemInstruction:
      'Return structured, honest creator workflow suggestions aligned with the active Channel DNA. Never fabricate channel performance stats.',
    prompt,
    schema,
  });

  const validSections = new Set([
    'dashboard',
    'planner',
    'competitors',
    'workflow',
    'analytics',
    'earn',
    'community',
    'team',
    'others',
  ]);
  const validPriorities = new Set(['low', 'medium', 'high', 'urgent']);

  return (res.recommendations || []).slice(0, 4).map((r) => ({
    id: `rec_${crypto.randomBytes(4).toString('hex')}`,
    title: r.title,
    rationale: r.rationale,
    suggestedAction: r.suggestedAction,
    suggestedWorkspaceSection: (validSections.has(r.suggestedWorkspaceSection)
      ? r.suggestedWorkspaceSection
      : 'workflow') as YtmAiRecommendation['suggestedWorkspaceSection'],
    suggestedPriority: (validPriorities.has(r.suggestedPriority)
      ? r.suggestedPriority
      : 'medium') as YtmAiRecommendation['suggestedPriority'],
    requiresApproval: true,
  }));
}

export async function aiYtmGenerateTitles(params: {
  seedIdea: string;
  targetAudience?: string;
  notes?: string;
  channelDnaPrompt?: string;
}): Promise<YtmTitleOption[]> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      options: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            angle: { type: Type.STRING },
            psychologicalAppeal: { type: Type.STRING },
            curiosityGap: { type: Type.STRING },
          },
          required: ['title', 'angle', 'psychologicalAppeal', 'curiosityGap'],
        },
      },
    },
    required: ['options'],
  };

  const res = await runStructuredPrompt<{ options: Array<Omit<YtmTitleOption, 'id'>> }>({
    systemInstruction:
      'Generate 5 high-CTR, honest, original YouTube titles across distinct psychological angles (curiosity, outcome, contrarian, mistake-avoidance, story). Respect the active Channel DNA voice, preferred language, title preferences, and words to use/avoid. No misleading clickbait.',
    prompt: `${params.channelDnaPrompt ? `${params.channelDnaPrompt}\n\n` : ''}Seed Video Idea: "${params.seedIdea}"
Audience: ${params.targetAudience || 'Curious YouTube viewers'}
Additional Notes: ${params.notes || 'None'}`,
    schema,
  });

  return (res.options || []).slice(0, 5).map((o, idx) => ({
    id: `title_opt_${idx + 1}_${crypto.randomBytes(3).toString('hex')}`,
    title: o.title,
    angle: o.angle,
    psychologicalAppeal: o.psychologicalAppeal,
    curiosityGap: o.curiosityGap,
    isSelected: idx === 0,
  }));
}

export async function aiYtmExpandTopic(params: {
  selectedTitle: string;
  seedIdea: string;
  notes?: string;
  channelDnaPrompt?: string;
}): Promise<YtmWorkflowStage2Topic> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      centralTopic: { type: Type.STRING },
      targetAudience: { type: Type.STRING },
      coreProblem: { type: Type.STRING },
      desiredOutcome: { type: Type.STRING },
      valueAngle: { type: Type.STRING },
      supportingPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
    },
    required: [
      'centralTopic',
      'targetAudience',
      'coreProblem',
      'desiredOutcome',
      'valueAngle',
      'supportingPoints',
    ],
  };

  const res = await runStructuredPrompt<Omit<YtmWorkflowStage2Topic, 'notes'>>({
    systemInstruction:
      'Clarify the video topic thesis before scripting so the promise matches the title cleanly and reflects the active Channel DNA positioning and storytelling approach.',
    prompt: `${params.channelDnaPrompt ? `${params.channelDnaPrompt}\n\n` : ''}Title: "${params.selectedTitle}"\nSeed Idea: "${params.seedIdea}"\nCreator Notes: ${params.notes || 'None'}`,
    schema,
  });

  return {
    ...res,
    notes: params.notes || '',
  };
}

export async function aiYtmGenerateThumbnails(params: {
  title: string;
  topicSummary: string;
  notes?: string;
  channelDnaPrompt?: string;
}): Promise<YtmWorkflowStage4Thumbnail['concepts']> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      concepts: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            conceptName: { type: Type.STRING },
            mainSubject: { type: Type.STRING },
            composition: { type: Type.STRING },
            colorContrast: { type: Type.STRING },
            emotion: { type: Type.STRING },
            textOverlayOptions: { type: Type.ARRAY, items: { type: Type.STRING } },
            imagePrompt: { type: Type.STRING },
          },
          required: [
            'conceptName',
            'mainSubject',
            'composition',
            'colorContrast',
            'emotion',
            'textOverlayOptions',
            'imagePrompt',
          ],
        },
      },
    },
    required: ['concepts'],
  };

  const res = await runStructuredPrompt<{
    concepts: Array<Omit<YtmWorkflowStage4Thumbnail['concepts'][number], 'id'>>;
  }>({
    systemInstruction:
      'Design 3 distinct high-contrast YouTube thumbnail concepts with 2-4 word mobile-readable text overlays and a detailed 16:9 image-generation prompt for each. Respect the active Channel DNA thumbnail design preferences, color palette, and typography.',
    prompt: `${params.channelDnaPrompt ? `${params.channelDnaPrompt}\n\n` : ''}Video Title: "${params.title}"\nTopic Context: ${params.topicSummary}\nNotes: ${params.notes || 'None'}`,
    schema,
  });

  return (res.concepts || []).slice(0, 3).map((c, idx) => ({
    id: `th_c_${idx + 1}_${crypto.randomBytes(3).toString('hex')}`,
    ...c,
  }));
}

export async function aiYtmGenerateSeo(params: {
  title: string;
  topicSummary: string;
  scriptExcerpt?: string;
  channelDnaPrompt?: string;
}): Promise<YtmWorkflowStage5Seo> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      description: { type: Type.STRING },
      keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
      tags: { type: Type.ARRAY, items: { type: Type.STRING } },
      hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
      chapters: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            timestamp: { type: Type.STRING },
            title: { type: Type.STRING },
          },
          required: ['timestamp', 'title'],
        },
      },
      pinnedComment: { type: Type.STRING },
      playlistRecommendation: { type: Type.STRING },
    },
    required: [
      'description',
      'keywords',
      'tags',
      'hashtags',
      'chapters',
      'pinnedComment',
      'playlistRecommendation',
    ],
  };

  const res = await runStructuredPrompt<Omit<YtmWorkflowStage5Seo, 'uploadChecklist'>>({
    systemInstruction:
      'Create an authentic, non-spammy YouTube SEO optimization package matching the video content and active Channel DNA tone, preferred language, and niche.',
    prompt: `${params.channelDnaPrompt ? `${params.channelDnaPrompt}\n\n` : ''}Title: "${params.title}"\nTopic Summary: ${params.topicSummary}\nScript Excerpt: ${(
      params.scriptExcerpt || ''
    ).slice(0, 2000)}`,
    schema,
  });

  return {
    ...res,
    uploadChecklist: [
      { item: 'Title & 16:9 thumbnail reinforce each other without repeating text', checked: false },
      { item: 'First two lines of description state clear viewer payoff', checked: false },
      { item: 'End screen & related video card planned', checked: false },
      { item: 'Pinned comment ready to post after upload', checked: false },
    ],
  };
}

export async function aiYtmGenerateDistribution(params: {
  title: string;
  topicSummary: string;
  youtubeVideoUrl?: string | null;
  platforms: YtmDistributionPlatform[];
  channelDnaPrompt?: string;
}): Promise<
  Array<{
    platform: YtmDistributionPlatform;
    assetType: string;
    title: string;
    bodyCopy: string;
    hashtags: string;
    carouselSlides: string[];
    imagePrompt: string;
  }>
> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      assets: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            platform: { type: Type.STRING },
            assetType: { type: Type.STRING },
            title: { type: Type.STRING },
            bodyCopy: { type: Type.STRING },
            hashtags: { type: Type.STRING },
            carouselSlides: { type: Type.ARRAY, items: { type: Type.STRING } },
            imagePrompt: { type: Type.STRING },
          },
          required: ['platform', 'assetType', 'title', 'bodyCopy', 'hashtags', 'carouselSlides', 'imagePrompt'],
        },
      },
    },
    required: ['assets'],
  };

  const prompt = `${params.channelDnaPrompt ? `${params.channelDnaPrompt}\n\n` : ''}Generate tailored promotional social assets for this YouTube video across EACH requested platform: ${params.platforms.join(', ')}.
Video Title: "${params.title}"
Topic Summary: ${params.topicSummary}
YouTube Video Link: ${params.youtubeVideoUrl || '[Add YouTube Link Here Once Published]'}

Return one distinct asset per requested platform matching its native format (Instagram caption/carousel slides, Facebook post, Pinterest pin copy, YouTube Community post/poll, WhatsApp broadcast, X thread/post, YouTube Shorts teaser script, Telegram announcement).`;

  const res = await runStructuredPrompt<{
    assets: Array<{
      platform: string;
      assetType: string;
      title: string;
      bodyCopy: string;
      hashtags: string;
      carouselSlides: string[];
      imagePrompt: string;
    }>;
  }>({
    systemInstruction:
      'Craft native, human-sounding promotional copy tailored to each social network and faithful to the active Channel DNA voice and audience. Return an entry for every requested platform.',
    prompt,
    schema,
  });

  return params.platforms.map((plat) => {
    const matched = res.assets.find((a) => a.platform === plat);
    if (matched) {
      return {
        platform: plat,
        assetType: matched.assetType || 'post',
        title: matched.title || params.title,
        bodyCopy: matched.bodyCopy || '',
        hashtags: matched.hashtags || '',
        carouselSlides: matched.carouselSlides || [],
        imagePrompt: matched.imagePrompt || '',
      };
    }
    return {
      platform: plat,
      assetType: 'post',
      title: params.title,
      bodyCopy: `New video: ${params.title}\n\n${params.topicSummary}`,
      hashtags: '',
      carouselSlides: [],
      imagePrompt: `Visual promotional graphic for "${params.title}"`,
    };
  });
}

export async function aiYtmAdaptInspirationForChannel(params: {
  originalVideoTitle: string;
  originalVideoUrl: string;
  competitorChannelName: string;
  inspirationCategory: string;
  inspirationSnippet: string;
  userNotes: string;
  channelDnaPrompt: string;
  creatorDirection?: string;
}): Promise<{
  originalConceptSummary: string;
  whyItWorks: string;
  freshAngle: string;
  titleOptions: string[];
  uniqueHook: string;
  videoOutline: string[];
  thumbnailDirection: string;
  channelFitExplanation: string;
}> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      originalConceptSummary: { type: Type.STRING },
      whyItWorks: { type: Type.STRING },
      freshAngle: { type: Type.STRING },
      titleOptions: { type: Type.ARRAY, items: { type: Type.STRING } },
      uniqueHook: { type: Type.STRING },
      videoOutline: { type: Type.ARRAY, items: { type: Type.STRING } },
      thumbnailDirection: { type: Type.STRING },
      channelFitExplanation: { type: Type.STRING },
    },
    required: [
      'originalConceptSummary',
      'whyItWorks',
      'freshAngle',
      'titleOptions',
      'uniqueHook',
      'videoOutline',
      'thumbnailDirection',
      'channelFitExplanation',
    ],
  };

  const prompt = `${params.channelDnaPrompt}

SAVED COMPETITOR INSPIRATION TO ADAPT (DO NOT COPY — CREATE AN ORIGINAL DIFFERENTIATED VIDEO CONCEPT):
- Inspiration Category: ${params.inspirationCategory}
- Competitor Channel: ${params.competitorChannelName || 'Unknown competitor'}
- Competitor Video / Reference Title: "${params.originalVideoTitle}"
- Reference URL: ${params.originalVideoUrl || 'Not provided'}
- Saved Detail / Observation: ${params.inspirationSnippet || 'None'}
- Creator's Personal Notes: ${params.userNotes || 'None'}
- Extra Adaptation Direction: ${params.creatorDirection || 'None'}

Produce a genuinely original video adaptation for the active channel:
1. originalConceptSummary: Concise breakdown of the underlying idea that caught the creator's attention (without copying verbatim text).
2. whyItWorks: Viewer psychology, curiosity mechanism, or structural reason this resonates.
3. freshAngle: A clearly differentiated angle tailored to our channel's niche, target audience, and unique positioning.
4. titleOptions: 5 original title options written in our channel's preferred language, tone, and title preferences — NEVER reuse or lightly rephrase the competitor's exact title.
5. uniqueHook: An original 15–30 second opening hook written in our channel's tone of voice and storytelling approach.
6. videoOutline: 5–7 structured sections following our channel's script structure and preferred video duration.
7. thumbnailDirection: Concrete visual thumbnail direction aligned with our channel's thumbnail preferences, color palette, and typography.
8. channelFitExplanation: Specific explanation of why this adapted version fits our Channel DNA and avoids any words/styles on our avoid list.`;

  const res = await runStructuredPrompt<{
    originalConceptSummary: string;
    whyItWorks: string;
    freshAngle: string;
    titleOptions: string[];
    uniqueHook: string;
    videoOutline: string[];
    thumbnailDirection: string;
    channelFitExplanation: string;
  }>({
    systemInstruction:
      'You are a YouTube Creative Strategist. Transform competitor inspiration into 100% original, differentiated channel-specific video concepts grounded strictly in the creator’s Channel DNA. Never copy competitor scripts or exact titles, and strictly avoid forbidden words/styles.',
    prompt,
    schema,
  });

  return {
    originalConceptSummary: res.originalConceptSummary || '',
    whyItWorks: res.whyItWorks || '',
    freshAngle: res.freshAngle || '',
    titleOptions: (res.titleOptions || []).filter(Boolean).slice(0, 6),
    uniqueHook: res.uniqueHook || '',
    videoOutline: (res.videoOutline || []).filter(Boolean).slice(0, 10),
    thumbnailDirection: res.thumbnailDirection || '',
    channelFitExplanation: res.channelFitExplanation || '',
  };
}

export async function aiYtmSuggestDailyPlan(params: {
  todayDateKey: string;
  channelName: string;
  channelDnaPrompt: string;
  todaysTopics: Array<{ title: string; status: string; priority: string }>;
  tasksDueToday: Array<{ taskName: string; status: string; priority: string }>;
  overdueTasks: Array<{ taskName: string; deadline: string | null }>;
  inProgressVideos: Array<{ title: string; status: string; plannedDate: string | null }>;
  savedInspirationAwaitingReview: Array<{
    originalVideoTitle: string;
    inspirationCategory: string;
    competitorChannelName: string;
  }>;
}): Promise<{
  summary: string;
  suggestedItems: Array<{
    id: string;
    title: string;
    rationale: string;
    suggestedAction: string;
    suggestedWorkspaceSection: YtmAiRecommendation['suggestedWorkspaceSection'];
    suggestedPriority: YtmAiRecommendation['suggestedPriority'];
    estimatedMinutes: number;
    status: 'pending';
  }>;
}> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      summary: { type: Type.STRING },
      suggestedItems: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            rationale: { type: Type.STRING },
            suggestedAction: { type: Type.STRING },
            suggestedWorkspaceSection: { type: Type.STRING },
            suggestedPriority: { type: Type.STRING },
            estimatedMinutes: { type: Type.INTEGER },
          },
          required: [
            'title',
            'rationale',
            'suggestedAction',
            'suggestedWorkspaceSection',
            'suggestedPriority',
            'estimatedMinutes',
          ],
        },
      },
    },
    required: ['summary', 'suggestedItems'],
  };

  const prompt = `Build a realistic, focused daily creator practice plan for ${params.todayDateKey} for channel "${params.channelName}".
${params.channelDnaPrompt}

CURRENT REAL WORKSPACE STATE:
- Topics planned for today (${params.todaysTopics.length}): ${
    params.todaysTopics.map((t) => `"${t.title}" [${t.status}, ${t.priority}]`).join('; ') || 'None'
  }
- Tasks due today (${params.tasksDueToday.length}): ${
    params.tasksDueToday.map((t) => `"${t.taskName}" [${t.status}]`).join('; ') || 'None'
  }
- Overdue tasks (${params.overdueTasks.length}): ${
    params.overdueTasks.map((t) => `"${t.taskName}" (due ${t.deadline || 'past'})`).join('; ') || 'None'
  }
- In-progress videos (${params.inProgressVideos.length}): ${
    params.inProgressVideos
      .slice(0, 6)
      .map((v) => `"${v.title}" [${v.status}${v.plannedDate ? `, planned ${v.plannedDate}` : ''}]`)
      .join('; ') || 'None'
  }
- Saved inspiration awaiting review (${params.savedInspirationAwaitingReview.length}): ${
    params.savedInspirationAwaitingReview
      .slice(0, 6)
      .map((i) => `"${i.originalVideoTitle}" (${i.inspirationCategory} from ${i.competitorChannelName || 'competitor'})`)
      .join('; ') || 'None'
  }

Suggest 4 practical, time-boxed steps (15–60 min each) that help the creator stay consistent today without overwhelming them. Use valid sections: dashboard, planner, competitors, workflow, analytics, community. Never fabricate stats.`;

  const res = await runStructuredPrompt<{
    summary: string;
    suggestedItems: Array<{
      title: string;
      rationale: string;
      suggestedAction: string;
      suggestedWorkspaceSection: string;
      suggestedPriority: string;
      estimatedMinutes: number;
    }>;
  }>({
    systemInstruction:
      'You are a pragmatic daily YouTube production coach. Produce concise, achievable daily practice steps grounded strictly in the creator’s real queue and Channel DNA.',
    prompt,
    schema,
  });

  const validSections = new Set([
    'dashboard',
    'planner',
    'competitors',
    'workflow',
    'analytics',
    'earn',
    'community',
    'team',
    'others',
  ]);
  const validPriorities = new Set(['low', 'medium', 'high', 'urgent']);

  return {
    summary: res.summary || `Focused daily production plan for ${params.todayDateKey}.`,
    suggestedItems: (res.suggestedItems || []).slice(0, 5).map((item) => ({
      id: `dp_${crypto.randomBytes(4).toString('hex')}`,
      title: item.title,
      rationale: item.rationale,
      suggestedAction: item.suggestedAction,
      suggestedWorkspaceSection: (validSections.has(item.suggestedWorkspaceSection)
        ? item.suggestedWorkspaceSection
        : 'planner') as YtmAiRecommendation['suggestedWorkspaceSection'],
      suggestedPriority: (validPriorities.has(item.suggestedPriority)
        ? item.suggestedPriority
        : 'medium') as YtmAiRecommendation['suggestedPriority'],
      estimatedMinutes: Math.min(180, Math.max(10, Number(item.estimatedMinutes) || 25)),
      status: 'pending' as const,
    })),
  };
}

export async function aiYtmAnalyticsInsights(report: YtmChannelAnalyticsReport): Promise<{
  summary: string;
  growthExperiments: string[];
}> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      summary: { type: Type.STRING },
      growthExperiments: { type: Type.ARRAY, items: { type: Type.STRING } },
    },
    required: ['summary', 'growthExperiments'],
  };

  const prompt = `Analyze ONLY the real YouTube Analytics data below for channel "${report.channelTitle}" (${report.dateRangeStart} to ${report.dateRangeEnd}).
Views: ${report.totals.views ?? 'Unavailable'}
Watch Time (mins): ${report.totals.estimatedMinutesWatched ?? 'Unavailable'}
Avg View Duration (sec): ${report.totals.averageViewDurationSec ?? 'Unavailable'}
Subscribers Gained/Lost: +${report.totals.subscribersGained ?? 0} / -${report.totals.subscribersLost ?? 0}
Top Traffic Sources: ${report.trafficSources.slice(0, 5).map((t) => `${t.sourceType}: ${t.views} views`).join('; ') || 'None'}
Top Videos: ${report.topVideos.slice(0, 5).map((v) => `"${v.title}" (${v.views} views, ${v.averageViewDurationSec}s avg dur)`).join('; ') || 'None'}

Note: Impressions and CTR are unavailable from this API response — do NOT guess or invent them.`;

  return runStructuredPrompt<{ summary: string; growthExperiments: string[] }>({
    systemInstruction:
      'Summarize channel performance strictly from provided API metrics and suggest 3 testable growth experiments.',
    prompt,
    schema,
  });
}

export async function aiYtmDraftCommentReply(params: {
  commentText: string;
  authorName: string;
  videoTitle?: string | null;
  tone?: string;
}): Promise<string> {
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      draftReply: { type: Type.STRING },
    },
    required: ['draftReply'],
  };

  const res = await runStructuredPrompt<{ draftReply: string }>({
    systemInstruction:
      'Draft a warm, helpful, concise YouTube creator reply ready for creator review before publishing.',
    prompt: `Viewer Name: ${params.authorName}
Video: ${params.videoTitle || 'Channel video'}
Comment: "${params.commentText}"
Desired Tone: ${params.tone || 'Helpful, human, appreciative'}`,
    schema,
  });
  return res.draftReply || '';
}
