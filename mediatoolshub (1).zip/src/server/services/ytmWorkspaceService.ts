import crypto from 'node:crypto';
import { and, desc, eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import {
  users,
  ytmActivityLogs,
  ytmNotifications,
  ytmWorkspaceMembers,
  ytmWorkspaces,
} from '../../db/schema.ts';
import type { YtmWorkspaceRecord, YtmWorkspaceRole } from '../../shared/types.ts';
import {
  hasYtmPermission,
  normalizeYtmRole,
  YTM_DEFAULT_PIPELINE_STATUSES,
  type YtmPermissionAction,
} from '../../shared/ytmHelpers.ts';

export class YtmAccessError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 403, code = 'FORBIDDEN') {
    super(message);
    this.name = 'YtmAccessError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

export function safeJsonParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function hydrateWorkspace(
  row: typeof ytmWorkspaces.$inferSelect,
  myRole: YtmWorkspaceRole
): YtmWorkspaceRecord {
  const parsedStatuses = safeJsonParse<string[]>(
    row.customStatusesJson,
    YTM_DEFAULT_PIPELINE_STATUSES
  );
  return {
    id: row.id,
    workspaceKey: row.workspaceKey,
    ownerUserId: row.ownerUserId,
    name: row.name,
    description: row.description,
    channelGoal: row.channelGoal,
    customStatuses:
      Array.isArray(parsedStatuses) && parsedStatuses.length > 0
        ? parsedStatuses
        : YTM_DEFAULT_PIPELINE_STATUSES,
    myRole,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function ensureDefaultWorkspaceForUser(user: {
  id: number;
  displayName?: string | null;
  email: string;
}): Promise<YtmWorkspaceRecord> {
  const memberships = await db
    .select({
      workspace: ytmWorkspaces,
      member: ytmWorkspaceMembers,
    })
    .from(ytmWorkspaceMembers)
    .innerJoin(ytmWorkspaces, eq(ytmWorkspaceMembers.workspaceId, ytmWorkspaces.id))
    .where(and(eq(ytmWorkspaceMembers.userId, user.id), eq(ytmWorkspaceMembers.status, 'active')))
    .orderBy(desc(ytmWorkspaces.updatedAt));

  if (memberships.length > 0) {
    const first = memberships[0];
    return hydrateWorkspace(first.workspace, normalizeYtmRole(first.member.role));
  }

  const owned = await db
    .select()
    .from(ytmWorkspaces)
    .where(eq(ytmWorkspaces.ownerUserId, user.id))
    .limit(1);

  if (owned[0]) {
    await db
      .insert(ytmWorkspaceMembers)
      .values({
        workspaceId: owned[0].id,
        userId: user.id,
        role: 'owner',
        invitedByUserId: user.id,
        status: 'active',
      })
      .onConflictDoNothing();
    return hydrateWorkspace(owned[0], 'owner');
  }

  const workspaceKey = `ytm_ws_${crypto.randomBytes(8).toString('hex')}`;
  const defaultName = user.displayName
    ? `${user.displayName}'s YouTube Studio`
    : 'My YouTube Creator Workspace';

  const inserted = await db
    .insert(ytmWorkspaces)
    .values({
      workspaceKey,
      ownerUserId: user.id,
      name: defaultName.slice(0, 120),
      description: 'Unified workspace for YouTube planning, scripting, SEO, publishing & analytics.',
      channelGoal: 'Publish consistent, high-retention videos every week.',
      customStatusesJson: JSON.stringify(YTM_DEFAULT_PIPELINE_STATUSES),
    })
    .returning();

  await db.insert(ytmWorkspaceMembers).values({
    workspaceId: inserted[0].id,
    userId: user.id,
    role: 'owner',
    invitedByUserId: user.id,
    status: 'active',
  });

  return hydrateWorkspace(inserted[0], 'owner');
}

export async function listUserWorkspaces(userId: number): Promise<YtmWorkspaceRecord[]> {
  const rows = await db
    .select({
      workspace: ytmWorkspaces,
      member: ytmWorkspaceMembers,
    })
    .from(ytmWorkspaceMembers)
    .innerJoin(ytmWorkspaces, eq(ytmWorkspaceMembers.workspaceId, ytmWorkspaces.id))
    .where(and(eq(ytmWorkspaceMembers.userId, userId), eq(ytmWorkspaceMembers.status, 'active')))
    .orderBy(desc(ytmWorkspaces.updatedAt));

  return rows.map((r) => hydrateWorkspace(r.workspace, normalizeYtmRole(r.member.role)));
}

export async function resolveAuthorizedWorkspace(params: {
  userId: number;
  workspaceKey?: string | null;
  requiredPermission?: YtmPermissionAction;
}): Promise<{ workspace: YtmWorkspaceRecord; role: YtmWorkspaceRole }> {
  let wsRow: typeof ytmWorkspaces.$inferSelect | undefined;

  if (params.workspaceKey) {
    const found = await db
      .select()
      .from(ytmWorkspaces)
      .where(eq(ytmWorkspaces.workspaceKey, params.workspaceKey))
      .limit(1);
    wsRow = found[0];
    if (!wsRow) {
      throw new YtmAccessError('Workspace not found.', 404, 'WORKSPACE_NOT_FOUND');
    }
  } else {
    const userRow = await db.select().from(users).where(eq(users.id, params.userId)).limit(1);
    if (!userRow[0]) {
      throw new YtmAccessError('Authenticated user profile not found.', 401, 'AUTH_REQUIRED');
    }
    const ws = await ensureDefaultWorkspaceForUser(userRow[0]);
    const role = ws.myRole;
    if (params.requiredPermission && !hasYtmPermission(role, params.requiredPermission)) {
      throw new YtmAccessError(
        `Your workspace role (${role}) is not permitted to perform "${params.requiredPermission}".`,
        403,
        'INSUFFICIENT_ROLE_PERMISSION'
      );
    }
    return { workspace: ws, role };
  }

  let role: YtmWorkspaceRole | null = null;
  if (wsRow.ownerUserId === params.userId) {
    role = 'owner';
  } else {
    const mem = await db
      .select()
      .from(ytmWorkspaceMembers)
      .where(
        and(
          eq(ytmWorkspaceMembers.workspaceId, wsRow.id),
          eq(ytmWorkspaceMembers.userId, params.userId),
          eq(ytmWorkspaceMembers.status, 'active')
        )
      )
      .limit(1);
    if (mem[0]) {
      role = normalizeYtmRole(mem[0].role);
    }
  }

  if (!role) {
    throw new YtmAccessError(
      'You do not have access to this workspace.',
      403,
      'WORKSPACE_ACCESS_DENIED'
    );
  }

  if (params.requiredPermission && !hasYtmPermission(role, params.requiredPermission)) {
    throw new YtmAccessError(
      `Your workspace role (${role}) is not permitted to perform "${params.requiredPermission}".`,
      403,
      'INSUFFICIENT_ROLE_PERMISSION'
    );
  }

  return {
    workspace: hydrateWorkspace(wsRow, role),
    role,
  };
}

export async function recordYtmActivity(params: {
  workspaceId: number;
  actorUserId?: number | null;
  actorEmail?: string | null;
  action: string;
  resourceType: string;
  resourceId?: string | number | null;
  details?: unknown;
}): Promise<void> {
  try {
    await db.insert(ytmActivityLogs).values({
      workspaceId: params.workspaceId,
      actorUserId: params.actorUserId ?? null,
      actorEmail: params.actorEmail ?? '',
      action: params.action,
      resourceType: params.resourceType,
      resourceId: params.resourceId !== undefined && params.resourceId !== null ? String(params.resourceId) : null,
      detailsJson: params.details ? JSON.stringify(params.details) : null,
    });
  } catch {
    // Non-blocking audit telemetry
  }
}

export async function createYtmNotification(params: {
  workspaceId: number;
  userId: number;
  title: string;
  message: string;
  linkSection?: string;
}): Promise<void> {
  try {
    await db.insert(ytmNotifications).values({
      workspaceId: params.workspaceId,
      userId: params.userId,
      title: params.title.slice(0, 160),
      message: params.message.slice(0, 600),
      linkSection: params.linkSection || 'dashboard',
    });
  } catch {
    // Non-blocking notification
  }
}
