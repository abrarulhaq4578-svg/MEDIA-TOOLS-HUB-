import { eq } from 'drizzle-orm';
import { db } from '../../db/index.ts';
import { competitorChannelCaches } from '../../db/schema.ts';
import {
  computeOutliersAndChannelMetrics,
  parseIso8601DurationToSeconds,
  parseYouTubeChannelInput,
  type RawFetchedVideoInput,
} from '../../shared/competitorHelpers.ts';
import type {
  CompetitorChannelCollection,
  CompetitorChannelProfile,
  CompetitorChannelSearchResult,
} from '../../shared/types.ts';
import { getServerConfig } from '../config/env.ts';
import { fetchYouTubeTranscript } from './mediaExtractor.ts';
import { safeFetch } from './ssrfGuard.ts';

const CHANNEL_CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 hours
const YT_BASE = 'https://www.googleapis.com/youtube/v3';

export class CollectorError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 502, code = 'YOUTUBE_COLLECTION_FAILED') {
    super(message);
    this.name = 'CollectorError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

function requireYoutubeApiKey(): string {
  const { youtubeApiKey } = getServerConfig();
  if (!youtubeApiKey) {
    throw new CollectorError(
      'YouTube Data API v3 is not configured on the server. Add YOUTUBE_API_KEY in Settings > Secrets to resolve channels and collect live public competitor metrics.',
      503,
      'YOUTUBE_API_KEY_MISSING'
    );
  }
  return youtubeApiKey;
}

interface YouTubeApiChannelItem {
  id?: string;
  snippet?: {
    title?: string;
    description?: string;
    customUrl?: string;
    publishedAt?: string;
    country?: string;
    thumbnails?: {
      high?: { url?: string };
      medium?: { url?: string };
      default?: { url?: string };
    };
  };
  statistics?: {
    viewCount?: string;
    subscriberCount?: string;
    hiddenSubscriberCount?: boolean;
    videoCount?: string;
  };
  contentDetails?: {
    relatedPlaylists?: {
      uploads?: string;
    };
  };
}

interface YouTubeApiSearchItem {
  id?: { channelId?: string };
  snippet?: {
    channelId?: string;
    title?: string;
    description?: string;
    publishedAt?: string;
    thumbnails?: {
      high?: { url?: string };
      medium?: { url?: string };
      default?: { url?: string };
    };
  };
}

interface YouTubeApiPlaylistItem {
  contentDetails?: {
    videoId?: string;
    videoPublishedAt?: string;
  };
  snippet?: {
    resourceId?: { videoId?: string };
  };
}

interface YouTubeApiVideoItem {
  id?: string;
  snippet?: {
    channelId?: string;
    channelTitle?: string;
    title?: string;
    description?: string;
    publishedAt?: string;
    tags?: string[];
    thumbnails?: {
      maxres?: { url?: string };
      standard?: { url?: string };
      high?: { url?: string };
      medium?: { url?: string };
      default?: { url?: string };
    };
  };
  contentDetails?: {
    duration?: string;
  };
  statistics?: {
    viewCount?: string;
    likeCount?: string;
    commentCount?: string;
  };
}

function parseOptionalInt(raw: string | undefined): number | null {
  if (raw === undefined || raw === null || raw === '') return null;
  const parsed = Number.parseInt(raw, 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
}

async function fetchYouTubeJson<T>(url: string): Promise<T> {
  const res = await safeFetch(url, {
    allowedHosts: ['www.googleapis.com'],
    timeoutMs: 12_000,
  });

  if (!res.ok) {
    let reason = `HTTP ${res.status}`;
    try {
      const errBody = (await res.json()) as {
        error?: { message?: string; errors?: Array<{ reason?: string }> };
      };
      const apiReason = errBody.error?.errors?.[0]?.reason;
      const apiMsg = errBody.error?.message;
      if (apiReason === 'quotaExceeded' || apiReason === 'dailyLimitExceeded') {
        throw new CollectorError(
          'The server YouTube Data API v3 daily quota has been reached. Try again later or analyze cached channels.',
          429,
          'YOUTUBE_QUOTA_EXCEEDED'
        );
      }
      if (apiMsg) reason = apiMsg;
    } catch (e) {
      if (e instanceof CollectorError) throw e;
    }

    if (res.status === 403 || res.status === 400) {
      throw new CollectorError(
        `YouTube Data API v3 rejected the request: ${reason}`,
        res.status,
        'YOUTUBE_API_ERROR'
      );
    }
    throw new CollectorError(
      `Failed to fetch YouTube data (${reason}).`,
      res.status >= 500 ? 502 : res.status,
      'YOUTUBE_API_ERROR'
    );
  }

  return (await res.json()) as T;
}

function mapChannelItemToProfile(
  item: YouTubeApiChannelItem,
  retrievedAt: string
): CompetitorChannelProfile {
  const channelId = item.id || '';
  const hiddenSubscriberCount = Boolean(item.statistics?.hiddenSubscriberCount);
  const subscriberCount = hiddenSubscriberCount
    ? null
    : parseOptionalInt(item.statistics?.subscriberCount);
  const customUrl = item.snippet?.customUrl || null;
  const handle = customUrl && customUrl.startsWith('@') ? customUrl : null;
  const thumb =
    item.snippet?.thumbnails?.high?.url ||
    item.snippet?.thumbnails?.medium?.url ||
    item.snippet?.thumbnails?.default?.url ||
    null;

  return {
    channelId,
    title: item.snippet?.title || 'Untitled YouTube Channel',
    handle,
    customUrl,
    channelUrl: handle
      ? `https://www.youtube.com/${handle}`
      : `https://www.youtube.com/channel/${channelId}`,
    description: (item.snippet?.description || '').trim(),
    thumbnailUrl: thumb,
    publishedAt: item.snippet?.publishedAt || null,
    country: item.snippet?.country || null,
    subscriberCount,
    hiddenSubscriberCount,
    viewCount: parseOptionalInt(item.statistics?.viewCount),
    videoCount: parseOptionalInt(item.statistics?.videoCount),
    uploadsPlaylistId: item.contentDetails?.relatedPlaylists?.uploads || null,
    retrievedAt,
    availabilityNote: hiddenSubscriberCount
      ? 'Subscriber count is hidden by the channel owner.'
      : 'All available public channel statistics retrieved from YouTube Data API v3.',
  };
}

export async function searchYouTubeChannels(
  query: string,
  maxResults = 6
): Promise<CompetitorChannelSearchResult[]> {
  const clean = query.trim();
  if (!clean) return [];
  const apiKey = requireYoutubeApiKey();
  const clamped = Math.min(10, Math.max(1, maxResults));

  const url = `${YT_BASE}/search?part=snippet&type=channel&maxResults=${clamped}&q=${encodeURIComponent(clean)}&key=${encodeURIComponent(apiKey)}`;
  const data = await fetchYouTubeJson<{ items?: YouTubeApiSearchItem[] }>(url);
  const items = data.items || [];

  return items
    .map((item) => {
      const channelId = item.id?.channelId || item.snippet?.channelId || '';
      if (!channelId) return null;
      const thumb =
        item.snippet?.thumbnails?.high?.url ||
        item.snippet?.thumbnails?.medium?.url ||
        item.snippet?.thumbnails?.default?.url ||
        null;
      return {
        channelId,
        title: item.snippet?.title || 'YouTube Channel',
        description: (item.snippet?.description || '').trim(),
        thumbnailUrl: thumb,
        publishedAt: item.snippet?.publishedAt || null,
        channelUrl: `https://www.youtube.com/channel/${channelId}`,
      } satisfies CompetitorChannelSearchResult;
    })
    .filter((x): x is CompetitorChannelSearchResult => Boolean(x));
}

export async function resolveYouTubeChannel(
  rawInput: string
): Promise<{ profile: CompetitorChannelProfile; quotaUnits: number }> {
  const trimmed = rawInput.trim();
  if (!trimmed) {
    throw new CollectorError('Please enter a YouTube channel URL, @handle, ID, or name.', 400, 'INVALID_INPUT');
  }
  const apiKey = requireYoutubeApiKey();
  const parsed = parseYouTubeChannelInput(trimmed);
  const retrievedAt = new Date().toISOString();
  const part = 'snippet,statistics,contentDetails';
  let quotaUnits = 0;

  const fetchByChannelId = async (channelId: string) => {
    quotaUnits += 1;
    const url = `${YT_BASE}/channels?part=${part}&id=${encodeURIComponent(channelId)}&key=${encodeURIComponent(apiKey)}`;
    const data = await fetchYouTubeJson<{ items?: YouTubeApiChannelItem[] }>(url);
    return data.items?.[0] || null;
  };

  let item: YouTubeApiChannelItem | null = null;

  if (parsed.kind === 'channelId') {
    item = await fetchByChannelId(parsed.value);
  } else if (parsed.kind === 'handle') {
    quotaUnits += 1;
    const handleParam = parsed.value.startsWith('@') ? parsed.value : `@${parsed.value}`;
    const url = `${YT_BASE}/channels?part=${part}&forHandle=${encodeURIComponent(handleParam)}&key=${encodeURIComponent(apiKey)}`;
    const data = await fetchYouTubeJson<{ items?: YouTubeApiChannelItem[] }>(url);
    item = data.items?.[0] || null;
  } else if (parsed.kind === 'username') {
    quotaUnits += 1;
    const url = `${YT_BASE}/channels?part=${part}&forUsername=${encodeURIComponent(parsed.value)}&key=${encodeURIComponent(apiKey)}`;
    const data = await fetchYouTubeJson<{ items?: YouTubeApiChannelItem[] }>(url);
    item = data.items?.[0] || null;
  } else if (parsed.kind === 'custom') {
    quotaUnits += 1;
    const url = `${YT_BASE}/channels?part=${part}&forHandle=${encodeURIComponent(`@${parsed.value}`)}&key=${encodeURIComponent(apiKey)}`;
    const data = await fetchYouTubeJson<{ items?: YouTubeApiChannelItem[] }>(url);
    item = data.items?.[0] || null;
  }

  // Fallback via search.list when handle/custom/name did not directly match
  if (!item) {
    quotaUnits += 100;
    const results = await searchYouTubeChannels(parsed.value, 1);
    if (results[0]) {
      item = await fetchByChannelId(results[0].channelId);
    }
  }

  if (!item || !item.id) {
    throw new CollectorError(
      `No public YouTube channel found matching "${trimmed}". Check the handle, channel URL, or UC channel ID.`,
      404,
      'CHANNEL_NOT_FOUND'
    );
  }

  return {
    profile: mapChannelItemToProfile(item, retrievedAt),
    quotaUnits,
  };
}

export async function collectChannelWithVideos(
  channelInputOrId: string,
  options: {
    sampleSize?: number;
    forceRefresh?: boolean;
    sampleTranscripts?: boolean;
  } = {}
): Promise<CompetitorChannelCollection> {
  const sampleSize = Math.min(50, Math.max(5, options.sampleSize ?? 20));
  const parsed = parseYouTubeChannelInput(channelInputOrId);

  // Check DB cache first if we already know channelId or handle
  if (!options.forceRefresh) {
    try {
      const cacheRow =
        parsed.kind === 'channelId'
          ? (
              await db
                .select()
                .from(competitorChannelCaches)
                .where(eq(competitorChannelCaches.channelId, parsed.value))
                .limit(1)
            )[0]
          : parsed.kind === 'handle'
            ? (
                await db
                  .select()
                  .from(competitorChannelCaches)
                  .where(eq(competitorChannelCaches.handle, parsed.value))
                  .limit(1)
              )[0]
            : undefined;

      if (
        cacheRow &&
        cacheRow.sampleSize >= sampleSize &&
        Date.now() - cacheRow.retrievedAt.getTime() < CHANNEL_CACHE_TTL_MS
      ) {
        const profile = JSON.parse(cacheRow.channelJson) as CompetitorChannelProfile;
        const cachedRawVideos = JSON.parse(cacheRow.videosJson) as RawFetchedVideoInput[];
        const sliced = cachedRawVideos.slice(0, sampleSize);
        const computed = computeOutliersAndChannelMetrics(
          sliced,
          cacheRow.retrievedAt.toISOString()
        );
        return {
          profile,
          videos: computed.videos,
          metrics: computed.metrics,
          cached: true,
          quotaUnitsEstimated: 0,
        };
      }
    } catch {
      // Cache lookup failure should not block live collection
    }
  }

  const apiKey = requireYoutubeApiKey();
  const { profile, quotaUnits: resolveUnits } = await resolveYouTubeChannel(channelInputOrId);
  let quotaUnits = resolveUnits;

  // Also check cache by resolved channelId if handle/search wasn't matched earlier
  if (!options.forceRefresh) {
    try {
      const existing = await db
        .select()
        .from(competitorChannelCaches)
        .where(eq(competitorChannelCaches.channelId, profile.channelId))
        .limit(1);
      const cacheRow = existing[0];
      if (
        cacheRow &&
        cacheRow.sampleSize >= sampleSize &&
        Date.now() - cacheRow.retrievedAt.getTime() < CHANNEL_CACHE_TTL_MS
      ) {
        const cachedRawVideos = JSON.parse(cacheRow.videosJson) as RawFetchedVideoInput[];
        const sliced = cachedRawVideos.slice(0, sampleSize);
        const computed = computeOutliersAndChannelMetrics(
          sliced,
          cacheRow.retrievedAt.toISOString()
        );
        return {
          profile,
          videos: computed.videos,
          metrics: computed.metrics,
          cached: true,
          quotaUnitsEstimated: quotaUnits,
        };
      }
    } catch {
      // Proceed with live collection
    }
  }

  const uploadsPlaylistId =
    profile.uploadsPlaylistId ||
    (profile.channelId.startsWith('UC') ? `UU${profile.channelId.slice(2)}` : null);

  if (!uploadsPlaylistId) {
    const empty = computeOutliersAndChannelMetrics([], profile.retrievedAt);
    return {
      profile,
      videos: empty.videos,
      metrics: empty.metrics,
      cached: false,
      quotaUnitsEstimated: quotaUnits,
    };
  }

  // Paginate playlistItems up to sampleSize
  const videoIdSet = new Set<string>();
  let pageToken: string | undefined;

  while (videoIdSet.size < sampleSize) {
    const remaining = Math.min(50, sampleSize - videoIdSet.size);
    quotaUnits += 1;
    const pageUrl = `${YT_BASE}/playlistItems?part=contentDetails,snippet&playlistId=${encodeURIComponent(uploadsPlaylistId)}&maxResults=${remaining}${pageToken ? `&pageToken=${encodeURIComponent(pageToken)}` : ''}&key=${encodeURIComponent(apiKey)}`;

    const pageData = await fetchYouTubeJson<{
      items?: YouTubeApiPlaylistItem[];
      nextPageToken?: string;
    }>(pageUrl);

    const items = pageData.items || [];
    for (const item of items) {
      const vid = item.contentDetails?.videoId || item.snippet?.resourceId?.videoId;
      if (vid && /^[a-zA-Z0-9_-]{11}$/.test(vid)) {
        videoIdSet.add(vid);
      }
    }

    if (!pageData.nextPageToken || items.length === 0) break;
    pageToken = pageData.nextPageToken;
  }

  const videoIds = Array.from(videoIdSet).slice(0, sampleSize);
  const rawVideos: RawFetchedVideoInput[] = [];

  // Batch videos.list calls in chunks of 50
  for (let i = 0; i < videoIds.length; i += 50) {
    const chunk = videoIds.slice(i, i + 50);
    quotaUnits += 1;
    const vidUrl = `${YT_BASE}/videos?part=snippet,contentDetails,statistics&id=${encodeURIComponent(chunk.join(','))}&key=${encodeURIComponent(apiKey)}`;
    const vidData = await fetchYouTubeJson<{ items?: YouTubeApiVideoItem[] }>(vidUrl);
    for (const item of vidData.items || []) {
      if (!item.id) continue;
      const thumbs = item.snippet?.thumbnails;
      const thumbnailUrl =
        thumbs?.maxres?.url ||
        thumbs?.standard?.url ||
        thumbs?.high?.url ||
        thumbs?.medium?.url ||
        thumbs?.default?.url ||
        `https://i.ytimg.com/vi/${item.id}/hqdefault.jpg`;

      rawVideos.push({
        videoId: item.id,
        channelId: item.snippet?.channelId || profile.channelId,
        channelTitle: item.snippet?.channelTitle || profile.title,
        title: (item.snippet?.title || 'Untitled Video').trim(),
        description: (item.snippet?.description || '').trim().slice(0, 1200),
        publishedAt: item.snippet?.publishedAt || null,
        durationSeconds: parseIso8601DurationToSeconds(item.contentDetails?.duration),
        thumbnailUrl,
        viewCount: parseOptionalInt(item.statistics?.viewCount),
        likeCount: parseOptionalInt(item.statistics?.likeCount),
        commentCount: parseOptionalInt(item.statistics?.commentCount),
        tags: (item.snippet?.tags || []).slice(0, 20),
        transcriptAvailable: false,
        transcriptExcerpt: null,
      });
    }
  }

  // Optional caption probing on top 2 most-viewed videos in sample to ground Module 7 Hook & Storytelling
  let transcriptsSampledCount = 0;
  if (options.sampleTranscripts !== false && rawVideos.length > 0) {
    const topForTranscript = [...rawVideos]
      .sort((a, b) => (b.viewCount ?? 0) - (a.viewCount ?? 0))
      .slice(0, 2);

    await Promise.all(
      topForTranscript.map(async (v) => {
        try {
          const tr = await fetchYouTubeTranscript(v.videoId);
          if (tr.plainText && tr.plainText.length > 40) {
            v.transcriptAvailable = true;
            // Store brief structural opening + ending snippet (~900 chars total max, never full transcript)
            const opening = tr.plainText.slice(0, 550);
            const closing =
              tr.plainText.length > 900 ? tr.plainText.slice(-300) : '';
            v.transcriptExcerpt = closing ? `${opening} [...] ${closing}` : opening;
            transcriptsSampledCount += 1;
          }
        } catch {
          // Captions disabled or unavailable — do not fail collection
        }
      })
    );
  }

  const retrievedAt = new Date().toISOString();
  profile.retrievedAt = retrievedAt;
  const computed = computeOutliersAndChannelMetrics(rawVideos, retrievedAt);

  // Persist to DB cache to save quota across refreshes & reopens
  try {
    await db
      .insert(competitorChannelCaches)
      .values({
        channelId: profile.channelId,
        handle: profile.handle,
        title: profile.title,
        channelJson: JSON.stringify(profile),
        videosJson: JSON.stringify(rawVideos),
        sampleSize: rawVideos.length,
        transcriptsSampledCount,
        retrievedAt: new Date(retrievedAt),
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: competitorChannelCaches.channelId,
        set: {
          handle: profile.handle,
          title: profile.title,
          channelJson: JSON.stringify(profile),
          videosJson: JSON.stringify(rawVideos),
          sampleSize: rawVideos.length,
          transcriptsSampledCount,
          retrievedAt: new Date(retrievedAt),
          updatedAt: new Date(),
        },
      });
  } catch (err) {
    console.warn('Unable to write competitor channel cache:', err);
  }

  return {
    profile,
    videos: computed.videos,
    metrics: computed.metrics,
    cached: false,
    quotaUnitsEstimated: quotaUnits,
  };
}
