import crypto from 'node:crypto';
import { GoogleGenAI, ThinkingLevel, Type, type Schema } from '@google/genai';
import { getServerConfig } from '../config/env.ts';
import {
  computeTargetWordCount,
  countSpokenWords,
  formatDurationFromWords,
  stripProductionNotes,
} from '../../shared/scriptStudioHelpers.ts';
import type {
  AssembledScript,
  BodySectionDraft,
  IntroductionParts,
  OutlineResearchNotes,
  OutlineSection,
  OutroDraft,
  QualityControlCheck,
  ScriptAiModelId,
  ScriptPersonalizationSettings,
  ScriptProjectRecord,
  ScriptStageNumber,
  ThumbnailConcept,
  TitleConcept,
  TopicAnalysis,
  TopicIdea,
  VideoPromiseSummary,
} from '../../shared/types.ts';

export class ScriptAiError extends Error {
  statusCode: number;
  code: string;

  constructor(message: string, statusCode = 500, code = 'AI_GENERATION_FAILED') {
    super(message);
    this.name = 'ScriptAiError';
    this.statusCode = statusCode;
    this.code = code;
  }
}

export function extractReadableAiErrorMessage(err: unknown): string {
  const raw = err instanceof Error ? err.message : String(err ?? 'AI generation failed.');
  const trimmed = raw.trim();
  if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
    try {
      const parsed = JSON.parse(trimmed) as {
        error?: { message?: string; status?: string; code?: number };
        message?: string;
      };
      const nested = parsed.error?.message || parsed.message;
      if (typeof nested === 'string' && nested.trim()) {
        return nested.trim();
      }
    } catch {
      // Keep raw string if not valid JSON
    }
  }
  return trimmed || 'AI generation failed.';
}

export function isTransientModelOverloadError(lowerMsg: string): boolean {
  return (
    lowerMsg.includes('503') ||
    lowerMsg.includes('unavailable') ||
    lowerMsg.includes('high demand') ||
    lowerMsg.includes('overloaded') ||
    lowerMsg.includes('429') ||
    lowerMsg.includes('resource_exhausted') ||
    lowerMsg.includes('quota') ||
    lowerMsg.includes('500') ||
    lowerMsg.includes('internal') ||
    lowerMsg.includes('timeout') ||
    lowerMsg.includes('econnreset') ||
    lowerMsg.includes('network')
  );
}

// Shared short-circuit cooldown when gemini-4-hydrogen is rate-limited, overloaded, or timing out.
// Prevents every subsequent user click from stalling for 15-20s before falling back to gemini-3.1-flash-lite.
let hydrogenCooldownUntil = 0;

export function markHydrogenTemporarilyUnavailable(durationMs = 3 * 60_000): void {
  hydrogenCooldownUntil = Math.max(hydrogenCooldownUntil, Date.now() + durationMs);
}

export function getOrderedModelCandidates(primaryModel: ScriptAiModelId): ScriptAiModelId[] {
  if (primaryModel === 'gemini-3.1-flash-lite') {
    return ['gemini-3.1-flash-lite'];
  }
  if (Date.now() < hydrogenCooldownUntil) {
    return ['gemini-3.1-flash-lite', 'gemini-4-hydrogen'];
  }
  return ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];
}

export function buildModelThinkingConfig(
  model: ScriptAiModelId
): { thinkingConfig?: { thinkingLevel: ThinkingLevel } } {
  if (model === 'gemini-4-hydrogen') {
    return { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } };
  }
  return {};
}

const CREATIVE_DIRECTOR_SYSTEM_INSTRUCTION = `You are an elite YouTube content strategist, video packaging expert, storytelling architect, audience psychologist, professional scriptwriter, and viewer-retention specialist inside MediaToolsHub.

Core Operating Principles:
1. Collaborate thoughtfully with the creator—whether complete beginner or seasoned creator. Explain WHY choices work in plain, encouraging English.
2. Packaging-first psychology: Title and thumbnail create an Expectation; the opening confirms that exact Reality immediately without generic greetings ("Hey guys, welcome back") or bloated channel intros.
3. Never invent fake statistics, fake scientific studies, fake quotes, or fabricated personal anecdotes ("I tried this for 30 days and lost 20 pounds"). Clearly mark illustrative hypothetical scenarios as examples, and flag factual claims that need source verification.
4. Write spoken narration for listening, not reading: vary sentence cadence, use concrete everyday language, avoid robotic AI clichés ("delve into", "in today's fast-paced world", "unlock your full potential", "game-changer", "buckle up", "without further ado", "let's dive right in").
5. Respect the creator's exact personalization settings: target language/style (including Hinglish or simple English if requested), audience, age group, region, tone, storytelling intensity, faceless vs. on-camera format, CTA preference, and word/duration budget.
6. Whenever mentioning technical scriptwriting concepts (curiosity gap, packaging, open loop, pattern interruption), keep explanations accessible to beginners.`;

function getGeminiClient(): GoogleGenAI {
  const cfg = getServerConfig();
  const apiKey = cfg.geminiApiKey;
  if (!apiKey) {
    throw new ScriptAiError(
      'Server AI generation is not configured yet. Please add GEMINI_API_KEY in Settings > Secrets.',
      500,
      'GEMINI_API_KEY_MISSING'
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function resolveModel(requested?: string | null): ScriptAiModelId {
  if (requested === 'gemini-3.1-flash-lite') return 'gemini-3.1-flash-lite';
  const cfg = getServerConfig();
  return cfg.scriptAiModel || 'gemini-4-hydrogen';
}

function formatSettingsContext(settings: ScriptPersonalizationSettings): string {
  const targetWords = computeTargetWordCount(settings);
  return [
    `Channel Niche: ${settings.channelNiche || 'Not specified (pick strong broad appeal)'}`,
    `Target Audience: ${settings.targetAudience}`,
    `Viewer Age Group: ${settings.viewerAgeGroup}`,
    `Country/Region: ${settings.countryOrRegion}`,
    `Script Language: ${settings.scriptLanguage} (Style: ${settings.languageStyle})`,
    `Video Format: ${settings.videoFormat}`,
    `Content Tone: ${settings.contentTone}`,
    `Storytelling Intensity: ${settings.storytellingIntensity}`,
    `Presentation Mode: ${settings.presentationMode}`,
    `Speaking Speed: ${settings.narrationSpeedWpm} WPM`,
    `Target Duration: ${settings.targetDurationMinutes} minutes (~${targetWords} spoken words; priority=${settings.constraintPriority})`,
    `CTA Preference: ${settings.ctaPreferences}`,
    settings.customInstructions ? `Creator Special Instructions: ${settings.customInstructions}` : '',
  ]
    .filter(Boolean)
    .join('\n');
}

function extractCleanJsonString(raw: string): string {
  const trimmed = raw.trim();
  if (trimmed.startsWith('```')) {
    return trimmed.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();
  }
  return trimmed;
}

const AI_REQUEST_TIMEOUT_MS = 45_000;

async function withTimeout<T>(promise: Promise<T>, timeoutMs: number, label: string): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | null = null;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        timer = setTimeout(() => {
          reject(
            new ScriptAiError(
              `${label} timed out after ${Math.round(timeoutMs / 1000)}s. Your project progress is preserved — please retry.`,
              500,
              'AI_TIMEOUT'
            )
          );
        }, timeoutMs);
      }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function generateStructuredJson<T>(params: {
  model: ScriptAiModelId;
  prompt: string;
  schema: Schema;
  extraInstruction?: string;
}): Promise<T> {
  const ai = getGeminiClient();
  const systemInstruction = params.extraInstruction
    ? `${CREATIVE_DIRECTOR_SYSTEM_INSTRUCTION}\n\nActive Stage Guidance:\n${params.extraInstruction}`
    : CREATIVE_DIRECTOR_SYSTEM_INSTRUCTION;

  const modelCandidates: ScriptAiModelId[] = getOrderedModelCandidates(params.model);

  const deadline = Date.now() + AI_REQUEST_TIMEOUT_MS;
  let lastErr: unknown;

  for (let attempt = 0; attempt < modelCandidates.length; attempt++) {
    const activeModel = modelCandidates[attempt];
    const remainingMs = deadline - Date.now();
    if (remainingMs <= 1500) {
      throw new ScriptAiError(
        'AI generation timed out before completing. Your progress is saved — please retry.',
        500,
        'AI_TIMEOUT'
      );
    }

    const attemptTimeoutMs =
      attempt === 0 && modelCandidates.length > 1
        ? Math.min(remainingMs, activeModel === 'gemini-4-hydrogen' ? 16_000 : 24_000)
        : remainingMs;

    try {
      const response = await withTimeout(
        ai.models.generateContent({
          model: activeModel,
          contents: params.prompt,
          config: {
            systemInstruction,
            responseMimeType: 'application/json',
            responseSchema: params.schema,
            ...buildModelThinkingConfig(activeModel),
          },
        }),
        attemptTimeoutMs,
        'AI script generation'
      );
      const raw = extractCleanJsonString(response.text ?? '');
      if (!raw) {
        throw new ScriptAiError(
          'The AI model returned an empty response. Please retry.',
          500,
          'AI_INVALID_RESPONSE'
        );
      }
      try {
        return JSON.parse(raw) as T;
      } catch {
        throw new ScriptAiError(
          'The AI model returned malformed structured output. Please retry.',
          500,
          'AI_INVALID_RESPONSE'
        );
      }
    } catch (err: unknown) {
      lastErr = err;
      const readableMsg = extractReadableAiErrorMessage(err);
      const lower = readableMsg.toLowerCase();

      if (
        lower.includes('api_key_invalid') ||
        lower.includes('permission_denied') ||
        lower.includes('api key not valid')
      ) {
        throw new ScriptAiError(
          'The server GEMINI_API_KEY was rejected or lacks permission. Please verify it in Settings > Secrets.',
          500,
          'GEMINI_AUTH_ERROR'
        );
      }

      const hasFallbackModel = attempt + 1 < modelCandidates.length;
      const isModelNotFound = lower.includes('not_found') || lower.includes('404');
      const isDailyQuotaExhausted =
        lower.includes('generaterequestsperday') ||
        lower.includes('per day') ||
        (lower.includes('quota') && lower.includes('exceeded'));
      const isRateLimited = lower.includes('429') || lower.includes('resource_exhausted');
      const isTimeout = err instanceof ScriptAiError && err.code === 'AI_TIMEOUT';
      const isTransient = isTransientModelOverloadError(lower) || isTimeout;

      if (
        activeModel === 'gemini-4-hydrogen' &&
        (isTransient || isModelNotFound || isDailyQuotaExhausted || isRateLimited)
      ) {
        markHydrogenTemporarilyUnavailable(isDailyQuotaExhausted ? 10 * 60_000 : 3 * 60_000);
      }

      // Automatically fall back to gemini-3.1-flash-lite if gemini-4-hydrogen is overloaded,
      // rate-limited, unavailable, or times out.
      if (hasFallbackModel && (isTransient || isModelNotFound || isDailyQuotaExhausted || isRateLimited)) {
        await new Promise((r) => setTimeout(r, 250));
        continue;
      }

      if (isModelNotFound) {
        throw new ScriptAiError(
          `Requested Gemini model (${activeModel}) is unavailable. Try switching to Gemini 3.1 Flash Lite in Personalize settings.`,
          400,
          'GEMINI_MODEL_NOT_FOUND'
        );
      }

      if (isDailyQuotaExhausted) {
        const altHint =
          activeModel === 'gemini-4-hydrogen'
            ? ' Switch to Gemini 3.1 Flash Lite in Personalize settings or retry later.'
            : ' Please retry again shortly.';
        throw new ScriptAiError(
          `Free-tier daily request quota reached for ${activeModel}.${altHint} All your approved progress is safely preserved.`,
          429,
          'AI_RATE_LIMITED'
        );
      }

      if (isRateLimited) {
        throw new ScriptAiError(
          `AI provider rate limit reached for ${activeModel}. Wait a moment or switch to Gemini 3.1 Flash Lite and retry.`,
          429,
          'AI_RATE_LIMITED'
        );
      }

      if (err instanceof ScriptAiError) {
        throw err;
      }

      throw new ScriptAiError(readableMsg, 500, 'AI_GENERATION_FAILED');
    }
  }

  if (lastErr instanceof ScriptAiError) {
    throw lastErr;
  }
  throw new ScriptAiError(extractReadableAiErrorMessage(lastErr), 500, 'AI_GENERATION_FAILED');
}

// ==============================================================================
// STAGE 1: TOPIC DISCOVERY
// ==============================================================================

export async function aiGenerateTopicIdeas(params: {
  niche: string;
  settings: ScriptPersonalizationSettings;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<{ ideas: TopicIdea[]; directorComment: string }> {
  const model = resolveModel(params.modelName);
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: {
        type: Type.STRING,
        description:
          'Friendly Creative Director note explaining which 1-2 topic ideas are strongest and why, defining any helpful terms in simple language.',
      },
      ideas: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            targetAudience: { type: Type.STRING },
            mainAudienceProblem: { type: Type.STRING },
            viewerTransformation: { type: Type.STRING },
            whyAttractive: { type: Type.STRING },
            storytellingAngle: { type: Type.STRING },
          },
          required: [
            'title',
            'targetAudience',
            'mainAudienceProblem',
            'viewerTransformation',
            'whyAttractive',
            'storytellingAngle',
          ],
        },
      },
    },
    required: ['directorComment', 'ideas'],
  };

  const prompt = `Generate exactly 10 specific, non-generic, emotionally relevant YouTube video topic ideas for this niche/category: "${params.niche}".

Creator Personalization Settings:
${formatSettingsContext(params.settings)}
${params.instruction ? `\nCreator Revision Request: ${params.instruction}` : ''}

Avoid vague broad topics like "How to be productive". Make each topic solve a recognizable audience tension with a clear viewer transformation and compelling storytelling angle.`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    ideas: Array<Omit<TopicIdea, 'id'>>;
  }>({ model, prompt, schema });

  const ideas: TopicIdea[] = (raw.ideas || []).slice(0, 10).map((item, idx) => ({
    id: `topic-${idx + 1}-${crypto.randomUUID().slice(0, 6)}`,
    title: item.title,
    targetAudience: item.targetAudience,
    mainAudienceProblem: item.mainAudienceProblem,
    viewerTransformation: item.viewerTransformation,
    whyAttractive: item.whyAttractive,
    storytellingAngle: item.storytellingAngle,
  }));

  return { ideas, directorComment: raw.directorComment };
}

export async function aiAnalyzeCustomTopic(params: {
  topicInput: string;
  settings: ScriptPersonalizationSettings;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<{ analysis: TopicAnalysis; selectedTopic: TopicIdea; directorComment: string }> {
  const model = resolveModel(params.modelName);
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: {
        type: Type.STRING,
        description:
          'Plain-language creative director review encouraging the creator and explaining the sharpest curiosity angle.',
      },
      centralIdea: { type: Type.STRING },
      targetViewer: { type: Type.STRING },
      mainProblem: { type: Type.STRING },
      desiredOutcome: { type: Type.STRING },
      curiosityGap: { type: Type.STRING },
      contentOpportunities: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
      recommendedRefinedTopicTitle: { type: Type.STRING },
      storytellingAngle: { type: Type.STRING },
    },
    required: [
      'directorComment',
      'centralIdea',
      'targetViewer',
      'mainProblem',
      'desiredOutcome',
      'curiosityGap',
      'contentOpportunities',
      'recommendedRefinedTopicTitle',
      'storytellingAngle',
    ],
  };

  const prompt = `Analyze this creator's custom YouTube video topic idea before we move into packaging:
"${params.topicInput}"

Creator Personalization Settings:
${formatSettingsContext(params.settings)}
${params.instruction ? `\nCreator Revision Request: ${params.instruction}` : ''}

Identify the central idea, target viewer, core audience problem, desired transformation/outcome, curiosity gap (explain briefly what makes viewers wonder), and 3-5 content opportunities.`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    centralIdea: string;
    targetViewer: string;
    mainProblem: string;
    desiredOutcome: string;
    curiosityGap: string;
    contentOpportunities: string[];
    recommendedRefinedTopicTitle: string;
    storytellingAngle: string;
  }>({ model, prompt, schema });

  const analysis: TopicAnalysis = {
    centralIdea: raw.centralIdea,
    targetViewer: raw.targetViewer,
    mainProblem: raw.mainProblem,
    desiredOutcome: raw.desiredOutcome,
    curiosityGap: raw.curiosityGap,
    contentOpportunities: raw.contentOpportunities || [],
    directorRecommendation: raw.directorComment,
  };

  const selectedTopic: TopicIdea = {
    id: `custom-${crypto.randomUUID().slice(0, 8)}`,
    title: raw.recommendedRefinedTopicTitle || params.topicInput,
    targetAudience: raw.targetViewer,
    mainAudienceProblem: raw.mainProblem,
    viewerTransformation: raw.desiredOutcome,
    whyAttractive: raw.curiosityGap,
    storytellingAngle: raw.storytellingAngle,
  };

  return { analysis, selectedTopic, directorComment: raw.directorComment };
}

// ==============================================================================
// STAGE 2: VIDEO PACKAGING
// ==============================================================================

export async function aiGeneratePackaging(params: {
  project: ScriptProjectRecord;
  scope: 'all' | 'titles' | 'thumbnails';
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<{
  videoPromise: VideoPromiseSummary;
  titleConcepts: TitleConcept[];
  thumbnailConcepts: ThumbnailConcept[];
  thumbnailTextOptions: string[];
  directorComment: string;
}> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const { stage1, stage2 } = params.project.state;
  const topic = stage1.selectedTopic;
  if (!topic) {
    throw new ScriptAiError('Stage 1 topic must be selected before generating packaging.', 400);
  }

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: { type: Type.STRING },
      videoPromise: {
        type: Type.OBJECT,
        properties: {
          whatVideoIsAbout: { type: Type.STRING },
          viewerExpectation: { type: Type.STRING },
          problemSolved: { type: Type.STRING },
          whyInteresting: { type: Type.STRING },
          centralCuriosityGap: { type: Type.STRING },
          supportingEvidenceIdeas: { type: Type.ARRAY, items: { type: Type.STRING } },
          expectationsVsRealityNote: { type: Type.STRING },
        },
        required: [
          'whatVideoIsAbout',
          'viewerExpectation',
          'problemSolved',
          'whyInteresting',
          'centralCuriosityGap',
          'supportingEvidenceIdeas',
          'expectationsVsRealityNote',
        ],
      },
      titleConcepts: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            angleType: { type: Type.STRING },
            angleLabel: { type: Type.STRING },
            title: { type: Type.STRING },
            psychologicalAngle: { type: Type.STRING },
            viewerPromise: { type: Type.STRING },
            whyItAttractsClicks: { type: Type.STRING },
            potentialLimitation: { type: Type.STRING },
            isRecommended: { type: Type.BOOLEAN },
          },
          required: [
            'angleType',
            'angleLabel',
            'title',
            'psychologicalAngle',
            'viewerPromise',
            'whyItAttractsClicks',
            'potentialLimitation',
            'isRecommended',
          ],
        },
      },
      thumbnailConcepts: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            conceptName: { type: Type.STRING },
            mainSubject: { type: Type.STRING },
            positioning: { type: Type.STRING },
            facialExpression: { type: Type.STRING },
            background: { type: Type.STRING },
            composition: { type: Type.STRING },
            lighting: { type: Type.STRING },
            visualContrast: { type: Type.STRING },
            emotionalTrigger: { type: Type.STRING },
            visualStorytelling: { type: Type.STRING },
          },
          required: [
            'conceptName',
            'mainSubject',
            'positioning',
            'facialExpression',
            'background',
            'composition',
            'lighting',
            'visualContrast',
            'emotionalTrigger',
            'visualStorytelling',
          ],
        },
      },
      thumbnailTextOptions: {
        type: Type.ARRAY,
        items: { type: Type.STRING },
      },
    },
    required: [
      'directorComment',
      'videoPromise',
      'titleConcepts',
      'thumbnailConcepts',
      'thumbnailTextOptions',
    ],
  };

  const approvedTitleHint =
    params.scope === 'thumbnails' && (stage2.customTitleText || stage2.titleConcepts.length > 0)
      ? `Approved Video Title to pair thumbnails with: "${stage2.customTitleText || stage2.titleConcepts.find((t) => t.id === stage2.selectedTitleId)?.title || topic.title}"`
      : '';

  const comp = params.project.state.competitorResearch;
  const competitorHint =
    comp && !comp.skipped && (comp.selectedChannelTitles.length > 0 || comp.competitorSummary)
      ? `\nOptional Competitor Research Context (use to outperform competitor angles, titles, and gaps):
- Selected Competitors: ${comp.selectedChannelTitles.join(', ') || 'Saved research'}
- Competitor Summary: ${comp.competitorSummary}
- Winning Title Patterns: ${comp.keyTitlePatterns.join(' | ') || 'None specified'}
- Content Gaps to Exploit: ${comp.contentGaps.join(' | ') || 'None specified'}`
      : '';

  const prompt = `Design complete packaging (Expectations vs. Reality) BEFORE writing any script.
Approved Topic: "${topic.title}"
Audience: ${topic.targetAudience}
Core Problem: ${topic.mainAudienceProblem}
Viewer Transformation: ${topic.viewerTransformation}
Storytelling Angle: ${topic.storytellingAngle}
${approvedTitleHint}
Regeneration focus: ${params.scope}
${competitorHint}

Personalization Settings:
${formatSettingsContext(params.project.settings)}
${params.instruction ? `\nCreator Revision Instruction: ${params.instruction}` : ''}

Requirements:
1. Video Promise: clearly state Expectations vs. Reality positioning in simple language.
2. Generate 5 distinct video title concepts (1. curiosity, 2. problem-solving, 3. transformation, 4. contrarian, 5. specific-outcome). Set isRecommended=true on ONLY ONE strongest honest title (no misleading clickbait).
3. Generate 3 distinct thumbnail visual concepts that COMPLEMENT the title instead of repeating it verbatim (${params.project.settings.presentationMode === 'faceless' ? 'Use objects/metaphors/visual storytelling if faceless' : 'Include expressive framing/subject details'}).
4. Generate 4 short thumbnail text options, strictly 2-4 words each, high contrast and mobile-readable.`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    videoPromise: VideoPromiseSummary;
    titleConcepts: Array<Omit<TitleConcept, 'id'>>;
    thumbnailConcepts: Array<Omit<ThumbnailConcept, 'id'>>;
    thumbnailTextOptions: string[];
  }>({ model, prompt, schema });

  const allowedAngles: TitleConcept['angleType'][] = [
    'curiosity',
    'problem-solving',
    'transformation',
    'contrarian',
    'specific-outcome',
  ];

  const titleConcepts: TitleConcept[] = (raw.titleConcepts || []).slice(0, 5).map((t, i) => ({
    id: `title-${i + 1}-${crypto.randomUUID().slice(0, 6)}`,
    angleType: allowedAngles.includes(t.angleType) ? t.angleType : allowedAngles[i % allowedAngles.length],
    angleLabel: t.angleLabel,
    title: t.title,
    psychologicalAngle: t.psychologicalAngle,
    viewerPromise: t.viewerPromise,
    whyItAttractsClicks: t.whyItAttractsClicks,
    potentialLimitation: t.potentialLimitation,
    isRecommended: Boolean(t.isRecommended),
  }));
  if (titleConcepts.length > 0 && !titleConcepts.some((t) => t.isRecommended)) {
    titleConcepts[0].isRecommended = true;
  }

  const thumbnailConcepts: ThumbnailConcept[] = (raw.thumbnailConcepts || []).slice(0, 3).map((th, i) => ({
    id: `thumb-${i + 1}-${crypto.randomUUID().slice(0, 6)}`,
    ...th,
  }));

  return {
    videoPromise: raw.videoPromise,
    titleConcepts: params.scope === 'thumbnails' && stage2.titleConcepts.length > 0 ? stage2.titleConcepts : titleConcepts,
    thumbnailConcepts: params.scope === 'titles' && stage2.thumbnailConcepts.length > 0 ? stage2.thumbnailConcepts : thumbnailConcepts,
    thumbnailTextOptions:
      params.scope === 'titles' && stage2.thumbnailTextOptions.length > 0
        ? stage2.thumbnailTextOptions
        : (raw.thumbnailTextOptions || []).slice(0, 5),
    directorComment: raw.directorComment,
  };
}

// ==============================================================================
// STAGE 3: CONTENT OUTLINE
// ==============================================================================

export async function aiGenerateOutline(params: {
  project: ScriptProjectRecord;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<{
  research: OutlineResearchNotes;
  retentionArchitectureNote: string;
  sections: OutlineSection[];
  directorComment: string;
}> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const { stage1, stage2 } = params.project.state;
  const approvedTitle =
    stage2.customTitleText ||
    stage2.titleConcepts.find((t) => t.id === stage2.selectedTitleId)?.title ||
    stage1.selectedTopic?.title ||
    '';

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: { type: Type.STRING },
      retentionArchitectureNote: {
        type: Type.STRING,
        description:
          'Explain why sections are ordered this way (second-best major point placed early, building to strongest payoff, open loops).',
      },
      research: {
        type: Type.OBJECT,
        properties: {
          verifiedFactsNeeded: { type: Type.ARRAY, items: { type: Type.STRING } },
          commonKnowledgeToAvoid: { type: Type.ARRAY, items: { type: Type.STRING } },
          lessObviousInsights: { type: Type.ARRAY, items: { type: Type.STRING } },
          uniquePerspectives: { type: Type.ARRAY, items: { type: Type.STRING } },
          practicalExamples: { type: Type.ARRAY, items: { type: Type.STRING } },
          usefulFrameworks: { type: Type.ARRAY, items: { type: Type.STRING } },
          unexpectedConnections: { type: Type.ARRAY, items: { type: Type.STRING } },
          memorableStories: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: [
          'verifiedFactsNeeded',
          'commonKnowledgeToAvoid',
          'lessObviousInsights',
          'uniquePerspectives',
          'practicalExamples',
          'usefulFrameworks',
          'unexpectedConnections',
          'memorableStories',
        ],
      },
      sections: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            heading: { type: Type.STRING },
            mainIdea: { type: Type.STRING },
            whatViewerLearns: { type: Type.STRING },
            supportingExplanation: { type: Type.STRING },
            exampleOrStory: { type: Type.STRING },
            curiosityElement: { type: Type.STRING },
            transitionToNext: { type: Type.STRING },
            estimatedMinutes: { type: Type.NUMBER },
          },
          required: [
            'heading',
            'mainIdea',
            'whatViewerLearns',
            'supportingExplanation',
            'exampleOrStory',
            'curiosityElement',
            'transitionToNext',
            'estimatedMinutes',
          ],
        },
      },
    },
    required: ['directorComment', 'retentionArchitectureNote', 'research', 'sections'],
  };

  const targetWords = computeTargetWordCount(params.project.settings);
  const compOutline = params.project.state.competitorResearch;
  const competitorOutlineHint =
    compOutline && !compOutline.skipped && (compOutline.contentGaps.length > 0 || compOutline.competitorSummary)
      ? `\nCompetitor Differentiators & Gaps to Cover:\n- Summary: ${compOutline.competitorSummary}\n- Content Gaps: ${compOutline.contentGaps.join(' | ')}`
      : '';
  const prompt = `Build Stage 3 Content Architecture & Retention Outline (do NOT write the full script yet).

Approved Packaging:
- Title: "${approvedTitle}"
- Thumbnail Text: "${stage2.selectedThumbnailText}"
- Video Promise: ${stage2.videoPromise?.whatVideoIsAbout || ''}
- Central Curiosity Gap: ${stage2.videoPromise?.centralCuriosityGap || ''}
${competitorOutlineHint}

Personalization Settings:
${formatSettingsContext(params.project.settings)}
Target spoken budget: ~${targetWords} words across ~${params.project.settings.targetDurationMinutes} minutes.
${params.instruction ? `\nCreator Outline Instruction: ${params.instruction}` : ''}

Rules:
- Separate common knowledge (keep brief) from less-obvious insights and useful frameworks.
- Never invent statistics or studies; list any factual claims requiring verification in verifiedFactsNeeded.
- Design 3 to 6 distinct non-repetitive body sections scaled cleanly to the target duration.
- Place the second-best major point early to hook retention, and build toward the strongest payoff before the outro.`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    retentionArchitectureNote: string;
    research: OutlineResearchNotes;
    sections: Array<Omit<OutlineSection, 'id' | 'order'>>;
  }>({ model, prompt, schema });

  const sections: OutlineSection[] = (raw.sections || []).map((s, idx) => ({
    id: `sec-${idx + 1}-${crypto.randomUUID().slice(0, 6)}`,
    order: idx + 1,
    heading: s.heading,
    mainIdea: s.mainIdea,
    whatViewerLearns: s.whatViewerLearns,
    supportingExplanation: s.supportingExplanation,
    exampleOrStory: s.exampleOrStory,
    curiosityElement: s.curiosityElement,
    transitionToNext: s.transitionToNext,
    estimatedMinutes: Number(s.estimatedMinutes) || 1.5,
  }));

  return {
    research: raw.research,
    retentionArchitectureNote: raw.retentionArchitectureNote,
    sections,
    directorComment: raw.directorComment,
  };
}

// ==============================================================================
// STAGE 4: INTRODUCTION (5-PART FRAMEWORK)
// ==============================================================================

export async function aiGenerateIntroduction(params: {
  project: ScriptProjectRecord;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<{
  parts: IntroductionParts;
  spokenNarration: string;
  wordCount: number;
  estimatedSeconds: number;
  directorComment: string;
}> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const { stage2, stage3 } = params.project.state;
  const approvedTitle =
    stage2.customTitleText ||
    stage2.titleConcepts.find((t) => t.id === stage2.selectedTitleId)?.title ||
    '';

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: { type: Type.STRING },
      parts: {
        type: Type.OBJECT,
        properties: {
          context: { type: Type.STRING },
          commonBelief: { type: Type.STRING },
          contrast: { type: Type.STRING },
          proof: { type: Type.STRING },
          plan: { type: Type.STRING },
        },
        required: ['context', 'commonBelief', 'contrast', 'proof', 'plan'],
      },
      spokenNarration: {
        type: Type.STRING,
        description:
          'Complete natural spoken introduction weaving the 5 parts seamlessly, ready to read aloud without production cue tags.',
      },
    },
    required: ['directorComment', 'parts', 'spokenNarration'],
  };

  const outlinePreview = stage3.sections
    .map((s, i) => `${i + 1}. ${s.heading}: ${s.mainIdea}`)
    .join('\n');

  const compIntro = params.project.state.competitorResearch;
  const competitorIntroHint =
    compIntro && !compIntro.skipped && (compIntro.keyHookAngles.length > 0 || compIntro.competitorSummary)
      ? `\nCompetitor Hook Patterns to Differentiate From:\n- ${compIntro.keyHookAngles.join(' | ')}`
      : '';

  const prompt = `Write Stage 4 Introduction using the exact 5-part framework:
1. CONTEXT (immediately confirm the title & thumbnail expectation)
2. COMMON BELIEF (what most people assume)
3. CONTRAST (surprising perspective or overlooked truth)
4. PROOF (credible reason to stay and trust the video—never fabricate personal stories)
5. PLAN (what the viewer will discover, planting an open loop)

Approved Packaging:
- Title: "${approvedTitle}"
- Thumbnail Text: "${stage2.selectedThumbnailText}"
- Viewer Promise: ${stage2.videoPromise?.viewerExpectation || ''}
${competitorIntroHint}

Approved Outline:
${outlinePreview}

Personalization Settings:
${formatSettingsContext(params.project.settings)}
${params.instruction ? `\nCreator Revision Request (hook, tone, length, opening story, language): ${params.instruction}` : ''}

Hard Rules:
- No generic greetings ("Hey guys, welcome back to my channel").
- No "Today we're going to talk about..." or "In this video I will share...".
- Sound completely human, conversational, and tight (typically 90-190 words depending on total video length).`;

  const raw = await generateStructuredJson<{
    directorComment?: string;
    parts?: Partial<IntroductionParts>;
    spokenNarration?: string;
  }>({ model, prompt, schema });

  const spokenNarration = typeof raw.spokenNarration === 'string' ? raw.spokenNarration.trim() : '';
  if (!spokenNarration) {
    throw new ScriptAiError(
      'Introduction draft returned empty narration. Your approved outline is safe — please retry.',
      500,
      'AI_INVALID_RESPONSE'
    );
  }

  const parts: IntroductionParts = {
    context: raw.parts?.context || '',
    commonBelief: raw.parts?.commonBelief || '',
    contrast: raw.parts?.contrast || '',
    proof: raw.parts?.proof || '',
    plan: raw.parts?.plan || '',
  };

  const wordCount = countSpokenWords(spokenNarration);
  const wpm = params.project.settings.narrationSpeedWpm || 140;
  return {
    parts,
    spokenNarration,
    wordCount,
    estimatedSeconds: Math.round((wordCount / wpm) * 60),
    directorComment: raw.directorComment || '',
  };
}

// ==============================================================================
// STAGE 5: MAIN BODY (STRICTLY SECTION-BY-SECTION)
// ==============================================================================

export async function aiGenerateBodySection(params: {
  project: ScriptProjectRecord;
  sectionIndex: number;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<BodySectionDraft> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const { stage2, stage3, stage4, stage5 } = params.project.state;
  const targetSection = stage3.sections[params.sectionIndex];
  if (!targetSection) {
    throw new ScriptAiError(`Outline section #${params.sectionIndex + 1} does not exist.`, 400);
  }

  const nextSection = stage3.sections[params.sectionIndex + 1] || null;
  const approvedPreviousSections = stage5.sections
    .slice(0, params.sectionIndex)
    .map((s) => `Section ${s.sectionOrder} (${s.heading}):\n${s.spokenNarration.slice(0, 500)}...`)
    .join('\n\n');

  const totalBodyBudgetWords = Math.max(
    250,
    computeTargetWordCount(params.project.settings) -
      (stage4.wordCount || 140) -
      140
  );
  const totalEstMinutes =
    stage3.sections.reduce((acc, s) => acc + (s.estimatedMinutes || 1), 0) || stage3.sections.length;
  const sectionTargetWords = Math.max(
    140,
    Math.round((targetSection.estimatedMinutes / totalEstMinutes) * totalBodyBudgetWords)
  );

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: { type: Type.STRING },
      beats: {
        type: Type.OBJECT,
        properties: {
          mainPoint: { type: Type.STRING },
          simpleExplanation: { type: Type.STRING },
          relatableExample: { type: Type.STRING },
          storyOrScenario: { type: Type.STRING },
          practicalApplication: { type: Type.STRING },
          unexpectedInsight: { type: Type.STRING },
          transition: { type: Type.STRING },
        },
        required: [
          'mainPoint',
          'simpleExplanation',
          'relatableExample',
          'storyOrScenario',
          'practicalApplication',
          'unexpectedInsight',
          'transition',
        ],
      },
      spokenNarration: {
        type: Type.STRING,
        description:
          'Complete cohesive spoken narration for THIS section only, written for listening in natural human voice without bullet lists or robotic transitions.',
      },
    },
    required: ['directorComment', 'beats', 'spokenNarration'],
  };

  const approvedTitle =
    stage2.customTitleText ||
    stage2.titleConcepts.find((t) => t.id === stage2.selectedTitleId)?.title ||
    '';

  const prompt = `Write ONLY Body Section ${params.sectionIndex + 1} of ${stage3.sections.length} for "${approvedTitle}".
Do NOT write other sections. Wait for creator approval after this section.

Section Outline Blueprint:
- Heading: ${targetSection.heading}
- Main Idea: ${targetSection.mainIdea}
- What Viewer Learns: ${targetSection.whatViewerLearns}
- Explanation Notes: ${targetSection.supportingExplanation}
- Story/Example Seed: ${targetSection.exampleOrStory}
- Curiosity Element: ${targetSection.curiosityElement}
- Intended Transition: ${nextSection ? `Lead naturally into "${nextSection.heading}" (${targetSection.transitionToNext})` : `Lead naturally toward final video payoff / outro`}

Approved Introduction Excerpt:
${stage4.spokenNarration}

${approvedPreviousSections ? `Previously Approved Body Context (avoid repeating ideas or transitions used here):\n${approvedPreviousSections}` : ''}

Personalization Settings:
${formatSettingsContext(params.project.settings)}
Target length for this section: approximately ${sectionTargetWords} spoken words (natural, never padded).
${params.instruction ? `\nCreator Revision Instruction: ${params.instruction}` : ''}

7-Beat Structure to weave smoothly into human spoken prose:
1. Main point
2. Explanation in simple language
3. Relatable example
4. Story or clearly framed illustrative scenario (character, situation, challenge, decision, consequence, lesson—never claim fabricated personal history)
5. Practical application
6. Unexpected insight
7. Transition to the next section`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    beats: BodySectionDraft['beats'];
    spokenNarration: string;
  }>({ model, prompt, schema });

  return {
    sectionId: targetSection.id,
    sectionOrder: params.sectionIndex + 1,
    heading: targetSection.heading,
    beats: raw.beats,
    spokenNarration: raw.spokenNarration,
    wordCount: countSpokenWords(raw.spokenNarration),
    directorComment: raw.directorComment,
    approved: false,
    approvedAt: null,
  };
}

// ==============================================================================
// STAGE 6: OUTRO AND CALL TO ACTION (FORTUNE COOKIE PRINCIPLE)
// ==============================================================================

export async function aiGenerateOutro(params: {
  project: ScriptProjectRecord;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<OutroDraft> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const { stage2, stage4, stage5 } = params.project.state;
  const approvedTitle =
    stage2.customTitleText ||
    stage2.titleConcepts.find((t) => t.id === stage2.selectedTitleId)?.title ||
    '';

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: { type: Type.STRING },
      finalInsight: { type: Type.STRING },
      connectionToCentralMessage: { type: Type.STRING },
      takeaway: { type: Type.STRING },
      naturalCta: { type: Type.STRING },
      nextVideoRecommendation: { type: Type.STRING },
      spokenNarration: {
        type: Type.STRING,
        description: 'Natural, memorable spoken outro integrating the Fortune Cookie insight and native CTA seamlessly.',
      },
    },
    required: [
      'directorComment',
      'finalInsight',
      'connectionToCentralMessage',
      'takeaway',
      'naturalCta',
      'nextVideoRecommendation',
      'spokenNarration',
    ],
  };

  const bodySummary = stage5.sections
    .map((s) => `${s.sectionOrder}. ${s.heading}: ${s.beats?.mainPoint || s.spokenNarration.slice(0, 180)}`)
    .join('\n');

  const prompt = `Write Stage 6 Outro & Call to Action using the FORTUNE COOKIE principle (leave the viewer with one memorable final thought that encapsulates the deeper message).

Video Title: "${approvedTitle}"
Video Promise: ${stage2.videoPromise?.whatVideoIsAbout || ''}
Intro Hook: ${stage4.spokenNarration.slice(0, 350)}
Approved Body Key Points:
${bodySummary}

Personalization Settings:
${formatSettingsContext(params.project.settings)}
${params.instruction ? `\nCreator Revision Instruction: ${params.instruction}` : ''}

Outro Structure:
1. Final insight (Fortune Cookie closing line)
2. Brief connection to the central message
3. Emotional or practical takeaway
4. Natural CTA matching creator preference ("${params.project.settings.ctaPreferences}") — never interrupt emotionally or sound like a generic "like and subscribe smash that bell" template
5. Optional next-video recommendation logically continuing this discussion.`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    finalInsight: string;
    connectionToCentralMessage: string;
    takeaway: string;
    naturalCta: string;
    nextVideoRecommendation: string;
    spokenNarration: string;
  }>({ model, prompt, schema });

  return {
    ...raw,
    wordCount: countSpokenWords(raw.spokenNarration),
  };
}

// ==============================================================================
// STAGE 7: COMPLETE SCRIPT ASSEMBLY & QUALITY CONTROL
// ==============================================================================

export async function aiAssembleFinalScript(params: {
  project: ScriptProjectRecord;
  includeProductionNotes: boolean;
  modelName?: ScriptAiModelId;
  instruction?: string;
}): Promise<AssembledScript> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const { stage1, stage2, stage3, stage4, stage5, stage6 } = params.project.state;
  const approvedTitle =
    stage2.customTitleText ||
    stage2.titleConcepts.find((t) => t.id === stage2.selectedTitleId)?.title ||
    stage1.selectedTopic?.title ||
    'Untitled Video';

  const rawSpokenSections = [
    `## INTRODUCTION\n\n${stage4.spokenNarration.trim()}`,
    ...stage5.sections.map(
      (s) => `## SECTION ${s.sectionOrder}: ${s.heading.toUpperCase()}\n\n${s.spokenNarration.trim()}`
    ),
    `## OUTRO & CALL TO ACTION\n\n${(stage6.outro?.spokenNarration || '').trim()}`,
  ].join('\n\n');

  const spokenOnlyText = stripProductionNotes(rawSpokenSections);
  const spokenWordCount = countSpokenWords(spokenOnlyText);
  const wpm = params.project.settings.narrationSpeedWpm || 140;
  const targetWords = computeTargetWordCount(params.project.settings);
  const durationCalc = formatDurationFromWords(spokenWordCount, wpm);

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      directorComment: { type: Type.STRING },
      durationTradeoffNote: {
        type: Type.STRING,
        description:
          'If assembled word count differs notably from requested target without sacrificing quality, explain the trade-off transparently; otherwise empty string.',
      },
      productionScriptText: {
        type: Type.STRING,
        description:
          'When includeProductionNotes is true, insert clear standalone cue lines ([VISUAL], [B-ROLL], [ON-SCREEN TEXT], [SFX], [PAUSE], [TRANSITION], [MUSIC]) on their own lines ABOVE or BETWEEN the preserved spoken paragraphs without rewriting the approved spoken sentences.',
      },
      qualityChecks: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            label: { type: Type.STRING },
            passed: { type: Type.BOOLEAN },
            note: { type: Type.STRING },
          },
          required: ['label', 'passed', 'note'],
        },
      },
    },
    required: ['directorComment', 'durationTradeoffNote', 'productionScriptText', 'qualityChecks'],
  };

  const prompt = `Perform Stage 7 Final Quality Control (all 11 checks) on the creator's ALREADY APPROVED script sections.
CRITICAL: Do NOT rewrite, pad, or replace the approved spoken narration sentences. Preserve the creator's approved words faithfully.
${params.includeProductionNotes ? 'Add tasteful, minimal standalone production cue lines ([VISUAL], [B-ROLL], [ON-SCREEN TEXT], [SFX], [PAUSE], [TRANSITION], [MUSIC]) on their own separate lines between paragraphs (never inline inside spoken sentences).' : 'Return productionScriptText identical to the approved script text without adding cue tags.'}

Metadata:
- Approved Title: ${approvedTitle}
- Thumbnail Text: ${stage2.selectedThumbnailText}
- Target Audience: ${stage1.selectedTopic?.targetAudience || params.project.settings.targetAudience}
- Video Promise: ${stage2.videoPromise?.whatVideoIsAbout || ''}
- Outline Headings: ${stage3.sections.map((s) => s.heading).join(' -> ')}
- Actual Spoken Word Count: ${spokenWordCount} words (Target: ~${targetWords} words at ${wpm} WPM)
${params.instruction ? `\nCreator Assembly Note: ${params.instruction}` : ''}

Approved Script Body to audit${params.includeProductionNotes ? ' & annotate with separate cue lines' : ''}:
${rawSpokenSections}

Run all 11 Quality Control checks explicitly:
1. Opening confirms packaging
2. Delivers promised value
3. Outline is logically structured
4. Every section is useful
5. Zero repeated ideas
6. Stories believable & relevant
7. Factual claims supported/flagged
8. Transitions natural
9. Outro memorable
10. Meets requested duration/word constraint honestly
11. Narration sounds natural when read aloud`;

  const raw = await generateStructuredJson<{
    directorComment: string;
    durationTradeoffNote: string;
    productionScriptText: string;
    qualityChecks: QualityControlCheck[];
  }>({ model, prompt, schema });

  const fullScriptText = params.includeProductionNotes
    ? raw.productionScriptText || rawSpokenSections
    : spokenOnlyText;

  return {
    videoTitle: approvedTitle,
    thumbnailText: stage2.selectedThumbnailText || 'No thumbnail text selected',
    targetAudience: stage1.selectedTopic?.targetAudience || params.project.settings.targetAudience,
    videoPromise: stage2.videoPromise?.whatVideoIsAbout || '',
    estimatedDurationFormatted: durationCalc.formatted,
    estimatedDurationMinutes: durationCalc.minutes,
    estimatedWordCount: spokenWordCount,
    narrationSpeedWpm: wpm,
    includeProductionNotes: params.includeProductionNotes,
    fullScriptText,
    spokenOnlyText,
    qualityChecks: raw.qualityChecks || [],
    durationTradeoffNote: raw.durationTradeoffNote?.trim() ? raw.durationTradeoffNote.trim() : null,
    directorComment: raw.directorComment,
  };
}

// ==============================================================================
// CREATIVE DIRECTOR EXPLANATION / Q&A HELPER
// ==============================================================================

export async function aiExplainDecision(params: {
  project: ScriptProjectRecord;
  stage: ScriptStageNumber;
  question: string;
  modelName?: ScriptAiModelId;
}): Promise<{ explanation: string }> {
  const model = resolveModel(params.modelName ?? params.project.modelName);
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      explanation: { type: Type.STRING },
    },
    required: ['explanation'],
  };

  const prompt = `The creator is at Stage ${params.stage} of the MediaToolsHub AI Scriptwriting Studio and asks:
"${params.question}"

Project Context Summary:
- Topic: ${params.project.state.stage1.selectedTopic?.title || params.project.state.stage1.customTopicInput || 'Not set yet'}
- Title: ${params.project.state.stage2.customTitleText || 'Not finalized'}
- Target Audience: ${params.project.settings.targetAudience}
- Language/Style: ${params.project.settings.scriptLanguage} (${params.project.settings.languageStyle})

Respond like a calm, encouraging Creative Director in simple, beginner-friendly language. Explain any scriptwriting terms you use and tie your advice directly back to their video.`;

  return generateStructuredJson<{ explanation: string }>({ model, prompt, schema });
}
