import fs from 'node:fs';
import path from 'node:path';
import type {
  IntegrationState,
  IntegrationStatus,
  PublicIntegrationFlags,
  YtmOAuthCredentialDiagnostics,
} from '../../shared/types.ts';

export interface ServerEnvConfig {
  youtubeApiKey: string | null;
  adminEmail: string | null;
  geminiApiKey: string | null;
  scriptAiModel: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
  metaAppAccessToken: string | null;
  pinterestAccessToken: string | null;
  gaMeasurementId: string | null;
  gscVerificationToken: string | null;
  adsensePublisherId: string | null;
  googleClientId: string | null;
  googleClientSecret: string | null;
  googleRedirectUri: string | null;
  oauthTokenEncryptionKey: string | null;
}

export const CONFIRMED_MEDIATOOLSHUB_OAUTH_CLIENT_ID =
  '400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com';

export const CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI =
  'https://ais-dev-kvqh4xhi5cdvwvgadzh4th-465872861913.asia-east1.run.app/api/v1/ytm/auth/google/callback';

export interface GoogleOAuthConfig {
  clientId: string | null;
  clientSecret: string | null;
  redirectUri: string;
  redirectUriSource:
    | 'GOOGLE_REDIRECT_URI'
    | 'APP_URL'
    | 'confirmed_default'
    | 'local_dev'
    | 'request_derived';
  redirectUriValid: boolean;
  encryptionKey: string | null;
  configured: boolean;
  diagnostics: YtmOAuthCredentialDiagnostics;
}

function stripWrappingQuotes(value: string): string {
  let out = value.trim();
  const pairs: Array<[string, string]> = [
    ['"', '"'],
    ["'", "'"],
    ['`', '`'],
    ['\u201C', '\u201D'],
    ['\u2018', '\u2019'],
  ];
  for (const [open, close] of pairs) {
    if (out.startsWith(open) && out.endsWith(close) && out.length >= 2) {
      out = out.slice(open.length, out.length - close.length).trim();
    }
  }
  return out;
}

const PLACEHOLDER_SENTINELS = new Set([
  'my_app_url',
  'your_key_here',
  'null',
  'none',
  'nil',
  'n/a',
  'na',
  'true',
  'false',
  'undefined',
  'test',
  'fake',
  'placeholder',
  'changeme',
  'todo',
  'xxxx',
  '****',
  'empty',
  'unset',
  'demo',
  'mock',
  'stub',
  'skip',
  'temp',
  'noop',
  'void',
  '0000',
  '----',
  '____',
  'asdf',
  'abcd',
  '1234',
]);

const OPTIONAL_RUNTIME_ENV_KEYS = [
  'META_APP_ACCESS_TOKEN',
  'PINTEREST_ACCESS_TOKEN',
  'GA_MEASUREMENT_ID',
  'GSC_VERIFICATION_TOKEN',
  'ADSENSE_PUBLISHER_ID',
  'GOOGLE_CLIENT_ID',
  'GOOGLE_CLIENT_SECRET',
  'GOOGLE_REDIRECT_URI',
  'OAUTH_TOKEN_ENCRYPTION_KEY',
] as const;

export function isPlaceholderSentinel(
  value: string | null | undefined,
  injectedSentinel?: string | null
): boolean {
  if (!value) return false;
  const normalized = value.trim().toLowerCase();
  if (!normalized) return false;
  if (injectedSentinel && normalized === injectedSentinel.toLowerCase()) return true;
  if (PLACEHOLDER_SENTINELS.has(normalized)) return true;
  if (normalized.startsWith('replace_with_')) return true;
  return false;
}

function stripZeroWidthAndQuotes(raw: string, expectedKeyName?: string): string {
  // Remove invisible BOM/zero-width chars and accidental CR/LF introduced during secret paste,
  // then trim outer whitespace and matching outer quotes while preserving internal credential chars.
  let cleaned = raw.replace(/[\u200B-\u200D\uFEFF]/g, '').replace(/[\r\n]+/g, '').trim();
  if (!cleaned) return '';
  cleaned = stripWrappingQuotes(cleaned);
  if (expectedKeyName && cleaned.startsWith(`${expectedKeyName}=`)) {
    cleaned = stripWrappingQuotes(cleaned.slice(expectedKeyName.length + 1));
  }
  return cleaned;
}

function detectInjectedEnvSentinel(env: NodeJS.ProcessEnv): string | null {
  const counts = new Map<string, number>();
  for (const key of OPTIONAL_RUNTIME_ENV_KEYS) {
    const raw = env[key];
    if (!raw) continue;
    const stripped = stripZeroWidthAndQuotes(raw, key);
    if (!stripped || stripped.length > 16) continue;
    if (/^https?:\/\//i.test(stripped)) continue;
    const lower = stripped.toLowerCase();
    counts.set(lower, (counts.get(lower) ?? 0) + 1);
  }
  for (const [candidate, occurrences] of counts.entries()) {
    if (occurrences >= 3) {
      return candidate;
    }
  }
  return null;
}

function cleanEnvValue(
  raw: string | undefined,
  expectedKeyName?: string,
  injectedSentinel?: string | null
): string | null {
  if (!raw) return null;
  const trimmed = stripZeroWidthAndQuotes(raw, expectedKeyName);
  if (!trimmed) return null;
  if (isPlaceholderSentinel(trimmed, injectedSentinel)) {
    return null;
  }
  return trimmed;
}

function cleanOAuthCredentialValue(
  raw: string | undefined,
  expectedKeyName: string,
  injectedSentinel?: string | null
): {
  cleaned: string | null;
  isPlaceholderLiteral: boolean;
  hadFormattingArtifacts: boolean;
  hadInternalWhitespace: boolean;
} {
  if (!raw) {
    return {
      cleaned: null,
      isPlaceholderLiteral: false,
      hadFormattingArtifacts: false,
      hadInternalWhitespace: false,
    };
  }
  const baseStripped = stripZeroWidthAndQuotes(raw, expectedKeyName);
  if (!baseStripped) {
    return {
      cleaned: null,
      isPlaceholderLiteral: false,
      hadFormattingArtifacts: false,
      hadInternalWhitespace: false,
    };
  }
  if (isPlaceholderSentinel(baseStripped, injectedSentinel)) {
    return {
      cleaned: null,
      isPlaceholderLiteral: true,
      hadFormattingArtifacts: baseStripped !== raw,
      hadInternalWhitespace: /\s/.test(baseStripped),
    };
  }
  const hadInternalWhitespace = /\s/.test(baseStripped);
  const hadFormattingArtifacts = baseStripped !== raw;
  return {
    cleaned: baseStripped,
    isPlaceholderLiteral: false,
    hadFormattingArtifacts,
    hadInternalWhitespace,
  };
}

function readSecretFileFallback(
  env: NodeJS.ProcessEnv,
  fileEnvKey: string,
  defaultPaths: string[]
): { value: string | null; foundPath: string | null } {
  const candidates: string[] = [];
  const explicitPath = env[fileEnvKey]?.trim();
  if (explicitPath) candidates.push(explicitPath);
  candidates.push(...defaultPaths);

  for (const filePath of candidates) {
    try {
      if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
        const content = fs.readFileSync(filePath, 'utf8');
        if (content.trim()) {
          return { value: content, foundPath: filePath };
        }
      }
    } catch {
      // Skip unreadable or missing mount path
    }
  }
  return { value: null, foundPath: null };
}

function resolveOAuthSecretWithMount(
  env: NodeJS.ProcessEnv,
  envKey: 'GOOGLE_CLIENT_SECRET' | 'OAUTH_TOKEN_ENCRYPTION_KEY',
  injectedSentinel?: string | null
): {
  parsed: ReturnType<typeof cleanOAuthCredentialValue>;
  rawValue: string;
  fromSecretMount: boolean;
} {
  const envRaw = env[envKey];
  const envParsed = cleanOAuthCredentialValue(envRaw, envKey, injectedSentinel);
  if (envParsed.cleaned) {
    return {
      parsed: envParsed,
      rawValue: envRaw ?? '',
      fromSecretMount: false,
    };
  }

  const mountFallback = readSecretFileFallback(env, `${envKey}_FILE`, [
    `/secrets/${envKey}`,
    `/etc/secrets/${envKey}`,
    `/secrets/${envKey.toLowerCase()}`,
  ]);
  if (mountFallback.value) {
    const fileParsed = cleanOAuthCredentialValue(mountFallback.value, envKey, injectedSentinel);
    if (fileParsed.cleaned) {
      return {
        parsed: fileParsed,
        rawValue: mountFallback.value,
        fromSecretMount: true,
      };
    }
  }

  return {
    parsed: envParsed,
    rawValue: envRaw ?? '',
    fromSecretMount: false,
  };
}

export function getServerConfig(
  env: NodeJS.ProcessEnv = process.env
): ServerEnvConfig {
  const injectedSentinel = detectInjectedEnvSentinel(env);
  const rawModel = cleanEnvValue(env.SCRIPT_AI_MODEL, undefined, injectedSentinel);
  const scriptAiModel: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite' =
    rawModel === 'gemini-3.1-flash-lite' ? 'gemini-3.1-flash-lite' : 'gemini-4-hydrogen';

  const clientIdParsed = cleanOAuthCredentialValue(
    env.GOOGLE_CLIENT_ID,
    'GOOGLE_CLIENT_ID',
    injectedSentinel
  );
  const clientSecretResolved = resolveOAuthSecretWithMount(
    env,
    'GOOGLE_CLIENT_SECRET',
    injectedSentinel
  );
  const encryptionKeyResolved = resolveOAuthSecretWithMount(
    env,
    'OAUTH_TOKEN_ENCRYPTION_KEY',
    injectedSentinel
  );

  return {
    youtubeApiKey: cleanEnvValue(env.YOUTUBE_API_KEY, undefined, injectedSentinel),
    adminEmail: cleanEnvValue(env.ADMIN_EMAIL, undefined, injectedSentinel),
    geminiApiKey: cleanEnvValue(env.GEMINI_API_KEY, undefined, injectedSentinel),
    scriptAiModel,
    metaAppAccessToken: cleanEnvValue(env.META_APP_ACCESS_TOKEN, undefined, injectedSentinel),
    pinterestAccessToken: cleanEnvValue(env.PINTEREST_ACCESS_TOKEN, undefined, injectedSentinel),
    gaMeasurementId: cleanEnvValue(env.GA_MEASUREMENT_ID, undefined, injectedSentinel),
    gscVerificationToken: cleanEnvValue(env.GSC_VERIFICATION_TOKEN, undefined, injectedSentinel),
    adsensePublisherId: cleanEnvValue(env.ADSENSE_PUBLISHER_ID, undefined, injectedSentinel),
    googleClientId: clientIdParsed.cleaned,
    googleClientSecret: clientSecretResolved.parsed.cleaned,
    googleRedirectUri: cleanEnvValue(
      env.GOOGLE_REDIRECT_URI,
      'GOOGLE_REDIRECT_URI',
      injectedSentinel
    ),
    oauthTokenEncryptionKey: encryptionKeyResolved.parsed.cleaned,
  };
}

const GOOGLE_CLIENT_ID_PATTERN = /^\d{4,25}-[a-z0-9._-]{6,120}\.apps\.googleusercontent\.com$/i;

function normalizeCallbackUrl(raw: string): string | null {
  try {
    const parsed = new URL(raw.trim());
    if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
      return null;
    }
    const cleanPath = parsed.pathname.replace(/\/+$/, '');
    parsed.pathname = cleanPath || '/api/v1/ytm/auth/google/callback';
    parsed.search = '';
    parsed.hash = '';
    return parsed.toString();
  } catch {
    return null;
  }
}

export function getGoogleOAuthCredentialDiagnostics(
  env: NodeJS.ProcessEnv = process.env,
  resolvedRedirectUri?: string
): YtmOAuthCredentialDiagnostics {
  const injectedSentinel = detectInjectedEnvSentinel(env);
  const clientIdParsed = cleanOAuthCredentialValue(
    env.GOOGLE_CLIENT_ID,
    'GOOGLE_CLIENT_ID',
    injectedSentinel
  );
  const clientSecretResolved = resolveOAuthSecretWithMount(
    env,
    'GOOGLE_CLIENT_SECRET',
    injectedSentinel
  );
  const clientSecretParsed = clientSecretResolved.parsed;

  const clientId = clientIdParsed.cleaned;
  const clientSecret = clientSecretParsed.cleaned;
  const redirectOverride = cleanEnvValue(
    env.GOOGLE_REDIRECT_URI,
    'GOOGLE_REDIRECT_URI',
    injectedSentinel
  );
  const appUrl = cleanEnvValue(env.APP_URL, undefined, injectedSentinel);

  let googleRedirectUriValid = false;
  let normalizedRedirectOverride: string | null = null;
  if (redirectOverride) {
    normalizedRedirectOverride = normalizeCallbackUrl(redirectOverride);
    googleRedirectUriValid = Boolean(normalizedRedirectOverride);
  }

  const normalizedAppCallback = appUrl
    ? normalizeCallbackUrl(`${appUrl.replace(/\/+$/, '')}/api/v1/ytm/auth/google/callback`)
    : null;

  const normalizedResolvedOverride = resolvedRedirectUri
    ? normalizeCallbackUrl(resolvedRedirectUri)
    : null;

  const redirectUri =
    normalizedResolvedOverride ||
    normalizedRedirectOverride ||
    normalizedAppCallback ||
    CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI;

  const redirectUriValid = Boolean(normalizeCallbackUrl(redirectUri));

  const redirectUriSource: YtmOAuthCredentialDiagnostics['redirectUriSource'] =
    normalizedRedirectOverride
      ? 'GOOGLE_REDIRECT_URI'
      : normalizedAppCallback
        ? 'APP_URL'
        : normalizedResolvedOverride &&
            normalizedResolvedOverride !== CONFIRMED_MEDIATOOLSHUB_REDIRECT_URI
          ? 'local_dev'
          : 'confirmed_default';

  let dotenvFilePresent = false;
  try {
    dotenvFilePresent = fs.existsSync(path.join(process.cwd(), '.env'));
  } catch {
    dotenvFilePresent = false;
  }

  const frontendEnvOverridePresent = Boolean(
    cleanEnvValue(env.VITE_GOOGLE_CLIENT_ID) || cleanEnvValue(env.VITE_GOOGLE_CLIENT_SECRET)
  );

  const rawClientId = env.GOOGLE_CLIENT_ID ?? '';
  const rawClientSecret = clientSecretResolved.rawValue;
  const rawRedirectUri = env.GOOGLE_REDIRECT_URI ?? '';
  const rawClientIdHasQuotes = /["'`\u201C\u201D\u2018\u2019]/.test(rawClientId);
  const rawClientIdHasWhitespace = /\s/.test(rawClientId);
  const rawClientSecretHasQuotes = /["'`\u201C\u201D\u2018\u2019]/.test(rawClientSecret);
  const rawClientSecretHasWhitespace = /\s/.test(rawClientSecret);

  const issues: string[] = [];

  let clientIdIssueCode: YtmOAuthCredentialDiagnostics['clientIdIssueCode'] = 'ok';
  let clientIdIssueMessage = 'GOOGLE_CLIENT_ID is present and matches Google OAuth Web Client ID format.';
  let clientIdFormatValid = false;

  if (clientIdParsed.isPlaceholderLiteral) {
    clientIdIssueCode = 'placeholder_literal';
    clientIdIssueMessage = `GOOGLE_CLIENT_ID in server process.env is set to a ${rawClientId.trim().length}-character placeholder sentinel instead of your Google Web Client ID ending in .apps.googleusercontent.com.`;
    issues.push('placeholder_client_id');
  } else if (!clientId) {
    clientIdIssueCode = 'missing';
    clientIdIssueMessage = 'GOOGLE_CLIENT_ID is empty or missing from server environment configuration.';
    issues.push('missing_client_id');
  } else if (clientIdParsed.hadInternalWhitespace) {
    clientIdIssueCode = 'contains_whitespace';
    clientIdIssueMessage =
      'GOOGLE_CLIENT_ID contains internal whitespace characters. Copy only the clean Web application Client ID string.';
    issues.push('client_id_contains_whitespace');
  } else if (clientId.startsWith('{') || clientId.startsWith('[')) {
    clientIdIssueCode = 'looks_like_json';
    clientIdIssueMessage =
      'GOOGLE_CLIENT_ID appears to contain a JSON object instead of just the Client ID string ending in .apps.googleusercontent.com.';
    issues.push('client_id_looks_like_json');
  } else if (/^AIza/i.test(clientId)) {
    clientIdIssueCode = 'api_key_instead_of_client_id';
    clientIdIssueMessage =
      'GOOGLE_CLIENT_ID starts with "AIza", which is a Google API key rather than an OAuth 2.0 Web application Client ID.';
    issues.push('api_key_instead_of_client_id');
  } else if (/^GOCSPX-/i.test(clientId)) {
    clientIdIssueCode = 'swapped_with_secret';
    clientIdIssueMessage =
      'GOOGLE_CLIENT_ID starts with "GOCSPX-", which is an OAuth Client Secret. Swap GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your server environment variables.';
    issues.push('client_id_swapped_with_secret');
  } else if (!clientId.toLowerCase().endsWith('.apps.googleusercontent.com')) {
    clientIdIssueCode = 'missing_apps_domain';
    clientIdIssueMessage =
      'GOOGLE_CLIENT_ID does not end with ".apps.googleusercontent.com". Set the full Web application Client ID from Google Cloud Console.';
    issues.push('missing_apps_domain');
  } else if (!GOOGLE_CLIENT_ID_PATTERN.test(clientId)) {
    clientIdIssueCode = 'invalid_format';
    clientIdIssueMessage =
      'GOOGLE_CLIENT_ID does not match the expected "<project-number>-<hash>.apps.googleusercontent.com" format.';
    issues.push('invalid_client_id_format');
  } else {
    clientIdFormatValid = true;
  }

  let clientSecretIssueCode: YtmOAuthCredentialDiagnostics['clientSecretIssueCode'] = 'ok';
  let clientSecretIssueMessage = 'GOOGLE_CLIENT_SECRET is present and formatted cleanly.';
  let clientSecretFormatValid = false;

  if (clientSecretParsed.isPlaceholderLiteral) {
    clientSecretIssueCode = 'placeholder_literal';
    clientSecretIssueMessage = `GOOGLE_CLIENT_SECRET in server process.env is set to a ${rawClientSecret.trim().length}-character placeholder sentinel instead of a real Google OAuth Client Secret.`;
    issues.push('placeholder_client_secret');
  } else if (!clientSecret) {
    clientSecretIssueCode = 'missing';
    clientSecretIssueMessage =
      'GOOGLE_CLIENT_SECRET is empty or missing from server environment configuration.';
    issues.push('missing_client_secret');
  } else if (clientSecretParsed.hadInternalWhitespace) {
    clientSecretIssueCode = 'invalid_format';
    clientSecretIssueMessage =
      'GOOGLE_CLIENT_SECRET contains internal whitespace characters. Paste only the exact Client Secret string without spaces.';
    issues.push('invalid_format');
  } else if (clientSecret.startsWith('{') || clientSecret.startsWith('[')) {
    clientSecretIssueCode = 'looks_like_json';
    clientSecretIssueMessage =
      'GOOGLE_CLIENT_SECRET appears to contain JSON instead of the secret string.';
    issues.push('invalid_format');
  } else if (/\.apps\.googleusercontent\.com$/i.test(clientSecret)) {
    clientSecretIssueCode = 'swapped_with_client_id';
    clientSecretIssueMessage =
      'GOOGLE_CLIENT_SECRET ends with ".apps.googleusercontent.com", which is a Client ID. Swap GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your server environment variables.';
    issues.push('client_secret_swapped_with_client_id');
  } else if (/^AIza/i.test(clientSecret)) {
    clientSecretIssueCode = 'looks_like_api_key';
    clientSecretIssueMessage =
      'GOOGLE_CLIENT_SECRET starts with "AIza" (a Google API Key) instead of an OAuth 2.0 Client Secret.';
    issues.push('invalid_format');
  } else if (clientSecret.length < 12 || !/^[\x21-\x7E]+$/.test(clientSecret)) {
    // Allow GOCSPX-... and any future/legacy Google-issued ASCII secret >= 12 chars without rigid fixed-length assumptions
    clientSecretIssueCode = 'invalid_format';
    clientSecretIssueMessage =
      'GOOGLE_CLIENT_SECRET appears truncated or contains invalid characters. Paste the complete Client Secret from Google Cloud Console.';
    issues.push('invalid_format');
  } else {
    clientSecretFormatValid = true;
  }

  if (redirectOverride && !googleRedirectUriValid) {
    issues.push('invalid_redirect_uri');
  }
  if (!redirectUriValid) {
    issues.push('invalid_redirect_uri');
  }
  if (frontendEnvOverridePresent) {
    issues.push('frontend_env_override_detected');
  }

  const clientIdEndsWithAppsDomain = Boolean(
    clientId && clientId.toLowerCase().endsWith('.apps.googleusercontent.com')
  );
  const clientIdMatchesExpectedProjectClient = Boolean(
    clientId && clientId === CONFIRMED_MEDIATOOLSHUB_OAUTH_CLIENT_ID
  );
  const relatedEnvKeyLengths = Object.keys(env)
    .filter((k) =>
      /^(GOOGLE_CLIENT_ID|GOOGLE_CLIENT_SECRET|GOOGLE_REDIRECT_URI|OAUTH_TOKEN_ENCRYPTION_KEY|APP_URL)$/.test(
        k
      )
    )
    .sort()
    .map((k) => ({ key: k, length: (env[k] ?? '').length }));

  const source: YtmOAuthCredentialDiagnostics['source'] = clientSecretResolved.fromSecretMount
    ? 'secret_manager_mount'
    : clientId || clientSecret || clientIdParsed.isPlaceholderLiteral || clientSecretParsed.isPlaceholderLiteral
      ? 'server_env'
      : 'missing';

  const oauthConfigured = Boolean(
    clientId && clientSecret && clientIdFormatValid && clientSecretFormatValid && redirectUriValid
  );

  return {
    configured: Boolean(clientId && clientSecret),
    oauthConfigured,
    source,
    dotenvFilePresent,
    secretMountDetected: clientSecretResolved.fromSecretMount,
    cloudRunService: env.K_SERVICE || null,
    cloudRunRevision: env.K_REVISION || null,
    frontendEnvOverridePresent,
    clientIdPresent: Boolean(clientId),
    clientIdLength: clientId ? clientId.length : 0,
    rawClientIdLength: rawClientId.length,
    rawClientIdHasQuotes,
    rawClientIdHasWhitespace,
    clientIdHasQuotes: rawClientIdHasQuotes,
    clientIdHasWhitespace: rawClientIdHasWhitespace,
    clientIdEndsWithAppsDomain,
    clientIdSuffixMatches: clientIdEndsWithAppsDomain,
    clientIdIsPlaceholderLiteral: clientIdParsed.isPlaceholderLiteral,
    clientIdPlaceholder: clientIdParsed.isPlaceholderLiteral,
    clientIdFormatValid,
    clientIdHadFormattingArtifacts: clientIdParsed.hadFormattingArtifacts,
    clientIdMatchesExpectedProjectClient,
    clientIdIssueCode,
    clientIdIssueMessage,
    clientSecretPresent: Boolean(clientSecret),
    clientSecretLength: clientSecret ? clientSecret.length : 0,
    rawClientSecretLength: rawClientSecret.length,
    clientSecretHasQuotes: rawClientSecretHasQuotes,
    clientSecretHasWhitespace: rawClientSecretHasWhitespace,
    clientSecretIsPlaceholderLiteral: clientSecretParsed.isPlaceholderLiteral,
    clientSecretPlaceholder: clientSecretParsed.isPlaceholderLiteral,
    clientSecretFormatValid,
    clientSecretIssueCode,
    clientSecretIssueMessage,
    redirectUri,
    redirectUriValid,
    googleRedirectUriPresent: Boolean(redirectOverride),
    googleRedirectUriValid,
    googleRedirectUriLength: rawRedirectUri.length,
    redirectUriSource,
    issues: Array.from(new Set(issues)),
    serverUptimeSeconds: Math.round(process.uptime()),
    relatedEnvKeyLengths,
  };
}

export function getGoogleOAuthConfig(
  env: NodeJS.ProcessEnv = process.env,
  resolvedRedirectUri?: string
): GoogleOAuthConfig {
  const cfg = getServerConfig(env);
  const diagnostics = getGoogleOAuthCredentialDiagnostics(env, resolvedRedirectUri);
  return {
    clientId: cfg.googleClientId,
    clientSecret: cfg.googleClientSecret,
    redirectUri: diagnostics.redirectUri,
    redirectUriSource: diagnostics.redirectUriSource || 'confirmed_default',
    redirectUriValid: diagnostics.redirectUriValid,
    encryptionKey: cfg.oauthTokenEncryptionKey,
    configured: diagnostics.oauthConfigured,
    diagnostics,
  };
}

export function getYtmOAuthConfigStatus(env: NodeJS.ProcessEnv = process.env): {
  configured: boolean;
  hasClientId: boolean;
  hasClientSecret: boolean;
  hasEncryptionKey: boolean;
  redirectUriOverride: string | null;
  missingVars: string[];
  diagnostics: YtmOAuthCredentialDiagnostics;
} {
  const cfg = getServerConfig(env);
  const diagnostics = getGoogleOAuthCredentialDiagnostics(env);
  const missingVars: string[] = [];
  if (!cfg.googleClientId) missingVars.push('GOOGLE_CLIENT_ID');
  if (!cfg.googleClientSecret) missingVars.push('GOOGLE_CLIENT_SECRET');
  return {
    configured: Boolean(cfg.googleClientId && cfg.googleClientSecret),
    hasClientId: Boolean(cfg.googleClientId),
    hasClientSecret: Boolean(cfg.googleClientSecret),
    hasEncryptionKey: Boolean(cfg.oauthTokenEncryptionKey),
    redirectUriOverride: cfg.googleRedirectUri,
    missingVars,
    diagnostics,
  };
}

export function isValidGaMeasurementId(value: string | null | undefined): boolean {
  if (!value) return false;
  return /^G-[A-Z0-9]{4,20}$/i.test(value.trim());
}

export function resolveSettingWithEnv(
  dbSettings: Record<string, string | undefined>,
  settingKey: string,
  envValue: string | null
): { value: string; source: 'admin_settings' | 'env' | 'missing' } {
  const dbVal = cleanEnvValue(dbSettings[settingKey]);
  if (dbVal) {
    return { value: dbVal, source: 'admin_settings' };
  }
  if (envValue) {
    return { value: envValue, source: 'env' };
  }
  return { value: '', source: 'missing' };
}

function isIntegrationToggleEnabled(
  dbSettings: Record<string, string | undefined>,
  toggleKey: string
): boolean {
  const raw = dbSettings[toggleKey];
  if (raw === undefined || raw === '') return true;
  return raw !== 'false';
}

function resolveState(
  configured: boolean,
  enabled: boolean
): IntegrationState {
  if (!enabled) return 'Disabled';
  return configured ? 'Connected' : 'Not Configured';
}

export function getPublicIntegrationFlags(
  dbSettings: Record<string, string | undefined> = {},
  env: NodeJS.ProcessEnv = process.env
): PublicIntegrationFlags {
  const cfg = getServerConfig(env);
  const adsense = resolveSettingWithEnv(dbSettings, 'adsense_publisher_id', cfg.adsensePublisherId);
  const ga = resolveSettingWithEnv(dbSettings, 'ga_measurement_id', cfg.gaMeasurementId);
  const gsc = resolveSettingWithEnv(dbSettings, 'gsc_verification_token', cfg.gscVerificationToken);

  return {
    youtubeApiConfigured: Boolean(cfg.youtubeApiKey),
    metaApiConfigured:
      Boolean(cfg.metaAppAccessToken) &&
      isIntegrationToggleEnabled(dbSettings, 'integration_enabled_meta'),
    pinterestApiConfigured:
      Boolean(cfg.pinterestAccessToken) &&
      isIntegrationToggleEnabled(dbSettings, 'integration_enabled_pinterest'),
    adsenseEnabled:
      Boolean(adsense.value) &&
      isIntegrationToggleEnabled(dbSettings, 'integration_enabled_adsense'),
    gaEnabled:
      isValidGaMeasurementId(ga.value) &&
      isIntegrationToggleEnabled(dbSettings, 'integration_enabled_ga'),
    gscEnabled:
      Boolean(gsc.value) &&
      isIntegrationToggleEnabled(dbSettings, 'integration_enabled_gsc'),
  };
}

export function getAdminIntegrationsReport(
  dbSettings: Record<string, string | undefined> = {},
  env: NodeJS.ProcessEnv = process.env
): IntegrationStatus[] {
  const cfg = getServerConfig(env);
  const adsense = resolveSettingWithEnv(dbSettings, 'adsense_publisher_id', cfg.adsensePublisherId);
  const ga = resolveSettingWithEnv(dbSettings, 'ga_measurement_id', cfg.gaMeasurementId);
  const gsc = resolveSettingWithEnv(dbSettings, 'gsc_verification_token', cfg.gscVerificationToken);

  const metaEnabled = isIntegrationToggleEnabled(dbSettings, 'integration_enabled_meta');
  const pinterestEnabled = isIntegrationToggleEnabled(dbSettings, 'integration_enabled_pinterest');
  const gaEnabled = isIntegrationToggleEnabled(dbSettings, 'integration_enabled_ga');
  const gscEnabled = isIntegrationToggleEnabled(dbSettings, 'integration_enabled_gsc');
  const adsenseEnabled = isIntegrationToggleEnabled(dbSettings, 'integration_enabled_adsense');

  const gaValid = isValidGaMeasurementId(ga.value);
  const gaState: IntegrationState = !gaEnabled
    ? 'Disabled'
    : !ga.value
      ? 'Not Configured'
      : gaValid
        ? 'Connected'
        : 'Disabled';

  return [
    {
      envVar: 'YOUTUBE_API_KEY',
      label: 'YouTube Data API v3',
      required: true,
      status: cfg.youtubeApiKey ? 'Connected' : 'Not Configured',
      active: Boolean(cfg.youtubeApiKey),
      source: cfg.youtubeApiKey ? 'env' : 'missing',
      canConfigureInAdmin: false,
      statusMessage: cfg.youtubeApiKey
        ? 'Connected on server. videos.list and channels.list queries are active with response caching.'
        : 'Not Configured in environment. Required for YouTube Data API v3 statistics (views, likes, comments, channel counts); falling back to public oEmbed.',
      disabledBehavior:
        'Extended YouTube API statistics are inactive; public oEmbed titles and thumbnail probing remain available.',
      activationHint:
        'Set YOUTUBE_API_KEY in your server environment / Secrets panel.',
    },
    {
      envVar: 'ADMIN_EMAIL',
      label: 'Administrator Configuration',
      required: true,
      status: cfg.adminEmail ? 'Connected' : 'Not Configured',
      active: Boolean(cfg.adminEmail),
      source: cfg.adminEmail ? 'env' : 'missing',
      canConfigureInAdmin: false,
      statusMessage: cfg.adminEmail
        ? `Connected (${cfg.adminEmail}). Designated administrator receives admin role on verified Google Sign-In.`
        : 'Not Configured explicitly in ADMIN_EMAIL. Existing administrator database accounts continue to work.',
      disabledBehavior:
        'Automatic admin promotion for new accounts via environment variable waits until ADMIN_EMAIL is set.',
      activationHint:
        'Set ADMIN_EMAIL in your server environment / Secrets panel.',
    },
    {
      envVar: 'GEMINI_API_KEY',
      label: 'AI Scriptwriting Studio (Gemini)',
      required: false,
      status: cfg.geminiApiKey ? 'Connected' : 'Not Configured',
      active: Boolean(cfg.geminiApiKey),
      source: cfg.geminiApiKey ? 'env' : 'missing',
      canConfigureInAdmin: false,
      statusMessage: cfg.geminiApiKey
        ? `Connected on server using ${cfg.scriptAiModel}. Scriptwriting Studio stage generation is active.`
        : 'Not Configured in server environment. Scriptwriting Studio generation requires GEMINI_API_KEY in Secrets.',
      disabledBehavior:
        'Project saving and manual editing remain functional; AI stage generation reports an unavailable configuration notice.',
      activationHint:
        'Set GEMINI_API_KEY in your server environment / Secrets panel.',
    },
    {
      envVar: 'META_APP_ACCESS_TOKEN',
      label: 'Meta Graph API (Instagram & Facebook)',
      required: false,
      status: resolveState(Boolean(cfg.metaAppAccessToken), metaEnabled),
      active: Boolean(cfg.metaAppAccessToken) && metaEnabled,
      source: cfg.metaAppAccessToken ? 'env' : 'missing',
      canConfigureInAdmin: false,
      toggleSettingKey: 'integration_enabled_meta',
      statusMessage: !metaEnabled
        ? 'Disabled by administrator toggle. Meta Graph API requests are bypassed.'
        : cfg.metaAppAccessToken
          ? 'Connected on server. Live Meta Graph API oEmbed lookups are active.'
          : 'Not Configured (optional). Meta Graph API calls are skipped without blocking development.',
      disabledBehavior:
        'Instagram and Facebook tools continue URL validation and compliant official embed generation.',
      activationHint:
        'Add META_APP_ACCESS_TOKEN in server Secrets anytime to connect Meta oEmbed metadata.',
    },
    {
      envVar: 'PINTEREST_ACCESS_TOKEN',
      label: 'Pinterest API v5',
      required: false,
      status: resolveState(Boolean(cfg.pinterestAccessToken), pinterestEnabled),
      active: Boolean(cfg.pinterestAccessToken) && pinterestEnabled,
      source: cfg.pinterestAccessToken ? 'env' : 'missing',
      canConfigureInAdmin: false,
      toggleSettingKey: 'integration_enabled_pinterest',
      statusMessage: !pinterestEnabled
        ? 'Disabled by administrator toggle. Pinterest API v5 endpoints are skipped.'
        : cfg.pinterestAccessToken
          ? 'Connected on server. Official Pinterest API v5 Pin lookups are active.'
          : 'Not Configured (optional). Pinterest API v5 endpoints are skipped; public OpenGraph parser remains active.',
      disabledBehavior:
        'Official Pinterest API v5 lookups are bypassed cleanly; public OpenGraph inspection and embeds keep working.',
      activationHint:
        'Add PINTEREST_ACCESS_TOKEN in server Secrets anytime to connect Pinterest API v5.',
    },
    {
      envVar: 'GA_MEASUREMENT_ID',
      label: 'Google Analytics 4',
      required: false,
      status: gaState,
      active: gaState === 'Connected',
      source: ga.value ? ga.source : 'missing',
      canConfigureInAdmin: true,
      settingKey: 'ga_measurement_id',
      toggleSettingKey: 'integration_enabled_ga',
      statusMessage: !gaEnabled
        ? 'Disabled by administrator toggle. Google Analytics tracking script is omitted.'
        : gaState === 'Connected'
          ? `Connected (${ga.value}) via ${ga.source === 'admin_settings' ? 'Admin Settings' : 'environment variable'}.`
          : ga.value
            ? 'Disabled because the configured Measurement ID is invalid (expected G-XXXXXXXXXX).'
            : 'Not Configured (optional). Google Analytics script is omitted from public pages.',
      disabledBehavior:
        'No gtag.js script is injected and zero client-side tracking errors are produced.',
      activationHint:
        'Enter your G-XXXXXXXXXX ID in Settings & Limits or set GA_MEASUREMENT_ID later.',
    },
    {
      envVar: 'GSC_VERIFICATION_TOKEN',
      label: 'Google Search Console',
      required: false,
      status: resolveState(Boolean(gsc.value), gscEnabled),
      active: Boolean(gsc.value) && gscEnabled,
      source: gsc.value ? gsc.source : 'missing',
      canConfigureInAdmin: true,
      settingKey: 'gsc_verification_token',
      toggleSettingKey: 'integration_enabled_gsc',
      statusMessage: !gscEnabled
        ? 'Disabled by administrator toggle. Verification meta tag is omitted.'
        : gsc.value
          ? `Connected via ${gsc.source === 'admin_settings' ? 'Admin Settings' : 'environment variable'}. Verification meta tag is injected.`
          : 'Not Configured (optional). Search Console verification meta tag is omitted.',
      disabledBehavior:
        'No empty google-site-verification meta tag is rendered in HTML.',
      activationHint:
        'Paste your verification token in Settings & Limits or set GSC_VERIFICATION_TOKEN later.',
    },
    {
      envVar: 'ADSENSE_PUBLISHER_ID',
      label: 'Google AdSense',
      required: false,
      status: resolveState(Boolean(adsense.value), adsenseEnabled),
      active: Boolean(adsense.value) && adsenseEnabled,
      source: adsense.value ? adsense.source : 'missing',
      canConfigureInAdmin: true,
      settingKey: 'adsense_publisher_id',
      toggleSettingKey: 'integration_enabled_adsense',
      statusMessage: !adsenseEnabled
        ? 'Disabled by administrator toggle. Google AdSense ad slots are hidden.'
        : adsense.value
          ? `Connected (${adsense.value}) via ${adsense.source === 'admin_settings' ? 'Admin Settings' : 'environment variable'}.`
          : 'Not Configured (optional). AdSense ad units are hidden so visitors never see broken placeholders.',
      disabledBehavior:
        'Google AdSense slots remain hidden cleanly until a Publisher ID and Ad Unit IDs are configured.',
      activationHint:
        'Enter your ca-pub-... Publisher ID in Settings & Limits or set ADSENSE_PUBLISHER_ID later.',
    },
    {
      envVar: 'GOOGLE_CLIENT_ID',
      label: 'YouTube Channel OAuth 2.0 (YouTube Management)',
      required: false,
      status: Boolean(cfg.googleClientId && cfg.googleClientSecret) ? 'Connected' : 'Not Configured',
      active: Boolean(cfg.googleClientId && cfg.googleClientSecret),
      source: cfg.googleClientId && cfg.googleClientSecret ? 'env' : 'missing',
      canConfigureInAdmin: false,
      statusMessage:
        cfg.googleClientId && cfg.googleClientSecret
          ? 'Google OAuth 2.0 credentials configured. Creators can connect channels, upload videos, fetch analytics, and manage comments.'
          : 'Not Configured. Creators can plan, script, generate SEO, and use manual publishing; live YouTube OAuth requires GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET.',
      disabledBehavior:
        'Live channel connection, resumable upload, YouTube Analytics API v2, and API comment replies display setup guidance.',
      activationHint:
        'Configure GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI, and OAUTH_TOKEN_ENCRYPTION_KEY in your server runtime environment variables (Cloud Run Variables & Secrets) and redeploy/restart.',
    },
  ];
}

export function getMandatoryStartupConfig(
  env: NodeJS.ProcessEnv = process.env
): { youtubeApiKey: string | null; adminEmail: string | null } {
  const cfg = getServerConfig(env);
  return {
    youtubeApiKey: cfg.youtubeApiKey,
    adminEmail: cfg.adminEmail,
  };
}

export function logStartupEnvStatus(env: NodeJS.ProcessEnv = process.env): void {
  const mandatory = getMandatoryStartupConfig(env);
  const missing: string[] = [];
  if (!mandatory.youtubeApiKey) missing.push('YOUTUBE_API_KEY');
  if (!mandatory.adminEmail) missing.push('ADMIN_EMAIL');

  if (missing.length > 0) {
    console.warn(
      `[MediaToolsHub] Startup notice: ${missing.join(', ')} not set in environment. Server remains active without blocking development.`
    );
  }

  const ytmOAuth = getYtmOAuthConfigStatus(env);
  const diag = ytmOAuth.diagnostics;
  console.info(
    `[MediaToolsHub] YTM OAuth status: ${JSON.stringify({
      configured: ytmOAuth.configured,
      source: diag.source,
      dotenvFilePresent: diag.dotenvFilePresent,
      frontendEnvOverridePresent: diag.frontendEnvOverridePresent,
      clientIdPresent: diag.clientIdPresent,
      clientIdLength: diag.clientIdLength,
      rawClientIdLength: diag.rawClientIdLength,
      clientIdEndsWithAppsDomain: diag.clientIdEndsWithAppsDomain,
      clientIdIsPlaceholderLiteral: diag.clientIdIsPlaceholderLiteral,
      clientIdFormatValid: diag.clientIdFormatValid,
      clientIdIssueCode: diag.clientIdIssueCode,
      clientSecretPresent: diag.clientSecretPresent,
      clientSecretLength: diag.clientSecretLength,
      rawClientSecretLength: diag.rawClientSecretLength,
      clientSecretIsPlaceholderLiteral: diag.clientSecretIsPlaceholderLiteral,
      clientSecretFormatValid: diag.clientSecretFormatValid,
      clientSecretIssueCode: diag.clientSecretIssueCode,
      googleRedirectUriPresent: diag.googleRedirectUriPresent,
      redirectUriSource: diag.redirectUriSource,
      redirectUri: diag.redirectUri,
    })}`
  );
}
