import { eq } from 'drizzle-orm';
import { db } from './index.ts';
import { users } from './schema.ts';

function isBootstrapAdminEmail(email: string): boolean {
  const configured = (process.env.ADMIN_EMAIL || 'abrarulhaq4578@gmail.com')
    .trim()
    .toLowerCase();
  return email.trim().toLowerCase() === configured;
}

export async function getOrCreateUser(
  uid: string,
  email: string,
  displayName?: string | null,
  photoUrl?: string | null
) {
  try {
    const existing = await db
      .select()
      .from(users)
      .where(eq(users.uid, uid))
      .limit(1);

    if (existing.length > 0) {
      const updated = await db
        .update(users)
        .set({
          email,
          displayName: displayName ?? existing[0].displayName,
          photoUrl: photoUrl ?? existing[0].photoUrl,
          updatedAt: new Date(),
        })
        .where(eq(users.uid, uid))
        .returning();
      return updated[0];
    }

    const role = isBootstrapAdminEmail(email) ? 'admin' : 'user';
    const result = await db
      .insert(users)
      .values({
        uid,
        email,
        displayName: displayName ?? null,
        photoUrl: photoUrl ?? null,
        role,
        plan: role === 'admin' ? 'developer' : 'free',
        isActive: true,
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email,
          displayName: displayName ?? null,
          photoUrl: photoUrl ?? null,
          updatedAt: new Date(),
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database user sync failed:', error);
    throw new Error('Unable to synchronize user profile.', { cause: error });
  }
}

export async function getUserByUid(uid: string) {
  try {
    const rows = await db.select().from(users).where(eq(users.uid, uid)).limit(1);
    return rows[0] ?? null;
  } catch (error) {
    console.error('Database getUserByUid failed:', error);
    throw new Error('Unable to retrieve user record.', { cause: error });
  }
}
