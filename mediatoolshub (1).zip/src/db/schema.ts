import { relations } from 'drizzle-orm';
import {
  boolean,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from 'drizzle-orm/pg-core';

export const users = pgTable(
  'users',
  {
    id: serial('id').primaryKey(),
    uid: text('uid').notNull().unique(),
    email: text('email').notNull(),
    displayName: text('display_name'),
    photoUrl: text('photo_url'),
    role: text('role').notNull().default('user'), // 'user' | 'admin'
    plan: text('plan').notNull().default('free'), // 'free' | 'pro' | 'developer'
    isActive: boolean('is_active').notNull().default(true),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('users_email_idx').on(table.email)]
);

export const platforms = pgTable(
  'platforms',
  {
    id: serial('id').primaryKey(),
    slug: text('slug').notNull().unique(),
    name: text('name').notNull(),
    description: text('description').notNull(),
    isEnabled: boolean('is_enabled').notNull().default(true),
    sortOrder: integer('sort_order').notNull().default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  }
);

export const tools = pgTable(
  'tools',
  {
    id: serial('id').primaryKey(),
    slug: text('slug').notNull().unique(),
    routePath: text('route_path').notNull().unique(),
    name: text('name').notNull(),
    category: text('category').notNull(),
    platformSlug: text('platform_slug').notNull(),
    shortDescription: text('short_description').notNull(),
    seoTitle: text('seo_title').notNull(),
    seoDescription: text('seo_description').notNull(),
    isEnabled: boolean('is_enabled').notNull().default(true),
    isPopular: boolean('is_popular').notNull().default(false),
    isNew: boolean('is_new').notNull().default(false),
    usageCount: integer('usage_count').notNull().default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('tools_platform_idx').on(table.platformSlug),
    index('tools_category_idx').on(table.category),
  ]
);

export const processingJobs = pgTable(
  'processing_jobs',
  {
    id: serial('id').primaryKey(),
    toolSlug: text('tool_slug').notNull(),
    platformSlug: text('platform_slug').notNull(),
    userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
    targetUrl: text('target_url'),
    status: text('status').notNull(), // 'completed' | 'failed' | 'restricted'
    errorCode: text('error_code'),
    errorMessage: text('error_message'),
    durationMs: integer('duration_ms').notNull().default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('processing_jobs_tool_idx').on(table.toolSlug),
    index('processing_jobs_status_idx').on(table.status),
    index('processing_jobs_created_idx').on(table.createdAt),
  ]
);

export const downloadLogs = pgTable(
  'download_logs',
  {
    id: serial('id').primaryKey(),
    toolSlug: text('tool_slug').notNull(),
    platformSlug: text('platform_slug').notNull(),
    userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
    assetType: text('asset_type').notNull(),
    format: text('format').notNull(),
    resolution: text('resolution'),
    fileSizeBytes: integer('file_size_bytes'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('download_logs_created_idx').on(table.createdAt)]
);

export const conversionJobs = pgTable('conversion_jobs', {
  id: serial('id').primaryKey(),
  userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
  sourceFormat: text('source_format').notNull(),
  targetFormat: text('target_format').notNull(),
  sourceSizeBytes: integer('source_size_bytes').notNull(),
  outputSizeBytes: integer('output_size_bytes').notNull(),
  status: text('status').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const apiKeys = pgTable(
  'api_keys',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    name: text('name').notNull(),
    keyPrefix: text('key_prefix').notNull(),
    keyHash: text('key_hash').notNull().unique(),
    rateLimitPerMin: integer('rate_limit_per_min').notNull().default(60),
    isActive: boolean('is_active').notNull().default(true),
    lastUsedAt: timestamp('last_used_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('api_keys_user_idx').on(table.userId)]
);

export const apiUsage = pgTable(
  'api_usage',
  {
    id: serial('id').primaryKey(),
    apiKeyId: integer('api_key_id').references(() => apiKeys.id, { onDelete: 'set null' }),
    endpoint: text('endpoint').notNull(),
    statusCode: integer('status_code').notNull(),
    latencyMs: integer('latency_ms').notNull().default(0),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('api_usage_created_idx').on(table.createdAt)]
);

export const subscriptions = pgTable('subscriptions', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  planName: text('plan_name').notNull().default('free'),
  status: text('status').notNull().default('inactive'),
  currentPeriodEnd: timestamp('current_period_end'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const payments = pgTable('payments', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  subscriptionId: integer('subscription_id').references(() => subscriptions.id, {
    onDelete: 'set null',
  }),
  amountCents: integer('amount_cents').notNull(),
  currency: text('currency').notNull().default('USD'),
  provider: text('provider').notNull(),
  status: text('status').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const advertisements = pgTable('advertisements', {
  id: serial('id').primaryKey(),
  placementKey: text('placement_key').notNull().unique(),
  label: text('label').notNull(),
  provider: text('provider').notNull().default('google_adsense'),
  adUnitId: text('ad_unit_id').notNull().default(''),
  desktopEnabled: boolean('desktop_enabled').notNull().default(true),
  mobileEnabled: boolean('mobile_enabled').notNull().default(true),
  isEnabled: boolean('is_enabled').notNull().default(false),
  notes: text('notes').notNull().default(''),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const websiteSettings = pgTable('website_settings', {
  id: serial('id').primaryKey(),
  key: text('key').notNull().unique(),
  value: text('value').notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const seoPages = pgTable('seo_pages', {
  id: serial('id').primaryKey(),
  path: text('path').notNull().unique(),
  title: text('title').notNull(),
  metaDescription: text('meta_description').notNull(),
  canonicalPath: text('canonical_path').notNull(),
  ogTitle: text('og_title').notNull(),
  ogDescription: text('og_description').notNull(),
  schemaType: text('schema_type').notNull().default('WebApplication'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const blogPosts = pgTable(
  'blog_posts',
  {
    id: serial('id').primaryKey(),
    slug: text('slug').notNull().unique(),
    title: text('title').notNull(),
    excerpt: text('excerpt').notNull(),
    contentMarkdown: text('content_markdown').notNull(),
    coverImage: text('cover_image').notNull(),
    category: text('category').notNull(),
    readTimeMinutes: integer('read_time_minutes').notNull().default(4),
    seoTitle: text('seo_title').notNull(),
    seoDescription: text('seo_description').notNull(),
    isPublished: boolean('is_published').notNull().default(true),
    publishedAt: timestamp('published_at').defaultNow().notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('blog_posts_slug_idx').on(table.slug)]
);

export const contactMessages = pgTable('contact_messages', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  subject: text('subject').notNull(),
  message: text('message').notNull(),
  status: text('status').notNull().default('new'), // 'new' | 'reviewed' | 'resolved'
  createdAt: timestamp('created_at').defaultNow().notNull(),
});

export const abuseReports = pgTable('abuse_reports', {
  id: serial('id').primaryKey(),
  targetUrl: text('target_url').notNull(),
  reportType: text('report_type').notNull(), // 'dmca' | 'abuse' | 'privacy'
  reporterEmail: text('reporter_email').notNull(),
  details: text('details').notNull(),
  status: text('status').notNull().default('open'), // 'open' | 'reviewing' | 'resolved'
  reviewedByUid: text('reviewed_by_uid'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const auditLogs = pgTable(
  'audit_logs',
  {
    id: serial('id').primaryKey(),
    actorUid: text('actor_uid').notNull(),
    actorEmail: text('actor_email').notNull(),
    action: text('action').notNull(),
    resourceType: text('resource_type').notNull(),
    resourceId: text('resource_id'),
    metadataJson: text('metadata_json'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('audit_logs_created_idx').on(table.createdAt)]
);

export const dailyMetrics = pgTable('daily_metrics', {
  id: serial('id').primaryKey(),
  dateKey: text('date_key').notNull().unique(),
  visitors: integer('visitors').notNull().default(0),
  toolRuns: integer('tool_runs').notNull().default(0),
  failedRuns: integer('failed_runs').notNull().default(0),
  apiCalls: integer('api_calls').notNull().default(0),
});

export const scriptProjects = pgTable(
  'script_projects',
  {
    id: serial('id').primaryKey(),
    projectKey: text('project_key').notNull().unique(),
    userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
    guestToken: text('guest_token'),
    ytmWorkflowProjectId: integer('ytm_workflow_project_id'),
    title: text('title').notNull().default('Untitled Script Project'),
    currentStage: integer('current_stage').notNull().default(1),
    highestApprovedStage: integer('highest_approved_stage').notNull().default(0),
    modelName: text('model_name').notNull().default('gemini-4-hydrogen'),
    projectStatus: text('project_status').notNull().default('NOT STARTED'),
    finalApprovedScript: text('final_approved_script'),
    completedAt: timestamp('completed_at'),
    approvalTimestampsJson: text('approval_timestamps_json').notNull().default('{}'),
    settingsJson: text('settings_json').notNull(),
    stateJson: text('state_json').notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('script_projects_user_idx').on(table.userId),
    index('script_projects_guest_idx').on(table.guestToken),
    index('script_projects_wf_idx').on(table.ytmWorkflowProjectId),
    index('script_projects_updated_idx').on(table.updatedAt),
  ]
);

export const competitorChannelCaches = pgTable(
  'competitor_channel_caches',
  {
    id: serial('id').primaryKey(),
    channelId: text('channel_id').notNull().unique(),
    handle: text('handle'),
    title: text('title').notNull(),
    channelJson: text('channel_json').notNull(),
    videosJson: text('videos_json').notNull(),
    sampleSize: integer('sample_size').notNull().default(0),
    transcriptsSampledCount: integer('transcripts_sampled_count').notNull().default(0),
    retrievedAt: timestamp('retrieved_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('competitor_channel_caches_handle_idx').on(table.handle)]
);

export const competitorReports = pgTable(
  'competitor_reports',
  {
    id: serial('id').primaryKey(),
    reportKey: text('report_key').notNull().unique(),
    userId: integer('user_id').references(() => users.id, { onDelete: 'set null' }),
    guestToken: text('guest_token'),
    title: text('title').notNull().default('Competitor Intelligence Report'),
    status: text('status').notNull().default('draft'), // 'draft' | 'collecting' | 'collected' | 'analyzing' | 'completed' | 'failed'
    currentStep: text('current_step').notNull().default('selection'),
    modelName: text('model_name').notNull().default('gemini-4-hydrogen'),
    sampleSize: integer('sample_size').notNull().default(20),
    ownChannelJson: text('own_channel_json'),
    channelIdsJson: text('channel_ids_json').notNull(),
    rawCollectionJson: text('raw_collection_json'),
    channelAnalysesJson: text('channel_analyses_json'),
    synthesisJson: text('synthesis_json'),
    errorMessage: text('error_message'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('competitor_reports_user_idx').on(table.userId),
    index('competitor_reports_guest_idx').on(table.guestToken),
    index('competitor_reports_updated_idx').on(table.updatedAt),
  ]
);

export const ytmWorkspaces = pgTable(
  'ytm_workspaces',
  {
    id: serial('id').primaryKey(),
    workspaceKey: text('workspace_key').notNull().unique(),
    ownerUserId: integer('owner_user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    name: text('name').notNull(),
    description: text('description').notNull().default(''),
    channelGoal: text('channel_goal').notNull().default(''),
    customStatusesJson: text('custom_statuses_json').notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_workspaces_owner_idx').on(table.ownerUserId)]
);

export const ytmWorkspaceMembers = pgTable(
  'ytm_workspace_members',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    role: text('role').notNull().default('viewer'),
    invitedByUserId: integer('invited_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    status: text('status').notNull().default('active'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_members_workspace_idx').on(table.workspaceId),
    index('ytm_members_user_idx').on(table.userId),
  ]
);

export const ytmTeamInvitations = pgTable(
  'ytm_team_invitations',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    email: text('email').notNull(),
    role: text('role').notNull().default('editor'),
    token: text('token').notNull().unique(),
    invitedByUserId: integer('invited_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    status: text('status').notNull().default('pending'),
    expiresAt: timestamp('expires_at').notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    acceptedAt: timestamp('accepted_at'),
  },
  (table) => [
    index('ytm_invites_workspace_idx').on(table.workspaceId),
    index('ytm_invites_email_idx').on(table.email),
  ]
);

export const ytmConnectedAccounts = pgTable(
  'ytm_connected_accounts',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    provider: text('provider').notNull().default('google_youtube'),
    channelId: text('channel_id').notNull(),
    channelTitle: text('channel_title').notNull(),
    channelHandle: text('channel_handle'),
    thumbnailUrl: text('thumbnail_url'),
    subscriberCount: integer('subscriber_count'),
    videoCount: integer('video_count'),
    viewCount: text('view_count'),
    scopesJson: text('scopes_json').notNull().default('[]'),
    connectionStatus: text('connection_status').notNull().default('connected'),
    lastSyncedAt: timestamp('last_synced_at').defaultNow().notNull(),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_connected_ws_idx').on(table.workspaceId)]
);

export const ytmOAuthTokens = pgTable('ytm_oauth_tokens', {
  id: serial('id').primaryKey(),
  connectedAccountId: integer('connected_account_id')
    .references(() => ytmConnectedAccounts.id, { onDelete: 'cascade' })
    .notNull()
    .unique(),
  encryptedAccessToken: text('encrypted_access_token').notNull(),
  encryptedRefreshToken: text('encrypted_refresh_token'),
  iv: text('iv').notNull(),
  authTag: text('auth_tag').notNull(),
  expiryDate: timestamp('expiry_date'),
  tokenType: text('token_type').notNull().default('Bearer'),
  updatedAt: timestamp('updated_at').defaultNow().notNull(),
});

export const ytmPlannerProjects = pgTable(
  'ytm_planner_projects',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    assigneeUserId: integer('assignee_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    title: text('title').notNull(),
    topic: text('topic').notNull().default(''),
    description: text('description').notNull().default(''),
    notes: text('notes').notNull().default(''),
    targetAudience: text('target_audience').notNull().default(''),
    category: text('category').notNull().default('General'),
    status: text('status').notNull().default('Idea'),
    priority: text('priority').notNull().default('medium'),
    plannedDate: text('planned_date'),
    deadline: text('deadline'),
    recurrenceRule: text('recurrence_rule').notNull().default('none'),
    workflowProjectId: integer('workflow_project_id'),
    channelProfileId: integer('channel_profile_id'),
    savedInspirationId: integer('saved_inspiration_id'),
    adaptedIdeaId: integer('adapted_idea_id'),
    inspirationSourceLabel: text('inspiration_source_label').notNull().default(''),
    inspirationSourceUrl: text('inspiration_source_url').notNull().default(''),
    adaptedAngle: text('adapted_angle').notNull().default(''),
    productionChecklistJson: text('production_checklist_json').notNull().default('[]'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_planner_ws_idx').on(table.workspaceId),
    index('ytm_planner_date_idx').on(table.plannedDate),
    index('ytm_planner_channel_idx').on(table.channelProfileId),
  ]
);

export const ytmPlannerTasks = pgTable(
  'ytm_planner_tasks',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    plannerProjectId: integer('planner_project_id').references(() => ytmPlannerProjects.id, {
      onDelete: 'set null',
    }),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    assigneeUserId: integer('assignee_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    taskName: text('task_name').notNull(),
    workspaceSection: text('workspace_section').notNull().default('Workflow'),
    scheduledAt: text('scheduled_at'),
    deadline: text('deadline'),
    priority: text('priority').notNull().default('medium'),
    status: text('status').notNull().default('Not Started'),
    aiSuggested: boolean('ai_suggested').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_tasks_ws_idx').on(table.workspaceId),
    index('ytm_tasks_deadline_idx').on(table.deadline),
  ]
);

export const ytmWorkspaceCompetitors = pgTable(
  'ytm_workspace_competitors',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    addedByUserId: integer('added_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    channelId: text('channel_id').notNull(),
    channelUrl: text('channel_url').notNull(),
    handle: text('handle'),
    title: text('title').notNull(),
    thumbnailUrl: text('thumbnail_url'),
    subscriberCount: integer('subscriber_count'),
    lastReportKey: text('last_report_key'),
    notes: text('notes').notNull().default(''),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_competitors_ws_idx').on(table.workspaceId)]
);

export const ytmWorkflowProjects = pgTable(
  'ytm_workflow_projects',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    plannerProjectId: integer('planner_project_id').references(() => ytmPlannerProjects.id, {
      onDelete: 'set null',
    }),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    assigneeUserId: integer('assignee_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    title: text('title').notNull(),
    currentStage: integer('current_stage').notNull().default(1),
    stage1TitleJson: text('stage1_title_json').notNull().default('{}'),
    stage2TopicJson: text('stage2_topic_json').notNull().default('{}'),
    scriptProjectKey: text('script_project_key'),
    stage4ThumbnailJson: text('stage4_thumbnail_json').notNull().default('{}'),
    stage5SeoJson: text('stage5_seo_json').notNull().default('{}'),
    stage6DistributionJson: text('stage6_distribution_json').notNull().default('{}'),
    approvalsJson: text('approvals_json').notNull().default('{}'),
    stageWarningsJson: text('stage_warnings_json').notNull().default('{}'),
    reviewStatus: text('review_status').notNull().default('draft'),
    reviewNotes: text('review_notes').notNull().default(''),
    projectStatus: text('project_status').notNull().default('NOT STARTED'),
    stage4Mode: text('stage4_mode').notNull().default('thumbnail'),
    finalApprovedScript: text('final_approved_script'),
    completedAt: timestamp('completed_at'),
    approvalTimestampsJson: text('approval_timestamps_json').notNull().default('{}'),
    youtubeVideoId: text('youtube_video_id'),
    youtubeVideoUrl: text('youtube_video_url'),
    channelProfileId: integer('channel_profile_id'),
    savedInspirationId: integer('saved_inspiration_id'),
    adaptedIdeaId: integer('adapted_idea_id'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_workflow_ws_idx').on(table.workspaceId),
    index('ytm_workflow_channel_idx').on(table.channelProfileId),
  ]
);

export const ytmDistributionAssets = pgTable(
  'ytm_distribution_assets',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    workflowProjectId: integer('workflow_project_id')
      .references(() => ytmWorkflowProjects.id, { onDelete: 'cascade' })
      .notNull(),
    platform: text('platform').notNull(),
    assetType: text('asset_type').notNull().default('post'),
    title: text('title').notNull().default(''),
    bodyCopy: text('body_copy').notNull().default(''),
    hashtags: text('hashtags').notNull().default(''),
    carouselSlidesJson: text('carousel_slides_json').notNull().default('[]'),
    imagePrompt: text('image_prompt').notNull().default(''),
    scheduledAt: text('scheduled_at'),
    status: text('status').notNull().default('draft'),
    publishedExternalUrl: text('published_external_url'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_dist_wf_idx').on(table.workflowProjectId)]
);

export const ytmPublishingJobs = pgTable(
  'ytm_publishing_jobs',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    workflowProjectId: integer('workflow_project_id').references(() => ytmWorkflowProjects.id, {
      onDelete: 'set null',
    }),
    initiatedByUserId: integer('initiated_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    title: text('title').notNull(),
    description: text('description').notNull().default(''),
    tagsJson: text('tags_json').notNull().default('[]'),
    categoryId: text('category_id').notNull().default('22'),
    privacyStatus: text('privacy_status').notNull().default('private'),
    publishAt: text('publish_at'),
    fileName: text('file_name').notNull(),
    fileSizeBytes: integer('file_size_bytes').notNull().default(0),
    status: text('status').notNull().default('queued'),
    progressPercent: integer('progress_percent').notNull().default(0),
    youtubeVideoId: text('youtube_video_id'),
    youtubeVideoUrl: text('youtube_video_url'),
    errorMessage: text('error_message'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_pub_ws_idx').on(table.workspaceId)]
);

export const ytmAnalyticsSnapshots = pgTable(
  'ytm_analytics_snapshots',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelId: text('channel_id').notNull(),
    dateRangeStart: text('date_range_start').notNull(),
    dateRangeEnd: text('date_range_end').notNull(),
    metricsJson: text('metrics_json').notNull(),
    retrievedAt: timestamp('retrieved_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_analytics_ws_idx').on(table.workspaceId)]
);

export const ytmRevenueEntries = pgTable(
  'ytm_revenue_entries',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    category: text('category').notNull(),
    sourceLabel: text('source_label').notNull(),
    entryType: text('entry_type').notNull().default('manual'),
    amountCents: integer('amount_cents').notNull().default(0),
    currency: text('currency').notNull().default('USD'),
    monthKey: text('month_key').notNull(),
    paymentStatus: text('payment_status').notNull().default('pending'),
    targetCents: integer('target_cents'),
    notes: text('notes').notNull().default(''),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_rev_ws_idx').on(table.workspaceId)]
);

export const ytmBrandDeals = pgTable(
  'ytm_brand_deals',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    brandName: text('brand_name').notNull(),
    contactDetails: text('contact_details').notNull().default(''),
    campaign: text('campaign').notNull().default(''),
    dealAmountCents: integer('deal_amount_cents').notNull().default(0),
    currency: text('currency').notNull().default('USD'),
    deliverables: text('deliverables').notNull().default(''),
    deadline: text('deadline'),
    contractStatus: text('contract_status').notNull().default('negotiating'),
    paymentStatus: text('payment_status').notNull().default('unpaid'),
    followUpDate: text('follow_up_date'),
    notes: text('notes').notNull().default(''),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_deals_ws_idx').on(table.workspaceId)]
);

export const ytmCommunityItems = pgTable(
  'ytm_community_items',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    itemType: text('item_type').notNull().default('comment'),
    externalCommentId: text('external_comment_id'),
    videoId: text('video_id'),
    videoTitle: text('video_title'),
    authorName: text('author_name').notNull().default(''),
    content: text('content').notNull(),
    category: text('category').notNull().default('general'),
    aiDraftReply: text('ai_draft_reply').notNull().default(''),
    replyStatus: text('reply_status').notNull().default('none'),
    moderationStatus: text('moderation_status').notNull().default('published'),
    scheduledAt: text('scheduled_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_community_ws_idx').on(table.workspaceId)]
);

export const ytmAssets = pgTable(
  'ytm_assets',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    uploadedByUserId: integer('uploaded_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    assetType: text('asset_type').notNull().default('thumbnail'),
    title: text('title').notNull(),
    mimeType: text('mime_type').notNull().default('text/plain'),
    fileSizeBytes: integer('file_size_bytes').notNull().default(0),
    dataUrlOrPath: text('data_url_or_path').notNull(),
    promptText: text('prompt_text').notNull().default(''),
    tagsJson: text('tags_json').notNull().default('[]'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_assets_ws_idx').on(table.workspaceId)]
);

export const ytmNotifications = pgTable(
  'ytm_notifications',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    title: text('title').notNull(),
    message: text('message').notNull(),
    isRead: boolean('is_read').notNull().default(false),
    linkSection: text('link_section').notNull().default('dashboard'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_notif_user_idx').on(table.userId)]
);

export const ytmActivityLogs = pgTable(
  'ytm_activity_logs',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    actorUserId: integer('actor_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    actorEmail: text('actor_email').notNull().default(''),
    action: text('action').notNull(),
    resourceType: text('resource_type').notNull(),
    resourceId: text('resource_id'),
    detailsJson: text('details_json'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_activity_ws_idx').on(table.workspaceId)]
);

export const channelProfiles = pgTable(
  'channel_profiles',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelName: text('channel_name').notNull(),
    channelHandle: text('channel_handle').notNull().default(''),
    youtubeChannelId: text('youtube_channel_id'),
    description: text('description').notNull().default(''),
    niche: text('niche').notNull().default(''),
    subNiche: text('sub_niche').notNull().default(''),
    isDefault: boolean('is_default').notNull().default(false),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('channel_profiles_user_idx').on(table.userId),
    index('channel_profiles_ws_idx').on(table.workspaceId),
  ]
);

export const channelDna = pgTable(
  'channel_dna',
  {
    id: serial('id').primaryKey(),
    channelProfileId: integer('channel_profile_id')
      .references(() => channelProfiles.id, { onDelete: 'cascade' })
      .notNull()
      .unique(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    targetAudience: text('target_audience').notNull().default(''),
    preferredLanguage: text('preferred_language').notNull().default('English'),
    contentCategoriesJson: text('content_categories_json').notNull().default('[]'),
    contentFormat: text('content_format').notNull().default('Long-form YouTube'),
    videoStyle: text('video_style').notNull().default(''),
    toneOfVoice: text('tone_of_voice').notNull().default(''),
    storytellingApproach: text('storytelling_approach').notNull().default(''),
    scriptStructure: text('script_structure').notNull().default(''),
    preferredVideoDuration: text('preferred_video_duration').notNull().default('8–12 minutes'),
    titlePreferences: text('title_preferences').notNull().default(''),
    thumbnailDesignPreferences: text('thumbnail_design_preferences').notNull().default(''),
    colorPaletteJson: text('color_palette_json').notNull().default('[]'),
    typography: text('typography').notNull().default(''),
    wordsToUseJson: text('words_to_use_json').notNull().default('[]'),
    wordsToAvoidJson: text('words_to_avoid_json').notNull().default('[]'),
    uniquePositioning: text('unique_positioning').notNull().default(''),
    audienceProblemsJson: text('audience_problems_json').notNull().default('[]'),
    preferredFormatsJson: text('preferred_formats_json').notNull().default('[]'),
    brandVoice: text('brand_voice').notNull().default(''),
    publishingPreferences: text('publishing_preferences').notNull().default(''),
    contentRules: text('content_rules').notNull().default(''),
    creativeGuidelines: text('creative_guidelines').notNull().default(''),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('channel_dna_user_idx').on(table.userId),
    index('channel_dna_ws_idx').on(table.workspaceId),
  ]
);

export const savedInspiration = pgTable(
  'saved_inspiration',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    dedupeKey: text('dedupe_key').notNull(),
    originalVideoTitle: text('original_video_title').notNull(),
    originalVideoUrl: text('original_video_url').notNull().default(''),
    competitorChannelName: text('competitor_channel_name').notNull().default(''),
    competitorChannelId: text('competitor_channel_id').notNull().default(''),
    thumbnailUrl: text('thumbnail_url'),
    inspirationCategory: text('inspiration_category').notNull().default('video_topic'),
    inspirationSnippet: text('inspiration_snippet').notNull().default(''),
    userNotes: text('user_notes').notNull().default(''),
    status: text('status').notNull().default('saved'), // 'saved' | 'reviewed' | 'adapted' | 'converted' | 'archived'
    convertedPlannerProjectId: integer('converted_planner_project_id'),
    savedAt: timestamp('saved_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('saved_insp_ws_idx').on(table.workspaceId),
    index('saved_insp_user_idx').on(table.userId),
    index('saved_insp_channel_idx').on(table.channelProfileId),
    index('saved_insp_cat_idx').on(table.inspirationCategory),
    index('saved_insp_status_idx').on(table.status),
    index('saved_insp_dedupe_idx').on(table.workspaceId, table.dedupeKey),
  ]
);

export const adaptedIdeas = pgTable(
  'adapted_ideas',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    savedInspirationId: integer('saved_inspiration_id').references(() => savedInspiration.id, {
      onDelete: 'set null',
    }),
    originalConceptSummary: text('original_concept_summary').notNull().default(''),
    whyItWorks: text('why_it_works').notNull().default(''),
    freshAngle: text('fresh_angle').notNull().default(''),
    titleOptionsJson: text('title_options_json').notNull().default('[]'),
    selectedTitle: text('selected_title').notNull().default(''),
    uniqueHook: text('unique_hook').notNull().default(''),
    videoOutlineJson: text('video_outline_json').notNull().default('[]'),
    thumbnailDirection: text('thumbnail_direction').notNull().default(''),
    channelFitExplanation: text('channel_fit_explanation').notNull().default(''),
    userNotes: text('user_notes').notNull().default(''),
    convertedPlannerProjectId: integer('converted_planner_project_id'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('adapted_ideas_ws_idx').on(table.workspaceId),
    index('adapted_ideas_insp_idx').on(table.savedInspirationId),
    index('adapted_ideas_channel_idx').on(table.channelProfileId),
  ]
);

export const dailyPlans = pgTable(
  'daily_plans',
  {
    id: serial('id').primaryKey(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    planDate: text('plan_date').notNull(),
    summary: text('summary').notNull().default(''),
    suggestedItemsJson: text('suggested_items_json').notNull().default('[]'),
    userNotes: text('user_notes').notNull().default(''),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('daily_plans_ws_date_idx').on(table.workspaceId, table.planDate),
    index('daily_plans_user_idx').on(table.userId),
  ]
);

export const ytmContentStrategies = pgTable(
  'ytm_content_strategies',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    title: text('title').notNull().default('Content Strategy'),
    intakeJson: text('intake_json').notNull().default('{}'),
    publishingStrategyJson: text('publishing_strategy_json').notNull().default('{}'),
    communicationStrategyJson: text('communication_strategy_json').notNull().default('{}'),
    calendarItemsJson: text('calendar_items_json').notNull().default('[]'),
    auditReportJson: text('audit_report_json').notNull().default('null'),
    status: text('status').notNull().default('draft'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_strategies_ws_idx').on(table.workspaceId)]
);

export const ytmCommunityPosts = pgTable(
  'ytm_community_posts',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    workflowProjectId: integer('workflow_project_id').references(() => ytmWorkflowProjects.id, {
      onDelete: 'set null',
    }),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    createdByUserId: integer('created_by_user_id').references(() => users.id, {
      onDelete: 'set null',
    }),
    formatType: text('format_type').notNull().default('simple_text'), // 'quiz' | 'text_poll' | 'image_poll' | 'image_post' | 'simple_text'
    topic: text('topic').notNull().default(''),
    title: text('title').notNull().default(''),
    payloadJson: text('payload_json').notNull().default('{}'),
    status: text('status').notNull().default('draft'), // 'draft' | 'approved' | 'manually_published'
    approvedAt: timestamp('approved_at'),
    scheduledAt: text('scheduled_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_comm_posts_ws_idx').on(table.workspaceId),
    index('ytm_comm_posts_wf_idx').on(table.workflowProjectId),
  ]
);

export const ytmCoachSnapshots = pgTable(
  'ytm_coach_snapshots',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    channelId: text('channel_id').notNull(),
    periodStart: text('period_start').notNull(),
    periodEnd: text('period_end').notNull(),
    previousPeriodStart: text('previous_period_start').notNull(),
    previousPeriodEnd: text('previous_period_end').notNull(),
    dataSource: text('data_source').notNull().default('youtube_analytics_api_v2'),
    metricsSummaryJson: text('metrics_summary_json').notNull().default('{}'),
    diagnosisJson: text('diagnosis_json').notNull().default('{}'),
    improvementsJson: text('improvements_json').notNull().default('[]'),
    opportunitiesJson: text('opportunities_json').notNull().default('[]'),
    learningLessonsJson: text('learning_lessons_json').notNull().default('[]'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [index('ytm_coach_snap_ws_idx').on(table.workspaceId)]
);

export const ytmCoachActions = pgTable(
  'ytm_coach_actions',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    snapshotId: integer('snapshot_id').references(() => ytmCoachSnapshots.id, {
      onDelete: 'set null',
    }),
    horizon: text('horizon').notNull().default('weekly'), // 'daily' | 'weekly' | 'monthly' | 'experiment'
    title: text('title').notNull(),
    rationale: text('rationale').notNull().default(''),
    actionSteps: text('action_steps').notNull().default(''),
    expectedOutcome: text('expected_outcome').notNull().default(''),
    metricToMeasure: text('metric_to_measure').notNull().default(''),
    priority: text('priority').notNull().default('medium'),
    status: text('status').notNull().default('pending'), // 'pending' | 'approved' | 'in_progress' | 'completed' | 'dismissed'
    linkedPlannerProjectId: integer('linked_planner_project_id'),
    linkedPlannerTaskId: integer('linked_planner_task_id'),
    linkedWorkflowProjectId: integer('linked_workflow_project_id'),
    outcomeNotes: text('outcome_notes').notNull().default(''),
    completedAt: timestamp('completed_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_coach_actions_ws_idx').on(table.workspaceId),
    index('ytm_coach_actions_snap_idx').on(table.snapshotId),
  ]
);

// ==============================================================================
// YOUTUBE OS CENTRAL AI AGENT TABLES (ADDITIVE)
// ==============================================================================

export const ytmAgentSessions = pgTable(
  'ytm_agent_sessions',
  {
    id: serial('id').primaryKey(),
    sessionKey: text('session_key').notNull().unique(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    title: text('title').notNull().default('New Agent Session'),
    mode: text('mode').notNull().default('assist'), // 'chat' | 'assist' | 'autopilot'
    messagesJson: text('messages_json').notNull().default('[]'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_agent_sessions_ws_user_idx').on(table.workspaceId, table.userId),
    index('ytm_agent_sessions_updated_idx').on(table.updatedAt),
  ]
);

export const ytmAgentTasks = pgTable(
  'ytm_agent_tasks',
  {
    id: serial('id').primaryKey(),
    taskKey: text('task_key').notNull().unique(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    sessionId: integer('session_id').references(() => ytmAgentSessions.id, {
      onDelete: 'set null',
    }),
    channelProfileId: integer('channel_profile_id').references(() => channelProfiles.id, {
      onDelete: 'set null',
    }),
    workflowProjectId: integer('workflow_project_id').references(() => ytmWorkflowProjects.id, {
      onDelete: 'set null',
    }),
    idempotencyKey: text('idempotency_key'),
    command: text('command').notNull(),
    mode: text('mode').notNull().default('assist'), // 'chat' | 'assist' | 'autopilot'
    uiContextJson: text('ui_context_json').notNull().default('{}'),
    executionPlanJson: text('execution_plan_json').notNull().default('[]'),
    status: text('status').notNull().default('pending'), // 'pending' | 'running' | 'waiting_for_approval' | 'completed' | 'failed' | 'paused' | 'cancelled'
    currentStepIndex: integer('current_step_index').notNull().default(0),
    pendingApprovalJson: text('pending_approval_json'),
    conversationStateJson: text('conversation_state_json').notNull().default('[]'),
    resultSummary: text('result_summary').notNull().default(''),
    errorMessage: text('error_message'),
    startedAt: timestamp('started_at'),
    completedAt: timestamp('completed_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_agent_tasks_ws_user_idx').on(table.workspaceId, table.userId),
    index('ytm_agent_tasks_session_idx').on(table.sessionId),
    index('ytm_agent_tasks_status_idx').on(table.status),
    index('ytm_agent_tasks_idem_idx').on(table.workspaceId, table.userId, table.idempotencyKey),
  ]
);

export const ytmAgentTaskSteps = pgTable(
  'ytm_agent_task_steps',
  {
    id: serial('id').primaryKey(),
    taskId: integer('task_id')
      .references(() => ytmAgentTasks.id, { onDelete: 'cascade' })
      .notNull(),
    stepOrder: integer('step_order').notNull().default(1),
    toolName: text('tool_name').notNull(),
    label: text('label').notNull(),
    actionCategory: text('action_category').notNull().default('read'), // 'read' | 'write' | 'sensitive'
    inputJson: text('input_json').notNull().default('{}'),
    outputJson: text('output_json'),
    status: text('status').notNull().default('pending'), // 'pending' | 'running' | 'waiting_for_approval' | 'completed' | 'failed' | 'skipped' | 'cancelled'
    errorMessage: text('error_message'),
    startedAt: timestamp('started_at'),
    completedAt: timestamp('completed_at'),
    createdAt: timestamp('created_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_agent_task_steps_task_idx').on(table.taskId),
  ]
);

export const ytmAgentPermissions = pgTable(
  'ytm_agent_permissions',
  {
    id: serial('id').primaryKey(),
    workspaceId: integer('workspace_id')
      .references(() => ytmWorkspaces.id, { onDelete: 'cascade' })
      .notNull(),
    userId: integer('user_id')
      .references(() => users.id, { onDelete: 'cascade' })
      .notNull(),
    defaultMode: text('default_mode').notNull().default('assist'), // 'chat' | 'assist' | 'autopilot'
    allowedActionsJson: text('allowed_actions_json').notNull().default('[]'),
    approvalRequiredActionsJson: text('approval_required_actions_json').notNull().default('[]'),
    updatedAt: timestamp('updated_at').defaultNow().notNull(),
  },
  (table) => [
    index('ytm_agent_perms_ws_user_idx').on(table.workspaceId, table.userId),
  ]
);

export const usersRelations = relations(users, ({ many }) => ({
  apiKeys: many(apiKeys),
  processingJobs: many(processingJobs),
  subscriptions: many(subscriptions),
  scriptProjects: many(scriptProjects),
  competitorReports: many(competitorReports),
  ytmWorkspaces: many(ytmWorkspaces),
  ytmMemberships: many(ytmWorkspaceMembers),
}));

export const apiKeysRelations = relations(apiKeys, ({ one, many }) => ({
  user: one(users, {
    fields: [apiKeys.userId],
    references: [users.id],
  }),
  usage: many(apiUsage),
}));
