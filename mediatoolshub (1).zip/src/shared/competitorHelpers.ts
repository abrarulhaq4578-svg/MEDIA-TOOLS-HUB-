import type {
  ChannelQuantitativeMetrics,
  CompetitorReportRecord,
  CompetitorVideoItem,
  OutlierClassification,
} from './types.ts';

export type ParsedChannelIdentifier =
  | { kind: 'channelId'; value: string }
  | { kind: 'handle'; value: string }
  | { kind: 'username'; value: string }
  | { kind: 'custom'; value: string }
  | { kind: 'search'; value: string };

const STOP_WORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with',
  'by', 'from', 'is', 'are', 'was', 'were', 'be', 'been', 'being', 'this', 'that',
  'these', 'those', 'it', 'its', 'you', 'your', 'we', 'our', 'i', 'my', 'me', 'how',
  'what', 'why', 'when', 'where', 'who', 'which', 'not', 'no', 'so', 'if', 'into',
  'about', 'than', 'then', 'out', 'up', 'down', 'all', 'just', 'can', 'will', 'do',
]);

export function parseYouTubeChannelInput(raw: string): ParsedChannelIdentifier {
  const trimmed = raw.trim();
  if (!trimmed) {
    return { kind: 'search', value: '' };
  }

  // Direct Channel ID (UCxxxxxxxxxxxxxxxxxxxxxx - typically 24 chars)
  if (/^UC[a-zA-Z0-9_-]{20,26}$/.test(trimmed)) {
    return { kind: 'channelId', value: trimmed };
  }

  // Direct @handle
  if (/^@[a-zA-Z0-9._-]{2,60}$/.test(trimmed)) {
    return { kind: 'handle', value: trimmed };
  }

  // Try URL parsing (accept with or without protocol for youtube.com/...)
  const candidate = /^https?:\/\//i.test(trimmed)
    ? trimmed
    : trimmed.toLowerCase().includes('youtube.com')
      ? `https://${trimmed}`
      : '';

  if (candidate) {
    try {
      const url = new URL(candidate);
      const host = url.hostname.toLowerCase();
      if (host === 'youtube.com' || host.endsWith('.youtube.com')) {
        const segments = url.pathname.split('/').filter(Boolean);
        if (segments.length >= 2 && segments[0] === 'channel' && /^UC[a-zA-Z0-9_-]{20,26}$/.test(segments[1])) {
          return { kind: 'channelId', value: segments[1] };
        }
        if (segments.length >= 1 && segments[0].startsWith('@')) {
          return { kind: 'handle', value: decodeURIComponent(segments[0]) };
        }
        if (segments.length >= 2 && segments[0] === 'c') {
          return { kind: 'custom', value: decodeURIComponent(segments[1]) };
        }
        if (segments.length >= 2 && segments[0] === 'user') {
          return { kind: 'username', value: decodeURIComponent(segments[1]) };
        }
        if (segments.length === 1 && !['watch', 'shorts', 'playlist', 'feed', 'results'].includes(segments[0].toLowerCase())) {
          return { kind: 'custom', value: decodeURIComponent(segments[0]) };
        }
      }
    } catch {
      // Fallback to search query
    }
  }

  return { kind: 'search', value: trimmed };
}

export function parseIso8601DurationToSeconds(iso: string | null | undefined): number | null {
  if (!iso || typeof iso !== 'string') return null;
  const match = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$/i.exec(iso.trim());
  if (!match) return null;
  const days = Number(match[1] || 0);
  const hours = Number(match[2] || 0);
  const minutes = Number(match[3] || 0);
  const seconds = Number(match[4] || 0);
  const total = days * 86400 + hours * 3600 + minutes * 60 + seconds;
  return Number.isFinite(total) ? total : null;
}

export function formatSecondsAsClock(sec: number | null | undefined): string {
  if (sec === null || sec === undefined || !Number.isFinite(sec) || sec < 0) {
    return 'Not available';
  }
  const rounded = Math.round(sec);
  const h = Math.floor(rounded / 3600);
  const m = Math.floor((rounded % 3600) / 60);
  const s = rounded % 60;
  if (h > 0) {
    return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function detectVideoFormatType(
  durationSeconds: number | null,
  title: string,
  description: string
): 'long_form' | 'short' | 'unknown' {
  if (durationSeconds === null) {
    if (/#shorts\b/i.test(title) || /#shorts\b/i.test(description)) {
      return 'short';
    }
    return 'unknown';
  }
  if (durationSeconds > 0 && durationSeconds <= 62) {
    return 'short';
  }
  return 'long_form';
}

export function computeMedian(values: number[]): number | null {
  const valid = values.filter((v) => Number.isFinite(v) && v >= 0).sort((a, b) => a - b);
  if (valid.length === 0) return null;
  const mid = Math.floor(valid.length / 2);
  if (valid.length % 2 === 1) {
    return valid[mid];
  }
  return (valid[mid - 1] + valid[mid]) / 2;
}

export function classifyOutlierRatio(ratio: number | null): OutlierClassification {
  if (ratio === null || !Number.isFinite(ratio)) return 'Unavailable';
  if (ratio >= 3.0) return 'Exceptional outlier';
  if (ratio >= 1.75) return 'Strong outlier';
  if (ratio >= 0.6) return 'Typical performer';
  return 'Below typical performance';
}

export interface RawFetchedVideoInput {
  videoId: string;
  channelId: string;
  channelTitle: string;
  title: string;
  description: string;
  publishedAt: string | null;
  durationSeconds: number | null;
  thumbnailUrl: string | null;
  viewCount: number | null;
  likeCount: number | null;
  commentCount: number | null;
  tags: string[];
  transcriptAvailable?: boolean;
  transcriptExcerpt?: string | null;
}

export function computeOutliersAndChannelMetrics(
  rawVideos: RawFetchedVideoInput[],
  retrievedAt: string
): {
  videos: CompetitorVideoItem[];
  metrics: ChannelQuantitativeMetrics;
} {
  const withFormat = rawVideos.map((v) => ({
    ...v,
    formatType: detectVideoFormatType(v.durationSeconds, v.title, v.description),
  }));

  const allViewCounts = withFormat
    .map((v) => v.viewCount)
    .filter((n): n is number => typeof n === 'number' && Number.isFinite(n) && n >= 0);

  const longFormViews = withFormat
    .filter((v) => v.formatType === 'long_form')
    .map((v) => v.viewCount)
    .filter((n): n is number => typeof n === 'number' && Number.isFinite(n) && n >= 0);

  const shortViews = withFormat
    .filter((v) => v.formatType === 'short')
    .map((v) => v.viewCount)
    .filter((n): n is number => typeof n === 'number' && Number.isFinite(n) && n >= 0);

  const medianViewsOverall = computeMedian(allViewCounts);
  const medianViewsLongForm = computeMedian(longFormViews);
  const medianViewsShorts = computeMedian(shortViews);

  const videos: CompetitorVideoItem[] = withFormat.map((v) => {
    let baselineMedianViews: number | null = medianViewsOverall;
    if (v.formatType === 'long_form' && longFormViews.length >= 3 && medianViewsLongForm !== null) {
      baselineMedianViews = medianViewsLongForm;
    } else if (v.formatType === 'short' && shortViews.length >= 3 && medianViewsShorts !== null) {
      baselineMedianViews = medianViewsShorts;
    }

    let outlierRatio: number | null = null;
    if (
      v.viewCount !== null &&
      baselineMedianViews !== null &&
      baselineMedianViews > 0
    ) {
      outlierRatio = Math.round((v.viewCount / baselineMedianViews) * 100) / 100;
    }

    return {
      videoId: v.videoId,
      channelId: v.channelId,
      channelTitle: v.channelTitle,
      title: v.title,
      description: v.description,
      publishedAt: v.publishedAt,
      durationSeconds: v.durationSeconds,
      durationLabel: formatSecondsAsClock(v.durationSeconds),
      formatType: v.formatType,
      thumbnailUrl: v.thumbnailUrl,
      viewCount: v.viewCount,
      likeCount: v.likeCount,
      commentCount: v.commentCount,
      tags: v.tags,
      outlierRatio,
      baselineMedianViews: baselineMedianViews !== null ? Math.round(baselineMedianViews) : null,
      outlierClassification: classifyOutlierRatio(outlierRatio),
      transcriptAvailable: Boolean(v.transcriptAvailable),
      transcriptExcerpt: v.transcriptExcerpt || null,
      videoUrl: `https://www.youtube.com/watch?v=${v.videoId}`,
    };
  });

  const avgViewsOverall =
    allViewCounts.length > 0
      ? Math.round(allViewCounts.reduce((acc, n) => acc + n, 0) / allViewCounts.length)
      : null;

  const longDurations = videos
    .filter((v) => v.formatType === 'long_form' && v.durationSeconds !== null)
    .map((v) => v.durationSeconds!);
  const shortDurations = videos
    .filter((v) => v.formatType === 'short' && v.durationSeconds !== null)
    .map((v) => v.durationSeconds!);

  const avgDurationSecLongForm =
    longDurations.length > 0
      ? Math.round(longDurations.reduce((a, b) => a + b, 0) / longDurations.length)
      : null;
  const avgDurationSecShorts =
    shortDurations.length > 0
      ? Math.round(shortDurations.reduce((a, b) => a + b, 0) / shortDurations.length)
      : null;

  const datedMs = videos
    .map((v) => (v.publishedAt ? Date.parse(v.publishedAt) : Number.NaN))
    .filter((t) => Number.isFinite(t))
    .sort((a, b) => a - b);

  const earliestSampleDate = datedMs.length > 0 ? new Date(datedMs[0]).toISOString() : null;
  const latestSampleDate = datedMs.length > 0 ? new Date(datedMs[datedMs.length - 1]).toISOString() : null;

  let uploadsPerMonthEstimate: number | null = null;
  if (datedMs.length >= 2) {
    const spanDays = Math.max(1, (datedMs[datedMs.length - 1] - datedMs[0]) / (1000 * 60 * 60 * 24));
    uploadsPerMonthEstimate = Math.round(((datedMs.length / spanDays) * 30.4375) * 10) / 10;
  }

  // Title linguistics
  const titleLengths = videos.map((v) => v.title.length);
  const avgTitleLength =
    titleLengths.length > 0
      ? Math.round(titleLengths.reduce((a, b) => a + b, 0) / titleLengths.length)
      : 0;
  const questionCount = videos.filter((v) => v.title.includes('?')).length;
  const numberCount = videos.filter((v) => /\d/.test(v.title)).length;

  const openingCounts = new Map<string, number>();
  const keywordCounts = new Map<string, number>();

  for (const v of videos) {
    const words = v.title
      .toLowerCase()
      .replace(/[^a-z0-9\s']/g, ' ')
      .split(/\s+/)
      .filter(Boolean);

    if (words.length > 0) {
      const starter = words[0];
      openingCounts.set(starter, (openingCounts.get(starter) || 0) + 1);
    }

    for (const w of words) {
      if (w.length < 3 || STOP_WORDS.has(w) || /^\d+$/.test(w)) continue;
      keywordCounts.set(w, (keywordCounts.get(w) || 0) + 1);
    }
  }

  const topOpeningWords = Array.from(openingCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([word, count]) => ({ word, count }));

  const topKeywords = Array.from(keywordCounts.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 14)
    .map(([word, count]) => ({ word, count }));

  const strongOrExceptionalOutliersCount = videos.filter(
    (v) => v.outlierClassification === 'Exceptional outlier' || v.outlierClassification === 'Strong outlier'
  ).length;

  const transcriptsSampledCount = videos.filter((v) => v.transcriptAvailable).length;

  return {
    videos,
    metrics: {
      sampleSize: videos.length,
      longFormCount: videos.filter((v) => v.formatType === 'long_form').length,
      shortsCount: videos.filter((v) => v.formatType === 'short').length,
      medianViewsOverall: medianViewsOverall !== null ? Math.round(medianViewsOverall) : null,
      medianViewsLongForm: medianViewsLongForm !== null ? Math.round(medianViewsLongForm) : null,
      medianViewsShorts: medianViewsShorts !== null ? Math.round(medianViewsShorts) : null,
      avgViewsOverall,
      avgDurationSecLongForm,
      avgDurationSecShorts,
      uploadsPerMonthEstimate,
      earliestSampleDate,
      latestSampleDate,
      avgTitleLength,
      titleQuestionPercent:
        videos.length > 0 ? Math.round((questionCount / videos.length) * 100) : 0,
      titleNumberPercent:
        videos.length > 0 ? Math.round((numberCount / videos.length) * 100) : 0,
      topOpeningWords,
      topKeywords,
      strongOrExceptionalOutliersCount,
      transcriptsSampledCount,
      retrievedAt,
      dataWindowNote:
        videos.length > 0
          ? `Calculated from ${videos.length} public uploads retrieved via YouTube Data API v3 on ${new Date(retrievedAt).toUTCString()}.`
          : 'No public uploads were available in the requested sample window.',
    },
  };
}

export function formatCompactNumber(value: number | null | undefined, fallback = 'Not publicly available'): string {
  if (value === null || value === undefined || !Number.isFinite(value)) {
    return fallback;
  }
  if (value >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2).replace(/\.00$/, '')}B`;
  if (value >= 1_000_000) return `${(value / 1_000_000).toFixed(2).replace(/\.00$/, '')}M`;
  if (value >= 1_000) return `${(value / 1_000).toFixed(1).replace(/\.0$/, '')}K`;
  return value.toLocaleString('en-US');
}

export function exportCompetitorReportToMarkdown(report: CompetitorReportRecord): string {
  const lines: string[] = [];
  lines.push(`# ${report.title}`);
  lines.push('');
  lines.push(`- **Report Key**: \`${report.reportKey}\``);
  lines.push(`- **Model Used**: \`${report.modelName}\``);
  lines.push(`- **Sample Size Per Channel**: Up to ${report.sampleSize} recent public uploads`);
  lines.push(`- **Last Updated**: ${new Date(report.updatedAt).toUTCString()}`);
  lines.push('');

  lines.push('## Analyzed Competitor Channels (Observed & Calculated Metrics)');
  lines.push('');
  for (const col of report.collections) {
    lines.push(`### ${col.profile.title}`);
    lines.push(`- **Channel URL**: ${col.profile.channelUrl}`);
    lines.push(`- **Subscribers**: ${col.profile.hiddenSubscriberCount ? 'Not publicly available (hidden by creator)' : formatCompactNumber(col.profile.subscriberCount)}`);
    lines.push(`- **Total Views**: ${formatCompactNumber(col.profile.viewCount)}`);
    lines.push(`- **Published Videos (Channel Total)**: ${formatCompactNumber(col.profile.videoCount)}`);
    lines.push(`- **Sample Analyzed**: ${col.metrics.sampleSize} videos (${col.metrics.longFormCount} long-form, ${col.metrics.shortsCount} Shorts)`);
    lines.push(`- **Median Views (Sample)**: ${formatCompactNumber(col.metrics.medianViewsOverall)}`);
    lines.push(`- **Strong / Exceptional Outliers**: ${col.metrics.strongOrExceptionalOutliersCount}`);
    lines.push(`- **Retrieved At**: ${col.profile.retrievedAt}`);
    lines.push('');
  }

  if (report.synthesis?.report19Sections?.length) {
    lines.push('## Complete 19-Section Competitor Intelligence Report');
    lines.push('');
    for (const sec of report.synthesis.report19Sections) {
      lines.push(`### ${sec.number}. ${sec.title} [${sec.epistemicLabel.toUpperCase()}]`);
      lines.push('');
      lines.push(sec.summary);
      lines.push('');
      for (const bp of sec.bulletPoints) {
        lines.push(`- ${bp}`);
      }
      lines.push('');
    }
  }

  if (report.synthesis?.module10ContentGaps?.videoOpportunities?.length) {
    lines.push('## 10 Original Content Gap Video Opportunities');
    lines.push('');
    report.synthesis.module10ContentGaps.videoOpportunities.forEach((opp, idx) => {
      lines.push(`### ${idx + 1}. ${opp.suggestedTitle}`);
      lines.push(`- **Topic**: ${opp.topic}`);
      lines.push(`- **Target Viewer**: ${opp.targetViewer}`);
      lines.push(`- **Viewer Problem**: ${opp.viewerProblem}`);
      lines.push(`- **Unique Angle**: ${opp.uniqueAngle}`);
      lines.push(`- **Thumbnail Concept**: ${opp.thumbnailConcept}`);
      lines.push(`- **Format & Est. Length**: ${opp.recommendedFormat} (~${opp.recommendedDurationMinutes} min)`);
      lines.push('');
    });
  }

  return lines.join('\n');
}
