import type {
  ScriptAiModelId,
  ScriptPersonalizationSettings,
  ScriptProjectState,
  ScriptStageNumber,
} from './types.ts';

export const SCRIPT_STAGE_META: Array<{
  stage: ScriptStageNumber;
  label: string;
  shortLabel: string;
  description: string;
}> = [
  {
    stage: 1,
    label: 'Topic Discovery',
    shortLabel: '1. Topic',
    description: 'Choose or validate a specific, emotionally relevant video idea.',
  },
  {
    stage: 2,
    label: 'Video Packaging',
    shortLabel: '2. Packaging',
    description: 'Lock in the video promise, title, thumbnail visual, and thumbnail text first.',
  },
  {
    stage: 3,
    label: 'Content Outline',
    shortLabel: '3. Outline',
    description: 'Plan originality, logical section flow, and viewer retention structure.',
  },
  {
    stage: 4,
    label: 'Introduction',
    shortLabel: '4. Intro',
    description: 'Write a 5-part opening hook that confirms the title & thumbnail promise.',
  },
  {
    stage: 5,
    label: 'Main Body',
    shortLabel: '5. Body',
    description: 'Draft and approve each main section one by one with human storytelling.',
  },
  {
    stage: 6,
    label: 'Outro & CTA',
    shortLabel: '6. Outro',
    description: 'Deliver a memorable Fortune Cookie insight and natural call to action.',
  },
  {
    stage: 7,
    label: 'Complete Script',
    shortLabel: '7. Assembly',
    description: 'Review final pacing, quality checks, production cues, and export.',
  },
];

export const BEGINNER_GLOSSARY: Array<{ term: string; explanation: string }> = [
  {
    term: 'Packaging',
    explanation: 'The combination of your video title and thumbnail. Viewers decide whether to click based on packaging before they hear a single word.',
  },
  {
    term: 'Curiosity Gap',
    explanation: 'The space between what a viewer already knows and what they suddenly want to find out—giving them a clear reason to keep watching.',
  },
  {
    term: 'Expectations vs. Reality',
    explanation: 'Your title and thumbnail create an expectation; the first 30 seconds must confirm that exact promise immediately so viewers trust the video.',
  },
  {
    term: 'Open Loop',
    explanation: 'Introducing an intriguing question or unfinished point early that you explicitly resolve later, holding viewer attention naturally.',
  },
  {
    term: 'Fortune Cookie Outro',
    explanation: 'Ending with one memorable, overarching takeaway that connects the entire video together before inviting the next action.',
  },
];

export const WELCOME_SCRIPT_MESSAGE =
  "Let's create a video people genuinely want to watch. You don't need any scriptwriting experience. I'll guide you through everything, from choosing a topic to writing the final script.";

export const ALLOWED_SCRIPT_MODELS: Array<{ id: ScriptAiModelId; label: string; description: string }> = [
  {
    id: 'gemini-4-hydrogen',
    label: 'Gemini 4 Hydrogen (Recommended)',
    description: 'Balanced creative direction, human-sounding dialogue, and structured planning.',
  },
  {
    id: 'gemini-3.1-flash-lite',
    label: 'Gemini 3.1 Flash Lite (Fast)',
    description: 'Lower-latency drafting for rapid iterations and topic brainstorming.',
  },
];

export function createDefaultScriptSettings(): ScriptPersonalizationSettings {
  return {
    channelNiche: '',
    targetAudience: 'General curious viewers and beginners',
    viewerAgeGroup: '18-35',
    countryOrRegion: 'Global (English)',
    scriptLanguage: 'English',
    languageStyle: 'Simple, natural conversational',
    videoFormat: 'Explainer / Storytelling',
    contentTone: 'Thoughtful, engaging, and clear',
    storytellingIntensity: 'balanced',
    narrationSpeedWpm: 140,
    targetDurationMinutes: 8,
    targetWordCount: 1120,
    targetCharacterCount: 6500,
    constraintPriority: 'duration',
    presentationMode: 'on-camera',
    ctaPreferences: 'Invite viewers to watch the next logical topic or subscribe for related deep dives',
    customInstructions: '',
  };
}

export function createInitialScriptState(): ScriptProjectState {
  return {
    stage1: {
      entryMode: null,
      nicheInput: '',
      customTopicInput: '',
      generatedIdeas: [],
      selectedTopic: null,
      topicAnalysis: null,
      directorComment: '',
      approved: false,
      approvedAt: null,
    },
    stage2: {
      videoPromise: null,
      titleConcepts: [],
      selectedTitleId: null,
      customTitleText: '',
      titleApproved: false,
      thumbnailConcepts: [],
      selectedThumbnailId: null,
      customThumbnailNotes: '',
      thumbnailTextOptions: [],
      selectedThumbnailText: '',
      directorComment: '',
      approved: false,
      approvedAt: null,
    },
    stage3: {
      research: null,
      retentionArchitectureNote: '',
      sections: [],
      directorComment: '',
      approved: false,
      approvedAt: null,
    },
    stage4: {
      parts: null,
      spokenNarration: '',
      wordCount: 0,
      estimatedSeconds: 0,
      directorComment: '',
      approved: false,
      approvedAt: null,
    },
    stage5: {
      activeSectionIndex: 0,
      sections: [],
      approved: false,
      approvedAt: null,
    },
    stage6: {
      outro: null,
      approved: false,
      approvedAt: null,
    },
    stage7: {
      assembled: null,
      approved: false,
      approvedAt: null,
    },
    competitorResearch: null,
    needsReviewFromStage: null,
    dependencyWarning: null,
    revisionHistory: [],
  };
}

const PRODUCTION_TAG_REGEX =
  /\[(VISUAL|B-ROLL|ON-SCREEN TEXT|SFX|PAUSE|TRANSITION|MUSIC)(?:\s*:[^\]]*)?\]/gi;

export function stripProductionNotes(text: string): string {
  return text
    .replace(PRODUCTION_TAG_REGEX, '')
    .split('\n')
    .map((line) => line.trimEnd())
    .filter((line, idx, arr) => !(line === '' && arr[idx - 1] === ''))
    .join('\n')
    .trim();
}

export function countSpokenWords(text: string): number {
  const spoken = stripProductionNotes(text);
  if (!spoken) return 0;
  return spoken.split(/\s+/).filter(Boolean).length;
}

export function computeTargetWordCount(settings: ScriptPersonalizationSettings): number {
  const wpm = Math.max(80, Math.min(240, settings.narrationSpeedWpm || 140));
  if (settings.constraintPriority === 'words' && settings.targetWordCount > 0) {
    return settings.targetWordCount;
  }
  if (settings.constraintPriority === 'characters' && settings.targetCharacterCount > 0) {
    return Math.max(120, Math.round(settings.targetCharacterCount / 5.5));
  }
  const minutes = Math.max(1, Math.min(90, settings.targetDurationMinutes || 8));
  return Math.round(minutes * wpm);
}

export function formatDurationFromWords(wordCount: number, wpm: number): {
  minutes: number;
  formatted: string;
} {
  const safeWpm = Math.max(80, wpm || 140);
  const totalSeconds = Math.round((wordCount / safeWpm) * 60);
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return {
    minutes: Number((wordCount / safeWpm).toFixed(1)),
    formatted: `${mins}m ${String(secs).padStart(2, '0')}s`,
  };
}
