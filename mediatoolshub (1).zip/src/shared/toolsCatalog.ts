import type { PlatformDefinition, ToolDefinition } from './types.ts';

export const PLATFORMS_CATALOG: PlatformDefinition[] = [
  {
    slug: 'youtube',
    name: 'YouTube Tools',
    description:
      'Extract verified thumbnail resolutions, inspect public video metadata, and review official creator links.',
    sortOrder: 1,
  },
  {
    slug: 'instagram',
    name: 'Instagram Tools',
    description:
      'Generate responsive post and reel embeds and inspect authorized public metadata via official integrations.',
    sortOrder: 2,
  },
  {
    slug: 'pinterest',
    name: 'Pinterest Tools',
    description:
      'Inspect accessible public pin metadata, image dimensions, canonical URLs, and media structure.',
    sortOrder: 3,
  },
  {
    slug: 'tiktok',
    name: 'TikTok Tools',
    description:
      'Retrieve public video oEmbed details, creator attribution, thumbnails, and official embed snippets.',
    sortOrder: 4,
  },
  {
    slug: 'facebook',
    name: 'Facebook Tools',
    description:
      'Generate Facebook post and video embeds and verify authorized public OpenGraph metadata.',
    sortOrder: 5,
  },
  {
    slug: 'twitter',
    name: 'Twitter / X Tools',
    description:
      'Fetch official X/Twitter post oEmbed metadata, author handles, and responsive embed blocks.',
    sortOrder: 6,
  },
  {
    slug: 'general',
    name: 'General Media & Utility Tools',
    description:
      'Convert images, inspect local video metadata, generate crisp QR codes, format JSON, and analyze URLs.',
    sortOrder: 7,
  },
];

export const TOOLS_CATALOG: ToolDefinition[] = [
  // YOUTUBE TOOLS
  {
    slug: 'youtube-thumbnail-extractor',
    routePath: '/youtube-thumbnail-downloader',
    name: 'YouTube Thumbnail Extractor',
    category: 'YouTube',
    platformSlug: 'youtube',
    shortDescription:
      'Check which YouTube thumbnail resolutions exist for any public video and download verified images.',
    seoTitle: 'YouTube Thumbnail Extractor – HD & SD Preview | MediaToolsHub',
    seoDescription:
      'Inspect and download available YouTube thumbnail resolutions (MaxRes 1280x720, SD, HQ, MQ) with real HTTP availability checks.',
    isPopular: true,
    isNew: false,
    mode: 'youtube-thumbnail',
    urlPlaceholder: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    instructions: [
      'Paste a public YouTube watch, Shorts, or youtu.be share URL.',
      'Click Process URL to probe which resolutions exist on YouTube image servers.',
      'Preview verified dimensions, copy the direct image URL, or download the authorized image file.',
    ],
    complianceNote:
      'Thumbnails are probed directly from official YouTube image endpoints. Not every video has a 1280x720 MaxRes thumbnail; only verified existing files are enabled for download.',
    faqs: [
      {
        question: 'Why is MaxRes (1280x720) sometimes unavailable?',
        answer:
          'YouTube only generates a maxresdefault.jpg file when the creator uploaded a high-resolution thumbnail or HD video source. Older or 480p uploads typically top out at HQ (480x360) or SD (640x480).',
      },
      {
        question: 'Can I use extracted thumbnails commercially?',
        answer:
          'Video thumbnails remain the intellectual property of their creators. Use them only for videos you own, have permission to reference, or within applicable fair-use guidelines.',
      },
    ],
    relatedSlugs: ['youtube-video-details-extractor', 'youtube-thumbnail-size', 'image-format-converter'],
  },
  {
    slug: 'youtube-video-details-extractor',
    routePath: '/youtube-video-details-extractor',
    name: 'YouTube Video Details Extractor',
    category: 'YouTube',
    platformSlug: 'youtube',
    shortDescription:
      'Retrieve verified video title, channel attribution, embed markup, and official API statistics when configured.',
    seoTitle: 'YouTube Video Details Extractor – Public Metadata | MediaToolsHub',
    seoDescription:
      'Analyze public YouTube video details including title, channel name, canonical URL, thumbnails, and official API metrics where available.',
    isPopular: true,
    isNew: false,
    mode: 'youtube-details',
    urlPlaceholder: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    instructions: [
      'Enter any valid public YouTube video or Shorts URL.',
      'Run the metadata lookup to retrieve official title, channel details, and verified thumbnails.',
      'When YouTube Data API v3 is configured on the server, view counts, duration, and publication dates are displayed.',
    ],
    complianceNote:
      'Statistics such as view, like, and comment counts are only returned when official YouTube Data API v3 credentials are present. MediaToolsHub never fabricates missing analytics.',
    faqs: [
      {
        question: 'Why do view or like counts show as unavailable?',
        answer:
          'Without a server-side YouTube Data API v3 key, MediaToolsHub uses YouTube’s official public oEmbed endpoint, which provides title, channel, and thumbnail metadata without engagement counters.',
      },
      {
        question: 'Does this tool access private or unlisted analytics?',
        answer:
          'No. Only public metadata authorized by YouTube APIs is accessible.',
      },
    ],
    relatedSlugs: ['youtube-thumbnail-extractor', 'youtube-transcript-extractor', 'youtube-thumbnail-size'],
  },
  {
    slug: 'youtube-transcript-extractor',
    routePath: '/youtube-transcript-extractor',
    name: 'YouTube Transcript & Captions Extractor',
    category: 'YouTube',
    platformSlug: 'youtube',
    shortDescription:
      'Extract publicly available YouTube video captions and timestamps, copy clean text, or export .TXT and .SRT subtitles.',
    seoTitle: 'YouTube Transcript & Captions Extractor | MediaToolsHub',
    seoDescription:
      'Read, copy, and export publicly available YouTube transcripts and closed captions with timestamps in TXT or SRT format.',
    isPopular: true,
    isNew: true,
    mode: 'youtube-transcript',
    urlPlaceholder: 'https://www.youtube.com/watch?v=aqz-KE-bpKQ',
    instructions: [
      'Paste a public YouTube video URL that has closed captions or subtitles enabled.',
      'Click Process URL to load available public caption tracks and switch languages if multiple tracks exist.',
      'Copy the clean transcript text or download timestamped .TXT / .SRT files.',
    ],
    complianceNote:
      'Only publicly exposed closed-caption tracks are read. Videos with disabled captions or private/restricted access do not expose transcripts and nothing is fabricated.',
    faqs: [
      {
        question: 'Why does a video show no transcript available?',
        answer:
          'Creators can disable captions or omit subtitle tracks on their uploads. MediaToolsHub only extracts real caption tracks provided by YouTube.',
      },
      {
        question: 'Can I download subtitles in SRT format?',
        answer:
          'Yes. When public caption tracks are available, you can export both plain text (.TXT) and SubRip (.SRT) subtitle files.',
      },
    ],
    relatedSlugs: ['youtube-video-details-extractor', 'youtube-thumbnail-extractor', 'youtube-thumbnail-size'],
  },
  {
    slug: 'youtube-thumbnail-size',
    routePath: '/youtube-thumbnail-size',
    name: 'YouTube Thumbnail Size & Safe-Zone Guide',
    category: 'YouTube',
    platformSlug: 'youtube',
    shortDescription:
      'Interactive reference and validator for YouTube thumbnail dimensions, 16:9 aspect ratios, and file size limits.',
    seoTitle: 'YouTube Thumbnail Size Guide & Checker | MediaToolsHub',
    seoDescription:
      'Check recommended 1280x720 YouTube thumbnail specifications, safe zones, and test your custom thumbnail image before uploading.',
    isPopular: false,
    isNew: true,
    mode: 'youtube-thumbnail-size',
    instructions: [
      'Review the official 1280x720 (16:9) specifications and 2 MB upload ceiling.',
      'Upload a local thumbnail draft to verify its actual pixel width, height, aspect ratio, and file weight.',
      'Export an optimized JPEG or PNG copy if your image exceeds YouTube’s 2 MB threshold.',
    ],
    complianceNote:
      'All draft image dimension checks run locally in your browser without uploading private creative drafts to external servers.',
    faqs: [
      {
        question: 'What is the ideal YouTube thumbnail resolution?',
        answer:
          '1280 x 720 pixels (minimum width 640 pixels) in a 16:9 aspect ratio, saved as JPG, GIF, or PNG under 2 MB.',
      },
    ],
    relatedSlugs: ['youtube-thumbnail-extractor', 'image-format-converter', 'image-metadata-extractor'],
  },
  {
    slug: 'ai-video-scriptwriting-studio',
    routePath: '/ai-scriptwriting-studio',
    name: 'AI Video Scriptwriting Studio',
    category: 'YouTube',
    platformSlug: 'youtube',
    shortDescription:
      'Guided 7-stage packaging-first scriptwriting studio: topic discovery, titles & thumbnails, outline, hook, section-by-section script, and production export.',
    seoTitle: 'AI Video Scriptwriting Studio – Packaging-First YouTube Scripts | MediaToolsHub',
    seoDescription:
      'Collaborate step by step with an AI creative director to craft high-retention YouTube scripts from topic discovery and packaging to production-ready narration.',
    isPopular: true,
    isNew: true,
    mode: 'scriptwriting-studio',
    instructions: [
      'Choose whether to generate 10 tailored topic ideas or analyze your own video concept.',
      'Lock in your video packaging (title, thumbnail concept, thumbnail text, and viewer promise) before writing.',
      'Approve your content outline, 5-part introduction, section-by-section body narration, and outro to assemble your final script.',
    ],
    complianceNote:
      'All creative generation runs securely on the server. Research claims needing external verification are flagged clearly, and no stage advances without your explicit approval.',
    faqs: [
      {
        question: 'Why does the studio complete packaging before writing the script?',
        answer:
          'Viewers click because of the title and thumbnail promise. Locking packaging first ensures your opening lines immediately confirm expectations and prevent viewer drop-off.',
      },
      {
        question: 'Can beginners use the Scriptwriting Studio without scriptwriting experience?',
        answer:
          'Yes. Every technical concept such as curiosity gaps, packaging, and open loops is explained in plain language, with smart defaults and edit/alternative controls at every stage.',
      },
      {
        question: 'Are my unfinished script projects saved if I leave or refresh the page?',
        answer:
          'Yes. Your approved stages, settings, section drafts, and revision history are persisted in the database so you can reopen unfinished projects anytime.',
      },
    ],
    relatedSlugs: ['youtube-competitor-intelligence', 'youtube-video-details-extractor', 'youtube-transcript-extractor', 'youtube-thumbnail-extractor'],
  },
  {
    slug: 'youtube-competitor-intelligence',
    routePath: '/youtube-competitor-intelligence',
    name: 'YouTube Competitor Intelligence Studio',
    category: 'YouTube',
    platformSlug: 'youtube',
    shortDescription:
      'Analyze multiple YouTube competitors using real YouTube Data API v3 metrics, outlier math, title & thumbnail DNA, content gaps, and a 19-section growth blueprint.',
    seoTitle: 'YouTube Competitor Intelligence Studio – Outlier & Strategy Research | MediaToolsHub',
    seoDescription:
      'Compare 1 to 10 YouTube channels with live YouTube Data API metrics, outlier ratios, title formulas, thumbnail DNA, content gaps, and a 30-day growth plan.',
    isPopular: true,
    isNew: true,
    mode: 'competitor-intelligence',
    instructions: [
      'Search by channel name or paste 1–10 public YouTube channel URLs, @handles, or UC IDs (optionally add your own channel for comparison).',
      'Collect verified channel profiles, public upload histories, and format-aware outlier ratios via YouTube Data API v3.',
      'Explore all 11 strategy modules, compare channels side by side, export the 19-section report, or launch Script Studio directly from any video opportunity.',
    ],
    complianceNote:
      'All quantitative metrics come directly from official YouTube Data API v3 responses and real mathematical medians. Missing metrics or private captions are clearly marked as unavailable and never fabricated.',
    faqs: [
      {
        question: 'How is the Outlier Ratio calculated?',
        answer:
          'Each video view count is divided by the median view count of comparable uploads (long-form vs. Shorts when sample size permits) in that channel sample. Ratios of 3.0x+ indicate Exceptional Outliers and 1.75x+ indicate Strong Outliers.',
      },
      {
        question: 'Does Competitor Intelligence guess hidden channel data or private tools?',
        answer:
          'No. MediaToolsHub separates observed YouTube API facts, calculated ratios, inferred strategy patterns, and unknown production specs (such as editing software or cameras) transparently.',
      },
      {
        question: 'Can I turn a competitor gap opportunity straight into a YouTube script?',
        answer:
          'Yes. Every suggested video opportunity has a Create Script button that sends the topic, suggested title, target audience, angle, and thumbnail concept directly into the AI Video Scriptwriting Studio.',
      },
    ],
    relatedSlugs: ['ai-video-scriptwriting-studio', 'youtube-video-details-extractor', 'youtube-transcript-extractor'],
  },

  // INSTAGRAM TOOLS
  {
    slug: 'instagram-public-profile-info',
    routePath: '/instagram-profile-tools',
    name: 'Instagram Public Profile Information',
    category: 'Instagram',
    platformSlug: 'instagram',
    shortDescription:
      'Validate public Instagram profile URLs and inspect authorized metadata via Meta Graph API when configured.',
    seoTitle: 'Instagram Public Profile Analyzer | MediaToolsHub',
    seoDescription:
      'Validate Instagram profile handles and inspect authorized public creator metadata without bypassing login walls.',
    isPopular: false,
    isNew: false,
    mode: 'instagram-metadata',
    urlPlaceholder: 'https://www.instagram.com/instagram/',
    instructions: [
      'Paste a public Instagram profile URL (e.g., https://www.instagram.com/username/).',
      'MediaToolsHub validates the URL structure and queries Meta Graph API if authorized credentials are present.',
      'Use the official profile link or embed tools when private/login-gated restrictions apply.',
    ],
    complianceNote:
      'MediaToolsHub never scrapes private accounts or bypasses Instagram authentication barriers. Live API extraction requires an authorized Meta App Access Token.',
    faqs: [
      {
        question: 'Why does Instagram require an official Meta token for metadata?',
        answer:
          'Meta restricts unauthenticated automated requests to Instagram profiles and posts. Authorized Meta oEmbed / Graph API tokens ensure compliant access to public creator data.',
      },
    ],
    relatedSlugs: ['instagram-embed-generator', 'instagram-post-metadata', 'hashtag-generator'],
  },
  {
    slug: 'instagram-post-metadata',
    routePath: '/instagram-post-metadata',
    name: 'Instagram Post Metadata Extractor',
    category: 'Instagram',
    platformSlug: 'instagram',
    shortDescription:
      'Extract canonical Instagram post IDs, authorized oEmbed details, and compliant embed snippets.',
    seoTitle: 'Instagram Post Metadata Extractor | MediaToolsHub',
    seoDescription:
      'Inspect canonical Instagram post URLs, authorized Meta oEmbed metadata, and generate clean embed code.',
    isPopular: false,
    isNew: false,
    mode: 'instagram-metadata',
    urlPlaceholder: 'https://www.instagram.com/p/C_example/',
    instructions: [
      'Paste a public Instagram post URL (/p/...).',
      'Inspect the validated shortcode, canonical URL, and authorized oEmbed metadata.',
      'Copy the clean embed snippet for editorial or blog articles.',
    ],
    complianceNote:
      'Private posts and login-walled assets cannot be accessed. Only authorized Meta oEmbed data and official links are returned.',
    faqs: [
      {
        question: 'Can I extract metadata from private Instagram posts?',
        answer: 'No. Private content is strictly inaccessible and never bypassed.',
      },
    ],
    relatedSlugs: ['instagram-reel-metadata', 'instagram-embed-generator', 'instagram-public-profile-info'],
  },
  {
    slug: 'instagram-reel-metadata',
    routePath: '/instagram-reel-tools',
    name: 'Instagram Reel Metadata Extractor',
    category: 'Instagram',
    platformSlug: 'instagram',
    shortDescription:
      'Validate Instagram Reel URLs, extract Reel IDs, and generate responsive official Reel embeds.',
    seoTitle: 'Instagram Reel Metadata & Embed Tool | MediaToolsHub',
    seoDescription:
      'Analyze public Instagram Reel URLs, extract canonical Reel identifiers, and generate responsive embed markup.',
    isPopular: true,
    isNew: false,
    mode: 'instagram-metadata',
    urlPlaceholder: 'https://www.instagram.com/reel/C_example/',
    instructions: [
      'Paste a public Instagram Reel URL (/reel/... or /reels/...).',
      'Validate the Reel ID and retrieve authorized metadata.',
      'Copy the responsive embed HTML or open the official Reel link.',
    ],
    complianceNote:
      'Respects Instagram platform policies. Direct video file scraping is not performed without creator/API authorization.',
    faqs: [
      {
        question: 'How do I embed an Instagram Reel on my blog?',
        answer:
          'Paste the public Reel URL above and copy the generated blockquote embed markup into your HTML page.',
      },
    ],
    relatedSlugs: ['instagram-embed-generator', 'tiktok-video-info', 'youtube-video-details-extractor'],
  },
  {
    slug: 'instagram-image-downloader',
    routePath: '/instagram-image-downloader',
    name: 'Instagram Image Downloader (Authorized Only)',
    category: 'Instagram',
    platformSlug: 'instagram',
    shortDescription:
      'Check authorized Meta Graph media access and export creator-owned Instagram images safely.',
    seoTitle: 'Instagram Image Tool (Authorized Media) | MediaToolsHub',
    seoDescription:
      'Access authorized Instagram image assets via official Meta integrations or generate compliant post embeds.',
    isPopular: false,
    isNew: false,
    mode: 'instagram-metadata',
    urlPlaceholder: 'https://www.instagram.com/p/C_example/',
    instructions: [
      'Paste an authorized Instagram post URL.',
      'If Meta oEmbed/Graph API returns a permitted thumbnail URL, preview or save it.',
      'Otherwise, use the official Instagram link or embed snippet provided.',
    ],
    complianceNote:
      'Only authorized media URLs returned by official Meta APIs are eligible for download. No scraping or login bypasses are used.',
    faqs: [
      {
        question: 'Why is direct download disabled when no API token is set?',
        answer:
          'Instagram restricts automated media extraction without Meta Graph API authorization. Use the embed code or official Instagram export tools for your own posts.',
      },
    ],
    relatedSlugs: ['instagram-reel-metadata', 'instagram-embed-generator', 'image-format-converter'],
  },
  {
    slug: 'instagram-embed-generator',
    routePath: '/instagram-embed-generator',
    name: 'Instagram Embed Generator',
    category: 'Instagram',
    platformSlug: 'instagram',
    shortDescription:
      'Generate clean, responsive Instagram blockquote embed code with optional caption toggle.',
    seoTitle: 'Instagram Embed Code Generator | MediaToolsHub',
    seoDescription:
      'Create clean, copy-ready Instagram post and Reel embed HTML snippets for websites, CMS platforms, and blogs.',
    isPopular: false,
    isNew: true,
    mode: 'instagram-embed',
    urlPlaceholder: 'https://www.instagram.com/p/C_example/',
    instructions: [
      'Paste any public Instagram post or Reel URL.',
      'Toggle whether to include captions in the embed card.',
      'Copy the generated HTML embed code into your website or CMS.',
    ],
    complianceNote:
      'Uses Instagram’s official embed.js markup specification so embedded media loads directly from Instagram.',
    faqs: [
      {
        question: 'Do Instagram embeds work on WordPress and Webflow?',
        answer:
          'Yes. Paste the generated HTML into a Custom HTML block on WordPress, Ghost, Webflow, or any static site.',
      },
    ],
    relatedSlugs: ['tiktok-embed-generator', 'facebook-embed-generator', 'instagram-reel-metadata'],
  },

  // PINTEREST TOOLS
  {
    slug: 'pinterest-pin-info',
    routePath: '/pinterest-pin-info',
    name: 'Pinterest Pin Information Extractor',
    category: 'Pinterest',
    platformSlug: 'pinterest',
    shortDescription:
      'Inspect accessible public Pinterest pin metadata including title, description, canonical URL, and media tags.',
    seoTitle: 'Pinterest Pin Information Extractor | MediaToolsHub',
    seoDescription:
      'Analyze public Pinterest Pin URLs to view canonical metadata, OpenGraph descriptions, and media type details.',
    isPopular: false,
    isNew: false,
    mode: 'pinterest-metadata',
    urlPlaceholder: 'https://www.pinterest.com/pin/99360735500167749/',
    instructions: [
      'Paste a public Pinterest Pin URL (pinterest.com/pin/...).',
      'Click Analyze Pin to inspect authorized public OpenGraph or API metadata.',
      'Review extracted title, description, image preview, and canonical link.',
    ],
    complianceNote:
      'Only publicly accessible pin metadata or authorized Pinterest API v5 data is inspected. Private boards remain restricted.',
    faqs: [
      {
        question: 'Does this work with shortened pin.it links?',
        answer:
          'Full pinterest.com/pin/... URLs are recommended so our SSRF-safe validator can verify the destination host directly.',
      },
    ],
    relatedSlugs: ['pinterest-image-extractor', 'pinterest-video-metadata', 'pinterest-url-analyzer'],
  },
  {
    slug: 'pinterest-image-extractor',
    routePath: '/pinterest-image-extractor',
    name: 'Pinterest Image Extractor',
    category: 'Pinterest',
    platformSlug: 'pinterest',
    shortDescription:
      'Preview accessible public Pinterest pin cover images and copy verified OpenGraph image URLs.',
    seoTitle: 'Pinterest Image Extractor – Public Pin Preview | MediaToolsHub',
    seoDescription:
      'Extract accessible public OpenGraph cover images and dimensions from public Pinterest pins.',
    isPopular: false,
    isNew: false,
    mode: 'pinterest-metadata',
    urlPlaceholder: 'https://www.pinterest.com/pin/99360735500167749/',
    instructions: [
      'Enter a public Pinterest pin URL.',
      'Inspect the accessible og:image asset returned by Pinterest.',
      'Open the official pin or save authorized assets you have permission to use.',
    ],
    complianceNote:
      'Respects Pinterest copyright policies and creator rights. Only public metadata image URLs are surfaced.',
    faqs: [
      {
        question: 'Are private Pinterest boards supported?',
        answer: 'No. Secret and private boards require authentication and are never accessed.',
      },
    ],
    relatedSlugs: ['pinterest-pin-info', 'image-metadata-extractor', 'image-format-converter'],
  },
  {
    slug: 'pinterest-video-metadata',
    routePath: '/pinterest-video-tools',
    name: 'Pinterest Video Metadata Extractor',
    category: 'Pinterest',
    platformSlug: 'pinterest',
    shortDescription:
      'Inspect public Pinterest video pin OpenGraph metadata, duration tags, and cover thumbnails.',
    seoTitle: 'Pinterest Video Metadata Extractor | MediaToolsHub',
    seoDescription:
      'Check public metadata, video tags, and cover thumbnails on public Pinterest video pins.',
    isPopular: false,
    isNew: false,
    mode: 'pinterest-metadata',
    urlPlaceholder: 'https://www.pinterest.com/pin/99360735500167749/',
    instructions: [
      'Paste a public Pinterest video pin URL.',
      'Inspect available og:video and og:image tags.',
      'Review official pin links and media details.',
    ],
    complianceNote:
      'Only publicly exposed metadata is parsed; protected or DRM streams are never bypassed.',
    faqs: [
      {
        question: 'What metadata is visible for Pinterest video pins?',
        answer:
          'When Pinterest exposes public OpenGraph metadata, you can view the pin title, description, cover thumbnail URL, and video content tags.',
      },
    ],
    relatedSlugs: ['pinterest-pin-info', 'pinterest-url-analyzer', 'video-metadata-extractor'],
  },
  {
    slug: 'pinterest-url-analyzer',
    routePath: '/pinterest-url-analyzer',
    name: 'Pinterest Pin URL Analyzer',
    category: 'Pinterest',
    platformSlug: 'pinterest',
    shortDescription:
      'Parse Pinterest pin IDs, regional domains, tracking parameters, and canonical pin URLs.',
    seoTitle: 'Pinterest Pin URL Analyzer | MediaToolsHub',
    seoDescription:
      'Clean tracking query parameters and extract canonical Pinterest Pin IDs and regional host details.',
    isPopular: false,
    isNew: true,
    mode: 'pinterest-metadata',
    urlPlaceholder: 'https://www.pinterest.com/pin/99360735500167749/',
    instructions: [
      'Paste any Pinterest URL (including regional domains like uk.pinterest.com or tracking parameters).',
      'Inspect the extracted numeric Pin ID and stripped canonical URL.',
      'Copy the clean canonical link for sharing or referencing.',
    ],
    complianceNote:
      'Pure URL parsing and public metadata inspection with zero invasive tracking.',
    faqs: [
      {
        question: 'Why clean Pinterest URL parameters?',
        answer:
          'Removing invite codes and utm_ tracking parameters creates shorter, cleaner canonical links for citations and social sharing.',
      },
    ],
    relatedSlugs: ['url-analyzer', 'pinterest-pin-info', 'url-encoder-decoder'],
  },

  // TIKTOK TOOLS
  {
    slug: 'tiktok-video-info',
    routePath: '/tiktok-video-info',
    name: 'TikTok Video Information Extractor',
    category: 'TikTok',
    platformSlug: 'tiktok',
    shortDescription:
      'Fetch official TikTok oEmbed video title, creator handle, thumbnail preview, and embed HTML.',
    seoTitle: 'TikTok Video Information Extractor (oEmbed) | MediaToolsHub',
    seoDescription:
      'Inspect public TikTok video metadata using TikTok’s official oEmbed API: creator handle, title, thumbnail, and embed snippet.',
    isPopular: true,
    isNew: false,
    mode: 'tiktok-metadata',
    urlPlaceholder: 'https://www.tiktok.com/@scout2015/video/6718335390845095173',
    instructions: [
      'Paste a public TikTok video URL (tiktok.com/@user/video/...).',
      'Click Fetch Video Info to query TikTok’s official public oEmbed API.',
      'View creator attribution, video title, cover thumbnail, and official embed code.',
    ],
    complianceNote:
      'Powered by TikTok’s official public oEmbed endpoint. Private or region-locked videos are not bypassed.',
    faqs: [
      {
        question: 'What data does TikTok’s official oEmbed endpoint provide?',
        answer:
          'It returns the video caption/title, creator display name, profile URL, cover thumbnail URL, dimensions, and official embed HTML.',
      },
    ],
    relatedSlugs: ['tiktok-embed-generator', 'tiktok-metadata-extractor', 'youtube-video-details-extractor'],
  },
  {
    slug: 'tiktok-metadata-extractor',
    routePath: '/tiktok-metadata-extractor',
    name: 'TikTok Metadata Extractor',
    category: 'TikTok',
    platformSlug: 'tiktok',
    shortDescription:
      'Extract structured public metadata and canonical video IDs from TikTok links.',
    seoTitle: 'TikTok Metadata Extractor | MediaToolsHub',
    seoDescription:
      'Extract canonical TikTok video IDs, author links, and public oEmbed metadata cleanly.',
    isPopular: false,
    isNew: false,
    mode: 'tiktok-metadata',
    urlPlaceholder: 'https://www.tiktok.com/@scout2015/video/6718335390845095173',
    instructions: [
      'Enter a full TikTok video URL.',
      'Inspect extracted structured fields including author URL, thumbnail dimensions, and embed ID.',
      'Copy formatted metadata or open the official TikTok link.',
    ],
    complianceNote:
      'Uses only TikTok’s official oEmbed specification without scraping private feeds.',
    faqs: [
      {
        question: 'Are TikTok view counts included in oEmbed?',
        answer:
          'No. TikTok’s public oEmbed API omits real-time view and like counters, and MediaToolsHub never fabricates them.',
      },
    ],
    relatedSlugs: ['tiktok-video-info', 'tiktok-embed-generator', 'video-metadata-extractor'],
  },
  {
    slug: 'tiktok-embed-generator',
    routePath: '/tiktok-embed-generator',
    name: 'TikTok Embed Generator',
    category: 'TikTok',
    platformSlug: 'tiktok',
    shortDescription:
      'Generate ready-to-paste official TikTok embed HTML from any public TikTok video URL.',
    seoTitle: 'TikTok Embed Code Generator | MediaToolsHub',
    seoDescription:
      'Create clean, responsive TikTok embed code using official TikTok oEmbed markup.',
    isPopular: false,
    isNew: false,
    mode: 'tiktok-embed',
    urlPlaceholder: 'https://www.tiktok.com/@scout2015/video/6718335390845095173',
    instructions: [
      'Paste a public TikTok video URL.',
      'Fetch the official embed blockquote and preview metadata.',
      'Copy the HTML snippet directly into your article or website.',
    ],
    complianceNote:
      'Generates official TikTok embed code referencing TikTok’s embed script.',
    faqs: [
      {
        question: 'Does embedding a TikTok video credit the creator?',
        answer:
          'Yes. Official TikTok embeds automatically display and link back to the original creator profile.',
      },
    ],
    relatedSlugs: ['instagram-embed-generator', 'tiktok-video-info', 'twitter-metadata-extractor'],
  },

  // FACEBOOK TOOLS
  {
    slug: 'facebook-video-metadata',
    routePath: '/facebook-video-metadata',
    name: 'Facebook Video Metadata Extractor',
    category: 'Facebook',
    platformSlug: 'facebook',
    shortDescription:
      'Validate Facebook video URLs, check authorized Meta Graph oEmbed data, and generate video embeds.',
    seoTitle: 'Facebook Video Metadata Extractor | MediaToolsHub',
    seoDescription:
      'Inspect public Facebook video URLs, authorized Meta oEmbed metadata, and generate clean Facebook video embed markup.',
    isPopular: false,
    isNew: false,
    mode: 'facebook-metadata',
    urlPlaceholder: 'https://www.facebook.com/facebook/videos/10153231379946729/',
    instructions: [
      'Paste a public Facebook Watch or Page video URL.',
      'Validate the URL and query authorized Meta Graph oEmbed metadata (when configured).',
      'Copy the responsive Facebook video embed snippet or open the official post.',
    ],
    complianceNote:
      'Respects Meta Platform Terms. Private groups, friend-only posts, and login-gated videos are never bypassed.',
    faqs: [
      {
        question: 'Can this tool access videos in private Facebook groups?',
        answer:
          'No. Only publicly accessible Facebook Page content and official embed links are supported.',
      },
    ],
    relatedSlugs: ['facebook-embed-generator', 'facebook-post-info', 'video-metadata-extractor'],
  },
  {
    slug: 'facebook-post-info',
    routePath: '/facebook-post-info',
    name: 'Facebook Post Information Extractor',
    category: 'Facebook',
    platformSlug: 'facebook',
    shortDescription:
      'Analyze public Facebook post URLs, inspect canonical link structure, and build embed snippets.',
    seoTitle: 'Facebook Post Information & Embed Tool | MediaToolsHub',
    seoDescription:
      'Validate Facebook post URLs, inspect canonical IDs, and generate official Facebook post embed HTML.',
    isPopular: false,
    isNew: false,
    mode: 'facebook-metadata',
    urlPlaceholder: 'https://www.facebook.com/facebook/posts/10153231379946729',
    instructions: [
      'Enter a public Facebook post URL.',
      'Verify URL validity and inspect official Meta API status.',
      'Copy the clean embed snippet or canonical post link.',
    ],
    complianceNote:
      'Uses authorized Meta Graph oEmbed integrations when a token is configured; otherwise provides compliant embed markup.',
    faqs: [
      {
        question: 'What is needed for live Facebook oEmbed API responses?',
        answer:
          'A valid META_APP_ACCESS_TOKEN configured on the backend in accordance with Meta oEmbed Read feature approval.',
      },
    ],
    relatedSlugs: ['facebook-embed-generator', 'facebook-video-metadata', 'url-analyzer'],
  },
  {
    slug: 'facebook-embed-generator',
    routePath: '/facebook-embed-generator',
    name: 'Facebook Embed Generator',
    category: 'Facebook',
    platformSlug: 'facebook',
    shortDescription:
      'Generate responsive Facebook post and video embed HTML blocks ready for websites and articles.',
    seoTitle: 'Facebook Post & Video Embed Generator | MediaToolsHub',
    seoDescription:
      'Create clean Facebook post and video embed snippets with customizable width and text display.',
    isPopular: false,
    isNew: true,
    mode: 'facebook-embed',
    urlPlaceholder: 'https://www.facebook.com/facebook/posts/10153231379946729',
    instructions: [
      'Paste a public Facebook post or video URL.',
      'Choose embed width and whether to include full post text.',
      'Copy the generated div.fb-post / div.fb-video embed code.',
    ],
    complianceNote:
      'Generates official Facebook Social Plugin markup.',
    faqs: [
      {
        question: 'Will embedded Facebook posts update automatically?',
        answer:
          'Yes, Facebook’s Social Plugin loads live public state directly from Facebook.',
      },
    ],
    relatedSlugs: ['instagram-embed-generator', 'tiktok-embed-generator', 'facebook-post-info'],
  },

  // TWITTER / X TOOLS
  {
    slug: 'twitter-metadata-extractor',
    routePath: '/twitter-metadata-extractor',
    name: 'Twitter / X Post Metadata & Embed Tool',
    category: 'Twitter / X',
    platformSlug: 'twitter',
    shortDescription:
      'Fetch official X/Twitter oEmbed post data, author attribution, and clean embed HTML.',
    seoTitle: 'Twitter / X Post Metadata & Embed Tool | MediaToolsHub',
    seoDescription:
      'Extract public X (Twitter) post author details, canonical URLs, and official oEmbed HTML snippets.',
    isPopular: false,
    isNew: true,
    mode: 'twitter-metadata',
    urlPlaceholder: 'https://x.com/NASA/status/1777416779968610421',
    instructions: [
      'Paste a public x.com or twitter.com status URL.',
      'Click Inspect Post to fetch official publish.twitter.com oEmbed data.',
      'Copy the clean blockquote embed or author attribution.',
    ],
    complianceNote:
      'Powered by X/Twitter’s official public oEmbed endpoint. Protected accounts are never accessed.',
    faqs: [
      {
        question: 'Does this support both x.com and twitter.com links?',
        answer: 'Yes. Both x.com and twitter.com status URLs are validated and supported.',
      },
    ],
    relatedSlugs: ['tiktok-embed-generator', 'instagram-embed-generator', 'url-analyzer'],
  },

  // GENERAL MEDIA & UTILITIES
  {
    slug: 'video-metadata-extractor',
    routePath: '/video-metadata-extractor',
    name: 'Video Metadata Extractor',
    category: 'Media Utilities',
    platformSlug: 'general',
    shortDescription:
      'Inspect local MP4, WebM, and MOV video files locally in your browser: resolution, duration, aspect ratio, and size.',
    seoTitle: 'Video Metadata Extractor – Resolution & Duration Inspector | MediaToolsHub',
    seoDescription:
      'Analyze local video files privately in your browser to inspect resolution, duration, aspect ratio, MIME type, and estimated bitrate.',
    isPopular: true,
    isNew: false,
    mode: 'video-metadata',
    instructions: [
      'Select or drop any MP4, WebM, or MOV video file from your device.',
      'Your browser reads container metadata locally—no large video files are uploaded to external servers.',
      'Copy the structured JSON specification report.',
    ],
    complianceNote:
      'Local file inspection happens 100% client-side in browser memory for speed and privacy.',
    faqs: [
      {
        question: 'Are my video files uploaded anywhere?',
        answer:
          'No. MediaToolsHub reads video headers and metadata directly inside your browser using HTML5 media APIs.',
      },
    ],
    relatedSlugs: ['image-metadata-extractor', 'video-format-converter', 'youtube-video-details-extractor'],
  },
  {
    slug: 'image-metadata-extractor',
    routePath: '/image-metadata-extractor',
    name: 'Image Metadata Extractor',
    category: 'Media Utilities',
    platformSlug: 'general',
    shortDescription:
      'Inspect image pixel dimensions, aspect ratio, MIME format, megapixels, and EXIF/header indicators.',
    seoTitle: 'Image Metadata Extractor – Dimensions & EXIF Check | MediaToolsHub',
    seoDescription:
      'Check exact pixel width, height, aspect ratio, file size, and EXIF orientation metadata of PNG, JPG, WebP, and GIF files.',
    isPopular: false,
    isNew: false,
    mode: 'image-metadata',
    instructions: [
      'Choose or drop an image file (PNG, JPEG, WebP, GIF, AVIF).',
      'View instant pixel dimensions, aspect ratio, megapixel count, and file size.',
      'Export the metadata summary as JSON.',
    ],
    complianceNote:
      'Files are analyzed locally in your browser and never stored permanently on our servers.',
    faqs: [
      {
        question: 'Can this tool tell if a JPEG contains EXIF metadata?',
        answer:
          'Yes. For JPEG files, MediaToolsHub scans APP1/Exif binary markers locally to flag whether embedded camera metadata is present.',
      },
    ],
    relatedSlugs: ['image-format-converter', 'youtube-thumbnail-size', 'video-metadata-extractor'],
  },
  {
    slug: 'image-format-converter',
    routePath: '/image-converter',
    name: 'Image Format Converter',
    category: 'Media Utilities',
    platformSlug: 'general',
    shortDescription:
      'Convert images between PNG, JPEG, and WebP with custom quality compression and optional resizing.',
    seoTitle: 'Free Image Format Converter – PNG, JPG, WebP | MediaToolsHub',
    seoDescription:
      'Convert PNG, JPEG, and WebP images directly in your browser with quality control, size comparison, and instant download.',
    isPopular: true,
    isNew: false,
    mode: 'image-converter',
    instructions: [
      'Upload any browser-supported image (PNG, JPG, WebP, GIF, SVG).',
      'Choose target format (WebP, JPEG, or PNG), compression quality, and optional max width.',
      'Convert instantly and compare before/after file sizes before downloading.',
    ],
    complianceNote:
      'Conversions run securely in your browser via HTML5 Canvas. No images are retained on our servers.',
    faqs: [
      {
        question: 'Which format gives the smallest file size for web thumbnails?',
        answer:
          'WebP typically reduces file size by 25–35% compared to JPEG at equivalent visual quality while supporting transparency.',
      },
    ],
    relatedSlugs: ['image-metadata-extractor', 'youtube-thumbnail-size', 'video-format-converter'],
  },
  {
    slug: 'video-format-converter',
    routePath: '/video-converter',
    name: 'Browser Video Format Converter',
    category: 'Media Utilities',
    platformSlug: 'general',
    shortDescription:
      'Re-encode short browser-playable clips to WebM (VP9/VP8) locally using MediaRecorder APIs.',
    seoTitle: 'Browser Video Converter – MP4/MOV to WebM | MediaToolsHub',
    seoDescription:
      'Convert short local video clips to WebM directly in your browser with transparent codec support diagnostics.',
    isPopular: false,
    isNew: true,
    mode: 'video-converter',
    instructions: [
      'Select a short local video file supported by your browser.',
      'Choose an available browser MediaRecorder WebM codec profile.',
      'Start conversion and download the resulting WebM video file once playback capture finishes.',
    ],
    complianceNote:
      'Client-side conversion operates at real-time playback speed using your browser’s native MediaRecorder codecs. Very long videos are best converted with desktop FFmpeg.',
    faqs: [
      {
        question: 'Why does browser video conversion run at 1x speed?',
        answer:
          'Browser MediaRecorder captures rendered video frames and audio tracks in real time without server-side upload costs or file size limits.',
      },
    ],
    relatedSlugs: ['video-metadata-extractor', 'image-format-converter'],
  },
  {
    slug: 'qr-code-generator',
    routePath: '/qr-code-generator',
    name: 'QR Code Generator',
    category: 'General Utilities',
    platformSlug: 'general',
    shortDescription:
      'Generate sharp SVG and high-resolution PNG QR codes for URLs, social profiles, and text.',
    seoTitle: 'Free QR Code Generator – PNG & SVG Export | MediaToolsHub',
    seoDescription:
      'Create customizable high-resolution PNG and vector SVG QR codes with adjustable colors and error correction.',
    isPopular: true,
    isNew: false,
    mode: 'qr-generator',
    instructions: [
      'Enter any URL, social media handle link, or plain text.',
      'Adjust foreground/background colors, margin, pixel size, and error correction level.',
      'Download your crisp PNG or scalable SVG QR code immediately.',
    ],
    complianceNote:
      'Static QR codes never expire and contain no hidden tracking redirects.',
    faqs: [
      {
        question: 'Which error correction level should I choose?',
        answer:
          'Medium (M) works well for clean screens and print; Quartile (Q) or High (H) is recommended for posters or outdoor signage.',
      },
    ],
    relatedSlugs: ['url-analyzer', 'url-encoder-decoder', 'hashtag-generator'],
  },
  {
    slug: 'url-encoder-decoder',
    routePath: '/url-encoder-decoder',
    name: 'URL Encoder / Decoder',
    category: 'General Utilities',
    platformSlug: 'general',
    shortDescription:
      'Safely encode or decode URL query strings, UTF-8 characters, and UTM tracking parameters.',
    seoTitle: 'URL Encoder & Decoder – Percent-Encoding Tool | MediaToolsHub',
    seoDescription:
      'Encode or decode URL components and full URIs instantly with UTF-8 percent-encoding support.',
    isPopular: false,
    isNew: false,
    mode: 'url-encoder',
    instructions: [
      'Paste raw text or an encoded URL string into the input editor.',
      'Choose Component Mode (encodeURIComponent) or Full URI Mode (encodeURI).',
      'Copy the encoded or decoded output with one click.',
    ],
    complianceNote: 'Runs 100% locally in your browser.',
    faqs: [
      {
        question: 'When should I use Component mode vs Full URI mode?',
        answer:
          'Use Component mode for query parameter values (like ?q=...) and Full URI mode when keeping protocol slashes (https://) intact.',
      },
    ],
    relatedSlugs: ['url-analyzer', 'json-formatter', 'qr-code-generator'],
  },
  {
    slug: 'hashtag-generator',
    routePath: '/hashtag-generator',
    name: 'Social Hashtag Generator',
    category: 'Creator Utilities',
    platformSlug: 'general',
    shortDescription:
      'Generate structured, platform-appropriate hashtags tailored for YouTube, Instagram, TikTok, and X.',
    seoTitle: 'Social Media Hashtag Generator | MediaToolsHub',
    seoDescription:
      'Build relevant, clean hashtag sets formatted for YouTube, Instagram, TikTok, Pinterest, and X character guidelines.',
    isPopular: false,
    isNew: false,
    mode: 'hashtag-generator',
    instructions: [
      'Enter your topic keywords separated by spaces or commas.',
      'Select your target social platform to apply recommended tag count limits.',
      'Select or deselect generated tags and copy the formatted set.',
    ],
    complianceNote:
      'Generates clean keyword combinations following each platform’s recommended tag density.',
    faqs: [
      {
        question: 'How many hashtags should I use on YouTube vs Instagram?',
        answer:
          'YouTube recommends 3–5 focused hashtags in descriptions, while Instagram typically performs best with 5–10 topical hashtags.',
      },
    ],
    relatedSlugs: ['word-counter', 'character-counter', 'youtube-video-details-extractor'],
  },
  {
    slug: 'text-case-converter',
    routePath: '/text-case-converter',
    name: 'Text Case Converter',
    category: 'Writing Utilities',
    platformSlug: 'general',
    shortDescription:
      'Transform titles, video descriptions, and slugs into Title Case, Sentence case, camelCase, snake_case, or kebab-case.',
    seoTitle: 'Text Case Converter – Title, Sentence, Camel & Snake Case | MediaToolsHub',
    seoDescription:
      'Convert captions, titles, and headlines between Title Case, UPPERCASE, lowercase, snake_case, and URL slugs.',
    isPopular: false,
    isNew: false,
    mode: 'text-case',
    instructions: [
      'Paste or type your headline, caption, or text block.',
      'Click any formatting transformation button to convert instantly.',
      'Copy the formatted result for your video title or blog post.',
    ],
    complianceNote: 'Runs locally in your browser with zero data retention.',
    faqs: [
      {
        question: 'What is kebab-case used for?',
        answer: 'kebab-case is ideal for SEO-friendly URL slugs and file names.',
      },
    ],
    relatedSlugs: ['word-counter', 'character-counter', 'json-formatter'],
  },
  {
    slug: 'word-counter',
    routePath: '/word-counter',
    name: 'Word Counter & Read-Time Calculator',
    category: 'Writing Utilities',
    platformSlug: 'general',
    shortDescription:
      'Count words, sentences, paragraphs, reading time, and speaking duration for scripts and blog posts.',
    seoTitle: 'Word Counter & Speaking Time Calculator | MediaToolsHub',
    seoDescription:
      'Count words, characters, paragraphs, and estimated reading or video narration time accurately in real time.',
    isPopular: false,
    isNew: false,
    mode: 'word-counter',
    instructions: [
      'Paste your video script, social caption, or article draft.',
      'Inspect live word, sentence, paragraph, reading time, and narration duration metrics.',
    ],
    complianceNote: 'All text processing stays inside your browser.',
    faqs: [
      {
        question: 'How is video speaking time estimated?',
        answer: 'Using a standard conversational narration pace of ~140 words per minute.',
      },
    ],
    relatedSlugs: ['character-counter', 'text-case-converter', 'hashtag-generator'],
  },
  {
    slug: 'character-counter',
    routePath: '/character-counter',
    name: 'Social Character Counter & Limit Checker',
    category: 'Writing Utilities',
    platformSlug: 'general',
    shortDescription:
      'Check live character counts against YouTube title, X/Twitter, Instagram caption, TikTok, and meta description limits.',
    seoTitle: 'Social Media Character Counter & Limit Checker | MediaToolsHub',
    seoDescription:
      'Verify exact character lengths against YouTube, Instagram, TikTok, X/Twitter, and SEO meta tag limits in real time.',
    isPopular: false,
    isNew: true,
    mode: 'character-counter',
    instructions: [
      'Type or paste your post copy, video title, or SEO meta description.',
      'Check visual progress meters against official platform character limits.',
    ],
    complianceNote: 'Runs locally in your browser.',
    faqs: [
      {
        question: 'What is the maximum YouTube video title length?',
        answer:
          'YouTube allows up to 100 characters, though keeping key terms within the first 60–70 characters prevents truncation in search results.',
      },
    ],
    relatedSlugs: ['word-counter', 'text-case-converter', 'hashtag-generator'],
  },
  {
    slug: 'json-formatter',
    routePath: '/json-formatter',
    name: 'JSON Formatter & Validator',
    category: 'Developer Utilities',
    platformSlug: 'general',
    shortDescription:
      'Pretty-print, minify, validate syntax, and inspect nested API metadata payloads cleanly.',
    seoTitle: 'JSON Formatter & Validator | MediaToolsHub',
    seoDescription:
      'Format, validate, minify, and inspect JSON payloads cleanly with exact syntax error diagnostics.',
    isPopular: false,
    isNew: false,
    mode: 'json-formatter',
    instructions: [
      'Paste raw JSON from an oEmbed response, API call, or config file.',
      'Format with 2-space or 4-space indentation, or minify for compact transfer.',
      'View exact parse error line details if syntax is invalid.',
    ],
    complianceNote: 'Formats locally in your browser without sending payloads to external servers.',
    faqs: [
      {
        question: 'Can I sort JSON object keys alphabetically?',
        answer: 'Yes, toggle Sort Keys to normalize JSON structures for easier comparison.',
      },
    ],
    relatedSlugs: ['url-analyzer', 'url-encoder-decoder', 'youtube-video-details-extractor'],
  },
  {
    slug: 'url-analyzer',
    routePath: '/url-analyzer',
    name: 'URL Analyzer & OpenGraph Inspector',
    category: 'General Utilities',
    platformSlug: 'general',
    shortDescription:
      'Break down URL anatomy, query parameters, platform detection, and inspect public OpenGraph tags.',
    seoTitle: 'URL Analyzer & OpenGraph Inspector | MediaToolsHub',
    seoDescription:
      'Parse URL protocols, query strings, detect social media platforms, and inspect public OpenGraph social share cards safely.',
    isPopular: false,
    isNew: true,
    mode: 'url-analyzer',
    urlPlaceholder: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=12s',
    instructions: [
      'Paste any public web or social media URL.',
      'Run the server-validated check to inspect URL components, query parameters, and public OpenGraph tags.',
      'Copy cleaned canonical URLs without tracking query strings.',
    ],
    complianceNote:
      'Protected by strict SSRF filtering and private-IP blocking. Internal network URLs are automatically rejected.',
    faqs: [
      {
        question: 'Why does the analyzer block local or private IP addresses?',
        answer:
          'To protect infrastructure against Server-Side Request Forgery (SSRF), only verified public internet hosts are reachable.',
      },
    ],
    relatedSlugs: ['url-encoder-decoder', 'qr-code-generator', 'pinterest-url-analyzer'],
  },
];

export function getToolBySlug(slug: string): ToolDefinition | undefined {
  return TOOLS_CATALOG.find((t) => t.slug === slug);
}

export function getToolByRoutePath(path: string): ToolDefinition | undefined {
  const clean = path.replace(/\/+$/, '') || '/';
  return TOOLS_CATALOG.find((t) => t.routePath === clean);
}
