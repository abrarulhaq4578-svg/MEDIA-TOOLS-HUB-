import type {
  YtmDistributionPlatform,
  YtmRevenueCategory,
  YtmSidebarSection,
  YtmWorkspaceRole,
} from './types.ts';

export const YTM_DEFAULT_PIPELINE_STATUSES = [
  'Idea',
  'Selected',
  'Researching',
  'Scripting',
  'Production',
  'Ready to Publish',
  'Published',
];

export const YTM_INSPIRATION_CATEGORIES: Array<{
  id:
    | 'video_topic'
    | 'video_title'
    | 'thumbnail_concept'
    | 'hook_opening'
    | 'video_format'
    | 'storytelling_structure'
    | 'content_strategy'
    | 'creative_observation';
  label: string;
}> = [
  { id: 'video_topic', label: 'Video Topic' },
  { id: 'video_title', label: 'Video Title' },
  { id: 'thumbnail_concept', label: 'Thumbnail Concept' },
  { id: 'hook_opening', label: 'Hook & Opening' },
  { id: 'video_format', label: 'Video Format' },
  { id: 'storytelling_structure', label: 'Storytelling Structure' },
  { id: 'content_strategy', label: 'Content Strategy' },
  { id: 'creative_observation', label: 'Creative Observation' },
];

export const YTM_DEFAULT_PRODUCTION_CHECKLIST: Array<{ id: string; label: string; done: boolean }> = [
  { id: 'chk_research', label: 'Topic & audience research complete', done: false },
  { id: 'chk_packaging', label: 'Title angle & thumbnail direction locked', done: false },
  { id: 'chk_script', label: 'Hook & full script approved', done: false },
  { id: 'chk_production', label: 'Filming / recording & editing complete', done: false },
  { id: 'chk_seo', label: 'SEO metadata, chapters & distribution ready', done: false },
];

export const YTM_SIDEBAR_SECTIONS: Array<{
  id: YtmSidebarSection;
  order: number;
  label: string;
  shortDesc: string;
}> = [
  { id: 'dashboard', order: 1, label: 'Dashboard', shortDesc: 'Channel overview & daily focus' },
  {
    id: 'competitors',
    order: 2,
    label: 'Competitor Intelligence',
    shortDesc: 'Research channels & opportunities',
  },
  {
    id: 'planner',
    order: 3,
    label: 'Content Planner',
    shortDesc: 'Calendar, AI Strategy & backlog',
  },
  { id: 'workflow', order: 4, label: 'Workflow', shortDesc: '6-stage video production' },
  {
    id: 'analytics',
    order: 5,
    label: 'Analytics & Growth',
    shortDesc: 'Own connected channel metrics',
  },
  {
    id: 'coach',
    order: 6,
    label: 'Creator Performance Coach',
    shortDesc: 'Diagnosis, coaching & next steps',
  },
  { id: 'earn', order: 7, label: 'Earn', shortDesc: 'Revenue & Brand Deal CRM' },
  { id: 'community', order: 8, label: 'Community', shortDesc: 'Comments, replies & posts' },
  { id: 'team', order: 9, label: 'Team & Delegation', shortDesc: 'Members, roles & reviews' },
  { id: 'others', order: 10, label: 'Others', shortDesc: 'Assets, prompts, exports & settings' },
];

export const YTM_WORKFLOW_STAGES: Array<{
  stage: 1 | 2 | 3 | 4 | 5 | 6;
  label: string;
  description: string;
}> = [
  { stage: 1, label: '1. Title', description: 'Psychological title angles & packaging hook' },
  { stage: 2, label: '2. Topic', description: 'Audience clarity, problem & transformation' },
  { stage: 3, label: '3. Script', description: 'AI Video Scriptwriting Studio integration' },
  {
    stage: 4,
    label: '4. Thumbnail & Post',
    description: 'Video Thumbnail or YouTube Community Post creator',
  },
  { stage: 5, label: '5. SEO', description: 'Description, tags, chapters & checklist' },
  { stage: 6, label: '6. Distribution', description: '8-platform promotion & YouTube publishing' },
];

export const YTM_COMMUNITY_POST_FORMATS: Array<{
  id: 'quiz' | 'text_poll' | 'image_poll' | 'image_post' | 'simple_text';
  label: string;
  description: string;
}> = [
  {
    id: 'quiz',
    label: 'Quiz',
    description: 'Question, multiple answer choices, correct answer, explanation & optional visual',
  },
  {
    id: 'text_poll',
    label: 'Text Poll',
    description: 'Poll question, text answer choices, and optional introductory caption',
  },
  {
    id: 'image_poll',
    label: 'Image Poll',
    description: 'Poll question with image-based options (upload or AI image prompts) & caption',
  },
  {
    id: 'image_post',
    label: 'Image Post',
    description: 'Post visual (upload or AI image prompt), caption, supporting text & CTA',
  },
  {
    id: 'simple_text',
    label: 'Simple Text Post',
    description: 'Community update, discussion question or announcement, and optional CTA',
  },
];

export const YTM_DISTRIBUTION_PLATFORMS: Array<{
  id: YtmDistributionPlatform;
  label: string;
  officialPublishUrl: string;
  supportsDirectApi: boolean;
  note: string;
}> = [
  {
    id: 'instagram',
    label: 'Instagram',
    officialPublishUrl: 'https://www.instagram.com/',
    supportsDirectApi: false,
    note: 'Copy caption, hashtags, or slide plan and post via Instagram app or Meta Business Suite.',
  },
  {
    id: 'facebook',
    label: 'Facebook',
    officialPublishUrl: 'https://business.facebook.com/',
    supportsDirectApi: false,
    note: 'Copy Facebook post copy or upload vertical clip via Meta Business Suite.',
  },
  {
    id: 'pinterest',
    label: 'Pinterest',
    officialPublishUrl: 'https://www.pinterest.com/pin-creation-tool/',
    supportsDirectApi: false,
    note: 'Copy Pin title/description and upload vertical asset in Pinterest Pin Builder.',
  },
  {
    id: 'youtube_community',
    label: 'YouTube Community',
    officialPublishUrl: 'https://studio.youtube.com/',
    supportsDirectApi: false,
    note: 'Copy Community post/poll draft and publish directly in YouTube Studio.',
  },
  {
    id: 'whatsapp',
    label: 'WhatsApp',
    officialPublishUrl: 'https://web.whatsapp.com/',
    supportsDirectApi: false,
    note: 'Copy broadcast update or open WhatsApp Web to share with subscribers.',
  },
  {
    id: 'x',
    label: 'X',
    officialPublishUrl: 'https://x.com/compose/post',
    supportsDirectApi: false,
    note: 'Copy thread or launch post and compose cleanly in X.',
  },
  {
    id: 'youtube_shorts',
    label: 'YouTube Shorts',
    officialPublishUrl: 'https://studio.youtube.com/',
    supportsDirectApi: false,
    note: 'Use Shorts hook & teaser script; upload clip via Publishing or YouTube Studio.',
  },
  {
    id: 'telegram',
    label: 'Telegram',
    officialPublishUrl: 'https://web.telegram.org/',
    supportsDirectApi: false,
    note: 'Copy Telegram channel announcement with CTA links and post via Telegram.',
  },
];

export const YTM_REVENUE_CATEGORIES: Array<{
  id: YtmRevenueCategory;
  label: string;
  description: string;
}> = [
  { id: 'ads', label: 'Ads Revenue', description: 'YouTube Partner Program ad earnings' },
  { id: 'membership', label: 'Membership Revenue', description: 'Channel memberships & perks' },
  {
    id: 'brands_shopping',
    label: 'Brands & Shopping Revenue',
    description: 'Affiliate shopping & tagged products',
  },
  {
    id: 'collaborations',
    label: 'Collaborations',
    description: 'Sponsored integrations & brand partnerships',
  },
  {
    id: 'super_thanks',
    label: 'Super Thanks & Fan Funding',
    description: 'Super Thanks, Super Chat & tips',
  },
  { id: 'other', label: 'Other Revenue', description: 'Digital products, courses & licensing' },
];

export const YTM_ROLE_LABELS: Record<YtmWorkspaceRole, string> = {
  owner: 'Owner',
  admin: 'Admin',
  manager: 'Manager',
  editor: 'Editor',
  thumbnail_designer: 'Thumbnail Designer',
  script_writer: 'Script Writer',
  analyst: 'Analyst',
  viewer: 'Viewer',
};

export type YtmPermissionAction =
  | 'workspace:read'
  | 'workspace:manage'
  | 'team:manage'
  | 'oauth:manage'
  | 'planner:write'
  | 'workflow:write'
  | 'workflow:approve'
  | 'publish:youtube'
  | 'earn:read'
  | 'earn:write'
  | 'community:write'
  | 'analytics:read';

const ROLE_PERMISSIONS: Record<YtmWorkspaceRole, Set<YtmPermissionAction>> = {
  owner: new Set([
    'workspace:read',
    'workspace:manage',
    'team:manage',
    'oauth:manage',
    'planner:write',
    'workflow:write',
    'workflow:approve',
    'publish:youtube',
    'earn:read',
    'earn:write',
    'community:write',
    'analytics:read',
  ]),
  admin: new Set([
    'workspace:read',
    'workspace:manage',
    'team:manage',
    'oauth:manage',
    'planner:write',
    'workflow:write',
    'workflow:approve',
    'publish:youtube',
    'earn:read',
    'earn:write',
    'community:write',
    'analytics:read',
  ]),
  manager: new Set([
    'workspace:read',
    'team:manage',
    'planner:write',
    'workflow:write',
    'workflow:approve',
    'publish:youtube',
    'earn:read',
    'earn:write',
    'community:write',
    'analytics:read',
  ]),
  editor: new Set([
    'workspace:read',
    'planner:write',
    'workflow:write',
    'community:write',
    'analytics:read',
  ]),
  thumbnail_designer: new Set(['workspace:read', 'planner:write', 'workflow:write']),
  script_writer: new Set(['workspace:read', 'planner:write', 'workflow:write']),
  analyst: new Set(['workspace:read', 'analytics:read', 'earn:read']),
  viewer: new Set(['workspace:read', 'analytics:read']),
};

export function hasYtmPermission(role: YtmWorkspaceRole, action: YtmPermissionAction): boolean {
  return ROLE_PERMISSIONS[role]?.has(action) ?? false;
}

export function normalizeYtmRole(raw: unknown): YtmWorkspaceRole {
  const valid: YtmWorkspaceRole[] = [
    'owner',
    'admin',
    'manager',
    'editor',
    'thumbnail_designer',
    'script_writer',
    'analyst',
    'viewer',
  ];
  return typeof raw === 'string' && valid.includes(raw as YtmWorkspaceRole)
    ? (raw as YtmWorkspaceRole)
    : 'viewer';
}

export function getTodayDateKey(now: Date = new Date()): string {
  return now.toISOString().slice(0, 10);
}

export function classifyDistributionState(params: {
  platform: YtmDistributionPlatform;
  apiPublishSucceeded: boolean;
  markedManuallyPublished: boolean;
}): 'published_api' | 'manually_published' | 'draft' {
  if (params.apiPublishSucceeded) return 'published_api';
  if (params.markedManuallyPublished) return 'manually_published';
  return 'draft';
}

export const GOOGLE_OAUTH_AUTHORIZATION_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
export const YTM_OAUTH_CALLBACK_PATH = '/api/v1/ytm/auth/google/callback';

export function validateGoogleOAuthAuthorizationUrl(rawUrl: unknown): string {
  if (typeof rawUrl !== 'string' || !rawUrl.trim()) {
    throw new Error('Backend did not return an OAuth authorizationUrl.');
  }
  let parsed: URL;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    throw new Error('Google OAuth authorizationUrl is not a valid URL.');
  }
  if (parsed.protocol !== 'https:') {
    throw new Error('Google OAuth authorizationUrl must use HTTPS.');
  }
  if (parsed.hostname !== 'accounts.google.com') {
    throw new Error(
      `Invalid OAuth hostname "${parsed.hostname}". Expected accounts.google.com.`
    );
  }
  if (parsed.pathname !== '/o/oauth2/v2/auth') {
    throw new Error(
      `Invalid OAuth path "${parsed.pathname}". Expected /o/oauth2/v2/auth.`
    );
  }
  const requiredParams = ['client_id', 'redirect_uri', 'response_type', 'scope', 'state'] as const;
  for (const key of requiredParams) {
    if (!parsed.searchParams.get(key)) {
      throw new Error(`Google OAuth URL is missing required parameter "${key}".`);
    }
  }
  if (parsed.searchParams.get('response_type') !== 'code') {
    throw new Error('Google OAuth URL must use response_type=code.');
  }
  return parsed.toString();
}

