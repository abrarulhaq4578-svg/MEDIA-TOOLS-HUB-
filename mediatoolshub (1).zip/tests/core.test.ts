import { describe, expect, it } from 'vitest';
import {
  getAdminIntegrationsReport,
  getMandatoryStartupConfig,
  getPublicIntegrationFlags,
  getServerConfig,
} from '../src/server/config/env.ts';
import {
  isPrivateOrReservedIp,
  validateUrlSyntaxOnly,
} from '../src/server/services/ssrfGuard.ts';
import {
  classifyMediaUrl,
  detectAndNormalizeUrl,
  detectPlatformFromUrl,
} from '../src/server/services/urlDetector.ts';
import {
  buildSupportedVideoFormatOptions,
  validateMediaSignature,
} from '../src/server/services/mediaProcessor.ts';
import { TOOLS_CATALOG } from '../src/shared/toolsCatalog.ts';
import {
  buildModelThinkingConfig,
  extractReadableAiErrorMessage,
  getOrderedModelCandidates,
  isTransientModelOverloadError,
  markHydrogenTemporarilyUnavailable,
} from '../src/server/services/scriptStudioAi.ts';
import {
  ALLOWED_SCRIPT_MODELS,
  computeTargetWordCount,
  countSpokenWords,
  createDefaultScriptSettings,
  createInitialScriptState,
  formatDurationFromWords,
  stripProductionNotes,
} from '../src/shared/scriptStudioHelpers.ts';
import {
  classifyOutlierRatio,
  computeMedian,
  computeOutliersAndChannelMetrics,
  formatCompactNumber,
  formatSecondsAsClock,
  parseIso8601DurationToSeconds,
  parseYouTubeChannelInput,
} from '../src/shared/competitorHelpers.ts';
import {
  ApiClientError,
  fetchWithWarmupRetry,
  parseSafeJsonResponse,
} from '../src/lib/apiClient.ts';

describe('SSRF Security Guard', () => {
  it('blocks private IPv4, loopback, CGNAT, and cloud metadata IPs', () => {
    expect(isPrivateOrReservedIp('127.0.0.1')).toBe(true);
    expect(isPrivateOrReservedIp('10.0.0.5')).toBe(true);
    expect(isPrivateOrReservedIp('172.16.4.2')).toBe(true);
    expect(isPrivateOrReservedIp('192.168.1.1')).toBe(true);
    expect(isPrivateOrReservedIp('169.254.169.254')).toBe(true);
    expect(isPrivateOrReservedIp('100.64.0.1')).toBe(true);
    expect(isPrivateOrReservedIp('::1')).toBe(true);
    expect(isPrivateOrReservedIp('::ffff:127.0.0.1')).toBe(true);
    expect(isPrivateOrReservedIp('fc00::1')).toBe(true);
    expect(isPrivateOrReservedIp('fe80::1')).toBe(true);
  });

  it('allows public IPv4 addresses', () => {
    expect(isPrivateOrReservedIp('8.8.8.8')).toBe(false);
    expect(isPrivateOrReservedIp('142.250.190.46')).toBe(false);
  });

  it('blocks internal hostnames, non-HTTP protocols, and embedded credentials', () => {
    expect(validateUrlSyntaxOnly('http://localhost:3000').safe).toBe(false);
    expect(validateUrlSyntaxOnly('http://metadata.google.internal/computeMetadata/v1/').safe).toBe(false);
    expect(validateUrlSyntaxOnly('file:///etc/passwd').safe).toBe(false);
    expect(validateUrlSyntaxOnly('https://user:pass@youtube.com/watch?v=dQw4w9WgXcQ').safe).toBe(false);
    expect(validateUrlSyntaxOnly('https://www.youtube.com/watch?v=dQw4w9WgXcQ').safe).toBe(true);
  });
});

describe('Platform URL Detection & Extraction', () => {
  it('extracts YouTube video IDs across watch, youtu.be, and Shorts URLs', () => {
    const watch = detectPlatformFromUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=12s');
    expect(watch.valid).toBe(true);
    expect(watch.platform).toBe('youtube');
    expect(watch.entityId).toBe('dQw4w9WgXcQ');

    const shortLink = detectPlatformFromUrl('https://youtu.be/aqz-KE-bpKQ');
    expect(shortLink.valid).toBe(true);
    expect(shortLink.entityId).toBe('aqz-KE-bpKQ');

    const shorts = detectPlatformFromUrl('https://www.youtube.com/shorts/aqz-KE-bpKQ');
    expect(shorts.valid).toBe(true);
    expect(shorts.entityType).toBe('short');
  });

  it('detects Instagram, Pinterest, TikTok, Facebook, and X/Twitter URLs', () => {
    expect(detectPlatformFromUrl('https://www.instagram.com/reel/C_example123/').platform).toBe('instagram');
    expect(detectPlatformFromUrl('https://www.pinterest.com/pin/99360735500167749/').platform).toBe('pinterest');
    expect(detectPlatformFromUrl('https://www.tiktok.com/@scout2015/video/6718335390845095173').platform).toBe('tiktok');
    expect(detectPlatformFromUrl('https://www.facebook.com/facebook/videos/10153231379946729/').platform).toBe('facebook');
    expect(detectPlatformFromUrl('https://x.com/NASA/status/1777416779968610421').platform).toBe('twitter');
  });

  it('rejects malformed YouTube URLs lacking an 11-character ID', () => {
    const bad = detectPlatformFromUrl('https://www.youtube.com/watch?v=invalid');
    expect(bad.valid).toBe(false);
    expect(bad.platform).toBe('youtube');
  });
});

describe('Tools Catalog Integrity', () => {
  it('has unique slugs, unique SEO route paths, and valid relatedSlugs', () => {
    const slugs = new Set<string>();
    const paths = new Set<string>();

    for (const tool of TOOLS_CATALOG) {
      expect(slugs.has(tool.slug)).toBe(false);
      expect(paths.has(tool.routePath)).toBe(false);
      expect(tool.routePath.startsWith('/')).toBe(true);
      expect(tool.seoTitle.length).toBeGreaterThan(15);
      expect(tool.seoDescription.length).toBeGreaterThan(40);
      slugs.add(tool.slug);
      paths.add(tool.routePath);
    }

    for (const tool of TOOLS_CATALOG) {
      for (const rel of tool.relatedSlugs) {
        expect(slugs.has(rel) || rel === 'copyright-policy').toBe(true);
      }
    }
  });
});

describe('Environment & Integration Configuration', () => {
  it('keeps only YOUTUBE_API_KEY and ADMIN_EMAIL in mandatory startup config and marks missing optional integrations as Not Configured', () => {
    const minimalEnv: NodeJS.ProcessEnv = {
      YOUTUBE_API_KEY: 'test-yt-key-placeholder',
      ADMIN_EMAIL: 'owner@example.com',
    };

    const mandatory = getMandatoryStartupConfig(minimalEnv);
    expect(Object.keys(mandatory)).toEqual(['youtubeApiKey', 'adminEmail']);

    const cfg = getServerConfig(minimalEnv);
    expect(cfg.youtubeApiKey).toBe('test-yt-key-placeholder');
    expect(cfg.adminEmail).toBe('owner@example.com');
    expect(cfg.metaAppAccessToken).toBeNull();

    const report = getAdminIntegrationsReport({}, minimalEnv);
    const byEnv = Object.fromEntries(report.map((r) => [r.envVar, r]));

    expect(byEnv.YOUTUBE_API_KEY.required).toBe(true);
    expect(byEnv.YOUTUBE_API_KEY.status).toBe('Connected');
    expect(byEnv.ADMIN_EMAIL.required).toBe(true);
    expect(byEnv.ADMIN_EMAIL.status).toBe('Connected');

    expect(byEnv.META_APP_ACCESS_TOKEN.required).toBe(false);
    expect(byEnv.META_APP_ACCESS_TOKEN.status).toBe('Not Configured');
    expect(byEnv.PINTEREST_ACCESS_TOKEN.status).toBe('Not Configured');
    expect(byEnv.GA_MEASUREMENT_ID.status).toBe('Not Configured');
    expect(byEnv.GSC_VERIFICATION_TOKEN.status).toBe('Not Configured');
    expect(byEnv.ADSENSE_PUBLISHER_ID.status).toBe('Not Configured');
  });

  it('supports Connected, Not Configured, and Disabled integration states dynamically via admin settings', () => {
    const minimalEnv: NodeJS.ProcessEnv = {
      YOUTUBE_API_KEY: 'test-yt-key-placeholder',
      ADMIN_EMAIL: 'owner@example.com',
    };
    const dbSettings = {
      ga_measurement_id: 'G-ABCD123456',
      gsc_verification_token: 'verify-token-xyz',
      adsense_publisher_id: 'ca-pub-1234567890123456',
      integration_enabled_adsense: 'false',
    };

    const flags = getPublicIntegrationFlags(dbSettings, minimalEnv);
    expect(flags.gaEnabled).toBe(true);
    expect(flags.gscEnabled).toBe(true);
    expect(flags.adsenseEnabled).toBe(false);

    const report = getAdminIntegrationsReport(dbSettings, minimalEnv);
    const byEnv = Object.fromEntries(report.map((r) => [r.envVar, r]));
    expect(byEnv.GA_MEASUREMENT_ID.status).toBe('Connected');
    expect(byEnv.GSC_VERIFICATION_TOKEN.status).toBe('Connected');
    expect(byEnv.ADSENSE_PUBLISHER_ID.status).toBe('Disabled');
  });
});

describe('Media URL Classification & Format Validation', () => {

  it('builds supported MP4 quality presets (1080p, 720p, 480p, 360p) strictly without upscaling', () => {
    const hd720 = buildSupportedVideoFormatOptions({
      sourceHeight: 720,
      sourceWidth: 1280,
      codecLabel: 'H264',
      contentType: 'video/mp4',
      knownSourceBytes: 12_000_000,
      durationSec: 60,
    });
    expect(hd720.map((f) => f.height)).toEqual([720, 480, 360]);
    expect(hd720[0].formatId).toBe('mp4-source');
    expect(hd720[0].fileSizeBytes).toBe(12_000_000);

    const fhd1080 = buildSupportedVideoFormatOptions({
      sourceHeight: 1080,
      sourceWidth: 1920,
      codecLabel: 'H264',
      contentType: 'video/mp4',
      knownSourceBytes: 30_000_000,
      durationSec: 60,
    });
    expect(fhd1080.map((f) => f.height)).toEqual([1080, 720, 480, 360]);

    const sd480Webm = buildSupportedVideoFormatOptions({
      sourceHeight: 480,
      sourceWidth: 854,
      codecLabel: 'VP9',
      contentType: 'video/webm',
      knownSourceBytes: 5_000_000,
      durationSec: 30,
    });
    expect(sd480Webm.map((f) => f.height)).toEqual([480, 360]);
    expect(sd480Webm[0].formatId).toBe('mp4-480');
  });

  it('classifies YouTube, social platforms, and direct MP4/WEBM/MOV/MP3/WAV URLs accurately', () => {
    expect(classifyMediaUrl('https://www.youtube.com/watch?v=dQw4w9WgXcQ').sourceType).toBe('youtube-watch');
    expect(classifyMediaUrl('https://youtu.be/aqz-KE-bpKQ').sourceType).toBe('youtube-short');
    expect(classifyMediaUrl('https://www.instagram.com/reel/C_example123/').sourceType).toBe('instagram');
    expect(classifyMediaUrl('https://www.pinterest.com/pin/99360735500167749/').sourceType).toBe('pinterest');
    expect(classifyMediaUrl('https://www.tiktok.com/@scout2015/video/6718335390845095173').sourceType).toBe('tiktok');
    expect(classifyMediaUrl('https://www.facebook.com/facebook/videos/10153231379946729/').sourceType).toBe('facebook');

    const mp4 = classifyMediaUrl('https://cdn.example.com/clips/sample.mp4?dl=1');
    expect(mp4.sourceType).toBe('direct-mp4');
    expect(mp4.downloadable).toBe(true);

    expect(classifyMediaUrl('https://cdn.example.com/clips/sample.webm').sourceType).toBe('direct-webm');
    expect(classifyMediaUrl('https://cdn.example.com/clips/sample.mov').sourceType).toBe('direct-mov');
    expect(classifyMediaUrl('https://cdn.example.com/audio/track.mp3').sourceType).toBe('direct-mp3');
    expect(classifyMediaUrl('https://cdn.example.com/audio/track.wav').sourceType).toBe('direct-wav');
  });

  it('validates binary media file headers and rejects disguised HTML/text files', () => {
    const htmlFake = Buffer.from('<!DOCTYPE html><html><body>fake</body></html>', 'utf8');
    expect(validateMediaSignature(htmlFake, '.mp4').valid).toBe(false);

    const mp4Ftyp = Buffer.from([0x00, 0x00, 0x00, 0x18, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6f, 0x6d]);
    expect(validateMediaSignature(mp4Ftyp, '.mp4').valid).toBe(true);
    expect(validateMediaSignature(mp4Ftyp, '.mov').valid).toBe(true);

    const webmEbml = Buffer.from([0x1a, 0x45, 0xdf, 0xa3, 0x9f, 0x42, 0x86, 0x81]);
    expect(validateMediaSignature(webmEbml, '.webm').valid).toBe(true);
    expect(validateMediaSignature(htmlFake, '.webm').valid).toBe(false);

    const mp3Id3 = Buffer.from([0x49, 0x44, 0x33, 0x04, 0x00, 0x00, 0x00, 0x00]);
    expect(validateMediaSignature(mp3Id3, '.mp3').valid).toBe(true);

    const wavRiff = Buffer.from('RIFF\x24\x00\x00\x00WAVEfmt ', 'ascii');
    expect(validateMediaSignature(wavRiff, '.wav').valid).toBe(true);
    expect(validateMediaSignature(mp3Id3, '.wav').valid).toBe(false);
  });

  it('normalizes URLs cleanly across international Pinterest domains and Facebook Reels via detectAndNormalizeUrl', () => {
    const ukPin = detectAndNormalizeUrl('https://www.pinterest.co.uk/pin/99360735500167749/');
    expect(ukPin.valid).toBe(true);
    expect(ukPin.platform).toBe('pinterest');
    expect(ukPin.entityId).toBe('99360735500167749');
    expect(ukPin.normalizedUrl).toBe('https://www.pinterest.com/pin/99360735500167749/');

    const fbReel = detectAndNormalizeUrl('https://www.facebook.com/reel/123456789012345/');
    expect(fbReel.valid).toBe(true);
    expect(fbReel.platform).toBe('facebook');
    expect(fbReel.entityType).toBe('video');
    expect(fbReel.entityId).toBe('123456789012345');

    const blocked = detectAndNormalizeUrl('http://127.0.0.1:8080/video.mp4');
    expect(blocked.valid).toBe(false);
    expect(blocked.ssrfSafe).toBe(false);
  });
});

describe('AI Scriptwriting Studio Helpers & Catalog', () => {
  it('registers ai-video-scriptwriting-studio cleanly and limits models to free-tier defaults', () => {
    const studio = TOOLS_CATALOG.find((t) => t.slug === 'ai-video-scriptwriting-studio');
    expect(studio).toBeDefined();
    expect(studio?.routePath).toBe('/ai-scriptwriting-studio');
    expect(studio?.mode).toBe('scriptwriting-studio');
    expect(ALLOWED_SCRIPT_MODELS.map((m) => m.id)).toEqual([
      'gemini-4-hydrogen',
      'gemini-3.1-flash-lite',
    ]);
  });

  it('strips production tags cleanly before counting spoken words and formatting duration', () => {
    const script = `[VISUAL: Close-up on messy desk]
[PAUSE: 1 second]
Most people think procrastination happens because they are lazy.
[B-ROLL: Student staring at blank screen]
Actually, it is usually emotional friction.`;

    const spokenOnly = stripProductionNotes(script);
    expect(spokenOnly).not.toContain('[VISUAL');
    expect(spokenOnly).not.toContain('[PAUSE');
    expect(spokenOnly).not.toContain('[B-ROLL');
    expect(countSpokenWords(script)).toBe(15);

    const dur = formatDurationFromWords(280, 140);
    expect(dur.minutes).toBe(2);
    expect(dur.formatted).toBe('2m 00s');
  });

  it('computes word budget accurately across duration, words, and character priority modes', () => {
    const settings = createDefaultScriptSettings();
    settings.narrationSpeedWpm = 150;
    settings.targetDurationMinutes = 10;
    settings.constraintPriority = 'duration';
    expect(computeTargetWordCount(settings)).toBe(1500);

    settings.constraintPriority = 'words';
    settings.targetWordCount = 950;
    expect(computeTargetWordCount(settings)).toBe(950);

    settings.constraintPriority = 'characters';
    settings.targetCharacterCount = 5500;
    expect(computeTargetWordCount(settings)).toBe(1000);
  });

  it('initializes all 7 stages unapproved in sequential state', () => {
    const state = createInitialScriptState();
    expect(state.stage1.approved).toBe(false);
    expect(state.stage2.approved).toBe(false);
    expect(state.stage3.approved).toBe(false);
    expect(state.stage4.approved).toBe(false);
    expect(state.stage5.approved).toBe(false);
    expect(state.stage6.approved).toBe(false);
    expect(state.stage7.approved).toBe(false);
    expect(state.needsReviewFromStage).toBeNull();
  });
});

describe('Safe API JSON Response Parser', () => {
  it('throws a clear non-JSON error when server returns HTML (e.g., SPA fallback)', async () => {
    const htmlRes = new Response('<!doctype html><html><body>SPA</body></html>', {
      status: 200,
      headers: { 'content-type': 'text/html; charset=utf-8' },
    });

    await expect(parseSafeJsonResponse(htmlRes)).rejects.toThrow(
      'API returned non-JSON response (200). Check API routing and backend deployment.'
    );
  });

  it('throws invalid JSON error when content-type is application/json but body is corrupted', async () => {
    const badJsonRes = new Response('{not valid json', {
      status: 500,
      headers: { 'content-type': 'application/json' },
    });

    await expect(parseSafeJsonResponse(badJsonRes)).rejects.toThrow(
      'The API returned invalid JSON.'
    );
  });

  it('throws ApiClientError with structured code and message when ok is false', async () => {
    const errRes = new Response(
      JSON.stringify({
        ok: false,
        error: {
          code: 'API_NOT_FOUND',
          message: 'The requested API endpoint does not exist.',
        },
      }),
      {
        status: 404,
        headers: { 'content-type': 'application/json' },
      }
    );

    try {
      await parseSafeJsonResponse(errRes);
      expect.unreachable('Should have thrown ApiClientError');
    } catch (err) {
      expect(err).toBeInstanceOf(ApiClientError);
      const apiErr = err as ApiClientError;
      expect(apiErr.code).toBe('API_NOT_FOUND');
      expect(apiErr.status).toBe(404);
      expect(apiErr.message).toBe('The requested API endpoint does not exist.');
    }
  });

  it('classifies non-JSON 404, 401, 403, and 503 responses cleanly without exposing raw HTML', async () => {
    const res404 = new Response('<html>404</html>', {
      status: 404,
      headers: { 'content-type': 'text/html' },
    });
    await expect(parseSafeJsonResponse(res404)).rejects.toThrow('API endpoint not found (404)');

    const res401 = new Response('<html>401</html>', {
      status: 401,
      headers: { 'content-type': 'text/html' },
    });
    await expect(parseSafeJsonResponse(res401)).rejects.toThrow('User authentication required (401)');

    const res403 = new Response('<html>403</html>', {
      status: 403,
      headers: { 'content-type': 'text/html' },
    });
    await expect(parseSafeJsonResponse(res403)).rejects.toThrow('Permission denied (403)');

    const res503 = new Response('<html>503</html>', {
      status: 503,
      headers: { 'content-type': 'text/html' },
    });
    await expect(parseSafeJsonResponse(res503)).rejects.toThrow('Backend unavailable (503)');
  });

  it('resolves parsed payload when response is ok and valid JSON', async () => {
    const okRes = new Response(JSON.stringify({ ok: true, project: { projectKey: 'sp_123' } }), {
      status: 200,
      headers: { 'content-type': 'application/json; charset=utf-8' },
    });

    const data = await parseSafeJsonResponse<{ ok: boolean; project: { projectKey: string } }>(okRes);
    expect(data.ok).toBe(true);
    expect(data.project.projectKey).toBe('sp_123');
  });

  it('detects reverse-proxy 200 HTML warmup pages with a clear retryable message', async () => {
    const warmupRes = new Response('<!doctype html><html><head><title>Starting Server...</title></head><body>Warming up</body></html>', {
      status: 200,
      headers: { 'content-type': 'text/html' },
    });
    await expect(parseSafeJsonResponse(warmupRes)).rejects.toThrow(
      'The backend server is warming up or an upstream AI request was interrupted'
    );
  });

  it('unwraps raw Gemini JSON overload error payloads into readable text and flags transient overload', () => {
    const rawJsonErr = new Error(
      '{"error":{"code":503,"message":"This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.","status":"UNAVAILABLE"}}'
    );
    const readable = extractReadableAiErrorMessage(rawJsonErr);
    expect(readable).toBe(
      'This model is currently experiencing high demand. Spikes in demand are usually temporary. Please try again later.'
    );
    expect(isTransientModelOverloadError(readable.toLowerCase())).toBe(true);
    expect(isTransientModelOverloadError('api_key_invalid')).toBe(false);
  });
});

describe('YouTube Competitor Intelligence Helpers & Math', () => {
  it('registers youtube-competitor-intelligence cleanly in TOOLS_CATALOG', () => {
    const ci = TOOLS_CATALOG.find((t) => t.slug === 'youtube-competitor-intelligence');
    expect(ci).toBeDefined();
    expect(ci?.routePath).toBe('/youtube-competitor-intelligence');
    expect(ci?.mode).toBe('competitor-intelligence');
    expect(ci?.platformSlug).toBe('youtube');
  });

  it('parses channel URLs, @handles, /c/, /user/, bare UC IDs, and search queries cleanly', () => {
    expect(parseYouTubeChannelInput('https://www.youtube.com/@mkbhd')).toEqual({
      kind: 'handle',
      value: '@mkbhd',
    });
    expect(parseYouTubeChannelInput('https://youtube.com/channel/UCBJycsmduvYEL83R_U4JriQ')).toEqual({
      kind: 'channelId',
      value: 'UCBJycsmduvYEL83R_U4JriQ',
    });
    expect(parseYouTubeChannelInput('UCBJycsmduvYEL83R_U4JriQ')).toEqual({
      kind: 'channelId',
      value: 'UCBJycsmduvYEL83R_U4JriQ',
    });
    expect(parseYouTubeChannelInput('@veritasium')).toEqual({
      kind: 'handle',
      value: '@veritasium',
    });
    expect(parseYouTubeChannelInput('https://www.youtube.com/c/Kurzgesagt')).toEqual({
      kind: 'custom',
      value: 'Kurzgesagt',
    });
    expect(parseYouTubeChannelInput('https://www.youtube.com/user/LinusTechTips')).toEqual({
      kind: 'username',
      value: 'LinusTechTips',
    });
    expect(parseYouTubeChannelInput('Ali Abdaal')).toEqual({
      kind: 'search',
      value: 'Ali Abdaal',
    });
  });

  it('parses ISO 8601 YouTube video durations accurately', () => {
    expect(parseIso8601DurationToSeconds('PT45S')).toBe(45);
    expect(parseIso8601DurationToSeconds('PT12M30S')).toBe(750);
    expect(parseIso8601DurationToSeconds('PT1H5M2S')).toBe(3902);
    expect(parseIso8601DurationToSeconds(null)).toBeNull();
    expect(formatSecondsAsClock(750)).toBe('12:30');
    expect(formatSecondsAsClock(3902)).toBe('1:05:02');
    expect(formatSecondsAsClock(null)).toBe('Not available');
  });

  it('computes median views, format-aware outlier ratios, and classifications honestly', () => {
    expect(computeMedian([10, 50, 20])).toBe(20);
    expect(computeMedian([10, 20, 40, 100])).toBe(30);
    expect(computeMedian([])).toBeNull();

    expect(classifyOutlierRatio(3.5)).toBe('Exceptional outlier');
    expect(classifyOutlierRatio(1.9)).toBe('Strong outlier');
    expect(classifyOutlierRatio(1.0)).toBe('Typical performer');
    expect(classifyOutlierRatio(0.4)).toBe('Below typical performance');
    expect(classifyOutlierRatio(null)).toBe('Unavailable');

    const { videos, metrics } = computeOutliersAndChannelMetrics(
      [
        {
          videoId: 'vid00000001',
          channelId: 'UC123',
          channelTitle: 'Test Channel',
          title: 'How 5 Habits Changed Everything?',
          description: 'Long video 1',
          publishedAt: '2026-01-01T00:00:00Z',
          durationSeconds: 600,
          thumbnailUrl: null,
          viewCount: 100_000,
          likeCount: 5000,
          commentCount: 200,
          tags: ['habits'],
        },
        {
          videoId: 'vid00000002',
          channelId: 'UC123',
          channelTitle: 'Test Channel',
          title: 'Why Focus Fails',
          description: 'Long video 2',
          publishedAt: '2026-01-15T00:00:00Z',
          durationSeconds: 720,
          thumbnailUrl: null,
          viewCount: 120_000,
          likeCount: null,
          commentCount: null,
          tags: [],
        },
        {
          videoId: 'vid00000003',
          channelId: 'UC123',
          channelTitle: 'Test Channel',
          title: 'Deep Work System Explained',
          description: 'Long video 3 viral hit',
          publishedAt: '2026-02-01T00:00:00Z',
          durationSeconds: 900,
          thumbnailUrl: null,
          viewCount: 480_000,
          likeCount: 20_000,
          commentCount: 800,
          tags: [],
        },
        {
          videoId: 'vid00000004',
          channelId: 'UC123',
          channelTitle: 'Test Channel',
          title: 'Quick Tip #shorts',
          description: '',
          publishedAt: '2026-02-10T00:00:00Z',
          durationSeconds: 42,
          thumbnailUrl: null,
          viewCount: 25_000,
          likeCount: null,
          commentCount: null,
          tags: [],
        },
      ],
      '2026-02-15T00:00:00Z'
    );

    expect(metrics.sampleSize).toBe(4);
    expect(metrics.longFormCount).toBe(3);
    expect(metrics.shortsCount).toBe(1);
    expect(metrics.medianViewsLongForm).toBe(120_000);
    expect(metrics.titleQuestionPercent).toBe(25);
    expect(metrics.titleNumberPercent).toBe(25);

    const viral = videos.find((v) => v.videoId === 'vid00000003')!;
    expect(viral.outlierRatio).toBe(4);
    expect(viral.outlierClassification).toBe('Exceptional outlier');
    expect(formatCompactNumber(null)).toBe('Not publicly available');
    expect(formatCompactNumber(1_250_000)).toBe('1.25M');
  });
});

describe('Warmup Auto-Retry & AI Model Fallback Hardening', () => {
  it('retries reverse-proxy warmup HTML responses automatically and returns JSON once ready', async () => {
    let calls = 0;
    const mockFetch = (async () => {
      calls += 1;
      if (calls === 1) {
        return new Response('<!doctype html><html><title>Starting Server...</title></html>', {
          status: 200,
          headers: { 'content-type': 'text/html; charset=utf-8' },
        });
      }
      return new Response(JSON.stringify({ ok: true, status: 'ready' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      });
    }) as unknown as typeof fetch;

    const res = await fetchWithWarmupRetry('/api/v1/health', undefined, {
      maxRetries: 2,
      retryDelaysMs: [5, 5],
      fetchImpl: mockFetch,
    });
    const parsed = await parseSafeJsonResponse<{ ok: boolean; status: string }>(res);
    expect(calls).toBe(2);
    expect(parsed.ok).toBe(true);
    expect(parsed.status).toBe('ready');
  });

  it('does not retry normal JSON error responses (e.g. 401 or 500)', async () => {
    let calls = 0;
    const mockFetch = (async () => {
      calls += 1;
      return new Response(JSON.stringify({ ok: false, error: { code: 'AUTH_REQUIRED', message: 'Sign in' } }), {
        status: 401,
        headers: { 'content-type': 'application/json' },
      });
    }) as unknown as typeof fetch;

    const res = await fetchWithWarmupRetry('/api/v1/ytm/workspace', undefined, {
      maxRetries: 2,
      retryDelaysMs: [5, 5],
      fetchImpl: mockFetch,
    });
    expect(calls).toBe(1);
    expect(res.status).toBe(401);
  });

  it('configures ThinkingLevel.LOW on gemini-4-hydrogen and short-circuits to flash-lite during cooldown', () => {
    const hydrogenCfg = buildModelThinkingConfig('gemini-4-hydrogen');
    expect(hydrogenCfg.thinkingConfig?.thinkingLevel).toBe('LOW');
    expect(buildModelThinkingConfig('gemini-3.1-flash-lite')).toEqual({});

    markHydrogenTemporarilyUnavailable(60_000);
    expect(getOrderedModelCandidates('gemini-4-hydrogen')[0]).toBe('gemini-3.1-flash-lite');
  });
});
