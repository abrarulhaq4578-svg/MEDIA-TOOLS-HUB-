import 'dotenv/config';
import { execFile, spawn } from 'node:child_process';
import crypto from 'node:crypto';
import dns from 'node:dns/promises';
import fsSync from 'node:fs';
import fs from 'node:fs/promises';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import cors from 'cors';
import express from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import multer from 'multer';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
const PORT = Number.parseInt(process.env.PORT || '4000', 10);
const MAX_UPLOAD_MB = Math.min(500, Math.max(1, Number.parseInt(process.env.MAX_UPLOAD_MB || '100', 10)));
const MAX_UPLOAD_BYTES = MAX_UPLOAD_MB * 1024 * 1024;
const JOB_TTL_MINUTES = Math.min(240, Math.max(1, Number.parseInt(process.env.JOB_TTL_MINUTES || '30', 10)));
const FFMPEG_TIMEOUT_MS = Number.parseInt(process.env.FFMPEG_TIMEOUT_MS || '120000', 10);
const MAX_INSPECT_BYTES = Number.parseInt(process.env.MAX_INSPECT_BYTES || String(2 * 1024 * 1024), 10);
const ADMIN_CLEANUP_KEY = (process.env.ADMIN_CLEANUP_KEY || '').trim();

const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);

const ALLOWED_MEDIA_DOMAINS = (process.env.ALLOWED_MEDIA_DOMAINS || '')
  .split(',')
  .map((d) => d.trim().toLowerCase())
  .filter(Boolean);

const MEDIA_JOBS_ROOT = process.env.MEDIA_TEMP_DIR
  ? path.resolve(process.env.MEDIA_TEMP_DIR)
  : path.join(os.tmpdir(), 'mediatoolshub-media-backend');
const UPLOAD_STAGING_DIR = path.join(MEDIA_JOBS_ROOT, '_incoming');

fsSync.mkdirSync(UPLOAD_STAGING_DIR, { recursive: true });

// ---------------------------------------------------------------------------
// Constants & Presets
// ---------------------------------------------------------------------------
const ALLOWED_MEDIA_EXTENSIONS = new Set([
  '.mp4',
  '.m4v',
  '.webm',
  '.mov',
  '.mp3',
  '.wav',
  '.m4a',
]);

const ALLOWED_MEDIA_MIME_TYPES = new Set([
  'video/mp4',
  'video/x-m4v',
  'video/webm',
  'video/quicktime',
  'audio/mpeg',
  'audio/mp3',
  'audio/wav',
  'audio/x-wav',
  'audio/wave',
  'audio/vnd.wave',
  'audio/mp4',
  'audio/x-m4a',
  'audio/aac',
  'application/octet-stream',
]);

const VIDEO_PRESETS = [
  { formatId: 'mp4-1080', height: 1080, width: 1920, label: 'MP4 1080p Full HD', targetBitrateKbps: 3800 },
  { formatId: 'mp4-720', height: 720, width: 1280, label: 'MP4 720p HD', targetBitrateKbps: 2200 },
  { formatId: 'mp4-480', height: 480, width: 854, label: 'MP4 480p SD', targetBitrateKbps: 1100 },
  { formatId: 'mp4-360', height: 360, width: 640, label: 'MP4 360p', targetBitrateKbps: 650 },
];

const AUDIO_PRESETS = [
  { formatId: 'mp3-320', bitrateKbps: 320, label: 'MP3 320 kbps' },
  { formatId: 'mp3-192', bitrateKbps: 192, label: 'MP3 192 kbps' },
  { formatId: 'mp3-128', bitrateKbps: 128, label: 'MP3 128 kbps' },
];

const ALLOWED_FORMAT_IDS = new Set([
  'mp4-source',
  ...VIDEO_PRESETS.map((v) => v.formatId),
  ...AUDIO_PRESETS.map((a) => a.formatId),
]);

// ---------------------------------------------------------------------------
// SSRF & Network Security Guard
// ---------------------------------------------------------------------------
const BLOCKED_HOSTNAMES = new Set([
  'localhost',
  '127.0.0.1',
  '0.0.0.0',
  '::1',
  'metadata.google.internal',
  'metadata',
  '169.254.169.254',
]);

function ipv4ToInt(ip) {
  return ip.split('.').reduce((acc, part) => (acc << 8) + Number.parseInt(part, 10), 0) >>> 0;
}

function inCidr(ipInt, baseIp, prefix) {
  const mask = prefix === 0 ? 0 : (~0 << (32 - prefix)) >>> 0;
  return (ipInt & mask) === (ipv4ToInt(baseIp) & mask);
}

function isPrivateOrReservedIp(ip) {
  const trimmed = ip.trim().toLowerCase();
  if (trimmed.startsWith('::ffff:')) {
    return isPrivateOrReservedIp(trimmed.slice(7));
  }
  const version = net.isIP(trimmed);
  if (version === 4) {
    const n = ipv4ToInt(trimmed);
    return (
      inCidr(n, '0.0.0.0', 8) ||
      inCidr(n, '10.0.0.0', 8) ||
      inCidr(n, '100.64.0.0', 10) ||
      inCidr(n, '127.0.0.0', 8) ||
      inCidr(n, '169.254.0.0', 16) ||
      inCidr(n, '172.16.0.0', 12) ||
      inCidr(n, '192.0.0.0', 24) ||
      inCidr(n, '192.168.0.0', 16) ||
      inCidr(n, '198.18.0.0', 15) ||
      inCidr(n, '224.0.0.0', 4) ||
      inCidr(n, '240.0.0.0', 4)
    );
  }
  if (version === 6) {
    return (
      trimmed === '::' ||
      trimmed === '::1' ||
      trimmed.startsWith('fc') ||
      trimmed.startsWith('fd') ||
      trimmed.startsWith('fe8') ||
      trimmed.startsWith('fe9') ||
      trimmed.startsWith('fea') ||
      trimmed.startsWith('feb') ||
      trimmed.startsWith('ff')
    );
  }
  return true;
}

function validateUrlSyntax(rawUrl) {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return { safe: false, reason: 'Please provide a media URL.' };
  }
  let parsed;
  try {
    parsed = new URL(rawUrl.trim());
  } catch {
    return { safe: false, reason: 'Invalid URL format. Include https:// or http://.' };
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return { safe: false, reason: 'Only HTTP and HTTPS protocols are supported.' };
  }
  if (parsed.username || parsed.password) {
    return { safe: false, reason: 'Embedded URL credentials are not permitted.' };
  }
  const host = parsed.hostname.toLowerCase();
  if (!host || BLOCKED_HOSTNAMES.has(host) || host.endsWith('.local') || host.endsWith('.internal')) {
    return { safe: false, reason: 'Internal or loopback hostnames are blocked.' };
  }
  if (net.isIP(host) && isPrivateOrReservedIp(host)) {
    return { safe: false, reason: 'Private or reserved IP targets are blocked.' };
  }
  if (ALLOWED_MEDIA_DOMAINS.length > 0) {
    const allowed = ALLOWED_MEDIA_DOMAINS.some((d) => host === d || host.endsWith(`.${d}`));
    if (!allowed) {
      return { safe: false, reason: `Domain "${host}" is not in ALLOWED_MEDIA_DOMAINS.` };
    }
  }
  return { safe: true, parsed };
}

async function assertPublicHost(hostname) {
  const host = hostname.toLowerCase();
  if (net.isIP(host)) {
    if (isPrivateOrReservedIp(host)) {
      throw new Error('Blocked private IP target.');
    }
    return;
  }
  const records = await dns.lookup(host, { all: true });
  if (!records || records.length === 0) {
    throw new Error('Unable to resolve target media hostname.');
  }
  for (const rec of records) {
    if (isPrivateOrReservedIp(rec.address)) {
      throw new Error('Target domain resolves to a private or reserved IP address.');
    }
  }
}

async function safeFetch(rawUrl, options = {}) {
  const timeoutMs = options.timeoutMs || 25000;
  let currentUrl = rawUrl;

  for (let hop = 0; hop <= 3; hop++) {
    const check = validateUrlSyntax(currentUrl);
    if (!check.safe) {
      throw new Error(check.reason || 'Unsafe URL rejected.');
    }
    await assertPublicHost(check.parsed.hostname);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let res;
    try {
      res = await fetch(currentUrl, {
        method: options.method || 'GET',
        signal: controller.signal,
        redirect: 'manual',
        headers: {
          'User-Agent': 'MediaToolsHub-MediaBackend/1.0',
          ...(options.headers || {}),
        },
      });
    } finally {
      clearTimeout(timer);
    }

    if (res.status >= 300 && res.status < 400) {
      const location = res.headers.get('location');
      if (!location) {
        throw new Error('Redirect response missing target Location header.');
      }
      currentUrl = new URL(location, currentUrl).toString();
      continue;
    }

    return res;
  }

  throw new Error('Too many HTTP redirects while accessing media source.');
}

// ---------------------------------------------------------------------------
// Platform & Direct Media URL Classifier (Zero yt-dlp, Zero Bypass)
// ---------------------------------------------------------------------------
function extractYouTubeVideoId(parsed) {
  const host = parsed.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '');
  if (host === 'youtu.be') {
    const seg = parsed.pathname.split('/').filter(Boolean)[0];
    return seg && /^[A-Za-z0-9_-]{11}$/.test(seg) ? seg : null;
  }
  if (host === 'youtube.com' || host === 'music.youtube.com' || host === 'youtube-nocookie.com') {
    const v = parsed.searchParams.get('v');
    if (v && /^[A-Za-z0-9_-]{11}$/.test(v)) return v;
    const parts = parsed.pathname.split('/').filter(Boolean);
    if (parts.length >= 2 && ['shorts', 'embed', 'live', 'v'].includes(parts[0])) {
      return /^[A-Za-z0-9_-]{11}$/.test(parts[1]) ? parts[1] : null;
    }
  }
  return null;
}

function classifyMediaUrl(rawUrl) {
  const check = validateUrlSyntax(rawUrl);
  if (!check.safe) {
    return { valid: false, reason: check.reason };
  }

  const parsed = check.parsed;
  const host = parsed.hostname.toLowerCase().replace(/^www\./, '').replace(/^m\./, '');
  const pathname = parsed.pathname.toLowerCase();

  // YouTube (strictly non-downloadable via external scraping)
  if (
    host === 'youtube.com' ||
    host === 'youtu.be' ||
    host === 'music.youtube.com' ||
    host === 'youtube-nocookie.com'
  ) {
    const videoId = extractYouTubeVideoId(parsed);
    const isShort = host === 'youtu.be' || pathname.startsWith('/shorts/');
    return {
      valid: true,
      platform: 'youtube',
      sourceType: isShort ? 'youtube-short' : 'youtube-watch',
      canonicalUrl: videoId ? `https://www.youtube.com/watch?v=${videoId}` : parsed.toString(),
      officialStudioUrl: videoId
        ? `https://studio.youtube.com/video/${videoId}/edit`
        : 'https://studio.youtube.com/',
      officialTakeoutUrl: 'https://takeout.google.com/',
      downloadable: false,
      complianceNotice:
        'Direct YouTube stream downloading is not supported. Watch on YouTube, export your own uploaded video via YouTube Studio or Google Takeout, or upload an authorized file for FFmpeg conversion.',
    };
  }

  // Restricted social platforms (strictly no stream scraping)
  const restrictedPlatforms = [
    { hosts: ['instagram.com', 'instagr.am'], name: 'instagram' },
    { hosts: ['pinterest.com', 'pin.it'], name: 'pinterest' },
    { hosts: ['tiktok.com', 'vt.tiktok.com', 'vm.tiktok.com'], name: 'tiktok' },
    { hosts: ['facebook.com', 'fb.watch', 'fb.com'], name: 'facebook' },
    { hosts: ['twitter.com', 'x.com'], name: 'twitter' },
  ];

  for (const rp of restrictedPlatforms) {
    if (rp.hosts.some((h) => host === h || host.endsWith(`.${h}`))) {
      return {
        valid: true,
        platform: rp.name,
        sourceType: rp.name,
        canonicalUrl: parsed.toString(),
        downloadable: false,
        complianceNotice: `Direct stream downloading from ${rp.name} links is restricted. Upload a file you own or are authorized to convert instead.`,
      };
    }
  }

  // Authorized direct media file URLs
  const extMap = [
    { ext: '.mp4', type: 'direct-mp4' },
    { ext: '.m4v', type: 'direct-mp4' },
    { ext: '.webm', type: 'direct-webm' },
    { ext: '.mov', type: 'direct-mov' },
    { ext: '.mp3', type: 'direct-mp3' },
    { ext: '.wav', type: 'direct-wav' },
    { ext: '.m4a', type: 'direct-m4a' },
  ];

  for (const item of extMap) {
    if (pathname.endsWith(item.ext)) {
      return {
        valid: true,
        platform: 'general',
        sourceType: item.type,
        canonicalUrl: parsed.toString(),
        downloadable: true,
        extHint: item.ext,
      };
    }
  }

  return {
    valid: true,
    platform: 'general',
    sourceType: 'webpage',
    canonicalUrl: parsed.toString(),
    downloadable: false,
    complianceNotice:
      'Target URL does not appear to be a direct .mp4, .webm, .mov, .mp3, .wav, or .m4a media file. Paste a direct media file URL or upload a local file.',
  };
}

// ---------------------------------------------------------------------------
// Binary Signature Validation & FFprobe / FFmpeg Engine
// ---------------------------------------------------------------------------
function validateMediaSignature(header, ext) {
  if (!header || header.byteLength < 8) {
    return { valid: false, reason: 'File is too small or corrupted to be a valid media stream.' };
  }

  const normalizedExt = ext.toLowerCase();
  const asciiPrefix = header.subarray(0, Math.min(header.byteLength, 32)).toString('utf8').trimStart().toLowerCase();
  if (asciiPrefix.startsWith('<!doctype') || asciiPrefix.startsWith('<html') || asciiPrefix.startsWith('<?xml')) {
    return { valid: false, reason: 'HTML/XML document rejected: expected a binary video or audio stream.' };
  }

  if (['.mp4', '.m4v', '.mov', '.m4a'].includes(normalizedExt)) {
    const boxType = header.subarray(4, 8).toString('ascii');
    if (['ftyp', 'moov', 'mdat', 'wide', 'free'].includes(boxType) || header.includes(Buffer.from('ftyp', 'ascii'))) {
      return { valid: true };
    }
    return { valid: false, reason: `Invalid ${normalizedExt.toUpperCase()} binary signature.` };
  }

  if (normalizedExt === '.webm') {
    if (header[0] === 0x1a && header[1] === 0x45 && header[2] === 0xdf && header[3] === 0xa3) {
      return { valid: true };
    }
    return { valid: false, reason: 'Invalid WEBM binary signature (missing EBML header).' };
  }

  if (normalizedExt === '.mp3') {
    const isId3 = header[0] === 0x49 && header[1] === 0x44 && header[2] === 0x33;
    const isMpegFrame = header[0] === 0xff && (header[1] & 0xe0) === 0xe0;
    if (isId3 || isMpegFrame) {
      return { valid: true };
    }
    return { valid: false, reason: 'Invalid MP3 binary signature (missing ID3 or MPEG sync header).' };
  }

  if (normalizedExt === '.wav') {
    const isRiff = header.subarray(0, 4).toString('ascii') === 'RIFF';
    const isWave = header.byteLength >= 12 && header.subarray(8, 12).toString('ascii') === 'WAVE';
    if (isRiff && isWave) {
      return { valid: true };
    }
    return { valid: false, reason: 'Invalid WAV binary signature (missing RIFF/WAVE header).' };
  }

  return { valid: false, reason: 'Unsupported media file extension.' };
}

function normalizeFileFormat(ffprobeFormatName, extHint) {
  const hint = extHint ? extHint.replace('.', '').toUpperCase() : '';
  if (['MP4', 'M4V', 'WEBM', 'MOV', 'MP3', 'WAV', 'M4A'].includes(hint)) {
    return hint === 'M4V' ? 'MP4' : hint;
  }
  const lower = (ffprobeFormatName || '').toLowerCase();
  if (lower.includes('webm')) return 'WEBM';
  if (lower.includes('mp3')) return 'MP3';
  if (lower.includes('wav')) return 'WAV';
  if (lower.includes('mov')) return 'MOV';
  if (lower.includes('mp4')) return 'MP4';
  return lower.toUpperCase() || 'UNKNOWN';
}

function parseFrameRate(rawRate) {
  if (!rawRate || rawRate === '0/0') return null;
  const parts = rawRate.split('/');
  if (parts.length === 2) {
    const num = Number.parseFloat(parts[0]);
    const den = Number.parseFloat(parts[1]);
    if (Number.isFinite(num) && Number.isFinite(den) && den > 0 && num > 0) {
      const fps = num / den;
      return `${Number.isInteger(fps) ? fps : fps.toFixed(2)} fps`;
    }
  }
  const single = Number.parseFloat(rawRate);
  if (Number.isFinite(single) && single > 0) {
    return `${Number.isInteger(single) ? single : single.toFixed(2)} fps`;
  }
  return null;
}

async function inspectWithFfprobe(filePath, knownSizeBytes, extHint) {
  const st = await fs.stat(filePath).catch(() => null);
  const fileSizeBytes = knownSizeBytes ?? st?.size ?? null;

  const { stdout } = await execFileAsync(
    'ffprobe',
    ['-v', 'quiet', '-print_format', 'json', '-show_format', '-show_streams', filePath],
    { timeout: 12000 }
  );

  const parsed = JSON.parse(stdout);
  const videoStream = parsed.streams?.find((s) => s.codec_type === 'video');
  const audioStream = parsed.streams?.find((s) => s.codec_type === 'audio');

  if (!videoStream && !audioStream) {
    throw new Error('No playable video or audio streams found in media file.');
  }

  const rawDuration = parsed.format?.duration ? Number.parseFloat(parsed.format.duration) : NaN;
  const durationSec =
    Number.isFinite(rawDuration) && rawDuration > 0 ? Math.round(rawDuration * 100) / 100 : null;

  const rawBitrate = parsed.format?.bit_rate ? Number.parseInt(parsed.format.bit_rate, 10) : NaN;
  const bitrateKbps =
    Number.isFinite(rawBitrate) && rawBitrate > 0 ? Math.round(rawBitrate / 1000) : null;

  const width = typeof videoStream?.width === 'number' && videoStream.width > 0 ? videoStream.width : null;
  const height = typeof videoStream?.height === 'number' && videoStream.height > 0 ? videoStream.height : null;

  return {
    fileFormat: normalizeFileFormat(parsed.format?.format_name, extHint),
    containerLongName: parsed.format?.format_long_name || null,
    videoCodec: videoStream?.codec_name ? videoStream.codec_name.toUpperCase() : null,
    audioCodec: audioStream?.codec_name ? audioStream.codec_name.toUpperCase() : null,
    resolution: width && height ? `${width}×${height}` : null,
    width,
    height,
    durationSec,
    frameRate: parseFrameRate(videoStream?.avg_frame_rate || videoStream?.r_frame_rate),
    bitrateKbps,
    fileSizeBytes,
    hasVideo: Boolean(videoStream),
    hasAudio: Boolean(audioStream),
  };
}

function buildVideoFormatOptions({ sourceHeight, sourceWidth, codecLabel, contentType, knownSourceBytes, durationSec }) {
  const formats = [];
  if (sourceHeight && sourceHeight >= 360) {
    const exactMatch = VIDEO_PRESETS.some((p) => p.height === sourceHeight);
    if (!exactMatch) {
      formats.push({
        formatId: 'mp4-source',
        container: 'mp4',
        qualityLabel: `MP4 ${sourceHeight}p Original`,
        resolution: sourceWidth ? `${sourceWidth}×${sourceHeight}` : `${sourceHeight}p`,
        width: sourceWidth,
        height: sourceHeight,
        codec: codecLabel || 'H264',
        fileSizeBytes: knownSourceBytes,
        isEstimatedSize: !contentType.includes('mp4') && knownSourceBytes !== null,
      });
    }

    for (const preset of VIDEO_PRESETS) {
      if (sourceHeight >= preset.height) {
        const isExactMp4 = sourceHeight === preset.height && contentType.includes('mp4');
        const scaledWidth =
          2 * Math.round(((sourceWidth || preset.width) * (preset.height / sourceHeight)) / 2);
        const estimatedBytes =
          isExactMp4 && knownSourceBytes
            ? knownSourceBytes
            : durationSec
              ? Math.round((durationSec * preset.targetBitrateKbps * 1000) / 8)
              : null;

        formats.push({
          formatId: isExactMp4 ? 'mp4-source' : preset.formatId,
          container: 'mp4',
          qualityLabel: preset.label,
          resolution: `${scaledWidth}×${preset.height}`,
          width: scaledWidth,
          height: preset.height,
          codec: 'H264',
          fileSizeBytes: estimatedBytes,
          isEstimatedSize: !isExactMp4 && estimatedBytes !== null,
        });
      }
    }
  } else {
    formats.push({
      formatId: 'mp4-source',
      container: 'mp4',
      qualityLabel: sourceHeight ? `MP4 ${sourceHeight}p Source` : 'MP4 Original Quality',
      resolution: sourceWidth && sourceHeight ? `${sourceWidth}×${sourceHeight}` : 'Original',
      width: sourceWidth,
      height: sourceHeight,
      codec: codecLabel || 'H264',
      fileSizeBytes: knownSourceBytes,
      isEstimatedSize: false,
    });
  }
  return formats;
}

function buildAudioFormatOptions(inspection) {
  if (!inspection.hasAudio) return [];
  return AUDIO_PRESETS.map((tier) => {
    const estimatedBytes = inspection.durationSec
      ? Math.round((inspection.durationSec * tier.bitrateKbps * 1000) / 8)
      : null;
    return {
      formatId: tier.formatId,
      container: 'mp3',
      qualityLabel: tier.label,
      bitrateKbps: tier.bitrateKbps,
      fileSizeBytes: estimatedBytes,
      isEstimatedSize: estimatedBytes !== null,
    };
  });
}

async function readPrefixBytes(response, maxBytes) {
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        const buf = Buffer.from(value);
        chunks.push(buf);
        total += buf.byteLength;
        if (total >= maxBytes) {
          await reader.cancel();
          break;
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks).subarray(0, maxBytes);
}

async function readBoundedBytes(response, maxBytes) {
  if (!response.body) return Buffer.alloc(0);
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        const buf = Buffer.from(value);
        total += buf.byteLength;
        if (total > maxBytes) {
          await reader.cancel();
          throw new Error(`Remote file exceeds the configured ${MAX_UPLOAD_MB} MB limit.`);
        }
        chunks.push(buf);
      }
    }
  } finally {
    reader.releaseLock();
  }
  return Buffer.concat(chunks);
}

function getExtFromUrlOrContentType(urlStr, contentType) {
  try {
    const p = new URL(urlStr).pathname.toLowerCase();
    for (const ext of ALLOWED_MEDIA_EXTENSIONS) {
      if (p.endsWith(ext)) return ext;
    }
  } catch {
    // ignore URL parse error
  }
  if (contentType.includes('webm')) return '.webm';
  if (contentType.includes('quicktime')) return '.mov';
  if (contentType.includes('mpeg') || contentType.includes('mp3')) return '.mp3';
  if (contentType.includes('wav')) return '.wav';
  if (contentType.includes('m4a') || contentType.includes('audio/mp4')) return '.m4a';
  return '.mp4';
}

// ---------------------------------------------------------------------------
// Job Store, Progress Runner & Automatic Cleanup Engine
// ---------------------------------------------------------------------------
const jobStore = new Map();
let lastCleanupInfo = { at: null, removed: 0, freedBytes: 0 };

function toPublicJobRecord(job) {
  return {
    jobId: job.jobId,
    sourceKind: job.sourceKind,
    sourceLabel: job.sourceLabel,
    status: job.status,
    progressPct: job.progressPct,
    sourceFormat: job.inspection?.fileFormat || null,
    targetFormat: job.targetFormat,
    targetContainer: job.targetContainer,
    sourceSizeBytes: job.sourceSizeBytes,
    outputSizeBytes: job.outputSizeBytes,
    outputFilename: job.outputFilename,
    outputCodec: job.outputCodec,
    outputResolution: job.outputResolution,
    outputBitrateKbps: job.outputBitrateKbps,
    outputDurationSec: job.outputDurationSec,
    downloadUrl:
      job.status === 'Completed'
        ? `/api/v1/media/download/${job.jobId}?token=${job.downloadToken}`
        : null,
    errorMessage: job.errorMessage,
    expiresAt: new Date(job.expiresAtMs).toISOString(),
    createdAt: new Date(job.createdAtMs).toISOString(),
    updatedAt: new Date(job.updatedAtMs).toISOString(),
  };
}

function runFfmpegWithProgress({ args, durationSec, onProgress }) {
  return new Promise((resolve, reject) => {
    const child = spawn('ffmpeg', ['-progress', 'pipe:1', '-nostats', ...args], {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stderrTail = '';
    const timer = setTimeout(() => {
      child.kill('SIGKILL');
      reject(new Error(`FFmpeg conversion timed out after ${Math.round(FFMPEG_TIMEOUT_MS / 1000)}s.`));
    }, FFMPEG_TIMEOUT_MS);

    child.stdout.on('data', (chunk) => {
      const text = chunk.toString('utf8');
      for (const line of text.split('\n')) {
        if (line.startsWith('out_time_us=')) {
          const us = Number.parseInt(line.slice('out_time_us='.length), 10);
          if (Number.isFinite(us) && durationSec && durationSec > 0) {
            const pct = Math.min(96, Math.max(8, Math.round((us / (durationSec * 1_000_000)) * 100)));
            onProgress(pct);
          }
        } else if (line.trim() === 'progress=end') {
          onProgress(98);
        }
      }
    });

    child.stderr.on('data', (chunk) => {
      stderrTail = (stderrTail + chunk.toString('utf8')).slice(-1500);
    });

    child.on('error', (err) => {
      clearTimeout(timer);
      reject(err);
    });

    child.on('close', (code) => {
      clearTimeout(timer);
      if (code === 0) {
        resolve();
      } else {
        reject(new Error(`FFmpeg failed (exit ${code}): ${stderrTail.slice(-220).trim()}`));
      }
    });
  });
}

async function executeBackgroundConversion(job, formatId) {
  try {
    if (job.sourceKind === 'url' && job.sourceUrl) {
      job.status = 'Validating';
      job.progressPct = 5;
      job.updatedAtMs = Date.now();

      const upstream = await safeFetch(job.sourceUrl, { method: 'GET', timeoutMs: 30000 });
      if (!upstream.ok) {
        throw new Error(`Unable to fetch direct media URL (HTTP ${upstream.status}).`);
      }

      const contentType = (upstream.headers.get('content-type') || '').toLowerCase();
      const ext = getExtFromUrlOrContentType(job.sourceUrl, contentType);
      const sourceBytes = await readBoundedBytes(upstream, MAX_UPLOAD_BYTES);
      if (sourceBytes.byteLength === 0) {
        throw new Error('Remote media source returned an empty response.');
      }

      const sig = validateMediaSignature(sourceBytes.subarray(0, 64), ext);
      if (!sig.valid) {
        throw new Error(sig.reason || 'Remote resource failed binary signature validation.');
      }

      await fs.mkdir(job.jobDir, { recursive: true });
      const inputPath = path.join(job.jobDir, `input${ext}`);
      await fs.writeFile(inputPath, sourceBytes);
      job.inputPath = inputPath;
      job.inputExt = ext;
      job.sourceSizeBytes = sourceBytes.byteLength;
      job.inspection = await inspectWithFfprobe(inputPath, sourceBytes.byteLength, ext);
    }

    if (!job.inputPath || !job.inspection) {
      throw new Error('Input media file is missing or expired.');
    }

    const isAudioTarget = formatId.startsWith('mp3-');
    if (isAudioTarget && !job.inspection.hasAudio) {
      throw new Error('Cannot extract MP3 audio because this video has no audio track.');
    }
    if (!isAudioTarget && !job.inspection.hasVideo) {
      throw new Error('Cannot convert audio-only input into MP4 video.');
    }

    job.status = 'Processing';
    job.progressPct = 10;
    job.updatedAtMs = Date.now();

    const inputExt = job.inputExt || path.extname(job.inputPath).toLowerCase();

    if (isAudioTarget) {
      const tier = AUDIO_PRESETS.find((a) => a.formatId === formatId) || AUDIO_PRESETS[1];
      const outputFilename = `mediatoolshub-${tier.bitrateKbps}kbps-${job.jobId.slice(0, 8)}.mp3`;
      const outputPath = path.join(job.jobDir, outputFilename);

      await runFfmpegWithProgress({
        args: ['-y', '-i', job.inputPath, '-vn', '-codec:a', 'libmp3lame', '-b:a', `${tier.bitrateKbps}k`, outputPath],
        durationSec: job.inspection.durationSec,
        onProgress: (pct) => {
          job.progressPct = pct;
          job.updatedAtMs = Date.now();
        },
      });

      const outProbe = await inspectWithFfprobe(outputPath, null, '.mp3');
      job.outputPath = outputPath;
      job.outputFilename = outputFilename;
      job.outputContentType = 'audio/mpeg';
      job.targetContainer = 'mp3';
      job.outputSizeBytes = outProbe.fileSizeBytes;
      job.outputCodec = outProbe.audioCodec || 'MP3';
      job.outputResolution = null;
      job.outputBitrateKbps = tier.bitrateKbps;
      job.outputDurationSec = outProbe.durationSec;
      job.status = 'Completed';
      job.progressPct = 100;
      job.updatedAtMs = Date.now();
    } else {
      const videoPreset = VIDEO_PRESETS.find((v) => v.formatId === formatId);
      if (videoPreset && job.inspection.height && job.inspection.height < videoPreset.height) {
        throw new Error(
          `Requested ${videoPreset.height}p exceeds source resolution (${job.inspection.height}p). Upscaling is not permitted.`
        );
      }

      const tag = videoPreset ? `${videoPreset.height}p` : 'source';
      const outputFilename = `mediatoolshub-${tag}-${job.jobId.slice(0, 8)}.mp4`;
      const outputPath = path.join(job.jobDir, outputFilename);

      if (formatId === 'mp4-source' && inputExt === '.mp4') {
        await fs.copyFile(job.inputPath, outputPath);
        job.progressPct = 95;
      } else {
        const args = ['-y', '-i', job.inputPath];
        if (videoPreset) {
          args.push('-vf', `scale=-2:min(ih\\,${videoPreset.height})`);
        }
        args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p');
        if (job.inspection.hasAudio) {
          args.push('-c:a', 'aac', '-b:a', '128k');
        } else {
          args.push('-an');
        }
        args.push('-movflags', '+faststart', outputPath);

        await runFfmpegWithProgress({
          args,
          durationSec: job.inspection.durationSec,
          onProgress: (pct) => {
            job.progressPct = pct;
            job.updatedAtMs = Date.now();
          },
        });
      }

      const outProbe = await inspectWithFfprobe(outputPath, null, '.mp4');
      job.outputPath = outputPath;
      job.outputFilename = outputFilename;
      job.outputContentType = 'video/mp4';
      job.targetContainer = 'mp4';
      job.outputSizeBytes = outProbe.fileSizeBytes;
      job.outputCodec = outProbe.videoCodec || 'H264';
      job.outputResolution = outProbe.resolution;
      job.outputBitrateKbps = outProbe.bitrateKbps;
      job.outputDurationSec = outProbe.durationSec;
      job.status = 'Completed';
      job.progressPct = 100;
      job.updatedAtMs = Date.now();
    }
  } catch (err) {
    job.status = 'Failed';
    job.progressPct = 0;
    job.errorMessage = err instanceof Error ? err.message : 'Media conversion failed.';
    job.updatedAtMs = Date.now();
  }
}

async function computeDirStats(dirPath) {
  let bytes = 0;
  let files = 0;
  try {
    const entries = await fs.readdir(dirPath, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(dirPath, entry.name);
      if (entry.isDirectory()) {
        const sub = await computeDirStats(full);
        bytes += sub.bytes;
        files += sub.files;
      } else if (entry.isFile()) {
        const st = await fs.stat(full).catch(() => null);
        if (st) {
          bytes += st.size;
          files += 1;
        }
      }
    }
  } catch {
    // ignore missing directory
  }
  return { bytes, files };
}

async function cleanupMediaJobs({ forceAll = false } = {}) {
  const now = Date.now();
  let removedJobs = 0;
  let freedBytes = 0;

  for (const [id, job] of jobStore.entries()) {
    const isBusy = job.status === 'Validating' || job.status === 'Processing';
    const isExpired = now > job.expiresAtMs || job.status === 'Expired';
    const isStaleFailed = job.status === 'Failed' && now - job.updatedAtMs > 5 * 60_000;

    if (forceAll ? !isBusy : isExpired || isStaleFailed) {
      const info = await computeDirStats(job.jobDir);
      await fs.rm(job.jobDir, { recursive: true, force: true }).catch(() => {});
      job.status = 'Expired';
      job.inputPath = null;
      job.outputPath = null;
      job.updatedAtMs = now;
      if (isExpired || forceAll) {
        removedJobs += 1;
        freedBytes += info.bytes;
      }
      if (forceAll || now - job.updatedAtMs > 24 * 60 * 60_000) {
        jobStore.delete(id);
      }
    }
  }

  // Sweep orphaned job folders without deleting the _incoming staging folder
  try {
    const entries = await fs.readdir(MEDIA_JOBS_ROOT, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      if (entry.name === '_incoming') {
        const stagedFiles = await fs.readdir(UPLOAD_STAGING_DIR, { withFileTypes: true }).catch(() => []);
        const maxAgeMs = forceAll ? 2_000 : 30 * 60_000;
        for (const f of stagedFiles) {
          if (!f.isFile()) continue;
          const p = path.join(UPLOAD_STAGING_DIR, f.name);
          const st = await fs.stat(p).catch(() => null);
          if (st && now - st.mtimeMs >= maxAgeMs) {
            await fs.rm(p, { force: true }).catch(() => {});
            freedBytes += st.size;
          }
        }
        continue;
      }
      if (!jobStore.has(entry.name)) {
        const full = path.join(MEDIA_JOBS_ROOT, entry.name);
        const info = await computeDirStats(full);
        await fs.rm(full, { recursive: true, force: true }).catch(() => {});
        removedJobs += 1;
        freedBytes += info.bytes;
      }
    }
  } catch {
    // ignore missing root
  }

  const remaining = await computeDirStats(MEDIA_JOBS_ROOT);
  const lastCleanupAt = new Date().toISOString();
  lastCleanupInfo = { at: lastCleanupAt, removed: removedJobs, freedBytes };

  return {
    removedJobs,
    freedBytes,
    storageUsedBytes: remaining.bytes,
    tempFileCount: remaining.files,
    lastCleanupAt,
  };
}

const cleanupInterval = setInterval(() => {
  void cleanupMediaJobs({ forceAll: false }).catch(() => {});
}, 60_000);
cleanupInterval.unref?.();

// ---------------------------------------------------------------------------
// Express App, Middleware & Routes
// ---------------------------------------------------------------------------
const app = express();
app.set('trust proxy', 1);

app.use(
  helmet({
    crossOriginResourcePolicy: { policy: 'cross-origin' },
    contentSecurityPolicy: false,
  })
);

app.use(
  cors({
    origin(origin, callback) {
      if (!origin || ALLOWED_ORIGINS.length === 0 || ALLOWED_ORIGINS.includes(origin)) {
        callback(null, true);
      } else {
        callback(new Error(`Origin ${origin} not allowed by CORS policy.`));
      }
    },
    methods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Admin-Key', 'X-Download-Token'],
  })
);

app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: Number.parseInt(process.env.API_RATE_LIMIT_MAX || '120', 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests from this IP. Please try again later.', code: 'RATE_LIMITED' },
});

const processLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: Number.parseInt(process.env.CONVERT_RATE_LIMIT_MAX || '30', 10),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Media upload/conversion rate limit exceeded.', code: 'PROCESS_RATE_LIMITED' },
});

app.use('/api', apiLimiter);

function requireAdminKey(req, res, next) {
  if (!ADMIN_CLEANUP_KEY) {
    return res.status(403).json({
      error: 'ADMIN_CLEANUP_KEY is not configured on this server.',
      code: 'ADMIN_NOT_CONFIGURED',
    });
  }
  const supplied = String(req.headers['x-admin-key'] || '');
  const expectedBuf = Buffer.from(ADMIN_CLEANUP_KEY);
  const suppliedBuf = Buffer.from(supplied);
  if (expectedBuf.length !== suppliedBuf.length || !crypto.timingSafeEqual(expectedBuf, suppliedBuf)) {
    return res.status(401).json({ error: 'Invalid or missing X-Admin-Key header.', code: 'UNAUTHORIZED' });
  }
  return next();
}

// Health & Binary Readiness Check
app.get('/api/v1/health', async (_req, res) => {
  try {
    await execFileAsync('ffmpeg', ['-version'], { timeout: 3000 });
    await execFileAsync('ffprobe', ['-version'], { timeout: 3000 });
    return res.json({
      status: 'ok',
      service: 'MediaToolsHub Standalone Media Backend',
      ffmpegReady: true,
      maxUploadMb: MAX_UPLOAD_MB,
      jobTtlMinutes: JOB_TTL_MINUTES,
      timestamp: new Date().toISOString(),
    });
  } catch {
    return res.status(503).json({
      status: 'degraded',
      service: 'MediaToolsHub Standalone Media Backend',
      ffmpegReady: false,
      error: 'FFmpeg or FFprobe binary not found in system PATH.',
    });
  }
});

// Route 1: Inspect URL (Authorized Direct Media vs Restricted Platform Compliance)
app.post('/api/v1/media/inspect', async (req, res) => {
  const url = typeof req.body?.url === 'string' ? req.body.url : '';
  const classified = classifyMediaUrl(url);

  if (!classified.valid) {
    return res.status(400).json({ error: classified.reason || 'Invalid URL.', code: 'INVALID_URL' });
  }

  if (!classified.downloadable) {
    return res.json({
      platform: classified.platform,
      sourceType: classified.sourceType,
      canonicalUrl: classified.canonicalUrl,
      downloadable: false,
      supportedFunctionality:
        classified.platform === 'youtube' ? ['metadata-api', 'creator-upload'] : ['creator-upload'],
      officialAccessUrl: classified.canonicalUrl,
      officialStudioUrl: classified.officialStudioUrl || null,
      officialTakeoutUrl: classified.officialTakeoutUrl || null,
      complianceNotice: classified.complianceNotice,
      inspection: null,
      videoFormats: [],
      audioFormats: [],
    });
  }

  let tmpDir = null;
  try {
    const upstream = await safeFetch(classified.canonicalUrl, { method: 'GET', timeoutMs: 20000 });
    if (!upstream.ok) {
      return res.status(400).json({
        error: `Remote server returned HTTP ${upstream.status}.`,
        code: 'UPSTREAM_ERROR',
      });
    }

    const contentType = (upstream.headers.get('content-type') || '').toLowerCase();
    const contentLengthHeader = upstream.headers.get('content-length');
    const remoteSize = contentLengthHeader ? Number.parseInt(contentLengthHeader, 10) : null;
    if (remoteSize && remoteSize > MAX_UPLOAD_BYTES) {
      return res.status(413).json({
        error: `Remote media (${(remoteSize / (1024 * 1024)).toFixed(1)} MB) exceeds ${MAX_UPLOAD_MB} MB limit.`,
        code: 'FILE_TOO_LARGE',
      });
    }

    const ext = getExtFromUrlOrContentType(classified.canonicalUrl, contentType);
    const prefixBuf = await readPrefixBytes(upstream, MAX_INSPECT_BYTES);
    const sig = validateMediaSignature(prefixBuf.subarray(0, 64), ext);
    if (!sig.valid) {
      return res.status(400).json({ error: sig.reason, code: 'INVALID_MEDIA_SIGNATURE' });
    }

    tmpDir = await fs.mkdtemp(path.join(MEDIA_JOBS_ROOT, '_probe-'));
    const probePath = path.join(tmpDir, `probe${ext}`);
    await fs.writeFile(probePath, prefixBuf);

    const inspection = await inspectWithFfprobe(probePath, remoteSize, ext);
    const videoFormats = inspection.hasVideo
      ? buildVideoFormatOptions({
          sourceHeight: inspection.height,
          sourceWidth: inspection.width,
          codecLabel: inspection.videoCodec || 'H264',
          contentType: ext === '.mp4' ? 'video/mp4' : contentType,
          knownSourceBytes: remoteSize,
          durationSec: inspection.durationSec,
        })
      : [];
    const audioFormats = buildAudioFormatOptions(inspection);

    return res.json({
      platform: 'general',
      sourceType: classified.sourceType,
      canonicalUrl: classified.canonicalUrl,
      downloadable: videoFormats.length > 0 || audioFormats.length > 0,
      supportedFunctionality: ['inspect', 'convert-mp4', 'convert-mp3'],
      officialAccessUrl: classified.canonicalUrl,
      officialStudioUrl: null,
      officialTakeoutUrl: null,
      complianceNotice: 'Authorized direct media stream inspected successfully with FFprobe.',
      inspection,
      videoFormats,
      audioFormats,
    });
  } catch (err) {
    return res.status(400).json({
      error: err instanceof Error ? err.message : 'Unable to inspect direct media URL.',
      code: 'MEDIA_INSPECT_ERROR',
    });
  } finally {
    if (tmpDir) {
      await fs.rm(tmpDir, { recursive: true, force: true }).catch(() => {});
    }
  }
});

// Route 2: Upload Local or Exported Video/Audio File
app.post('/api/v1/media/upload', processLimiter, async (req, res) => {
  await fs.mkdir(UPLOAD_STAGING_DIR, { recursive: true });

  const uploader = multer({
    dest: UPLOAD_STAGING_DIR,
    limits: { fileSize: MAX_UPLOAD_BYTES, files: 1 },
  }).single('file');

  uploader(req, res, async (uploadErr) => {
    if (uploadErr) {
      const isTooLarge = uploadErr instanceof multer.MulterError && uploadErr.code === 'LIMIT_FILE_SIZE';
      return res.status(isTooLarge ? 413 : 400).json({
        error: isTooLarge
          ? `Uploaded file exceeds the configured ${MAX_UPLOAD_MB} MB limit.`
          : uploadErr.message || 'Unable to process file upload.',
        code: isTooLarge ? 'FILE_TOO_LARGE' : 'UPLOAD_FAILED',
      });
    }

    if (!req.file) {
      return res.status(400).json({
        error: 'No media file attached. Upload MP4, WEBM, MOV, MP3, WAV, or M4A.',
        code: 'FILE_REQUIRED',
      });
    }

    const ext = path.extname(req.file.originalname || '').toLowerCase();
    const mime = (req.file.mimetype || '').toLowerCase();
    const jobId = crypto.randomUUID();
    const jobDir = path.join(MEDIA_JOBS_ROOT, jobId);

    try {
      if (!ALLOWED_MEDIA_EXTENSIONS.has(ext)) {
        throw new Error(`Unsupported file extension "${ext || 'unknown'}". Allowed: MP4, WEBM, MOV, MP3, WAV, M4A.`);
      }
      if (!ALLOWED_MEDIA_MIME_TYPES.has(mime) && !mime.startsWith('video/') && !mime.startsWith('audio/')) {
        throw new Error(`Unsupported MIME type "${mime}".`);
      }

      const fh = await fs.open(req.file.path, 'r');
      const headerBuf = Buffer.alloc(64);
      try {
        const { bytesRead } = await fh.read(headerBuf, 0, 64, 0);
        const sig = validateMediaSignature(headerBuf.subarray(0, bytesRead), ext);
        if (!sig.valid) {
          throw new Error(sig.reason || 'Uploaded file failed binary media signature check.');
        }
      } finally {
        await fh.close();
      }

      await fs.mkdir(jobDir, { recursive: true });
      const safeInputPath = path.join(jobDir, `input${ext}`);
      await fs.rename(req.file.path, safeInputPath);

      const inspection = await inspectWithFfprobe(safeInputPath, req.file.size, ext);
      const videoFormats = inspection.hasVideo
        ? buildVideoFormatOptions({
            sourceHeight: inspection.height,
            sourceWidth: inspection.width,
            codecLabel: inspection.videoCodec || 'H264',
            contentType: ext === '.mp4' ? 'video/mp4' : mime,
            knownSourceBytes: inspection.fileSizeBytes,
            durationSec: inspection.durationSec,
          })
        : [];
      const audioFormats = buildAudioFormatOptions(inspection);

      if (videoFormats.length === 0 && audioFormats.length === 0) {
        throw new Error('No convertible video or audio streams found in uploaded file.');
      }

      const now = Date.now();
      const expiresAtMs = now + JOB_TTL_MINUTES * 60_000;
      const downloadToken = crypto.randomBytes(24).toString('hex');

      jobStore.set(jobId, {
        jobId,
        sourceKind: 'upload',
        sourceLabel: req.file.originalname,
        sourceUrl: null,
        status: 'Uploaded',
        progressPct: 0,
        downloadToken,
        jobDir,
        inputPath: safeInputPath,
        inputExt: ext,
        inspection,
        outputPath: null,
        outputFilename: null,
        outputContentType: null,
        targetFormat: null,
        targetContainer: null,
        sourceSizeBytes: req.file.size,
        outputSizeBytes: null,
        outputCodec: null,
        outputResolution: null,
        outputBitrateKbps: null,
        outputDurationSec: null,
        errorMessage: null,
        createdAtMs: now,
        updatedAtMs: now,
        expiresAtMs,
      });

      return res.status(201).json({
        jobId,
        status: 'Uploaded',
        downloadToken,
        originalFilename: req.file.originalname,
        mimeType: req.file.mimetype,
        inspection,
        videoFormats,
        audioFormats,
        expiresAt: new Date(expiresAtMs).toISOString(),
      });
    } catch (err) {
      await fs.rm(req.file.path, { force: true }).catch(() => {});
      await fs.rm(jobDir, { recursive: true, force: true }).catch(() => {});
      return res.status(400).json({
        error: err instanceof Error ? err.message : 'Invalid uploaded media file.',
        code: 'INVALID_MEDIA_UPLOAD',
      });
    }
  });
});

// Route 3: Start Asynchronous FFmpeg Conversion Job
app.post('/api/v1/media/convert', processLimiter, async (req, res) => {
  const jobId = typeof req.body?.jobId === 'string' ? req.body.jobId.trim() : '';
  const url = typeof req.body?.url === 'string' ? req.body.url.trim() : '';
  const formatId = typeof req.body?.formatId === 'string' ? req.body.formatId.trim() : '';

  if (!ALLOWED_FORMAT_IDS.has(formatId)) {
    return res.status(400).json({
      error: 'Unsupported formatId. Select mp4-source, mp4-1080, mp4-720, mp4-480, mp4-360, mp3-320, mp3-192, or mp3-128.',
      code: 'INVALID_FORMAT',
    });
  }

  try {
    const now = Date.now();
    let job;

    if (jobId) {
      const existing = jobStore.get(jobId);
      if (!existing) {
        return res.status(404).json({ error: 'Uploaded job not found or expired.', code: 'JOB_NOT_FOUND' });
      }
      if (now > existing.expiresAtMs || !existing.inputPath) {
        existing.status = 'Expired';
        return res.status(410).json({ error: 'Uploaded file expired. Please upload it again.', code: 'JOB_EXPIRED' });
      }

      const childId = crypto.randomUUID();
      const childDir = path.join(MEDIA_JOBS_ROOT, childId);
      await fs.mkdir(childDir, { recursive: true });
      const copiedInput = path.join(childDir, `input${existing.inputExt || '.mp4'}`);
      await fs.copyFile(existing.inputPath, copiedInput);

      job = {
        ...existing,
        jobId: childId,
        jobDir: childDir,
        inputPath: copiedInput,
        downloadToken: crypto.randomBytes(24).toString('hex'),
        status: 'Validating',
        progressPct: 5,
        targetFormat: formatId,
        targetContainer: formatId.startsWith('mp3-') ? 'mp3' : 'mp4',
        outputPath: null,
        outputFilename: null,
        outputContentType: null,
        outputSizeBytes: null,
        outputCodec: null,
        outputResolution: null,
        outputBitrateKbps: null,
        outputDurationSec: null,
        errorMessage: null,
        createdAtMs: now,
        updatedAtMs: now,
        expiresAtMs: now + JOB_TTL_MINUTES * 60_000,
      };
      jobStore.set(job.jobId, job);
    } else if (url) {
      const classified = classifyMediaUrl(url);
      if (!classified.valid || !classified.downloadable) {
        return res.status(400).json({
          error: classified.complianceNotice || classified.reason || 'URL is not a directly downloadable media file.',
          code: 'SOURCE_NOT_DOWNLOADABLE',
        });
      }

      const newId = crypto.randomUUID();
      job = {
        jobId: newId,
        sourceKind: 'url',
        sourceLabel: classified.canonicalUrl,
        sourceUrl: classified.canonicalUrl,
        status: 'Validating',
        progressPct: 2,
        downloadToken: crypto.randomBytes(24).toString('hex'),
        jobDir: path.join(MEDIA_JOBS_ROOT, newId),
        inputPath: null,
        inputExt: null,
        inspection: null,
        targetFormat: formatId,
        targetContainer: formatId.startsWith('mp3-') ? 'mp3' : 'mp4',
        sourceSizeBytes: null,
        outputPath: null,
        outputFilename: null,
        outputContentType: null,
        outputSizeBytes: null,
        outputCodec: null,
        outputResolution: null,
        outputBitrateKbps: null,
        outputDurationSec: null,
        errorMessage: null,
        createdAtMs: now,
        updatedAtMs: now,
        expiresAtMs: now + JOB_TTL_MINUTES * 60_000,
      };
      jobStore.set(job.jobId, job);
    } else {
      return res.status(400).json({
        error: 'Provide either an uploaded jobId or an authorized direct media url.',
        code: 'SOURCE_REQUIRED',
      });
    }

    void executeBackgroundConversion(job, formatId);

    return res.status(202).json({
      job: toPublicJobRecord(job),
      downloadToken: job.downloadToken,
      pollUrl: `/api/v1/media/jobs/${job.jobId}`,
    });
  } catch (err) {
    return res.status(400).json({
      error: err instanceof Error ? err.message : 'Unable to start conversion job.',
      code: 'CONVERSION_START_FAILED',
    });
  }
});

// Route 4: Poll Live Conversion Progress
app.get('/api/v1/media/jobs/:id', (req, res) => {
  const job = jobStore.get(String(req.params.id));
  if (!job) {
    return res.status(404).json({ error: 'Conversion job not found or expired.', code: 'JOB_NOT_FOUND' });
  }
  if (Date.now() > job.expiresAtMs && job.status !== 'Expired') {
    job.status = 'Expired';
    job.updatedAtMs = Date.now();
  }
  return res.json({ job: toPublicJobRecord(job) });
});

// Route 5: Secure Tokenized Temporary File Download
app.get('/api/v1/media/download/:id', async (req, res) => {
  const job = jobStore.get(String(req.params.id));
  if (!job) {
    return res.status(404).json({ error: 'Download job not found or cleaned up.', code: 'JOB_NOT_FOUND' });
  }

  const token = String(req.query.token || req.headers['x-download-token'] || '');
  const expectedBuf = Buffer.from(job.downloadToken);
  const tokenBuf = Buffer.from(token);
  if (!token || expectedBuf.length !== tokenBuf.length || !crypto.timingSafeEqual(expectedBuf, tokenBuf)) {
    return res.status(403).json({ error: 'Invalid or missing download authorization token.', code: 'FORBIDDEN' });
  }

  if (Date.now() > job.expiresAtMs || job.status === 'Expired') {
    job.status = 'Expired';
    return res.status(410).json({ error: 'Download link expired. Convert the file again.', code: 'EXPIRED' });
  }

  if (job.status !== 'Completed' || !job.outputPath || !job.outputFilename) {
    return res.status(409).json({ error: `Output not ready (status: ${job.status}).`, code: 'NOT_READY' });
  }

  const stat = await fs.stat(job.outputPath).catch(() => null);
  if (!stat || !stat.isFile()) {
    return res.status(410).json({ error: 'Temporary converted file no longer exists.', code: 'EXPIRED' });
  }

  res.setHeader('Content-Type', job.outputContentType || 'application/octet-stream');
  res.setHeader('Content-Length', String(stat.size));
  res.setHeader('Content-Disposition', `attachment; filename="${job.outputFilename.replace(/"/g, '')}"`);
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  return fsSync.createReadStream(job.outputPath).pipe(res);
});

// Route 6: Admin Telemetry & Manual Temp Cleanup
app.get('/api/v1/admin/media', requireAdminKey, async (_req, res) => {
  const disk = await computeDirStats(MEDIA_JOBS_ROOT);
  const recentJobs = Array.from(jobStore.values())
    .sort((a, b) => b.createdAtMs - a.createdAtMs)
    .slice(0, 25)
    .map(toPublicJobRecord);

  return res.json({
    storageUsedBytes: disk.bytes,
    tempFileCount: disk.files,
    activeJobs: recentJobs.filter((j) => ['Uploaded', 'Validating', 'Processing'].includes(j.status)).length,
    lastCleanupInfo,
    recentJobs,
  });
});

app.post('/api/v1/media/cleanup', requireAdminKey, async (req, res) => {
  const forceAll = Boolean(req.body?.forceAll);
  const result = await cleanupMediaJobs({ forceAll });
  return res.json(result);
});

app.use((err, _req, res, _next) => {
  const message = err instanceof Error ? err.message : 'Unexpected backend error.';
  return res.status(500).json({ error: message, code: 'INTERNAL_ERROR' });
});

app.listen(PORT, () => {
  console.log(`MediaToolsHub Standalone FFmpeg Backend listening on http://localhost:${PORT}`);
});
