# MediaToolsHub Standalone Media Backend Starter

Production-oriented **Node.js + Express.js + FFmpeg/FFprobe** media inspection, transcoding, and temporary file download service built to pair cleanly with the MediaToolsHub frontend.

- Uses **FFmpeg** & **FFprobe** only for user-uploaded files (`.mp4`, `.m4v`, `.webm`, `.mov`, `.mp3`, `.wav`, `.m4a`) and authorized direct media URLs.
- **Does not** bundle `yt-dlp` or bypass YouTube, Instagram, Pinterest, TikTok, or Facebook platform restrictions.

---

## Directory Structure

```text
services/media-backend-starter/
├── package.json         # Standalone Express dependencies & scripts
├── server.js            # API server, SSRF guard, Multer staging, FFmpeg/FFprobe job engine, auto cleanup
├── public/
│   └── index.html       # Minimal test console (Tailwind + vanilla JS)
├── Dockerfile           # Production container image (Node 22 + FFmpeg)
├── .env.example         # Required & optional environment variables
└── README.md            # Setup, deployment & MediaToolsHub integration guide
```

---

## Installation (Local Development)

1. Install **Node.js 20+** and **FFmpeg / FFprobe** on the host machine:
   - Ubuntu / Debian: `sudo apt-get update && sudo apt-get install -y ffmpeg`
   - macOS (Homebrew): `brew install ffmpeg`
2. Navigate to this folder and install dependencies:
   ```bash
   cd services/media-backend-starter
   cp .env.example .env
   npm install
   ```
3. Start the server:
   ```bash
   npm start
   ```
   Open `http://localhost:4000` (or `GET /api/v1/health`).

---

## Environment Variables

| Variable | Required | Default | Purpose |
| --- | --- | --- | --- |
| `PORT` | No | `4000` | HTTP listen port |
| `ALLOWED_ORIGINS` | Yes (prod) | `""` (open if empty) | Comma-separated frontend origins permitted via CORS (set to your MediaToolsHub URL) |
| `MAX_UPLOAD_MB` | No | `100` | Max file upload / remote download size in MB (`1–500`) |
| `JOB_TTL_MINUTES` | No | `30` | Temporary file retention before auto-deletion (`1–240`) |
| `FFMPEG_TIMEOUT_MS` | No | `120000` | Per-job FFmpeg execution timeout |
| `ALLOWED_MEDIA_DOMAINS` | No | `""` (any public host) | Optional domain allowlist for direct remote URL fetching |
| `MEDIA_TEMP_DIR` | No | OS temp folder | Custom scratch path for conversion jobs |
| `API_RATE_LIMIT_MAX` | No | `120` | General API requests per 15 min per IP |
| `CONVERT_RATE_LIMIT_MAX` | No | `30` | Uploads/conversions per 15 min per IP |
| `ADMIN_CLEANUP_KEY` | Recommended | `""` | Secret header (`X-Admin-Key`) required for `/api/v1/admin/media` and `/api/v1/media/cleanup` |

---

## API Endpoints & Error Codes

- `GET /api/v1/health` — Checks FFmpeg & FFprobe availability (`503` if missing).
- `POST /api/v1/media/inspect` — Validates URL safety (SSRF guard) and returns platform compliance info or real FFprobe stream specs + allowed `mp4`/`mp3` options.
- `POST /api/v1/media/upload` — Accepts `multipart/form-data` (`file`), checks extension + MIME + binary signature (`413 FILE_TOO_LARGE`, `400 INVALID_MEDIA_UPLOAD`), probes tracks, returns `jobId` & formats.
- `POST /api/v1/media/convert` — Queues background FFmpeg conversion (`mp4-1080`, `mp4-720`, `mp4-480`, `mp4-360`, `mp4-source`, `mp3-320`, `mp3-192`, `mp3-128`) without upscaling. Returns `202` with `jobId`.
- `GET /api/v1/media/jobs/:id` — Returns live job state (`Uploaded`, `Validating`, `Processing`, `Completed`, `Failed`, `Expired`) and `progressPct`.
- `GET /api/v1/media/download/:id?token=...` — Streams finished output with cryptographic token verification (`403 FORBIDDEN`, `410 EXPIRED`) and `Content-Disposition: attachment`.
- `GET /api/v1/admin/media` & `POST /api/v1/media/cleanup` — Protected by `X-Admin-Key` header for temp storage inspection & manual cleanup.

---

## Connecting to Your Existing MediaToolsHub Video Downloader Page

The API endpoints and JSON contracts match `src/components/tools/VideoDownloaderTool.tsx`:
1. Deploy this service (e.g., to `https://media-api.yourdomain.com`) and set `ALLOWED_ORIGINS=https://your-mediatoolshub-domain.com`.
2. In your MediaToolsHub frontend `.env`, add `VITE_MEDIA_BACKEND_URL=https://media-api.yourdomain.com`.
3. In `VideoDownloaderTool.tsx`, prefix calls to `/api/v1/media/inspect`, `/api/v1/media/upload`, `/api/v1/media/convert`, `/api/v1/media/jobs/${id}`, and the resulting `downloadUrl` with `import.meta.env.VITE_MEDIA_BACKEND_URL || ''`.

---

## Deployment (Google Cloud Run / Docker)

```bash
gcloud run deploy mediatoolshub-media-backend \
  --source services/media-backend-starter \
  --region asia-southeast1 \
  --memory 2Gi \
  --cpu 2 \
  --timeout 300 \
  --set-env-vars ALLOWED_ORIGINS=https://your-mediatoolshub-domain.com,ADMIN_CLEANUP_KEY=your-secret-key \
  --allow-unauthenticated
```
*(Allocating 2 GiB memory ensures ample RAM-backed `/tmp` space on Cloud Run for concurrent uploads and FFmpeg encodes.)*
