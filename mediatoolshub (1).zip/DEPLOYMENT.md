# MediaToolsHub – Deployment & Operations Guide

## Architecture Summary
- **Frontend**: React 19 + TypeScript + Tailwind CSS v4 (served via Vite in development and Express static `dist/` in production).
- **Backend**: Node.js + Express (`server.ts`) with Helmet security headers, SSRF DNS/IP guard, sliding-window rate limiting, and REST API v1 routes (`/api/v1/*`).
- **Database**: Cloud SQL for PostgreSQL managed via Drizzle ORM (`src/db/schema.ts`).
- **Authentication**: Firebase Authentication (Google Sign-In) with server-side `firebase-admin` token verification and PostgreSQL role synchronization.

## Environment Variables
Copy `.env.example` and configure your environment:

### Required
- `YOUTUBE_API_KEY`: Required server-side YouTube Data API v3 key for extended video statistics (`videos.list`) and channel details (`channels.list`) on `/youtube-video-details-extractor`. Without it, MediaToolsHub falls back cleanly to YouTube oEmbed without blocking development.
- `ADMIN_EMAIL`: Email address granted administrator role upon verified Google Sign-In.

### Optional (Non-Blocking)
- `META_APP_ACCESS_TOKEN`: Optional Meta Graph API token with `oEmbed Read` approval for live Instagram/Facebook oEmbed previews.
- `PINTEREST_ACCESS_TOKEN`: Optional Pinterest API v5 bearer token for official Pin lookups.
- `GA_MEASUREMENT_ID`, `GSC_VERIFICATION_TOKEN`, `ADSENSE_PUBLISHER_ID`: Optional analytics, Search Console, and AdSense identifiers (can also be configured later in `/admin` under **Settings & Limits**).

## Build, Test & Start
```bash
npm run test    # Run unit/integration tests
npm run lint    # TypeScript type check
npm run build   # Compile production frontend into dist/
npm run start   # Launch production Express server on port 3000
```

## YouTube Management OAuth 2.0 (Cloud Run + Google Secret Manager)
MediaToolsHub reads `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`, and `OAUTH_TOKEN_ENCRYPTION_KEY` on the backend (`server.ts`). Both Cloud Run Secret Manager **environment variable references** (`--set-secrets`) and **mounted secret files** (`GOOGLE_CLIENT_SECRET_FILE`, `OAUTH_TOKEN_ENCRYPTION_KEY_FILE`, or `/secrets/GOOGLE_CLIENT_SECRET`, `/secrets/OAUTH_TOKEN_ENCRYPTION_KEY`) are supported.

1. Rotate the exposed OAuth Client Secret in Google Cloud Console (`mediatoolshub` → **APIs & Services → Credentials** → Web client `400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com`) and delete the old exposed secret.
2. Enable **Secret Manager API** in the project hosting your Cloud Run deployment and create two secrets (never commit secret values to source code):
   - `mediatoolshub-google-client-secret` (your newly rotated Google OAuth Client Secret)
   - `mediatoolshub-oauth-token-encryption-key` (64-char hex key from `openssl rand -hex 32`)
3. Grant `roles/secretmanager.secretAccessor` on both secrets to your Cloud Run service's runtime service account.
4. Bind environment variables and Secret Manager references on the Cloud Run service:
   - `GOOGLE_CLIENT_ID=400517076332-qqb4csopmmcv218b1oqfhcgisgk4g85t.apps.googleusercontent.com`
   - `GOOGLE_REDIRECT_URI=https://<your-cloud-run-host>/api/v1/ytm/auth/google/callback`
   - `GOOGLE_CLIENT_SECRET` ← Secret Manager `mediatoolshub-google-client-secret:latest`
   - `OAUTH_TOKEN_ENCRYPTION_KEY` ← Secret Manager `mediatoolshub-oauth-token-encryption-key:latest`
5. Ensure the exact Authorized JavaScript origin (`https://<your-cloud-run-host>`) and Authorized redirect URI (`https://<your-cloud-run-host>/api/v1/ytm/auth/google/callback`) are registered on the Google Cloud OAuth Web client.
6. Verify `GET /api/v1/health?checkOAuth=1` reports `valid: true`, `oauthConfigured: true`, `oauthClientInitialized: true`, and `authorizationUrlReady: true`.

## Monetization & SEO Checklist
1. Open `/admin` using the administrator Google account.
2. Under **Settings & Limits**, configure your Google AdSense Publisher ID (`ca-pub-...`), Google Analytics 4 Measurement ID (`G-...`), and Google Search Console verification token.
3. Under **Ad Placements**, configure individual Ad Unit IDs and desktop/mobile toggles before enabling slots.
4. Submit `/sitemap.xml` in Google Search Console.
