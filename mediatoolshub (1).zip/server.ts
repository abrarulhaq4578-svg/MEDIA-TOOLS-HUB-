import fs from 'node:fs/promises';
import path from 'node:path';
import express from 'express';
import helmet from 'helmet';
import dotenv from 'dotenv';
import { eq } from 'drizzle-orm';
import { db } from './src/db/index.ts';
import { blogPosts, websiteSettings } from './src/db/schema.ts';
import {
  getPublicIntegrationFlags,
  getServerConfig,
  isValidGaMeasurementId,
  logStartupEnvStatus,
  resolveSettingWithEnv,
} from './src/server/config/env.ts';
import apiRouter from './src/server/routes/api.ts';
import { getToolByRoutePath, TOOLS_CATALOG } from './src/shared/toolsCatalog.ts';

dotenv.config();
logStartupEnvStatus();

const PORT = Number(process.env.PORT) || 3000;
const isProd = process.env.NODE_ENV === 'production';
const ROOT_DIR = process.cwd();

function escapeHtmlAttr(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/"/g, '&quot;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function getBaseUrl(req: express.Request): string {
  const configured = process.env.APP_URL?.trim();
  if (configured && configured !== 'MY_APP_URL') {
    return configured.replace(/\/+$/, '');
  }
  const proto = req.header('x-forwarded-proto') || req.protocol || 'https';
  const host = req.header('x-forwarded-host') || req.get('host') || `localhost:${PORT}`;
  return `${proto}://${host}`;
}

async function resolveRouteSeoMeta(pathname: string) {
  const clean = pathname.replace(/\/+$/, '') || '/';
  const tool = getToolByRoutePath(clean);
  if (tool) {
    return {
      title: tool.seoTitle,
      description: tool.seoDescription,
      canonicalPath: tool.routePath,
    };
  }

  if (clean.startsWith('/blog/')) {
    const slug = clean.slice('/blog/'.length);
    try {
      const rows = await db
        .select()
        .from(blogPosts)
        .where(eq(blogPosts.slug, slug))
        .limit(1);
      if (rows[0]) {
        return {
          title: rows[0].seoTitle,
          description: rows[0].seoDescription,
          canonicalPath: `/blog/${rows[0].slug}`,
        };
      }
    } catch {
      // Fallback safely
    }
  }

  const staticRoutes: Record<string, { title: string; description: string }> = {
    '/': {
      title: 'MediaToolsHub – All Your Social Media Tools in One Place',
      description:
        'Free online social media utilities to extract YouTube thumbnails, analyze permitted video metadata, convert image formats, and generate QR codes.',
    },
    '/tools': {
      title: 'All Social Media & Media Tools Directory | MediaToolsHub',
      description:
        'Browse all 30+ free utilities across YouTube, Instagram, Pinterest, TikTok, Facebook, X/Twitter, and media conversion.',
    },
    '/youtube-management': {
      title: 'YouTube Management — Complete Creator Operating System | MediaToolsHub',
      description:
        'Plan, create, publish, analyze, and grow your YouTube channel from one workspace.',
    },
    '/blog': {
      title: 'Blog, Tutorials & Platform Guides | MediaToolsHub',
      description:
        'Practical technical guides on thumbnail optimization, oEmbed metadata APIs, and privacy-first browser utilities.',
    },
    '/pricing': {
      title: 'Plans & Developer API Access | MediaToolsHub',
      description:
        'Compare Free, Pro, and Developer API plans for MediaToolsHub utilities.',
    },
    '/api-docs': {
      title: 'REST API Documentation (v1) | MediaToolsHub',
      description:
        'Integrate MediaToolsHub URL validation, YouTube thumbnail probing, and oEmbed metadata endpoints.',
    },
    '/about': {
      title: 'About MediaToolsHub – Architecture & Compliance',
      description:
        'Learn about MediaToolsHub’s privacy-first processing model and commitment to platform compliance.',
    },
    '/contact': {
      title: 'Contact & Support | MediaToolsHub',
      description:
        'Get in touch with MediaToolsHub for support, developer API inquiries, or partnerships.',
    },
    '/privacy-policy': {
      title: 'Privacy Policy | MediaToolsHub',
      description: 'How MediaToolsHub handles data, local processing, logs, and cookies.',
    },
    '/terms-of-service': {
      title: 'Terms of Service | MediaToolsHub',
      description: 'Acceptable use, API compliance, and user responsibilities for MediaToolsHub.',
    },
    '/dmca': {
      title: 'DMCA Notice & Takedown Procedure | MediaToolsHub',
      description: 'Submit copyright complaints or abuse reports to MediaToolsHub.',
    },
  };

  const matched = staticRoutes[clean] || staticRoutes['/'];
  return {
    title: matched.title,
    description: matched.description,
    canonicalPath: clean,
  };
}

async function resolveOptionalHeadTokens(): Promise<{
  gscToken: string;
  gaMeasurementId: string;
}> {
  const cfg = getServerConfig();
  try {
    const rows = await db.select().from(websiteSettings);
    const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    const flags = getPublicIntegrationFlags(map);
    const gsc = resolveSettingWithEnv(map, 'gsc_verification_token', cfg.gscVerificationToken);
    const ga = resolveSettingWithEnv(map, 'ga_measurement_id', cfg.gaMeasurementId);
    return {
      gscToken: flags.gscEnabled ? gsc.value : '',
      gaMeasurementId: flags.gaEnabled && isValidGaMeasurementId(ga.value) ? ga.value : '',
    };
  } catch {
    return {
      gscToken: cfg.gscVerificationToken || '',
      gaMeasurementId: isValidGaMeasurementId(cfg.gaMeasurementId) ? cfg.gaMeasurementId! : '',
    };
  }
}

function injectSeoTags(
  html: string,
  meta: {
    title: string;
    description: string;
    canonicalUrl: string;
    gscToken?: string;
    gaMeasurementId?: string;
  }
): string {
  const safeTitle = escapeHtmlAttr(meta.title);
  const safeDesc = escapeHtmlAttr(meta.description);
  const safeUrl = escapeHtmlAttr(meta.canonicalUrl);

  const extraHeadTags: string[] = [
    `<link rel="canonical" href="${safeUrl}" />`,
    `<meta property="og:url" content="${safeUrl}" />`,
  ];

  if (meta.gscToken) {
    extraHeadTags.push(
      `<meta name="google-site-verification" content="${escapeHtmlAttr(meta.gscToken)}" />`
    );
  }

  if (meta.gaMeasurementId) {
    const safeGa = escapeHtmlAttr(meta.gaMeasurementId);
    extraHeadTags.push(
      `<script async src="https://www.googletagmanager.com/gtag/js?id=${safeGa}"></script>`,
      `<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${safeGa}');</script>`
    );
  }

  return html
    .replace(/<title>[\s\S]*?<\/title>/i, `<title>${safeTitle}</title>`)
    .replace(
      /<meta\s+name="description"[\s\S]*?\/>/i,
      `<meta name="description" content="${safeDesc}" />`
    )
    .replace(
      /<meta\s+property="og:title"[\s\S]*?\/>/i,
      `<meta property="og:title" content="${safeTitle}" />`
    )
    .replace(
      /<meta\s+property="og:description"[\s\S]*?\/>/i,
      `<meta property="og:description" content="${safeDesc}" />`
    )
    .replace(
      /<meta\s+name="twitter:title"[\s\S]*?\/>/i,
      `<meta name="twitter:title" content="${safeTitle}" />`
    )
    .replace(
      /<meta\s+name="twitter:description"[\s\S]*?\/>/i,
      `<meta name="twitter:description" content="${safeDesc}" />`
    )
    .replace('</head>', `  ${extraHeadTags.join('\n    ')}\n  </head>`);
}

async function createApp() {
  const app = express();
  app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      crossOriginOpenerPolicy: false,
    })
  );
  app.use(express.json({ limit: '2mb' }));

  // Guard /api JSON error responses against upstream reverse-proxy error interception
  // (nginx error_page 502 503 504 = /warmup.html rewrites 502/503/504 API JSON into 200 text/html).
  app.use('/api', (_req, res, next) => {
    const originalJson = res.json.bind(res);
    res.json = ((body: unknown) => {
      if (res.statusCode === 502 || res.statusCode === 503 || res.statusCode === 504) {
        res.setHeader('X-Upstream-Status', String(res.statusCode));
        res.status(500);
      }
      return originalJson(body);
    }) as typeof res.json;
    next();
  });

  // Mount REST API v1
  app.use('/api/v1', apiRouter);

  // Unknown /api/* routes must ALWAYS return JSON 404 (never fall through to Vite / SPA HTML)
  app.use('/api', (_req, res) => {
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    return res.status(404).json({
      ok: false,
      success: false,
      code: 'API_NOT_FOUND',
      message: 'The requested API endpoint does not exist.',
      error: {
        code: 'API_NOT_FOUND',
        message: 'The requested API endpoint does not exist.',
      },
    });
  });

  // Catch JSON body-parser or unexpected /api/* middleware errors as structured JSON
  app.use(
    '/api',
    (
      err: unknown,
      _req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      if (res.headersSent) return;
      res.setHeader('Content-Type', 'application/json; charset=utf-8');
      res.setHeader('Cache-Control', 'no-store');
      const errObj = err as {
        type?: string;
        status?: number;
        statusCode?: number;
        message?: string;
      };
      if (errObj?.type === 'entity.parse.failed' || err instanceof SyntaxError) {
        return res.status(400).json({
          ok: false,
          success: false,
          code: 'INVALID_JSON_BODY',
          message: 'Request body contains invalid JSON.',
          error: {
            code: 'INVALID_JSON_BODY',
            message: 'Request body contains invalid JSON.',
          },
        });
      }
      if (errObj?.type === 'entity.too.large' || errObj?.status === 413) {
        return res.status(413).json({
          ok: false,
          success: false,
          code: 'PAYLOAD_TOO_LARGE',
          message: 'Request payload exceeds the maximum allowed size.',
          error: {
            code: 'PAYLOAD_TOO_LARGE',
            message: 'Request payload exceeds the maximum allowed size.',
          },
        });
      }
      const status = typeof errObj?.statusCode === 'number' ? errObj.statusCode : 500;
      const message = errObj?.message || 'An unexpected server error occurred.';
      return res.status(status).json({
        ok: false,
        success: false,
        code: 'INTERNAL_SERVER_ERROR',
        message,
        error: {
          code: 'INTERNAL_SERVER_ERROR',
          message,
        },
      });
    }
  );

  // Dynamic robots.txt
  app.get('/robots.txt', (req, res) => {
    const baseUrl = getBaseUrl(req);
    res.type('text/plain');
    res.send(
      [
        'User-agent: *',
        'Allow: /',
        'Disallow: /admin',
        'Disallow: /api/',
        `Sitemap: ${baseUrl}/sitemap.xml`,
      ].join('\n')
    );
  });

  // Dynamic XML Sitemap
  app.get('/sitemap.xml', async (req, res) => {
    const baseUrl = getBaseUrl(req);
    const staticPaths = [
      '/',
      '/youtube-management',
      '/tools',
      '/blog',
      '/pricing',
      '/api-docs',
      '/about',
      '/contact',
      '/privacy-policy',
      '/terms-of-service',
      '/disclaimer',
      '/copyright-policy',
      '/dmca',
      '/cookie-policy',
      '/sitemap',
    ];

    const urls = [
      ...staticPaths,
      ...TOOLS_CATALOG.map((t) => t.routePath),
    ];

    try {
      const posts = await db
        .select({ slug: blogPosts.slug })
        .from(blogPosts)
        .where(eq(blogPosts.isPublished, true));
      for (const p of posts) {
        urls.push(`/blog/${p.slug}`);
      }
    } catch {
      // Serve static + tool URLs even if DB hasn't warmed yet
    }

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls
  .map(
    (u) => `  <url>
    <loc>${escapeHtmlAttr(`${baseUrl}${u}`)}</loc>
    <changefreq>weekly</changefreq>
  </url>`
  )
  .join('\n')}
</urlset>`;

    res.type('application/xml');
    res.send(xml);
  });

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom',
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      if (req.originalUrl.startsWith('/api/') || req.path.startsWith('/api/') || req.path === '/api') {
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.setHeader('Cache-Control', 'no-store');
        return res.status(404).json({
          ok: false,
          success: false,
          code: 'API_NOT_FOUND',
          message: 'The requested API endpoint does not exist.',
          error: {
            code: 'API_NOT_FOUND',
            message: 'The requested API endpoint does not exist.',
          },
        });
      }
      try {
        const url = req.originalUrl;
        const rawHtml = await fs.readFile(path.join(ROOT_DIR, 'index.html'), 'utf-8');
        const transformed = await vite.transformIndexHtml(url, rawHtml);
        const [seoMeta, tokens] = await Promise.all([
          resolveRouteSeoMeta(req.path),
          resolveOptionalHeadTokens(),
        ]);
        const html = injectSeoTags(transformed, {
          ...seoMeta,
          canonicalUrl: `${getBaseUrl(req)}${seoMeta.canonicalPath}`,
          ...tokens,
        });
        res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
      } catch (e) {
        vite.ssrFixStacktrace(e as Error);
        next(e);
      }
    });
  } else {
    const distDir = path.join(ROOT_DIR, 'dist');
    app.use(express.static(distDir, { index: false }));
    app.use('*', async (req, res) => {
      if (req.originalUrl.startsWith('/api/') || req.path.startsWith('/api/') || req.path === '/api') {
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        res.setHeader('Cache-Control', 'no-store');
        return res.status(404).json({
          ok: false,
          success: false,
          code: 'API_NOT_FOUND',
          message: 'The requested API endpoint does not exist.',
          error: {
            code: 'API_NOT_FOUND',
            message: 'The requested API endpoint does not exist.',
          },
        });
      }
      const rawHtml = await fs.readFile(path.join(distDir, 'index.html'), 'utf-8');
      const [seoMeta, tokens] = await Promise.all([
        resolveRouteSeoMeta(req.path),
        resolveOptionalHeadTokens(),
      ]);
      const html = injectSeoTags(rawHtml, {
        ...seoMeta,
        canonicalUrl: `${getBaseUrl(req)}${seoMeta.canonicalPath}`,
        ...tokens,
      });
      res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
    });
  }

  return app;
}

createApp()
  .then((app) => {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`MediaToolsHub server listening on http://0.0.0.0:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('Failed to start MediaToolsHub server:', err);
    process.exit(1);
  });
